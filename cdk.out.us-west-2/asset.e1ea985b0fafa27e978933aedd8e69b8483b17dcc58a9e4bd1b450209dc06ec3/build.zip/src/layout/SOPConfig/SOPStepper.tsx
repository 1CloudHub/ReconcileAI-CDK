import { Button, Modal, Select, Steps, message } from 'antd';
import { AlertCircle, CheckCircle2, XCircle } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { listJobs, type JobListItem } from '../../services/jobConfig';
import TokenUsage from '../../components/TokenUsage';
import FileUploadZone from '../../components/ui/FileUploadZone';

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
const ALLOWED_SOP_TYPES = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];

function toStartCase(value: string): string {
  return value
    .replace(/_/g, ' ')
    .split(' ')
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}

function formatExtractedValue(value: unknown): string {
  if (value == null) return '—';
  const raw = String(value).trim();
  if (!raw) return '—';
  const lowered = raw.toLowerCase();
  if (lowered === 'none' || lowered === 'n/a' || lowered === 'null' || lowered === 'undefined') return '—';

  if (raw.startsWith('[') || raw.startsWith('{')) {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.map((v) => String(v)).filter(Boolean).join(', ') || '—';
      }
      if (parsed && typeof parsed === 'object') {
        return JSON.stringify(parsed);
      }
    } catch {
      // ignore JSON parse errors
    }
  }

  return raw;
}

// ---------------------------------------------------------------------------
// Delivery Receipt cross-document table utilities (mirrored from ReconcileSessionDetail)
// ---------------------------------------------------------------------------

function slotForDocKey(rawKey: string): 'purchaseOrder' | 'goodsReceipt' | 'supplierInvoice' | 'deliveryReceipt' | null {
  const n = rawKey.trim().toLowerCase().replace(/\s+/g, '_');
  if (!n) return null;
  if (
    n.includes('goods_receipt') || n.includes('good_receipt') || n.includes('goodsreceipt') ||
    n.includes('goodreceipt') || n.includes('gr_amount') || n === 'gr' || n.endsWith('_gr') ||
    n === 'grn' || n.includes('grn_')
  ) return 'goodsReceipt';
  if (
    n.includes('purchase_order') || n.includes('purchaseorder') || n === 'po' ||
    n === 'total_amount' || n.includes('po_')
  ) return 'purchaseOrder';
  if (
    n.includes('invoice') || n.includes('supplier_invoice') || n === 'amount' ||
    n.includes('inv_') || n === 'si'
  ) return 'supplierInvoice';
  if (
    n.includes('delivery_receipt') || n.includes('delievery_receipt') || n === 'dr' ||
    n.includes('delivery') || n.includes('delievery')
  ) return 'deliveryReceipt';
  return null;
}

function _drNorm(s: string): string { return s.toLowerCase().replace(/[^a-z0-9]/g, ''); }

function _drGetAliases(key: string): string[] {
  const n = _drNorm(key);
  const aliases = new Set<string>([n]);
  if (n.includes('qty') || n.includes('quantity') || n.includes('count')) { aliases.add('qty'); aliases.add('quantity'); aliases.add('grquantity'); aliases.add('delivered'); aliases.add('received'); }
  if (n.includes('amount') && !n.includes('line') && !n.includes('total') && !n.includes('vat') && !n.includes('tax')) { aliases.add('amount'); aliases.add('amtdue'); aliases.add('gramount'); }
  if (n.includes('lineamount') || n.includes('subtotal')) { aliases.add('lineamount'); aliases.add('subtotal'); aliases.add('netamount'); }
  if (n.includes('total') || n.includes('sales') || n === 'grandtotal') { aliases.add('totalamount'); aliases.add('total'); aliases.add('totalsales'); }
  if (n.includes('price') || n.includes('rate')) { aliases.add('price'); aliases.add('unitprice'); aliases.add('rate'); }
  if (n.includes('vat') || n.includes('tax')) { aliases.add('vat'); aliases.add('vatamount'); aliases.add('tax'); }
  if (n.includes('po') || n.includes('purchaseorder')) { aliases.add('po'); aliases.add('pono'); aliases.add('ponumber'); }
  if (n.includes('code') || n.includes('mat') || n.includes('sku') || n.includes('stock')) { aliases.add('code'); aliases.add('matcode'); aliases.add('stockno'); aliases.add('sku'); }
  if (n.includes('unit') && n !== 'unitprice') { aliases.add('unit'); aliases.add('uom'); }
  if (n.includes('desc') || n.includes('spec')) { aliases.add('description'); aliases.add('specification'); }
  if (n.includes('dr') || n.includes('delivery')) { aliases.add('dr'); aliases.add('drno'); aliases.add('deliveryreceipt'); }
  if (n.includes('si') || n.includes('invoice')) { aliases.add('si'); aliases.add('invoiceno'); aliases.add('invoice'); }
  if (n.includes('date')) { aliases.add('date'); aliases.add('receiptdate'); }
  if (n.includes('term')) { aliases.add('terms'); aliases.add('paymentterms'); }
  if (n.includes('salesman') || n.includes('salesperson')) { aliases.add('salesman'); }
  if (n.includes('issue') || n.includes('prepared')) { aliases.add('issuedby'); aliases.add('preparedby'); }
  if (n.includes('check') || n.includes('verify')) { aliases.add('checkedby'); aliases.add('verifiedby'); }
  return Array.from(aliases);
}

function _drFindMatch(targetField: { name: string; value: string }, searchFields: Array<{ name: string; value: string }>): string {
  const targetAliases = _drGetAliases(targetField.name);
  let bestMatch = null;
  let bestScore = 0;
  for (const f of searchFields) {
    let score = 0;
    const searchAliases = _drGetAliases(f.name);
    if (_drNorm(f.name) === _drNorm(targetField.name)) score += 20;
    else if (targetAliases.some((ta) => searchAliases.includes(ta))) score += 10;
    else if (_drNorm(f.name).includes(_drNorm(targetField.name)) || _drNorm(targetField.name).includes(_drNorm(f.name))) score += 5;
    if (score > 0 && targetField.name.toLowerCase().includes('total') && !f.name.toLowerCase().includes('total')) score -= 5;
    if (score > bestScore) { bestScore = score; bestMatch = f; }
  }
  return bestMatch ? bestMatch.value : 'N/A';
}

function formatValueWithSum(val: string): string {
  if (!val || val === 'N/A' || val === '—') return val;
  const matches = val.match(/-?\d+[\d,.]*/g);
  if (!matches || matches.length === 0) return val;
  let total = 0;
  let numericCount = 0;
  for (const m of matches) {
    const n = parseFloat(m.replace(/,/g, ''));
    if (!isNaN(n) && isFinite(n)) { total += n; numericCount++; }
  }
  if (numericCount > 1) return new Intl.NumberFormat('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(total);
  return val;
}

/** Keys on each `reason_for_failure` item that are not the SOP rule name / description. */
const REASON_ENTRY_META_KEYS = new Set(['status', 'matching']);

function normalizeSopRuleLabel(s: string): string {
  return s.toLowerCase().replace(/_/g, ' ').replace(/\s+/g, ' ').trim();
}

function getSopRuleKeyFromReasonEntry(entry: Record<string, unknown>): string | undefined {
  return Object.keys(entry).find((k) => !REASON_ENTRY_META_KEYS.has(k));
}

/** True if this failure entry corresponds to the SOP being tested (matches API rule key, e.g. `quantity variance v4`). */
function reasonEntryMatchesSopName(entry: Record<string, unknown>, filterName: string): boolean {
  const ruleKey = getSopRuleKeyFromReasonEntry(entry);
  if (!ruleKey || !filterName.trim()) return false;
  const a = normalizeSopRuleLabel(ruleKey);
  const b = normalizeSopRuleLabel(filterName);
  if (a === b) return true;
  const stripTrailingVersion = (x: string) => x.replace(/\s+v\d+$/i, '').trim();
  if (stripTrailingVersion(a) === stripTrailingVersion(b)) return true;
  if (a.includes(b) || b.includes(a)) return true;
  return false;
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type SopTestInsight = {
  sopName: string;
  status: 'matched' | 'not_matched' | 'failed' | string;
  explanation: string;
};

export type PollStatusResult = {
  session_id?: string;
  reconcile_status?: string;
  message?: string;
  reason_for_failure?: Array<Record<string, unknown>> | Record<string, unknown>;
  extracted_fields?: Array<Record<string, Record<string, string>>>;
};

export type SOPStepperProps = {
  open: boolean;
  onClose: () => void | Promise<void>;
  /** Called when the user clicks Done after seeing test results (no save — just close). */
  onDone?: () => void;
  /** Called when the user clicks Skip — should keep the uploaded SOP temporarily so Create SOP can persist it later. */
  onSkip?: () => void;
  /** Document names from the selected job — drives step 2 upload zones. */
  documentNames: string[];
  /** Called when the user clicks Next on step 1 with the chosen file. */
  onUploadSop: (file: File) => Promise<void>;
  /** Called when the user removes the uploaded file in step 1 after it was already uploaded to the backend. */
  onRemoveSopFile?: () => Promise<void>;
  /** Called when the user clicks Run Test on step 2.
   *  Receives files keyed by doc index and the resolved document names.
   *  Returns the full poll status result to display in step 3. */
  onTestSop: (filesByDocIndex: Record<number, File>, documentNames: string[]) => Promise<PollStatusResult>;
  /** When set to 1, the stepper opens directly at step 2 (skipping the SOP upload step). */
  initialStep?: number;
  /** SOP name from the parent form to display in results. */
  sopDisplayName?: string;
  /** Label for step 2 in the stepper. Defaults to 'Test SOP'. */
  step2Label?: string;
  /** Modal header text. Defaults to 'Add & Test SOP'. */
  modalTitle?: string;
  /**
   * When set (e.g. test existing SOP), pick the `reason_for_failure` item whose rule key matches this name
   * so only that SOP’s description + matching fields are shown.
   */
  reasonFailureFilterName?: string;
  /** When true, disables the Run Test button due to token limit. */
  limitReached?: boolean;
};


// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

export default function SOPStepper({
  open,
  onClose,
  onDone,
  onSkip,
  documentNames,
  onUploadSop,
  onRemoveSopFile,
  onTestSop,
  initialStep = 0,
  sopDisplayName,
  step2Label = 'Test SOP',
  modalTitle = 'Add & Test SOP',
  reasonFailureFilterName,
  limitReached: limitReachedProp = false,
}: SOPStepperProps) {
  const [limitReached, setLimitReached] = useState(limitReachedProp);
  const [current, setCurrent] = useState(initialStep);

  // -- Step 1
  const [sopFile, setSopFile] = useState<File | null>(null);
  const [uploadLoading, setUploadLoading] = useState(false);
  const [sopUploaded, setSopUploaded] = useState(initialStep >= 1);

  // -- Step 2
  const [filesByIndex, setFilesByIndex] = useState<Record<number, File | null>>({});
  const [testLoading, setTestLoading] = useState(false);

  // -- Step 3 (results)
  const [testResults, setTestResults] = useState<PollStatusResult | null>(null);
  const [activeResultDocKey, setActiveResultDocKey] = useState<string>('');

  // -- Loader word cycling
  const LOADER_WORDS = [
    'scanning documents',
    'extracting fields',
    'interpreting SOP guidelines',
    'reconciliating documents',
    'verifying compliance',
    'generating structured results',
  ];
  const [loaderWordIdx, setLoaderWordIdx] = useState(0);
  const [loaderWordVisible, setLoaderWordVisible] = useState(true);
  useEffect(() => {
    if (!testLoading) { setLoaderWordIdx(0); setLoaderWordVisible(true); return; }
    const timers: ReturnType<typeof setTimeout>[] = [];
    LOADER_WORDS.forEach((_, i) => {
      if (i === 0) return; // start at 0 already
      const t = setTimeout(() => {
        setLoaderWordVisible(false);
        const t2 = setTimeout(() => {
          setLoaderWordIdx(i);
          setLoaderWordVisible(true);
        }, 400);
        timers.push(t2);
      }, i * 30_000);
      timers.push(t);
    });
    return () => timers.forEach(clearTimeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [testLoading]);

  // -- Job selector (for when documentNames not pre-filled from SOP details)
  const [jobs, setJobs] = useState<JobListItem[]>([]);
  const [jobsLoading, setJobsLoading] = useState(false);
  const [selectedJobId, setSelectedJobId] = useState<number | undefined>(undefined);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setJobsLoading(true);
    void listJobs()
      .then((list) => { if (!cancelled) setJobs(list); })
      .catch(() => { if (!cancelled) setJobs([]); })
      .finally(() => { if (!cancelled) setJobsLoading(false); });
    return () => { cancelled = true; };
  }, [open]);

  const activeDocumentNames = useMemo(() => {
    if (documentNames.length > 0) return documentNames;
    if (selectedJobId == null) return [];
    const job = jobs.find((j) => j.id === selectedJobId);
    if (!job) return [];
    const names = Array.isArray(job.document_names) ? [...(job.document_names as string[])] : [];
    if (job.reference_document_name) {
      names.push(String(job.reference_document_name));
    }
    return names;
  }, [documentNames, selectedJobId, jobs]);

  const docLabels = useMemo(
    () => activeDocumentNames.map((n) => `Upload ${toStartCase(n)}`),
    [activeDocumentNames]
  );

  const allDocsUploaded = useMemo(
    () => activeDocumentNames.length > 0 && activeDocumentNames.every((_, i) => Boolean(filesByIndex[i])),
    [activeDocumentNames, filesByIndex]
  );

  const uploadGridClass =
    activeDocumentNames.length <= 2
      ? 'grid-cols-1 md:grid-cols-2'
      : activeDocumentNames.length === 3
        ? 'grid-cols-1 md:grid-cols-2 xl:grid-cols-3'
        : 'grid-cols-1 md:grid-cols-2 xl:grid-cols-4';

  useEffect(() => {
    if (open) {
      setCurrent(initialStep);
      setSopUploaded(initialStep >= 1);
      setSopFile(null);
      setFilesByIndex({});
      setTestLoading(false);
      setTestResults(null);
      setActiveResultDocKey('');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const resetState = () => {
    setCurrent(0);
    setSopFile(null);
    setUploadLoading(false);
    setSopUploaded(false);
    setFilesByIndex({});
    setTestLoading(false);
    setSelectedJobId(undefined);
    setTestResults(null);
    setActiveResultDocKey('');
  };

  const closeModal = () => {
    void onClose();
  };

  const handleNext = async () => {
    if (!sopFile) return;
    setUploadLoading(true);
    try {
      await onUploadSop(sopFile);
      setSopUploaded(true);
      setCurrent(1);
    } catch (err) {
      void message.error(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setUploadLoading(false);
    }
  };

  const handleDone = async () => {
    if (!allDocsUploaded) return;
    const files: Record<number, File> = {};
    docLabels.forEach((_, i) => {
      if (filesByIndex[i]) files[i] = filesByIndex[i]!;
    });
    setTestLoading(true);
    try {
      const result = await onTestSop(files, activeDocumentNames);
      setTestResults(result);
      // Pre-select first extracted doc tab (skip 'sop')
      const firstNonSopObj = result.extracted_fields?.find((docObj) => {
        const key = Object.keys(docObj)[0] ?? '';
        return key.toLowerCase() !== 'sop';
      });
      if (firstNonSopObj) {
        setActiveResultDocKey(Object.keys(firstNonSopObj)[0] ?? '');
      }
    } catch (err) {
      void message.error(err instanceof Error ? err.message : 'Test failed');
    } finally {
      setTestLoading(false);
    }
  };

  // ---------------------------------------------------------------------------
  // Step content
  // ---------------------------------------------------------------------------

  const step1 = (
    <FileUploadZone
      id="sop-stepper-file"
      label="Upload SOP Document"
      file={sopFile}
      accept={ALLOWED_SOP_TYPES.join(',')}
      isLocked={uploadLoading}
      onFileSelected={(file) => {
        setSopFile(file);
      }}
      onRemove={() => {
        setSopFile(null);
        if (sopUploaded) {
          setSopUploaded(false);
          void onRemoveSopFile?.();
        }
      }}
    />
  );

  // -- Results derived data (declared before step2 JSX so they can be used inline)
  const resultDocTabs = useMemo((): Array<{ key: string; label: string; fields: Record<string, string> }> => {
    if (!testResults?.extracted_fields) return [];
    const tabs = testResults.extracted_fields.flatMap((docObj) =>
      Object.entries(docObj)
        .filter(([key]) => key.toLowerCase() !== 'sop')
        .map(([key, fields]) => {
          const safeFields: Record<string, string> =
            fields !== null && typeof fields === 'object' && !Array.isArray(fields)
              ? Object.fromEntries(
                  Object.entries(fields as Record<string, unknown>).map(([k, v]) => [
                    k,
                    v === null || v === undefined ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v),
                  ])
                )
              : {};
          return { key, label: toStartCase(key), fields: safeFields };
        })
    );
    // Delivery Receipt is always last (4th tab)
    const drIndex = tabs.findIndex((t) => slotForDocKey(t.key) === 'deliveryReceipt');
    if (drIndex > -1) {
      const [drTab] = tabs.splice(drIndex, 1);
      tabs.push(drTab);
    }
    return tabs;
  }, [testResults]);

  const activeResultDoc = useMemo(
    () => resultDocTabs.find((t) => t.key === activeResultDocKey) ?? resultDocTabs[0],
    [resultDocTabs, activeResultDocKey]
  );

  const selectedReasonEntry = useMemo((): Record<string, unknown> | null => {
    const raw = testResults?.reason_for_failure;
    const entries = Array.isArray(raw) ? raw : null;
    if (!entries?.length) return null;
    const filter = String(reasonFailureFilterName ?? '').trim();
    if (!filter) {
      return entries[0] as Record<string, unknown>;
    }
    const found = entries.find((e) => reasonEntryMatchesSopName(e as Record<string, unknown>, filter));
    return (found as Record<string, unknown>) ?? null;
  }, [testResults, reasonFailureFilterName]);

  const resultSopInfo = useMemo((): { sopName: string; description: string; status: string } | null => {
    const entry = selectedReasonEntry;
    if (!entry) return null;
    const sopStatus = String(entry.status ?? '').toLowerCase();
    const otherKey = getSopRuleKeyFromReasonEntry(entry);
    if (!otherKey) return null;
    const parentSopName = String(sopDisplayName ?? '').trim();
    const useFilter = Boolean(String(reasonFailureFilterName ?? '').trim());
    return {
      sopName: useFilter ? otherKey : parentSopName || otherKey,
      description: typeof entry[otherKey] === 'string' ? (entry[otherKey] as string) : JSON.stringify(entry[otherKey]),
      status: sopStatus === 'yes' ? 'matched' : sopStatus === 'no' ? 'not_matched' : 'unknown',
    };
  }, [selectedReasonEntry, sopDisplayName, reasonFailureFilterName]);

  const resultConsistencyRows = useMemo((): Array<{ field: string; columns: Array<{ key: string; label: string; value: string }>; status: 'matched' | 'not_matched' }> => {
    const entry = selectedReasonEntry;
    if (!entry) return [];
    const matchingData = entry.matching as Record<string, Record<string, string>> | undefined;
    if (!matchingData || typeof matchingData !== 'object') return [];
    // Collect all column keys, excluding 'matched' (shown as Status icon instead)
    const allColKeys = Array.from(
      new Set(Object.values(matchingData).flatMap((v) => (v && typeof v === 'object' ? Object.keys(v) : [])))
    );
    const colKeys = allColKeys.filter((k) => k.toLowerCase() !== 'matched');
    return Object.entries(matchingData).map(([field, docMap]) => {
      const cols = colKeys.map((k) => ({ key: k, label: toStartCase(k), value: String(docMap?.[k] ?? 'N/A') }));
      // Prefer the explicit matched field from the API (yes / no)
      const matchedRaw = String((docMap as Record<string, string>)?.matched ?? (docMap as Record<string, string>)?.Matched ?? '').trim().toLowerCase();
      let status: 'matched' | 'not_matched';
      if (matchedRaw === 'yes') {
        status = 'matched';
      } else if (matchedRaw === 'no') {
        status = 'not_matched';
      } else {
        // Fall back to comparing visible column values
        const vals = cols.map((c) => c.value.toLowerCase().trim()).filter((v) => v && v !== 'n/a');
        status = vals.length >= 2 && vals.every((v) => v === vals[0]) ? 'matched' : 'not_matched';
      }
      return { field: toStartCase(field), columns: cols, status };
    });
  }, [selectedReasonEntry]);

  const resultColHeaders = useMemo((): Array<{ key: string; label: string }> => {
    if (!resultConsistencyRows.length) return [];
    return resultConsistencyRows[0].columns.map((c) => ({ key: c.key, label: c.label }));
  }, [resultConsistencyRows]);

  const sopDynamicDRRows = useMemo((): Array<{
    field: string;
    purchaseOrder: string;
    goodsReceipt: string;
    supplierInvoice: string;
    deliveryReceipt: string;
  }> => {
    if (!resultDocTabs.length) return [];
    const toFieldArray = (fields: Record<string, string>) =>
      Object.entries(fields).map(([name, value]) => ({ name, value }));
    const drTab = resultDocTabs.find((t) => slotForDocKey(t.key) === 'deliveryReceipt');
    const poTab = resultDocTabs.find((t) => slotForDocKey(t.key) === 'purchaseOrder');
    const grTab =
      resultDocTabs.find((t) => slotForDocKey(t.key) === 'goodsReceipt') ||
      resultDocTabs.find((t) => { const l = t.key.toLowerCase(); return l.includes('receipt') || l.includes('grn') || l.includes('gr'); });
    const siTab = resultDocTabs.find((t) => slotForDocKey(t.key) === 'supplierInvoice');
    if (!drTab) return [];
    const drFields = toFieldArray(drTab.fields);
    const poFields = poTab ? toFieldArray(poTab.fields) : [];
    const grFields = grTab ? toFieldArray(grTab.fields) : [];
    const siFields = siTab ? toFieldArray(siTab.fields) : [];
    return drFields.map((drField) => ({
      field: toStartCase(drField.name),
      purchaseOrder: poFields.length ? _drFindMatch(drField, poFields) : 'N/A',
      goodsReceipt: grFields.length ? _drFindMatch(drField, grFields) : 'N/A',
      supplierInvoice: siFields.length ? _drFindMatch(drField, siFields) : 'N/A',
      deliveryReceipt: drField.value || 'N/A',
    }));
  }, [resultDocTabs]);

  const hasSopDRTable = sopDynamicDRRows.length > 0;

  const validationErrors = useMemo((): Array<{ message: string; expected_key?: string; document_name?: string }> => {
    const status = String(testResults?.reconcile_status ?? '').trim().toLowerCase();

    // Check for validation failed status
    const isValidationError =
      status === 'validation failed' ||
      status === 'validation_status' ||
      status === 'validation_failed' ||
      status === 'failed';

    if (!isValidationError) return [];

    let reasonForFailure = testResults?.reason_for_failure;

    // Try to parse if it's a string
    if (typeof reasonForFailure === 'string') {
      try {
        reasonForFailure = JSON.parse(reasonForFailure);
      } catch (e) {
        // Not JSON, continue
      }
    }

    let errors: any = null;

    if (Array.isArray(reasonForFailure)) {
      // Check first element for validation_errors
      errors = (reasonForFailure[0] as any)?.validation_errors;
      if (!errors) {
        // Maybe the array itself is the list of errors?
        errors = reasonForFailure;
      }
    } else if (reasonForFailure && typeof reasonForFailure === 'object') {
      errors = (reasonForFailure as any).validation_errors;
    }

    // If we have errors array, format them
    if (Array.isArray(errors) && errors.length > 0) {
      return errors.map(err => ({
        message: String(err.message || ''),
        expected_key: err.expected_key ? String(err.expected_key) : undefined,
        document_name: err.document_name ? String(err.document_name) : undefined,
      }));
    }

    // Fallback: use the top-level message field or reason_for_failure message
    const fallbackMsg =
      testResults?.message ||
      (reasonForFailure && typeof reasonForFailure === 'object' && (reasonForFailure as any).message) ||
      'Validation failed. Please check your documents and try again.';

    return [{ message: String(fallbackMsg) }];
  }, [testResults]);

  const step2 = (
    <div className="relative flex flex-col gap-5">
      {testLoading && (
        <>
          <style>{`
            @keyframes _sopBounce {
              0%, 80%, 100% { transform: translateY(0); opacity: 0.4; }
              40% { transform: translateY(-8px); opacity: 1; }
            }
          `}</style>
          <div className="absolute inset-0 z-10 rounded-lg bg-slate-50 flex flex-col items-center justify-center gap-5">
            <div className="flex gap-2">
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  className="w-2.5 h-2.5 rounded-full inline-block bg-[#1351cd]"
                  style={{ animation: `_sopBounce 1.2s ease-in-out ${i * 0.2}s infinite` }}
                />
              ))}
            </div>
            <div className="text-center">
              <p className="mb-1.5 text-lg font-medium flex items-center justify-center gap-1.5 min-w-[260px] text-[#1351cd]">
                <span>Agent is</span>
                <span
                  className={`inline-block transition-[opacity,transform] duration-[400ms] ease-in-out ${loaderWordVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-1.5'}`}
                >
                  {LOADER_WORDS[loaderWordIdx]}…
                </span>
              </p>
              <p className="m-0 text-xs text-slate-400">
                This may take a few moments. Please wait.
              </p>
            </div>
          </div>
        </>
      )}
      {!testResults && (
        <>
          {documentNames.length === 0 && (
            <div className="flex flex-col gap-1.5">
              <label className="font-semibold text-sm text-slate-950">
                Select Job <span className="text-red-500">*</span>
              </label>
              <Select
                className="w-full"
                placeholder="Select a job"
                loading={jobsLoading}
                value={selectedJobId}
                onChange={(val: number) => {
                  setSelectedJobId(val);
                  setFilesByIndex({});
                }}
                options={jobs.map((j) => ({ value: j.id, label: j.job_name }))}
                showSearch
              />
            </div>
          )}
          {activeDocumentNames.length > 0 ? (
            <div className={['grid w-full gap-5', uploadGridClass].join(' ')}>
              {activeDocumentNames.map((name, index) => (
                <FileUploadZone
                  key={`${name}-${index}`}
                  id={`sop-test-file-${index}`}
                  label={docLabels[index]}
                  file={filesByIndex[index] ?? null}
                  isLocked={testLoading}
                  onFileSelected={(file) => {
                    setFilesByIndex((prev) => ({ ...prev, [index]: file }));
                  }}
                  onRemove={() => {
                    setFilesByIndex((prev) => ({ ...prev, [index]: null }));
                  }}
                />
              ))}
            </div>
          ) : (
            <p className="m-0 text-[13px] text-slate-500">
              No documents configured for this job.
            </p>
          )}

          <TokenUsage onLimitUpdate={setLimitReached} />

          {activeDocumentNames.length > 0 && !allDocsUploaded && !testLoading && (
            <p className="m-0 text-[13px] text-slate-500 text-center">
              Please upload all required documents to proceed.
            </p>
          )}
        </>
      )}

      {testResults && validationErrors.length > 0 && (
        <div className="flex flex-col gap-3 mt-1">
          <div className="p-4 md:p-5 rounded-xl bg-rose-50 border border-rose-200 flex gap-4 items-start">
            <AlertCircle size={24} className="text-rose-600 mt-0.5 shrink-0" />
            <div className="flex-1">
              <p className="m-0 mb-3 text-[15px] font-bold text-rose-800">Validation Failed</p>
              <div className="flex flex-col gap-2.5">
                {validationErrors.map((e, i) => (
                  <div key={i} className="py-1">
                    {e.document_name && (
                      <div className="text-[13px] text-rose-600 mb-0.5">
                        {toStartCase(e.document_name)}
                      </div>
                    )}
                    <p className="m-0 text-[13px] text-rose-600 leading-relaxed">{e.message}</p>
                    {e.expected_key && (
                      <div className="mt-1 flex items-center gap-1.5 text-[13px] text-rose-600">
                        <span>Expected Key:</span>
                        <span>{e.expected_key}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {testResults && validationErrors.length === 0 && (
        <div className="flex flex-col md:flex-row gap-5 items-start mt-1">
          {/* Document Extracted Fields */}
          <div className="flex-1 min-w-0 rounded-xl border border-slate-200 bg-white overflow-hidden w-full">
            {/* Tabs — always shown when there are multiple docs */}
            {resultDocTabs.length > 1 && (
              <div className="px-4 py-3 border-b border-slate-200">
                <div className="flex flex-wrap gap-1.5">
                  {resultDocTabs.map((tab) => {
                    const isActive = activeResultDoc?.key === tab.key;
                    return (
                      <button
                        key={tab.key}
                        type="button"
                        onClick={() => setActiveResultDocKey(tab.key)}
                        className={`px-3 py-1 rounded-md text-[13px] transition-all duration-150 cursor-pointer ${isActive
                            ? 'border border-[#1351cd]/50 bg-[#1351cd]/10 text-[#1351cd] font-semibold'
                            : 'border border-transparent bg-transparent text-slate-500 font-normal hover:bg-slate-50'
                          }`}
                      >
                        {tab.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
            <div className="px-4 py-3 max-h-[480px] overflow-y-auto">
              {/* Active tab is Delivery Receipt → show 5-column cross-doc table */}
              {activeResultDoc && slotForDocKey(activeResultDoc.key) === 'deliveryReceipt' && hasSopDRTable ? (
                <div className="overflow-x-auto rounded-md border border-slate-200 bg-white">
                  <table className="w-full border-collapse text-[13px]">
                    <thead>
                      <tr className="border-b border-slate-200 bg-[#f8fafc] text-left">
                        <th className="px-3.5 py-2.5 text-xs font-semibold text-slate-700">Field</th>
                        <th className="px-3.5 py-2.5 text-xs font-semibold text-slate-700">Purchase Order</th>
                        <th className="px-3.5 py-2.5 text-xs font-semibold text-slate-700">Goods Receipt</th>
                        <th className="px-3.5 py-2.5 text-xs font-semibold text-slate-700">Supplier Invoice</th>
                        <th className="px-3.5 py-2.5 text-xs font-semibold text-slate-700">Delivery Receipt</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sopDynamicDRRows.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="px-3.5 py-4 text-center text-slate-500 italic">
                            No matching reconciliation data found for these fields.
                          </td>
                        </tr>
                      ) : (
                        sopDynamicDRRows.map((row, idx) => (
                          <tr key={`${row.field}-${idx}`} className="border-b border-slate-100 last:border-b-0 hover:bg-slate-50/50 align-top">
                            <td className="px-3.5 py-2.5 font-semibold text-slate-900 border-r border-slate-100">{row.field}</td>
                            <td className="px-3.5 py-2.5 text-slate-700 tabular-nums break-words min-w-[120px] max-w-[250px]">{formatValueWithSum(row.purchaseOrder)}</td>
                            <td className="px-3.5 py-2.5 text-slate-700 tabular-nums break-words min-w-[120px] max-w-[250px]">{formatValueWithSum(row.goodsReceipt)}</td>
                            <td className="px-3.5 py-2.5 text-slate-700 tabular-nums break-words min-w-[120px] max-w-[250px]">{formatValueWithSum(row.supplierInvoice)}</td>
                            <td className="px-3.5 py-2.5 text-slate-700 tabular-nums break-words min-w-[120px] max-w-[250px] font-medium border-l border-slate-100">{formatValueWithSum(row.deliveryReceipt)}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              ) : !activeResultDoc ? (
                <p className="m-0 text-[13px] text-slate-500">No document data available.</p>
              ) : (
                /* Other tabs (PO, GR, SI) → card-style field list matching session details */
                <div className="space-y-2">
                  {Object.entries(activeResultDoc.fields).length === 0 ? (
                    <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-500">
                      No sample fields found for this document.
                    </div>
                  ) : (
                    Object.entries(activeResultDoc.fields).map(([fieldName, fieldValue], idx) => {
                      const value = formatExtractedValue(fieldValue);
                      const ok = value !== '' && value !== '—';
                      return (
                        <div
                          key={`${fieldName}-${idx}`}
                          className="grid grid-cols-[1fr_auto] items-start gap-3 rounded-lg border border-slate-200 bg-slate-50/70 px-3 py-2"
                        >
                          <div>
                            <div className="text-xs font-medium uppercase tracking-wide text-slate-500">
                              {fieldName}
                            </div>
                            <div className="mt-1 text-sm text-slate-800">{value || '—'}</div>
                          </div>
                          {ok ? (
                            <CheckCircle2 size={16} className="mt-1 text-emerald-500" aria-hidden />
                          ) : (
                            <XCircle size={16} className="mt-1 text-rose-500" aria-hidden />
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Field Consistency Check */}
          <div className="flex-1 min-w-0 rounded-xl border border-slate-200 bg-white overflow-hidden w-full">
            <div className="px-4 py-3 border-b border-slate-200">
              <span className="text-[14px] font-semibold text-slate-900">Field Consistency Check</span>
            </div>
            <div className="px-4 py-3">
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 md:p-4 mb-3">
                <div className="grid grid-cols-[140px_1fr] gap-x-4 gap-y-1.5 mb-1.5">
                  <span className="text-[13px] font-medium text-slate-500">SOP Name</span>
                  <span className="text-[13px] font-semibold text-slate-900">{resultSopInfo?.sopName ?? '—'}</span>
                </div>
                <div className="grid grid-cols-[140px_1fr] gap-x-4 gap-y-1.5 mb-1.5">
                  <span className="text-[13px] font-medium text-slate-500">Description</span>
                  <span className="text-[13px] text-slate-700 whitespace-pre-wrap">{resultSopInfo?.description ?? '—'}</span>
                </div>
                <div className="grid grid-cols-[140px_1fr] gap-x-4 gap-y-1.5 items-center">
                  <span className="text-[13px] font-medium text-slate-500">SOP Status</span>
                  <div>
                    {resultSopInfo?.status === 'matched' ? (
                      <span className="inline-flex rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-0.5 text-[12px] font-semibold text-emerald-800">Matched</span>
                    ) : resultSopInfo?.status === 'not_matched' ? (
                      <span className="inline-flex rounded-full border border-rose-200 bg-rose-50 px-2.5 py-0.5 text-[12px] font-semibold text-rose-800">Not Matched</span>
                    ) : (
                      <span className="inline-flex rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-[12px] font-semibold text-slate-600">—</span>
                    )}
                  </div>
                </div>
              </div>

              {resultConsistencyRows.length === 0 ? (
                <div className="rounded-md border border-slate-200 bg-white px-3 py-2.5 text-[13px] text-slate-500">
                  {reasonFailureFilterName?.trim()
                    ? 'No field consistency data for this SOP in the response. Check that the exception name matches the rule name returned by reconciliation.'
                    : 'No matching field consistency data available.'}
                </div>
              ) : (
                <div className="overflow-x-auto rounded-md border border-slate-200 bg-white">
                  <table className="w-full border-collapse text-[13px]">
                    <thead>
                      <tr className="border-b border-slate-200 text-left font-semibold text-slate-700">
                        <th className="px-3.5 py-2.5">Field</th>
                        {resultColHeaders.map((col) => (
                          <th key={col.key} className="px-3.5 py-2.5">{col.label}</th>
                        ))}
                        <th className="px-3.5 py-2.5">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {resultConsistencyRows.map((row, idx) => (
                        <tr key={`${row.field}-${idx}`} className={`align-top ${idx < resultConsistencyRows.length - 1 ? 'border-b border-slate-100' : ''}`}>
                          <td className="px-3.5 py-2 font-medium text-slate-900">{row.field}</td>
                          {row.columns.map((col) => (
                            <td key={col.key} className="px-3.5 py-2 text-slate-700">{col.value}</td>
                          ))}
                          <td className="px-3.5 py-2">
                            {row.status === 'matched' ? (
                              <CheckCircle2 size={15} className="text-emerald-500" aria-label="Matched" />
                            ) : (
                              <XCircle size={15} className="text-rose-500" aria-label="Not matched" />
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );

  // ---------------------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------------------

  return (
    <Modal
      title={<span className="text-[18px] font-semibold text-slate-900">{modalTitle}</span>}
      open={open}
      onCancel={closeModal}
      afterClose={resetState}
      footer={null}
      width={current === 1 && testResults ? 1100 : current === 1 && docLabels.length > 2 ? 900 : 680}
      destroyOnHidden
      classNames={{ body: 'pt-0' }}
    >
      {initialStep === 0 && (
        <div className="mb-6">
          <Steps
            current={current}
            size="small"
            items={[{ title: 'Upload SOP' }, { title: step2Label }]}
          />
        </div>
      )}

      <div>
        {current === 0 && step1}
        {current === 1 && step2}
      </div>

      <div className="mt-6 flex justify-end gap-2">
        {current === 1 && (
          <>
            {initialStep === 0 ? (
              <Button disabled={testLoading} onClick={() => setCurrent(0)}>
                Previous
              </Button>
            ) : null}

            {!testResults ? (
              <>
                {onSkip ? (
                  <Button
                    disabled={testLoading}
                    onClick={() => {
                      onSkip?.();
                      closeModal();
                    }}
                  >
                    Submit
                  </Button>
                ) : null}
                <Button
                  type="primary"
                  loading={testLoading}
                  disabled={!allDocsUploaded || testLoading || limitReached}
                  onClick={() => void handleDone()}
                >
                  Run Test
                </Button>
              </>
            ) : (
              <Button type="primary" onClick={() => { onDone?.(); closeModal(); }}>
                Done
              </Button>
            )}
          </>
        )}

        {current === 0 && (
          <Button
            type="primary"
            loading={uploadLoading}
            disabled={!sopFile}
            onClick={() => void handleNext()}
          >
            Next
          </Button>
        )}
      </div>
    </Modal>
  );
}
