
from __future__ import annotations

import json
import logging
import re
import time
from typing import Any

import boto3
from strands import Agent, tool
from strands.models.bedrock import BedrockModel

# ---------------------------------------------------------------------------
# AWS clients
# ---------------------------------------------------------------------------
textract_client = boto3.client("textract", region_name="us-west-2")
s3_client = boto3.client("s3", region_name="us-west-2")
bedrock_runtime = boto3.client("bedrock-runtime", region_name="us-west-2")

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# DB helper – replace with your actual connection / query layer
# ---------------------------------------------------------------------------

def _get_db_connection():
    """
    Return a psycopg2 connection to your Postgres database.
    Reads credentials from environment variables.
    """
    import os
    import psycopg2

    return psycopg2.connect(
        host=os.environ.get("db_host", "sap-erp.czka2e64ehbk.us-west-2.rds.amazonaws.com"),
        port=5432,
        dbname=os.environ.get("db_database", "postgres"),
        user=os.environ.get("db_user", "postgres"),
        password=os.environ.get("db_password", "postgres123"),
        options="-c search_path=erp_no_sap",
    )


def _query(sql: str, params: tuple = ()) -> list[dict]:
    """Execute a read query and return rows as list of dicts."""
    conn = _get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            cols = [desc[0] for desc in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]
    finally:
        conn.close()


def _execute(sql: str, params: tuple = ()) -> int | None:
    """Execute a write query (INSERT/UPDATE/DELETE) and return the id if RETURNING is used."""
    conn = _get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            conn.commit()
            try:
                row = cur.fetchone()
                return row[0] if row else None
            except Exception:
                return None
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Textract helper
# ---------------------------------------------------------------------------

def _run_textract(bucket: str, key: str) -> dict:
    """
    Run Textract AnalyzeDocument (synchronous) on an S3 object and return
    structured key-value pairs + raw text.

    For documents > 1 page, falls back to StartDocumentAnalysis (async).
    """
    try:
        # Try synchronous first (single-page)
        response = textract_client.analyze_document(
            Document={"S3Object": {"Bucket": bucket, "Name": key}},
            FeatureTypes=["FORMS", "TABLES"],
        )
        return _parse_textract_response(response)
    except textract_client.exceptions.UnsupportedDocumentException:
        logger.info("Document %s may be multi-page, using async API", key)
        return _run_textract_async(bucket, key)


def _run_textract_async(bucket: str, key: str) -> dict:
    """Start an async Textract job and poll until complete."""
    start_resp = textract_client.start_document_analysis(
        DocumentLocation={"S3Object": {"Bucket": bucket, "Name": key}},
        FeatureTypes=["FORMS", "TABLES"],
    )
    job_id = start_resp["JobId"]

    # Poll for completion
    while True:
        result = textract_client.get_document_analysis(JobId=job_id)
        status = result["JobStatus"]
        if status == "SUCCEEDED":
            return _parse_textract_response(result)
        if status == "FAILED":
            raise RuntimeError(f"Textract job failed for s3://{bucket}/{key}")
        time.sleep(2)


def _parse_textract_response(response: dict) -> dict:
    """
    Parse Textract response into:
      - key_values : dict of form key->value pairs
      - tables     : list of tables (each table is list of rows)
      - raw_text   : concatenated LINE text
    """
    blocks = response.get("Blocks", [])
    block_map: dict[str, dict] = {b["Id"]: b for b in blocks}

    # --- Extract key-value pairs from FORMS ---
    key_values: dict[str, str] = {}
    for block in blocks:
        if block["BlockType"] == "KEY_VALUE_SET" and "KEY" in block.get("EntityTypes", []):
            key_text = _get_text_from_block(block, block_map)
            value_block = _get_value_block(block, block_map)
            value_text = _get_text_from_block(value_block, block_map) if value_block else ""
            if key_text:
                key_values[key_text.strip()] = value_text.strip()

    # --- Extract tables ---
    tables: list[list[list[str]]] = []
    for block in blocks:
        if block["BlockType"] == "TABLE":
            table = _parse_table(block, block_map)
            tables.append(table)

    # --- Raw text ---
    raw_lines = [
        b.get("Text", "")
        for b in blocks
        if b["BlockType"] == "LINE"
    ]

    return {
        "key_values": key_values,
        "tables": tables,
        "raw_text": "\n".join(raw_lines),
    }


def _get_text_from_block(block: dict, block_map: dict) -> str:
    """Get concatenated text from WORD children of a block."""
    text_parts = []
    for rel in block.get("Relationships", []):
        if rel["Type"] == "CHILD":
            for child_id in rel["Ids"]:
                child = block_map.get(child_id, {})
                if child.get("BlockType") == "WORD":
                    text_parts.append(child.get("Text", ""))
    return " ".join(text_parts)


def _get_value_block(key_block: dict, block_map: dict) -> dict | None:
    """Find the VALUE block paired with a KEY block."""
    for rel in key_block.get("Relationships", []):
        if rel["Type"] == "VALUE":
            for vid in rel["Ids"]:
                vb = block_map.get(vid, {})
                if vb.get("BlockType") == "KEY_VALUE_SET" and "VALUE" in vb.get("EntityTypes", []):
                    return vb
    return None


def _parse_table(table_block: dict, block_map: dict) -> list[list[str]]:
    """Parse a TABLE block into a 2-D list of cell texts."""
    cells: list[dict] = []
    for rel in table_block.get("Relationships", []):
        if rel["Type"] == "CHILD":
            for cid in rel["Ids"]:
                cell = block_map.get(cid, {})
                if cell.get("BlockType") == "CELL":
                    cells.append(cell)

    max_row = max((c.get("RowIndex", 1) for c in cells), default=1)
    max_col = max((c.get("ColumnIndex", 1) for c in cells), default=1)
    table = [["" for _ in range(max_col)] for _ in range(max_row)]

    for cell in cells:
        ri = cell.get("RowIndex", 1) - 1
        ci = cell.get("ColumnIndex", 1) - 1
        table[ri][ci] = _get_text_from_block(cell, block_map)

    return table


def _parse_s3_path(s3_path: str) -> tuple[str, str]:
    """Split 's3://bucket/key' into (bucket, key)."""
    path = s3_path.replace("s3://", "")
    bucket, _, key = path.partition("/")
    return bucket, key


# ---------------------------------------------------------------------------
# TOOL 1 – Textract documents
# ---------------------------------------------------------------------------

@tool
def textract_documents(documents: dict) -> dict:
    """
    Run Amazon Textract on uploaded documents and return structured output.

    Args:
        documents: A dict where keys are document names (from document_table)
                   and values are S3 keys (e.g. "s3://bucket/path/to/file.pdf").

    Returns:
        Dict keyed by document name with Textract-extracted raw_text:
        {
          "invoice": { "raw_text": "..." },
          "purchase_order": { "raw_text": "..." }
        }
    """
    results: dict[str, Any] = {}
    textract_cache: dict[str, str] = {}  # s3_path -> raw_text

    for doc_name, s3_path in documents.items():
        if s3_path in textract_cache:
            raw_text = textract_cache[s3_path]
        else:
            bucket, key = _parse_s3_path(s3_path)
            logger.info("Running Textract on %s  ->  s3://%s/%s", doc_name, bucket, key)
            extracted = _run_textract(bucket, key)
            raw_text = extracted.get("raw_text", "")
            textract_cache[s3_path] = raw_text

        results[doc_name] = {"raw_text": raw_text}
    print("TEXTRACT_RESULTS: ", results)
    return results


# ---------------------------------------------------------------------------
# TOOL 2 – Fetch SOP documents linked to a job, then Textract them
# ---------------------------------------------------------------------------

@tool
def fetch_sop_documents(job_id: int) -> dict:
    try:
        rows = _query(
            """
            SELECT id, exception_id, exception_name, s3_path
            FROM erp_no_sap.sop_table
            WHERE job_id @> %s::jsonb
            AND (delete_status IS NULL OR delete_status = false)
            """,
            (json.dumps([job_id]),),
        )

        if not rows:
            return {"message": f"No SOP documents found for job_id {job_id}"}

        results: dict[str, Any] = {}
        textract_cache: dict[str, str] = {}  # s3_uri -> raw_text (avoid re-Textracting dupes)

        for row in rows:
            sop_key = f"sop_{row['id']}"
            s3_path_json = row.get("s3_path")

            # --- resolve the active document from the JSONB array ---
            s3_uri = None
            if s3_path_json:
                docs = (
                    json.loads(s3_path_json)
                    if isinstance(s3_path_json, str)
                    else s3_path_json
                )
                active_doc = next(
                    (
                        d for d in docs
                        if d.get("active_status") is True
                        and d.get("document_delete_status") is not True
                    ),
                    None,
                )
                if active_doc:
                    s3_uri = active_doc.get("s3_uri")

            if not s3_uri:
                results[sop_key] = {
                    "exception_id": row.get("exception_id"),
                    "exception_name": row.get("exception_name"),
                    "raw_text": None,
                    "error": "No active s3_uri found for this SOP",
                }
                continue

            # --- Textract (with cache to skip duplicate PDFs) ---
            if s3_uri in textract_cache:
                raw_text = textract_cache[s3_uri]
            else:
                bucket, key = _parse_s3_path(s3_uri)
                extracted = _run_textract(bucket, key)
                raw_text = extracted.get("raw_text", "")
                textract_cache[s3_uri] = raw_text

            results[sop_key] = {
                "exception_id": row.get("exception_id"),
                "exception_name": row.get("exception_name"),
                "raw_text": raw_text,  # only raw_text, no key_values/tables
            }
        print("RESULTS: ", results)
        return results

    except Exception as e:
        print("ERROR: ", e)
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# TOOL 3 – Reconcile / compare documents via Bedrock LLM
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# TOOL 4 – Database helper to fetch job + document metadata
# ---------------------------------------------------------------------------

@tool
def get_job_and_documents(job_id: int) -> dict:
    """
    Fetch job metadata and its linked document details from the database.

    Args:
        job_id: The primary key of the job in job_table.

    Returns:
        {
          "job_id": 1,
          "job_name": "...",
          "document_ids": [1, 2, 3],
          "documents": {
            "invoice": { "id": 1, "needed_fields": {...} },
            "purchase_order": { "id": 2, "needed_fields": {...} }
          }
        }
    """
    job_rows = _query(
        "SELECT id, job_name, document_id FROM erp_no_sap.job_table WHERE id = %s",
        (job_id,),
    )
    if not job_rows:
        return {"error": f"Job with id {job_id} not found"}

    job = job_rows[0]
    document_ids: list[int] = job["document_id"]  # JSONB array of ints

    if not document_ids:
        return {
            "job_id": job_id,
            "job_name": job["job_name"],
            "document_ids": [],
            "documents": {},
        }

    placeholders = ",".join(["%s"] * len(document_ids))
    doc_rows = _query(
        f"SELECT id, document_name, needed_fields FROM erp_no_sap.document_table WHERE id IN ({placeholders})",
        tuple(document_ids),
    )

    documents = {}
    for doc in doc_rows:
        documents[doc["document_name"]] = {
            "id": doc["id"],
            "needed_fields": doc["needed_fields"],
        }

    return {
        "job_id": job_id,
        "job_name": job["job_name"],
        "document_ids": document_ids,
        "documents": documents,
    }

    
@tool
def reconcile_documents(
    needed_fields: dict,
    document_textract_outputs: dict,
    sop_textract_outputs: dict,
    session_id: str,
    job_id: int,
    created_by: str,
) -> dict:
    """
    Compare the extracted document contents against the needed fields,
    guided by the SOP instructions. Uses Bedrock Claude to perform the comparison.
    Saves the result to session_table automatically.
    """
    try:
        sop_names = [
            v.get("exception_name", k)
            for k, v in sop_textract_outputs.items()
            if isinstance(v, dict)
        ]

        prompt = f"""You are a document reconciliation specialist.

You will be given:
1. NEEDED FIELDS – the specific fields that must be compared across documents.
2. DOCUMENT CONTENTS – Textract outputs of the uploaded documents.
3. SOP (Standard Operating Procedure) – instructions on how to perform the reconciliation.

Your task:
- Extract ONLY the needed fields from each document.
- Follow EACH SOP to compare/reconcile the documents.
- For each SOP, determine if the documents pass that SOP's checks.

Return ONLY valid JSON (no markdown, no explanation) in this exact structure:
{{
  "match_status": "yes" or "no",
  "reason_for_failure": [
    {{
      "<exception_name>": "none" or "<clear reason for mismatch>",
      "status": "yes" or "no",
      "matching": {{
        "<field_name_from_sop>": {{
          "<document_name>": "<value_from_that_document>",
          ...
        }},
        ...
      }}
    }},
    ...
  ],
  "documents": {{
    "<document_name>": {{ "<needed_field>": "<extracted_value>", ... }},
    ...
  }}
}}

RULES for "reason_for_failure":
- It MUST be a JSON array with one object per SOP.
- Each object has exactly three keys: the exception_name, "status", and "matching".
- The exception names to use are: {json.dumps(sop_names, default=str)}
- If a SOP check passes: set the exception_name value to "none" and "status" to "yes".
- If a SOP check fails: set the exception_name value to a clear reason string and "status" to "no".
- "match_status" should be "yes" ONLY if ALL SOPs pass (all statuses are "yes").

RULES for "matching":
- "matching" shows the actual field values from each document that the SOP compared.
- Keys are the field names relevant to that SOP check (e.g. "unit_price", "quantity", "uom").
- Values are objects mapping document_name to the extracted value from that document.
- Include ALL fields that were compared for that SOP, whether they matched or not.
- Example for a price mismatch SOP:
  "matching": {{
    "unit_price": {{
      "purchase_order": "$250.00",
      "invoice": "$275.00"
    }},
    "total_amount": {{
      "purchase_order": "$12,500.00",
      "invoice": "$13,750.00"
    }}
  }}
- Example for a quantity check SOP:
  "matching": {{
    "quantity": {{
      "purchase_order": "50",
      "goods_receipt": "50",
      "invoice": "50"
    }}
  }}

--- NEEDED FIELDS ---
{json.dumps(needed_fields, indent=2)}

--- DOCUMENT CONTENTS ---
{json.dumps(document_textract_outputs, indent=2, default=str)}

--- SOP DOCUMENTS ---
{json.dumps(sop_textract_outputs, indent=2, default=str)}
"""

        body = json.dumps(
            {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 16384,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0,
            }
        )

        response = bedrock_runtime.invoke_model(
            modelId="us.anthropic.claude-sonnet-4-20250514-v1:0",
            contentType="application/json",
            accept="application/json",
            body=body,
        )

        resp_body = json.loads(response["body"].read())
        raw_text = resp_body["content"][0]["text"]

        try:
            result = json.loads(raw_text)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", raw_text, re.DOTALL)
            if match:
                result = json.loads(match.group())
            else:
                result = {
                    "match_status": "no",
                    "reason_for_failure": [{"parse_error": "Failed to parse LLM response", "status": "no", "matching": {}}],
                    "documents": {},
                }

        # Ensure reason_for_failure is always a list
        if not isinstance(result.get("reason_for_failure"), list):
            result["reason_for_failure"] = [{"unknown": str(result.get("reason_for_failure", "none")), "status": "no", "matching": {}}]

        # Ensure each entry has a "matching" key
        for entry in result["reason_for_failure"]:
            if "matching" not in entry:
                entry["matching"] = {}

        # Convert documents dict to list format
        documents_dict = result.get("documents", {})
        extracted_fields = [
            {doc_name: fields}
            for doc_name, fields in documents_dict.items()
        ]

        # Save to session_table directly
        _execute(
            """
            UPDATE erp_no_sap.session_table
            SET
                reconcile_status   = %s,
                reason_for_failure = %s::jsonb,
                extracted_fields   = %s::jsonb,
                updated_at         = (now() AT TIME ZONE 'Asia/Kolkata')
            WHERE session_id = %s
            """,
            (
                result["match_status"],
                json.dumps(result["reason_for_failure"]),
                json.dumps(extracted_fields),
                session_id,
            ),
        )

        result["session_id"] = session_id
        result["job_id"] = job_id
        result["created_by"] = created_by
        result["extracted_fields"] = extracted_fields
        result["message"] = "Session updated successfully"

        return result

    except Exception as e:
        print("ERROR_2: ", e)
        error_result = {
            "match_status": "no",
            "reason_for_failure": [{"error": str(e), "status": "no", "matching": {}}],
            "documents": {},
        }

        _execute(
            """
            UPDATE erp_no_sap.session_table
            SET
                reconcile_status   = 'failed',
                reason_for_failure = %s::jsonb,
                updated_at         = (now() AT TIME ZONE 'Asia/Kolkata')
            WHERE session_id = %s
            """,
            (json.dumps(error_result["reason_for_failure"]), session_id),
        )

        return error_result

# @tool
# def reconcile_documents(
#     needed_fields: dict,
#     document_textract_outputs: dict,
#     sop_textract_outputs: dict,
#     session_id: str,
#     job_id: int,
#     created_by: str,
# ) -> dict:
#     """
#     Compare the extracted document contents against the needed fields,
#     guided by the SOP instructions. Uses Bedrock Claude to perform the comparison.
#     Saves the result to session_table automatically.

#     Args:
#         needed_fields:              The needed_fields JSONB from document_table entries,
#                                     keyed by document name.
#         document_textract_outputs:  Output of textract_documents tool.
#         sop_textract_outputs:       Output of fetch_sop_documents tool.
#         session_id:                 The session identifier.
#         job_id:                     The job_table id.
#         created_by:                 Who triggered this reconciliation.

#     Returns:
#         JSON with reconciliation result and session save confirmation.
#     """
#     try:
#         sop_names = [
#             v.get("exception_name", k)
#             for k, v in sop_textract_outputs.items()
#             if isinstance(v, dict)
#         ]

#         prompt = f"""You are a document reconciliation specialist.

# You will be given:
# 1. NEEDED FIELDS – the specific fields that must be compared across documents.
# 2. DOCUMENT CONTENTS – Textract outputs of the uploaded documents.
# 3. SOP (Standard Operating Procedure) – instructions on how to perform the reconciliation.

# Your task:
# - Extract ONLY the needed fields from each document.
# - Follow EACH SOP to compare/reconcile the documents.
# - For each SOP, determine if the documents pass that SOP's checks.

# Return ONLY valid JSON (no markdown, no explanation) in this exact structure:
# {{
#   "match_status": "yes" or "no",
#   "reason_for_failure": [
#     {{ "<exception_name>": "none" or "<clear reason for mismatch>", "status": "yes" or "no" }},
#     ...
#   ],
#   "documents": {{
#     "<document_name>": {{ "<needed_field>": "<extracted_value>", ... }},
#     ...
#   }}
# }}

# RULES for "reason_for_failure":
# - It MUST be a JSON array with one object per SOP.
# - Each object has exactly two keys: the exception_name and "status".
# - The exception names to use are: {json.dumps(sop_names, default=str)}
# - If a SOP check passes: set the exception_name value to "none" and "status" to "yes".
# - If a SOP check fails: set the exception_name value to a clear reason string and "status" to "no".
# - "match_status" should be "yes" ONLY if ALL SOPs pass (all statuses are "yes").

# --- NEEDED FIELDS ---
# {json.dumps(needed_fields, indent=2)}

# --- DOCUMENT CONTENTS ---
# {json.dumps(document_textract_outputs, indent=2, default=str)}

# --- SOP DOCUMENTS ---
# {json.dumps(sop_textract_outputs, indent=2, default=str)}
# """

#         body = json.dumps(
#             {
#                 "anthropic_version": "bedrock-2023-05-31",
#                 "max_tokens": 16384,
#                 "messages": [{"role": "user", "content": prompt}],
#                 "temperature": 0,
#             }
#         )

#         response = bedrock_runtime.invoke_model(
#             modelId="us.anthropic.claude-sonnet-4-20250514-v1:0",
#             contentType="application/json",
#             accept="application/json",
#             body=body,
#         )

#         resp_body = json.loads(response["body"].read())
#         raw_text = resp_body["content"][0]["text"]

#         try:
#             result = json.loads(raw_text)
#         except json.JSONDecodeError:
#             match = re.search(r"\{.*\}", raw_text, re.DOTALL)
#             if match:
#                 result = json.loads(match.group())
#             else:
#                 result = {
#                     "match_status": "no",
#                     "reason_for_failure": [{"parse_error": f"Failed to parse LLM response: {raw_text[:500]}", "status": "no"}],
#                     "documents": {},
#                 }

#         # Ensure reason_for_failure is always a list
#         if not isinstance(result.get("reason_for_failure"), list):
#             result["reason_for_failure"] = [{"unknown": str(result.get("reason_for_failure", "none")), "status": "no"}]

#         # Save to session_table directly — no agent manipulation
#         _execute(
#             """
#             UPDATE erp_no_sap.session_table
#             SET
#                 reconcile_status   = %s,
#                 reason_for_failure = %s::jsonb,
#                 updated_at         = (now() AT TIME ZONE 'Asia/Kolkata')
#             WHERE session_id = %s
#             """,
#             (result["match_status"], json.dumps(result["reason_for_failure"]), session_id),
#         )

#         result["session_id"] = session_id
#         result["job_id"] = job_id
#         result["created_by"] = created_by
#         result["message"] = "Session updated successfully"

#         return result

#     except Exception as e:
#         print("ERROR_2: ", e)
#         error_result = {
#             "match_status": "no",
#             "reason_for_failure": [{"error": str(e), "status": "no"}],
#             "documents": {},
#         }

#         # Save failure to session_table
#         _execute(
#             """
#             UPDATE erp_no_sap.session_table
#             SET
#                 reconcile_status   = 'failed',
#                 reason_for_failure = %s::jsonb,
#                 updated_at         = (now() AT TIME ZONE 'Asia/Kolkata')
#             WHERE session_id = %s
#             """,
#             (json.dumps(error_result["reason_for_failure"]), session_id),
#         )

#         return error_result

# ---------------------------------------------------------------------------
# TOOL 5 – Save reconciliation result to session_table
# ---------------------------------------------------------------------------
# @tool
# def reconcile_documents(
#     needed_fields: dict,
#     document_textract_outputs: dict,
#     sop_textract_outputs: dict,
# ) -> dict:
#     """
#     Compare the extracted document contents against the needed fields,
#     guided by the SOP instructions. Uses Bedrock Claude to perform the comparison.

#     Args:
#         needed_fields:              The needed_fields JSONB from document_table entries,
#                                     keyed by document name.
#         document_textract_outputs:  Output of textract_documents tool.
#         sop_textract_outputs:       Output of fetch_sop_documents tool.

#     Returns:
#         JSON with structure:
#         {
#           "match_status": "yes" | "no",
#           "reason_for_failure": [
#             { "<exception_name>": "<reason>" | "none", "status": "yes" | "no" },
#             ...
#           ],
#           "documents": {
#             "document_1": { <needed_fields extracted values> },
#             ...
#           }
#         }
#     """
#     try:
#         # Build SOP name list for the prompt so the LLM knows the keys to use
#         sop_names = [
#             v.get("exception_name", k)
#             for k, v in sop_textract_outputs.items()
#             if isinstance(v, dict)
#         ]

#         prompt = f"""You are a document reconciliation specialist.

# You will be given:
# 1. NEEDED FIELDS – the specific fields that must be compared across documents.
# 2. DOCUMENT CONTENTS – Textract outputs of the uploaded documents.
# 3. SOP (Standard Operating Procedure) – instructions on how to perform the reconciliation.

# Your task:
# - Extract ONLY the needed fields from each document.
# - Follow EACH SOP to compare/reconcile the documents.
# - For each SOP, determine if the documents pass that SOP's checks.

# Return ONLY valid JSON (no markdown, no explanation) in this exact structure:
# {{
#   "match_status": "yes" or "no",
#   "reason_for_failure": [
#     {{ "<exception_name>": "none" or "<clear reason for mismatch>", "status": "yes" or "no" }},
#     ...
#   ],
#   "documents": {{
#     "<document_name>": {{ "<needed_field>": "<extracted_value>", ... }},
#     ...
#   }}
# }}

# RULES for "reason_for_failure":
# - It MUST be a JSON array with one object per SOP.
# - Each object has exactly two keys: the exception_name and "status".
# - The exception names to use are: {json.dumps(sop_names, default=str)}
# - If a SOP check passes: set the exception_name value to "none" and "status" to "yes".
# - If a SOP check fails: set the exception_name value to a clear reason string and "status" to "no".
# - "match_status" should be "yes" ONLY if ALL SOPs pass (all statuses are "yes").

# --- NEEDED FIELDS ---
# {json.dumps(needed_fields, indent=2)}

# --- DOCUMENT CONTENTS ---
# {json.dumps(document_textract_outputs, indent=2, default=str)}

# --- SOP DOCUMENTS ---
# {json.dumps(sop_textract_outputs, indent=2, default=str)}
# """

#         body = json.dumps(
#             {
#                 "anthropic_version": "bedrock-2023-05-31",
#                 "max_tokens": 16384,
#                 "messages": [{"role": "user", "content": prompt}],
#                 "temperature": 0,
#             }
#         )

#         response = bedrock_runtime.invoke_model(
#             modelId="us.anthropic.claude-sonnet-4-20250514-v1:0",
#             contentType="application/json",
#             accept="application/json",
#             body=body,
#         )

#         resp_body = json.loads(response["body"].read())
#         raw_text = resp_body["content"][0]["text"]

#         # Parse the JSON response
#         try:
#             result = json.loads(raw_text)
#         except json.JSONDecodeError:
#             match = re.search(r"\{.*\}", raw_text, re.DOTALL)
#             if match:
#                 result = json.loads(match.group())
#             else:
#                 result = {
#                     "match_status": "no",
#                     "reason_for_failure": [{"parse_error": f"Failed to parse LLM response: {raw_text[:500]}", "status": "no"}],
#                     "documents": {},
#                 }

#         # Ensure reason_for_failure is always a list
#         if not isinstance(result.get("reason_for_failure"), list):
#             result["reason_for_failure"] = [{"unknown": str(result.get("reason_for_failure", "none")), "status": "no"}]
#         print("RESULTSSSSS: ", result)
#         return result

#     except Exception as e:
#         print("ERROR_2: ", e)
#         return {
#             "match_status": "no",
#             "reason_for_failure": [{"error": str(e), "status": "no"}],
#             "documents": {},
#         }

# @tool
# def save_session(
#     session_id: str,
#     job_id: int,
#     reconcile_status: str,
#     reason_for_failure,
#     created_by: str,
# ) -> dict:
#     """
#     Update the reconciliation result in session_table.

#     Args:
#         session_id:          The session identifier (passed from the event).
#         job_id:              The job_table id this reconciliation belongs to.
#         reconcile_status:    "yes" or "no" (the match_status from reconciliation).
#         reason_for_failure:  Dict keyed by SOP/exception name with reason strings.
#         created_by:          Who triggered this reconciliation.

#     Returns:
#         Dict with the session record id and session_id.
#     """

#     print("FAILUREEEE: ", reason_for_failure)
#     _execute(
#         """
#         UPDATE erp_no_sap.session_table
#         SET
#             reconcile_status   = %s,
#             reason_for_failure = %s::jsonb,
#             updated_at         = (now() AT TIME ZONE 'Asia/Kolkata')
#         WHERE session_id = %s
#         """,
#         (reconcile_status, json.dumps(reason_for_failure), session_id),
#     )

#     return {
#         "session_id": session_id,
#         "job_id": job_id,
#         "reconcile_status": reconcile_status,
#         "reason_for_failure": reason_for_failure,
#         "created_by": created_by,
#         "message": "Session updated successfully",
#     }

# ---------------------------------------------------------------------------
# Agent factory
# ---------------------------------------------------------------------------

# def create_agent() -> Agent:
#     """
#     Build and return a configured Strands Agent with the reconciliation tool suite.
#     """
#     system_prompt = """You are a reconciliation agent. Your job is to compare documents uploaded
# by the user following the SOP (Standard Operating Procedure) associated with the job.

# When the user provides a job_id and documents (as S3 paths keyed by document name), follow
# these steps IN ORDER:

# 1. Call `get_job_and_documents` with the job_id to retrieve:
#    - The list of document_ids and their names
#    - The needed_fields for each document

# 2. Call `textract_documents` with the user-provided documents dict
#    (keys = document names from step 1, values = S3 paths provided by the user).

# 3. Call `fetch_sop_documents` with the job_id to get and Textract all linked SOP documents.

# 4. Call `reconcile_documents` with:
#    - needed_fields from step 1
#    - textract outputs from step 2
#    - SOP textract outputs from step 3

# 5. Call `save_session` to persist the reconciliation result to the database with:
#    - session_id from the input
#    - job_id from the input
#    - reconcile_status = the match_status from step 4 ("yes" or "no")
#    - reason_for_failure = the reason_for_failure from step 4
#    - created_by = the user who triggered the reconciliation (from the input)

# 6. Return the reconciliation result along with the session_id to the user.

# Always execute all steps. Do not skip any tool calls."""

#     sonnet_4 = "us.anthropic.claude-sonnet-4-20250514-v1:0"


#     model = BedrockModel(
        
        
#         model_id= sonnet_4,
#         region_name="us-west-2",
#     )

#     return Agent(
#         model=model,
#         system_prompt=system_prompt,
#         tools=[
#             get_job_and_documents,
#             textract_documents,
#             fetch_sop_documents,
#             reconcile_documents,
#             save_session,
#         ]
#     )

def create_agent() -> Agent:
    system_prompt = """You are a reconciliation agent. Your job is to compare documents uploaded
by the user following the SOP (Standard Operating Procedure) associated with the job.

When the user provides a job_id and documents (as S3 paths keyed by document name), follow
these steps IN ORDER:

1. Call `get_job_and_documents` with the job_id to retrieve:
   - The list of document_ids and their names
   - The needed_fields for each document

2. Call `textract_documents` with the user-provided documents dict
   (keys = document names from step 1, values = S3 paths provided by the user).

3. Call `fetch_sop_documents` with the job_id to get and Textract all linked SOP documents.

4. Call `reconcile_documents` with:
   - needed_fields from step 1
   - textract outputs from step 2
   - SOP textract outputs from step 3
   - session_id from the input
   - job_id from the input
   - created_by from the input
   This tool will also save the result to the database automatically.

5. Return the reconciliation result along with the session_id to the user.

Always execute all steps. Do not skip any tool calls."""

    model = BedrockModel(
        model_id="us.anthropic.claude-sonnet-4-20250514-v1:0",
        region_name="us-west-2",
        max_tokens=16384,
    )

    return Agent(
        model=model,
        system_prompt=system_prompt,
        tools=[
            get_job_and_documents,
            textract_documents,
            fetch_sop_documents,
            reconcile_documents,
        ]
    )
# ---------------------------------------------------------------------------
# Lambda / entry-point handler
# ---------------------------------------------------------------------------

def lambda_handler(event: dict, context: Any = None) -> dict:
    """
    Lambda handler (or direct invocation entry point).

    Expected event shape for reconcile_documents:
    {
      "event_type": "reconcile_documents",
      "session_id": "sess_abc123",
      "job_id": 1,
      "created_by": "user@example.com",
      "documents": {
        "invoice": "s3://my-bucket/uploads/invoice_001.pdf",
        "purchase_order": "s3://my-bucket/uploads/po_001.pdf"
      }
    }

    session_table DDL required:
      ALTER TABLE erp_no_sap.session_table
        ADD COLUMN IF NOT EXISTS documents      jsonb,
        ADD COLUMN IF NOT EXISTS created_at     timestamptz
            DEFAULT (now() AT TIME ZONE 'Asia/Kolkata');
    """
    event_type = event.get("event_type")

    if event_type == "reconcile_documents":
            job_id     = event.get("job_id")
            documents  = event.get("documents")   # { doc_name: s3_path }
            created_by = event.get("created_by", "system")
            session_id = event.get("session_id")
            testing_status = event.get("testing_status", "no")



            if not job_id or not documents or not session_id:
                return {
                    "statusCode": 400,
                    "body": json.dumps(
                        {"error": "job_id, session_id, and documents are required"}
                    ),
                }

            # -------------------------------------------------------------------
            # STEP 1 – Insert initial "processing" row BEFORE the agent runs.
            # -------------------------------------------------------------------
            _execute(
                """
                INSERT INTO erp_no_sap.session_table
                    (session_id, job_id, documents, reconcile_status,
                    reason_for_failure, created_by, created_at)
                VALUES (
                    %s, %s, %s::jsonb, 'processing',
                    %s::jsonb, %s,
                    (now() AT TIME ZONE 'Asia/Kolkata')
                )
                ON CONFLICT (session_id) DO UPDATE SET
                    reconcile_status   = 'processing',
                    reason_for_failure = %s::jsonb,
                    updated_at         = (now() AT TIME ZONE 'Asia/Kolkata')
                """,
                (
                    session_id, job_id, json.dumps(documents),
                    json.dumps({"status": "processing"}), created_by,
                    json.dumps({"status": "processing"}),
                ),
            )

            # -------------------------------------------------------------------
            # STEP 2 – Run the agent.
            # -------------------------------------------------------------------
            agent = create_agent()

            user_message = (
                f"Reconcile the following documents for job_id={job_id}.\n\n"
                f"Documents (name -> S3 path):\n"
                f"{json.dumps(documents, indent=2)}\n\n"
                f"session_id: {session_id}\n"
                f"created_by: {created_by}\n\n"
                f"Please run all reconciliation steps, save the session, and return the result."
            )
            try:
                result = agent(user_message)
                result_str = str(result)

                logger.info("Reconciliation complete for session_id=%s", session_id)

                return {
                    "statusCode": 200,
                    "body": result_str,
                }

            except Exception as exc:
                logger.exception("Agent failed for session_id=%s", session_id)

                _execute(
                    """
                    UPDATE erp_no_sap.session_table
                    SET
                        reconcile_status   = 'failed',
                        reason_for_failure = %s::jsonb,
                        updated_at         = (now() AT TIME ZONE 'Asia/Kolkata')
                    WHERE session_id = %s
                    """,
                    (json.dumps({"error": str(exc)[:1000]}), session_id),
                )

                return {
                    "statusCode": 500,
                    "body": json.dumps({"error": str(exc), "session_id": session_id}),
                }
    # Unknown event_type
    return {
        "statusCode": 400,
        "body": json.dumps({"error": f"Unknown event_type: {event_type}"}),
    }