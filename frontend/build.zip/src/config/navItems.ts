export interface SubNavItem {
  path: string;
  label: string;
  icon: string;
}

export interface NavItem {
  path?: string;
  label: string;
  icon: string;
  subItems?: SubNavItem[];
}

const mainNavItems: NavItem[] = [
  { path: '/dashboard', label: 'Dashboard', icon: 'dashboard' },
  { path: '/document-types', label: 'Doc Types', icon: 'config' },
  { path: '/job-config', label: 'Job Config', icon: 'job' },
  { path: '/sop-control-center', label: 'SOP Control Center', icon: 'document' },
  { path: '/reconcile-agent/records', label: 'Reconcile Agent', icon: 'agents' },
  { path: '/token-usage', label: 'Token Usage', icon: 'analytics' },
];

/** Admin-only sidebar extras (empty). */
export const superAdminNavItems: NavItem[] = [];

export function getNavItemsByRole(_role: string | null): NavItem[] {
  return mainNavItems;
}

export function isPathInSubmenu(subItems: SubNavItem[], pathname: string): boolean {
  return subItems.some((s) => s.path === pathname);
}

export function getInitialExpandedMenus(pathname: string, navItems: NavItem[]): string[] {
  return navItems
    .filter((item) => item.subItems && isPathInSubmenu(item.subItems, pathname))
    .map((item) => item.label);
}

/** Routes that should keep SOP Control Center highlighted in the sidebar (same section as list + editor). */
export function isSopEditorSectionPath(pathname: string): boolean {
  if (pathname === '/new_sop') return true;
  const parts = pathname.split('/').filter(Boolean);
  return parts.length === 2 && parts[1] === 'edit';
}
