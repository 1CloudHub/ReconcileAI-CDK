const BASE = import.meta.env.VITE_RECONCILEAI_DEV_ENV_NO_SAP_BASE_URL ?? '';

export const API_URLS = {
  ERP: import.meta.env.VITE_ERP_API_URL ?? '/api/erp',
  MULTI_DASHBOARD: import.meta.env.VITE_DASHBOARD_API_URL ?? '/api/dashboard',
  CONFIG: `${BASE}/dev/config`,
  RECONCILE_AI: `${BASE}/dev/reconcile-ai`,
  /** SOP list/add/update/delete Lambda (event_type-driven). */
};
