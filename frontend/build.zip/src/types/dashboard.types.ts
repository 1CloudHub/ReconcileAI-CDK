/** Single row for “Exceptions by Type” bar chart */
export interface ProcessedExceptionByTypeItem {
  uniqueId: string;
  name: string;
  count: number;
}

/** Daily trend series */
export interface TrendDataItem {
  day: string;
  detected: number;
  resolved: number;
}

/** Severity horizontal bar chart */
export interface SeverityDataItem {
  severity: string;
  count: number;
}

/** Props passed by Recharts to custom XAxis ticks */
export interface DashboardBarTickProps {
  x?: number;
  y?: number;
  payload?: { value?: string };
}
