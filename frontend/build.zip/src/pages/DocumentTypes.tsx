import { message, Tooltip } from 'antd';
import type { TableColumnsType } from 'antd';
import dayjs from 'dayjs';
import type { Dayjs } from 'dayjs';
import { Funnel, Pencil, Plus, Trash2 } from 'lucide-react';
import DeleteConfirmModal from '../components/ui/DeleteConfirmModal';
import { useCallback, useEffect, useMemo, useState } from 'react';
import DynamicFilterModal, {
  type DynamicFilterField,
  type DynamicFilterValue,
} from '../components/ui/DynamicFilterModal';
import PageBreadcrumb from '../components/ui/PageBreadcrumb';
import PrimaryButton from '../components/ui/PrimaryButton';
import TablePagination from '../components/ui/TablePagination';
import { TableLayout } from '../components/ui/TableLayout';
import ListPageTableSkeleton from '../components/ui/ListPageTableSkeleton';
import DocumentStepper from '../layout/DocumentTypes/DocumentStepper';
import useDocumentTypes, { type DocumentTypeRow } from '../hooks/useDocumentTypes';

const actionIconBtnClass =
  'inline-flex items-center justify-center rounded-md p-1.5 text-[#1351cd] hover:bg-[#1351cd]/10 transition-colors disabled:opacity-40 disabled:pointer-events-none';

const deleteIconBtnClass =
  'inline-flex items-center justify-center rounded-md p-1.5 text-rose-600 hover:bg-rose-50 hover:text-rose-600 transition-colors disabled:opacity-40 disabled:pointer-events-none';

/** Capitalise and replace underscores — matches source display style. */
function formatDocTypeName(name: string): string {
  return name
    .replace(/_/g, ' ')
    .split(' ')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

export default function DocumentTypes() {
  const [search, setSearch] = useState('');
  const [dateFilter, setDateFilter] = useState<Dayjs | null>(null);
  const [draftSearch, setDraftSearch] = useState('');
  const [draftDateFilter, setDraftDateFilter] = useState<Dayjs | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [isStepperOpen, setIsStepperOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [deleteRow, setDeleteRow] = useState<DocumentTypeRow | null>(null);
  const [deletePopupPosition, setDeletePopupPosition] = useState<{ top: number; left: number } | undefined>(
    undefined,
  );
  const [editingRow, setEditingRow] = useState<DocumentTypeRow | null>(null);
  /** Bump when opening the stepper so it remounts with empty state (avoids stale Add form after Edit). */
  const [stepperMountKey, setStepperMountKey] = useState(0);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const {
    rows,
    loading,
    error,
    listPagination,
    fetchDocumentTypes,
    addDocumentType,
    editDocumentType,
    deleteDocumentType,
    suggestDescription,
    initiateAiExtraction,
    pollAiExtractionStatus,
    initiateTestDoc,
    pollTestDocStatus,
  } = useDocumentTypes();

  useEffect(() => {
    window.scrollTo(0, 0);
    const main = document.querySelector('main');
    if (main) main.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const createdFrom =
      dateFilter != null && dateFilter.isValid()
        ? dateFilter.startOf('day').format('YYYY-MM-DDTHH:mm:ss')
        : undefined;
    const createdTo =
      dateFilter != null && dateFilter.isValid()
        ? dateFilter.endOf('day').format('YYYY-MM-DDTHH:mm:ss')
        : undefined;

    void fetchDocumentTypes({
      page: currentPage,
      page_size: pageSize,
      ...(search.trim() ? { document_name: search.trim() } : {}),
      ...(createdFrom ? { created_from: createdFrom, created_to: createdTo } : {}),
    });
  }, [fetchDocumentTypes, currentPage, pageSize, search, dateFilter]);

  useEffect(() => {
    if (error) void message.error(error);
  }, [error]);

  const handleOpenAdd = () => {
    setEditingRow(null);
    setStepperMountKey((k) => k + 1);
    setIsStepperOpen(true);
  };

  const handleOpenEdit = (record: DocumentTypeRow) => {
    setEditingRow(record);
    setStepperMountKey((k) => k + 1);
    setIsStepperOpen(true);
  };

  const openDeleteConfirm = useCallback(
    (record: DocumentTypeRow, event: React.MouseEvent<HTMLButtonElement>) => {
      const rect = event.currentTarget.getBoundingClientRect();
      setDeletePopupPosition({
        top: rect.bottom + 8,
        left: Math.max(16, rect.left - 350),
      });
      setDeleteRow(record);
    },
    [],
  );

  const handleStepperClose = () => {
    setIsStepperOpen(false);
    setEditingRow(null);
  };

  const columns: TableColumnsType<DocumentTypeRow> = useMemo(
    () => [
      {
        title: 'Created At',
        dataIndex: 'createdAt',
        key: 'createdAt',
        width: 220,
        render: (value: string) => (
          <span className="text-sm text-slate-700">
            {value ? dayjs(value).format('MMM D, YYYY, h:mm A') : '—'}
          </span>
        ),
      },
      {
        title: 'Document Type',
        dataIndex: 'documentType',
        key: 'documentType',
        width: 240,
        render: (text: string) => (
          <span className="text-sm font-semibold" style={{ color: 'var(--text-secondary, #475569)' }}>
            {formatDocTypeName(text)}
          </span>
        ),
      },
      {
        title: 'Description',
        dataIndex: 'description',
        key: 'description',
        render: (text: string) => {
          const displayText = text && text.length > 60 ? text.substring(0, 60) + '…' : text;
          return (
            <Tooltip title={text && text.length > 60 ? text : undefined} placement="top">
              <span className="text-sm text-slate-600">{displayText || '—'}</span>
            </Tooltip>
          );
        },
        ellipsis: true,
      },
      {
        title: 'Action',
        key: 'action',
        width: 120,
        align: 'left',
        render: (_: unknown, record) => (
          <div className="flex flex-wrap items-center gap-0.5">
            <Tooltip title="Edit">
              <button
                type="button"
                className={actionIconBtnClass}
                aria-label="Edit"
                onClick={() => handleOpenEdit(record)}
              >
                <Pencil size={18} strokeWidth={2} />
              </button>
            </Tooltip>
            <Tooltip title="Delete">
              <button
                type="button"
                className={deleteIconBtnClass}
                aria-label="Delete"
                onClick={(event) => openDeleteConfirm(record, event)}
              >
                <Trash2 size={18} strokeWidth={2} />
              </button>
            </Tooltip>
          </div>
        ),
      },
    ],
    [openDeleteConfirm],
  );

  const filterFields = useMemo<DynamicFilterField[]>(
    () => [
      {
        key: 'document_name',
        type: 'input',
        label: 'Document type',
        placeholder: 'Filter by document type name…',
      },
      {
        key: 'created_from',
        type: 'date',
        label: 'Date',
        placeholder: 'Select date',
      },
    ],
    []
  );

  const draftFilterValues = useMemo(
    () => ({
      document_name: draftSearch,
      created_from: draftDateFilter,
    }),
    [draftSearch, draftDateFilter]
  );

  const handleDraftFilterChange = (key: string, value: DynamicFilterValue) => {
    if (key === 'document_name') {
      setDraftSearch(typeof value === 'string' ? value : '');
      return;
    }
    if (key === 'created_from') {
      setDraftDateFilter((value as Dayjs | null | undefined) ?? null);
    }
  };

  const applyFilters = () => {
    setCurrentPage(1);
    setSearch(draftSearch.trim());
    setDateFilter(draftDateFilter);
    setFiltersOpen(false);
  };

  const clearFilters = () => {
    setCurrentPage(1);
    setDraftSearch('');
    setDraftDateFilter(null);
    setSearch('');
    setDateFilter(null);
    setFiltersOpen(false);
  };

  const hasDraftFilterValue = useMemo(
    () => [draftSearch.trim(), draftDateFilter].some(Boolean),
    [draftSearch, draftDateFilter]
  );

  const activeFilterCount = useMemo(
    () => [search.trim(), dateFilter].filter(Boolean).length,
    [search, dateFilter]
  );

  const openFilters = () => {
    setDraftSearch(search);
    setDraftDateFilter(dateFilter);
    setFiltersOpen(true);
  };
  const showPageSkeleton = loading;

  return (
    <div className="flex w-full flex-col gap-6">
      <PageBreadcrumb
        items={[
          { title: 'Home', to: '/dashboard' },
          { title: 'Doc Types' },
        ]}
      />

      <div>
        <h1 className="m-0 text-2xl font-semibold tracking-tight text-slate-900">
          Document Types
        </h1>
        <p className="mt-2 mb-0 text-sm text-slate-500">
          Manage and configure your document types
        </p>
      </div>

      {showPageSkeleton ? (
        <ListPageTableSkeleton toolbarButtonCount={2} tableColumns={4} tableRows={pageSize} />
      ) : (
      <section className="rounded-xl border border-slate-200/80 bg-white p-6 shadow-sm max-md:p-4">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="ml-auto flex w-full flex-col items-stretch gap-3 sm:w-auto sm:flex-row sm:flex-wrap sm:items-center sm:justify-end">
            <button
              type="button"
              className="relative inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-[10px] border border-[#c8d4e4] bg-white px-4 text-[15px] font-semibold text-slate-700 transition-all duration-200 hover:border-[#1351cd] hover:text-[#1351cd] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1351cd] sm:w-auto"
              onClick={openFilters}
            >
              <Funnel size={16} strokeWidth={2.25} aria-hidden />
              Filter
              {activeFilterCount > 0 ? (
                <span className="absolute -right-2 -top-2 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-[#1351cd] px-1.5 text-[11px] font-semibold text-white">
                  {activeFilterCount}
                </span>
              ) : null}
            </button>
            <PrimaryButton
              icon={<Plus strokeWidth={2.5} />}
              text="Add Document Type"
              type="button"
              className="w-full sm:w-auto"
              onClick={handleOpenAdd}
            />
          </div>
        </div>

        <div className="min-w-0">
          <TableLayout<DocumentTypeRow>
            card={false}
            columns={columns}
            dataSource={rows}
            rowKey="key"
            loading={loading}
            pagination={false}
          />
        </div>
        <TablePagination
          total={listPagination?.total ?? rows.length}
          current={currentPage}
          pageSize={pageSize}
          onChange={(page, nextPageSize) => {
            if (nextPageSize !== pageSize) {
              setPageSize(nextPageSize);
              setCurrentPage(1);
            } else {
              setCurrentPage(page);
            }
          }}
        />
      </section>
      )}

      <DynamicFilterModal
        open={filtersOpen}
        title="Filter document types"
        variant="drawer"
        width={360}
        fields={filterFields}
        values={draftFilterValues}
        onChange={handleDraftFilterChange}
        onCancel={() => setFiltersOpen(false)}
        onApply={applyFilters}
        onReset={clearFilters}
        applyText="Apply Filters"
        resetText="Reset Filters"
        applyDisabled={!hasDraftFilterValue}
        resetDisabled={!hasDraftFilterValue}
      />

      <DocumentStepper
        key={stepperMountKey}
        open={isStepperOpen}
        onClose={handleStepperClose}
        mode={editingRow ? 'edit' : 'add'}
        initialValues={
          editingRow
            ? {
                documentType: editingRow.documentType,
                documentDescription: editingRow.description,
                documentKey: editingRow.documentKey,
                documentKeyIsEnabled: editingRow.documentKeyIsEnabled,
                fields:
                  editingRow.fields.length > 0
                    ? editingRow.fields
                    : [{ name: '', description: '' }],
              }
            : null
        }
        onAdd={addDocumentType}
        onEdit={editDocumentType}
        onSuggestDescription={suggestDescription}
        onInitiateAiExtraction={initiateAiExtraction}
        onPollAiExtraction={pollAiExtractionStatus}
        onInitiateTestDoc={initiateTestDoc}
        onPollTestDoc={pollTestDocStatus}
      />

      <DeleteConfirmModal
        open={Boolean(deleteRow)}
        title="Delete Document Type"
        description="Are you sure you want to delete? This action cannot be undone."
        position={deletePopupPosition}
        loading={deleteLoading}
        onCancel={() => {
          setDeleteRow(null);
        }}
        onConfirm={async () => {
          if (!deleteRow) return;
          setDeleteLoading(true);
          try {
            await deleteDocumentType(deleteRow.id);
            void message.success('Document type deleted successfully');
            setDeleteRow(null);
          } catch (e) {
            const errMsg = e instanceof Error ? e.message : 'Failed to delete document type';
            void message.error(errMsg);
            // Close the modal after showing the backend warning.
            setDeleteRow(null);
          } finally {
            setDeleteLoading(false);
          }
        }}
        onAfterClose={() => {
          setDeletePopupPosition(undefined);
        }}
      />
    </div>
  );
}
