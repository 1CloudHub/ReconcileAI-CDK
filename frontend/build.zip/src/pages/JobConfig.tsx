import { useEffect, useMemo, useState } from 'react';
import type { TableColumnsType } from 'antd';
import { Tag, Tooltip, message } from 'antd';
import dayjs from 'dayjs';
import { Funnel, Pencil, Plus, Trash2 } from 'lucide-react';
import DeleteConfirmModal from '../components/ui/DeleteConfirmModal';
import DynamicFilterModal, {
  type DynamicFilterField,
  type DynamicFilterValue,
} from '../components/ui/DynamicFilterModal';
import PageBreadcrumb from '../components/ui/PageBreadcrumb';
import PrimaryButton from '../components/ui/PrimaryButton';
import TablePagination from '../components/ui/TablePagination';
import { TableLayout } from '../components/ui/TableLayout';
import ListPageTableSkeleton from '../components/ui/ListPageTableSkeleton';
import { getCookie } from '../utils/cookies';
import useJobConfig, { type JobItem } from '../hooks/useJobConfig';
import JobStepper from '../layout/JobConfig/JobStepper';

const actionIconBtnClass =
  'inline-flex items-center justify-center rounded-md p-1.5 text-[#1351cd] hover:bg-[#1351cd]/10 transition-colors disabled:opacity-40 disabled:pointer-events-none';

const deleteIconBtnClass =
  'inline-flex items-center justify-center rounded-md p-1.5 text-rose-600 hover:bg-rose-50 hover:text-rose-600 transition-colors disabled:opacity-40 disabled:pointer-events-none';

export default function JobConfig() {
  const {
    jobs,
    jobsPagination,
    documentTypeOptions,
    loading,
    error,
    createJob,
    editJob,
    deleteJob,
    fetchJobs,
  } = useJobConfig();
  const [jobNameFilter, setJobNameFilter] = useState('');
  const [createdByFilter, setCreatedByFilter] = useState('');
  const [documentNameFilter, setDocumentNameFilter] = useState('');
  const [draftJobName, setDraftJobName] = useState('');
  const [draftCreatedBy, setDraftCreatedBy] = useState('');
  const [draftDocumentName, setDraftDocumentName] = useState('');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [isStepperOpen, setIsStepperOpen] = useState(false);
  const [editingJob, setEditingJob] = useState<JobItem | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [deleteRow, setDeleteRow] = useState<JobItem | null>(null);
  const [deletePopupPosition, setDeletePopupPosition] = useState<{ top: number; left: number } | undefined>(undefined);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const actor = getCookie('userlogin') || 'system@reconcileai.local';

  useEffect(() => {
    window.scrollTo(0, 0);
    const main = document.querySelector('main');
    if (main) main.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    if (error) message.error(error);
  }, [error, message]);

  useEffect(() => {
    void fetchJobs({
      page: currentPage,
      page_size: pageSize,
      ...(jobNameFilter.trim() ? { job_name: jobNameFilter.trim() } : {}),
      ...(createdByFilter.trim() ? { created_by: createdByFilter.trim() } : {}),
      ...(documentNameFilter.trim() ? { document_name: documentNameFilter.trim() } : {}),
    });
  }, [fetchJobs, currentPage, pageSize, jobNameFilter, createdByFilter, documentNameFilter]);

  const columns: TableColumnsType<JobItem> = useMemo(
    () => [
      {
        title: 'Date & Time',
        dataIndex: 'created_at',
        key: 'created_at',
        width: 200,
        render: (value?: string) => (
          <span className="text-xs text-slate-700">
            {value ? dayjs(value).format('MMM D, YYYY, h:mm A') : '-'}
          </span>
        ),
      },
      {
        title: 'Job Name',
        dataIndex: 'job_name',
        key: 'job_name',
        render: (text: string) => <span className="text-sm">{text}</span>,
      },
      {
        title: 'Document Types',
        key: 'document_names',
        render: (_: unknown, record) => {
          const names =
            Array.isArray(record.document_names) && record.document_names.length
              ? record.document_names
              : record.document_id
                  ?.map((docId) => documentTypeOptions.find((option) => option.id === Number(docId))?.name)
                  .filter((name): name is string => Boolean(name)) ?? [];

          // Prepend reference document name to the list if present
          const allDisplayNames = [...names];
          if (record.reference_document_name && !allDisplayNames.includes(record.reference_document_name)) {
            allDisplayNames.unshift(record.reference_document_name);
          }

          return allDisplayNames.length ? (
            <div className="flex flex-wrap gap-2">
              {allDisplayNames.map((name) => (
                <Tag key={`${record.id}-${name}`} color="blue">
                  {name}
                </Tag>
              ))}
            </div>
          ) : (
            <span className="text-sm text-slate-500">-</span>
          );
        },
      },
      {
        title: 'Action',
        key: 'action',
        width: 120,
        align: 'left',
        render: (_: unknown, record) => (
          <div className="flex flex-wrap items-center gap-0.5">
            <Tooltip title="Edit">
              <button
                type="button"
                className={actionIconBtnClass}
                aria-label="Edit"
                onClick={() => {
                  setEditingJob(record);
                  setIsStepperOpen(true);
                }}
              >
                <Pencil size={18} strokeWidth={2} />
              </button>
            </Tooltip>
            <Tooltip title="Delete">
              <button
                type="button"
                className={deleteIconBtnClass}
                aria-label="Delete"
                onClick={(event) => {
                  const rect = event.currentTarget.getBoundingClientRect();
                  setDeletePopupPosition({
                    top: rect.bottom + 8,
                    left: Math.max(16, rect.left - 350),
                  });
                  setDeleteRow(record);
                }}
              >
                <Trash2 size={18} strokeWidth={2} />
              </button>
            </Tooltip>
          </div>
        ),
      },
    ],
    [documentTypeOptions, message]
  );

  const filterFields = useMemo<DynamicFilterField[]>(
    () => [
      {
        key: 'job_name',
        type: 'input',
        label: 'Job name',
        placeholder: 'Search job name',
      },
      // {
      //   key: 'created_by',
      //   type: 'input',
      //   label: 'Created by',
      //   placeholder: 'user@company.com',
      // },
      {
        key: 'document_name',
        type: 'input',
        label: 'Document type',
        placeholder: 'Filter by document type name…',
      },
    ],
    []
  );

  const draftFilterValues = useMemo(
    () => ({
      job_name: draftJobName,
      created_by: draftCreatedBy,
      document_name: draftDocumentName,
    }),
    [draftJobName, draftCreatedBy, draftDocumentName]
  );

  const handleDraftFilterChange = (key: string, value: DynamicFilterValue) => {
    if (key === 'job_name') {
      setDraftJobName(typeof value === 'string' ? value : '');
      return;
    }
    if (key === 'created_by') {
      setDraftCreatedBy(typeof value === 'string' ? value : '');
      return;
    }
    if (key === 'document_name') {
      setDraftDocumentName(typeof value === 'string' ? value : '');
    }
  };

  const applyFilters = () => {
    setCurrentPage(1);
    setJobNameFilter(draftJobName.trim());
    setCreatedByFilter(draftCreatedBy.trim());
    setDocumentNameFilter(draftDocumentName.trim());
    setFiltersOpen(false);
  };

  const clearFilters = () => {
    setCurrentPage(1);
    setDraftJobName('');
    setDraftCreatedBy('');
    setDraftDocumentName('');
    setJobNameFilter('');
    setCreatedByFilter('');
    setDocumentNameFilter('');
    setFiltersOpen(false);
  };

  const hasDraftFilterValue = useMemo(
    () => [draftJobName.trim(), draftCreatedBy.trim(), draftDocumentName.trim()].some(Boolean),
    [draftJobName, draftCreatedBy, draftDocumentName]
  );

  const activeFilterCount = useMemo(
    () => [jobNameFilter.trim(), createdByFilter.trim(), documentNameFilter.trim()].filter(Boolean).length,
    [jobNameFilter, createdByFilter, documentNameFilter]
  );

  const openFilters = () => {
    setDraftJobName(jobNameFilter);
    setDraftCreatedBy(createdByFilter);
    setDraftDocumentName(documentNameFilter);
    setFiltersOpen(true);
  };
  const showPageSkeleton = loading;

  return (
    <div className="flex w-full flex-col gap-6">
      <PageBreadcrumb
        items={[
          { title: 'Home', to: '/dashboard' },
          { title: 'Job Config' },
        ]}
      />

      <div>
        <h1 className="m-0 text-2xl font-semibold tracking-tight text-slate-900">Job Config</h1>
        <p className="mt-2 mb-0 text-sm text-slate-500">Create and manage reconciliation jobs</p>
      </div>

      {showPageSkeleton ? (
        <ListPageTableSkeleton toolbarButtonCount={2} tableColumns={4} tableRows={pageSize} />
      ) : (
      <section className="rounded-xl border border-slate-200/80 bg-white p-6 shadow-sm max-md:p-4">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="ml-auto flex w-full flex-col items-stretch gap-3 sm:w-auto sm:flex-row sm:flex-wrap sm:items-center sm:justify-end">
            <button
              type="button"
              className="relative inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-[10px] border border-[#c8d4e4] bg-white px-4 text-[15px] font-semibold text-slate-700 transition-all duration-200 hover:border-[#1351cd] hover:text-[#1351cd] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1351cd] sm:w-auto"
              onClick={openFilters}
            >
              <Funnel size={16} strokeWidth={2.25} aria-hidden />
              Filter
              {activeFilterCount > 0 ? (
                <span className="absolute -right-2 -top-2 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-[#1351cd] px-1.5 text-[11px] font-semibold text-white">
                  {activeFilterCount}
                </span>
              ) : null}
            </button>
            <PrimaryButton
              icon={<Plus strokeWidth={2.5} />}
              text="Add Job Config"
              type="button"
              className="w-full sm:w-auto"
              onClick={() => {
                setEditingJob(null);
                setIsStepperOpen(true);
              }}
            />
          </div>
        </div>

        <div className="min-w-0">
          <TableLayout<JobItem>
            card={false}
            loading={loading}
            columns={columns}
            dataSource={jobs}
            rowKey="id"
            pagination={false}
          />
        </div>
        <div className="mt-4 flex justify-end">
          <TablePagination
            current={currentPage}
            pageSize={pageSize}
            total={jobsPagination?.total ?? jobs.length}
            onChange={(page, size) => {
              if (size !== pageSize) {
                setPageSize(size);
                setCurrentPage(1);
              } else {
                setCurrentPage(page);
              }
            }}
          />
        </div>
      </section>
      )}

      <DynamicFilterModal
        open={filtersOpen}
        title="Filter jobs"
        variant="drawer"
        width={360}
        fields={filterFields}
        values={draftFilterValues}
        onChange={handleDraftFilterChange}
        onCancel={() => setFiltersOpen(false)}
        onApply={applyFilters}
        onReset={clearFilters}
        applyText="Apply Filters"
        resetText="Reset Filters"
        applyDisabled={!hasDraftFilterValue}
        resetDisabled={!hasDraftFilterValue}
      />

      <JobStepper
        open={isStepperOpen}
        onClose={() => {
          setIsStepperOpen(false);
          setEditingJob(null);
        }}
        documentTypeOptions={documentTypeOptions}
        initialValues={
          editingJob
            ? {
                id: Number(editingJob.id),
                jobName: editingJob.job_name,
                documentCount:
                  editingJob.reference_document_id != null && Number.isFinite(Number(editingJob.reference_document_id))
                    ? 4
                    : Number.isFinite(Number(editingJob.document_count))
                      ? Number(editingJob.document_count)
                      : Math.min(4, Math.max(2, editingJob.document_id?.length ?? 0)),
                documentIds: editingJob.document_id,
                masterDocumentId: editingJob.reference_document_id != null && Number.isFinite(Number(editingJob.reference_document_id))
                  ? Number(editingJob.reference_document_id)
                  : undefined,
              }
            : null
        }
        onDone={async (payload) => {
          if (editingJob?.id) {
            await editJob(
              Number(editingJob.id),
              payload.jobName,
              payload.documentIds,
              payload.documentCount,
              payload.masterDocumentId,
              actor
            );
            message.success('Job updated');
          } else {
            await createJob(
              payload.jobName,
              payload.documentIds,
              payload.documentCount,
              payload.masterDocumentId,
              actor
            );
            message.success('Job created');
          }
        }}
      />

      <DeleteConfirmModal
        open={Boolean(deleteRow)}
        title="Delete Job"
        description="Are you sure you want to delete? This action cannot be undone."
        position={deletePopupPosition}
        loading={deleteLoading}
        onCancel={() => {
          setDeleteRow(null);
        }}
        onConfirm={async () => {
          if (!deleteRow) return;
          setDeleteLoading(true);
          try {
            await deleteJob(Number(deleteRow.id));
            void message.success('Job deleted');
            setDeleteRow(null);
          } catch (e) {
            const errMsg = e instanceof Error ? e.message : 'Failed to delete job';
            void message.error(errMsg);
            // Close the modal after showing the backend warning.
            setDeleteRow(null);
          } finally {
            setDeleteLoading(false);
          }
        }}
        onAfterClose={() => {
          setDeletePopupPosition(undefined);
        }}
      />
    </div>
  );
}
