import { useEffect, useMemo, useState } from 'react';
import { message } from 'antd';
import type { Dayjs } from 'dayjs';
import { Funnel, RefreshCw, Upload } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import RecordsTable, { type ReconcileRecord } from '../../components/ReconcileAgent/RecordsTable';
import DynamicFilterModal, {
  type DynamicFilterField,
  type DynamicFilterValue,
} from '../../components/ui/DynamicFilterModal';
import PageBreadcrumb from '../../components/ui/PageBreadcrumb';
import PrimaryButton from '../../components/ui/PrimaryButton';
import TablePagination from '../../components/ui/TablePagination';
import ListPageTableSkeleton from '../../components/ui/ListPageTableSkeleton';
import { listAllSessions } from '../../services/reconcileSessions';
import { API_URLS } from '../../config/api.config';
import { apiRequest } from '../../services/api';

export interface ReconcileNavigationState {
  newRecord?: {
    id: string;
    jobName: string;
    documentTypes: string[];
    uploadedAt: string;
    reconcileStatus: 'processing';
  };
}

type ListDocumentTypeResponse = {
  result?: Array<Record<string, unknown>>;
};

function toDocumentTypeLabel(name: string): string {
  return name
    .replace(/_/g, ' ')
    .split(' ')
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

// Initial rows removed; data now fully driven from API (list_all_sessions).

export default function ReconcileRecords() {
  const location = useLocation();
  const navigate = useNavigate();
  const incoming = (location.state as ReconcileNavigationState | null)?.newRecord;
  const [rows, setRows] = useState<ReconcileRecord[]>([]);
  const [total, setTotal] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [jobNameFilter, setJobNameFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<'matched' | 'not_matched' | 'failed' | 'validation failed' | undefined>(undefined);
  const [documentTypeFilter, setDocumentTypeFilter] = useState('');
  const [dateFromFilter, setDateFromFilter] = useState<Dayjs | null>(null);
  const [dateToFilter, setDateToFilter] = useState<Dayjs | null>(null);
  const [draftJobNameFilter, setDraftJobNameFilter] = useState('');
  const [draftStatusFilter, setDraftStatusFilter] = useState<'matched' | 'not_matched' | 'failed' | 'validation failed' | undefined>(undefined);
  const [draftDocumentTypeFilter, setDraftDocumentTypeFilter] = useState('');
  const [draftDateFromFilter, setDraftDateFromFilter] = useState<Dayjs | null>(null);
  const [draftDateToFilter, setDraftDateToFilter] = useState<Dayjs | null>(null);
  const [documentTypeOptions, setDocumentTypeOptions] = useState<Array<{ value: string; label: string }>>([]);

  const filterFields = useMemo<DynamicFilterField[]>(
    () => [
      {
        key: 'jobName',
        type: 'input',
        label: 'Job Name',
        placeholder: 'Search by job name...',
      },
      {
        key: 'status',
        type: 'select',
        label: 'Reconcile Status',
        placeholder: 'Select status',
        allowClear: true,
        options: [
          { value: 'matched', label: 'Matched' },
          { value: 'not_matched', label: 'Not Matched' },
          { value: 'failed', label: 'Failed' },
          { value: 'validation failed', label: 'Validation Failed' },
        ],
      },
      {
        key: 'documentType',
        type: 'input',
        label: 'Document Type',
        placeholder: 'Type document type...',
      },
      // {
      //   key: 'fromDate',
      //   type: 'date',
      //   label: 'Date',
      //   placeholder: 'Select Date',
      // },
      // {
      //   key: 'toDate',
      //   type: 'date',
      //   label: 'To Date',
      //   placeholder: 'End Date',
      // },
    ],
    [documentTypeOptions]
  );

  useEffect(() => {
    void (async () => {
      try {
        const res = await apiRequest<ListDocumentTypeResponse, Record<string, string>>(API_URLS.CONFIG, {
          method: 'POST',
          body: { event_type: 'list_document_type' },
        });
        const raw = Array.isArray(res.result) ? res.result : [];
        const seen = new Set<string>();
        const options = raw
          .map((item) => String(item.document_name ?? '').trim())
          .filter(Boolean)
          .filter((name) => {
            const key = name.toLowerCase();
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
          })
          .map((name) => ({ value: name, label: toDocumentTypeLabel(name) }));
        setDocumentTypeOptions(options);
      } catch {
        setDocumentTypeOptions([]);
      }
    })();
  }, []);

  useEffect(() => {
    if (!incoming) return;
    
    // Immediately show the incoming record if it doesn't exist yet
    setRows(prev => {
        const exists = prev.some(r => r.id === incoming.id);
        if (exists) return prev;
        return [incoming as ReconcileRecord, ...prev];
    });

    // Clear navigation state
    navigate(location.pathname, { replace: true });
  }, [incoming, location.pathname, navigate]);



  const activeFilterCount = useMemo(
    () =>
      [jobNameFilter.trim(), statusFilter, documentTypeFilter.trim(), dateFromFilter, dateToFilter].filter(Boolean).length,
    [jobNameFilter, statusFilter, documentTypeFilter, dateFromFilter, dateToFilter]
  );

  const hasDraftFilterValue = useMemo(
    () =>
      [draftJobNameFilter.trim(), draftStatusFilter, draftDocumentTypeFilter.trim(), draftDateFromFilter, draftDateToFilter].some(Boolean),
    [draftJobNameFilter, draftStatusFilter, draftDocumentTypeFilter, draftDateFromFilter, draftDateToFilter]
  );

  const openFilters = () => {
    setDraftJobNameFilter(jobNameFilter);
    setDraftStatusFilter(statusFilter);
    setDraftDocumentTypeFilter(documentTypeFilter);
    setDraftDateFromFilter(dateFromFilter);
    setDraftDateToFilter(dateToFilter);
    setFiltersOpen(true);
  };

  const loadSessions = async (next?: {
    jobName?: string;
    status?: 'matched' | 'not_matched' | 'failed' | 'validation failed' | '';
    documentType?: string;
    fromDate?: Dayjs | null;
    toDate?: Dayjs | null;
    page?: number;
    pageSize?: number;
  }) => {
    const has = (key: string): boolean => Boolean(next && Object.prototype.hasOwnProperty.call(next, key));
    setIsLoading(true);
    try {
      const res = await listAllSessions({
        page: has('page') ? (next?.page ?? 1) : currentPage,
        pageSize: has('pageSize') ? (next?.pageSize ?? 10) : pageSize,
        jobName: has('jobName') ? (next?.jobName ?? '') : jobNameFilter,
        reconcileStatus: has('status') ? String(next?.status ?? '') : statusFilter,
        documentType: has('documentType') ? (next?.documentType ?? '') : documentTypeFilter,
        sessionId: '',
        createdBy: '',
        createdFrom: has('fromDate')
          ? (next?.fromDate?.format('YYYY-MM-DD') ?? '')
          : (dateFromFilter?.format('YYYY-MM-DD') ?? ''),
        createdTo: has('toDate')
          ? (next?.toDate?.format('YYYY-MM-DD') ?? '')
          : (dateToFilter?.format('YYYY-MM-DD') ?? ''),
      });
      setRows(res.rows);
      setTotal(res.total);
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Failed to load sessions';
      message.error(errorMsg);
      setRows([]);
      setTotal(0);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void loadSessions({
      page: currentPage,
      pageSize,
      jobName: jobNameFilter,
      status: statusFilter,
      documentType: documentTypeFilter,
      fromDate: dateFromFilter,
      toDate: dateToFilter,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage, pageSize]);

  const applyFilters = async () => {
    const next = {
      jobName: draftJobNameFilter.trim(),
      status: draftStatusFilter,
      documentType: draftDocumentTypeFilter.trim(),
      fromDate: draftDateFromFilter,
      toDate: draftDateToFilter,
    };
    setJobNameFilter(next.jobName);
    setStatusFilter(next.status);
    setDocumentTypeFilter(next.documentType);
    setDateFromFilter(next.fromDate);
    setDateToFilter(next.toDate);
    setCurrentPage(1);
    await loadSessions({ ...next, page: 1, pageSize });
    setFiltersOpen(false);
  };

  const draftFilterValues = useMemo(
    () => ({
      jobName: draftJobNameFilter,
      status: draftStatusFilter,
      documentType: draftDocumentTypeFilter || undefined,
      fromDate: draftDateFromFilter,
      toDate: draftDateToFilter,
    }),
    [draftJobNameFilter, draftStatusFilter, draftDocumentTypeFilter, draftDateFromFilter, draftDateToFilter]
  );

  const handleDraftFilterChange = (key: string, value: DynamicFilterValue) => {
    if (key === 'jobName') {
      setDraftJobNameFilter(typeof value === 'string' ? value : '');
      return;
    }
    if (key === 'status') {
      setDraftStatusFilter(value === 'matched' || value === 'not_matched' || value === 'failed' || value === 'validation failed' ? value : undefined);
      return;
    }
    if (key === 'documentType') {
      setDraftDocumentTypeFilter(typeof value === 'string' ? value : '');
      return;
    }
    if (key === 'fromDate') {
      setDraftDateFromFilter((value as Dayjs | null | undefined) ?? null);
      return;
    }
    if (key === 'toDate') {
      setDraftDateToFilter((value as Dayjs | null | undefined) ?? null);
    }
  };

  const clearFilters = async () => {
    setDraftJobNameFilter('');
    setDraftStatusFilter(undefined);
    setDraftDocumentTypeFilter('');
    setDraftDateFromFilter(null);
    setDraftDateToFilter(null);
    setJobNameFilter('');
    setStatusFilter(undefined);
    setDocumentTypeFilter('');
    setDateFromFilter(null);
    setDateToFilter(null);
    setCurrentPage(1);
    await loadSessions({
      jobName: '',
      status: '',
      documentType: '',
      fromDate: null,
      toDate: null,
      page: 1,
      pageSize,
    });
    setFiltersOpen(false);
  };

  const filteredRows = useMemo(() => rows, [rows]);
  const showPageSkeleton = isLoading;

  return (
    <div className="flex w-full flex-col gap-4 sm:gap-6">
      <PageBreadcrumb
        items={[
          { title: 'Home', to: '/dashboard' },
          { title: 'Reconcile Agent' },
        ]}
      />

      <div>
        <h1 className="m-0 text-xl font-semibold tracking-tight text-slate-900 sm:text-2xl">
          Reconcile Agent
        </h1>
        <p className="mt-2 mb-0 text-sm leading-6 text-slate-500">
          View uploaded files and reconciliation processing status.
        </p>
      </div>

      {showPageSkeleton ? (
        <ListPageTableSkeleton toolbarButtonCount={3} tableColumns={5} tableRows={pageSize} />
      ) : (
      <section className="rounded-xl border border-slate-200/80 bg-white p-4 shadow-sm sm:p-5 lg:p-6">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="ml-auto flex w-full flex-col items-stretch gap-3 sm:w-auto sm:flex-row sm:flex-wrap sm:items-center sm:justify-end">
          
            <button
              type="button"
              className="relative inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-[10px] border border-[#c8d4e4] bg-white px-4 text-[15px] font-semibold text-slate-700 transition-all duration-200 hover:border-[#1351cd] hover:text-[#1351cd] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1351cd] sm:w-auto"
              onClick={openFilters}
            >
              <Funnel size={16} strokeWidth={2.25} aria-hidden />
              Filter
              {activeFilterCount > 0 ? (
                <span className="absolute -right-2 -top-2 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-[#1351cd] px-1.5 text-[11px] font-semibold text-white">
                  {activeFilterCount}
                </span>
              ) : null}
            </button>
            <button
              type="button"
              className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-[10px] border border-[#c8d4e4] bg-white px-4 text-[15px] font-semibold text-slate-700 transition-all duration-200 hover:border-[#1351cd] hover:text-[#1351cd] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1351cd] sm:w-auto"
              onClick={() => {
                void (async () => {
                  setIsRefreshing(true);
                  try {
                    await loadSessions({
                      page: currentPage,
                      pageSize,
                      jobName: jobNameFilter,
                      status: statusFilter,
                      documentType: documentTypeFilter,
                      fromDate: dateFromFilter,
                      toDate: dateToFilter,
                    });
                  } finally {
                    setIsRefreshing(false);
                  }
                })();
              }}
              disabled={isLoading}
              title="Refresh records"
            >
              <RefreshCw size={16} strokeWidth={2.25} className={isRefreshing ? 'animate-spin' : ''} aria-hidden />
              Refresh
            </button>
            <PrimaryButton
              icon={<Upload strokeWidth={2.5} />}
              text="Reconcile Start"
              className="w-full sm:w-auto"
              onClick={() => navigate('/reconcile-agent/file-upload')}
            />
          </div>
        </div>

        <div className="w-full overflow-x-auto pb-1">
          <div className="min-w-[1120px]">
            <RecordsTable
              rows={filteredRows}
              loading={isLoading}
              onViewSession={(r) =>
                navigate('/reconcile-agent/records/view', { state: { record: r } })
              }
            />
          </div>
        </div>
        <TablePagination
          total={total}
          current={currentPage}
          pageSize={pageSize}
          onChange={(page, nextPageSize) => {
            setCurrentPage(page);
            setPageSize(nextPageSize);
          }}
        />
      </section>
      )}

      <DynamicFilterModal   
        open={filtersOpen}
        title="Filter"
        variant="drawer"
        width={360}
        fields={filterFields}
        values={draftFilterValues}
        onChange={handleDraftFilterChange}
        onCancel={() => setFiltersOpen(false)}
        onApply={() => void applyFilters()}
        onReset={() => void clearFilters()}
        applyText="Apply Filters"
        resetText="Reset Filters"
        applyDisabled={!hasDraftFilterValue}
        resetDisabled={!hasDraftFilterValue}
      />
    </div>
  );
}
