import { useEffect, useMemo, useState } from 'react';
import { message, Select } from 'antd';
import { useLocation, useNavigate } from 'react-router-dom';
import PageBreadcrumb from '../../components/ui/PageBreadcrumb';
import PrimaryButton from '../../components/ui/PrimaryButton';
import FileUploadZone from '../../components/ui/FileUploadZone';
import { listJobs, type JobListItem } from '../../services/jobConfig';
import {
  reconcileDocuments,
  reconcileGenerateUploadUrl,
  type ReconcileDocumentsPayload,
  uploadReconcileFileToPresignedUrl,
} from '../../services/reconcileSessions';
import { validateSinglePageDocument } from '../../utils/pdfSinglePageValidation';
import TokenUsage from '../../components/TokenUsage';
import { useRefreshTokensAfterReconcilePoll } from '../../hooks/useRefreshTokensAfterReconcilePoll';
import type { ReconcileNavigationState } from './ReconcileRecords';

// Inside your component:

function toStartCase(value: string): string {
  return value
    .replace(/_/g, ' ')
    .split(' ')
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

function toUploadLabel(documentName: string): string {
  return `Upload ${toStartCase(documentName)}`;
}

function randomAlphaNumeric(length: number): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let out = '';
  for (let i = 0; i < length; i += 1) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

function createUniqueSessionId(): string {
  return `sess_${randomAlphaNumeric(8)}`;
}

type PrefillState = {
  sessionId: string;
  jobId: number;
  jobName: string;
  originalNames: Record<string, string>;
  s3Uris: Record<string, string>;
};

export default function ReconcileFileUpload() {
  const navigate = useNavigate();
  const location = useLocation();
  const prefill = (location.state as { prefill?: PrefillState } | null)?.prefill ?? null;

  const [jobName, setJobName] = useState<number | undefined>(undefined);
  const [jobOptions, setJobOptions] = useState<JobListItem[]>([]);
  const [jobsLoading, setJobsLoading] = useState(true);
  const [filesByIndex, setFilesByIndex] = useState<Record<number, File | null>>({});
  const [uploadingByIndex, setUploadingByIndex] = useState<Record<number, boolean>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [limitReached, setLimitReached] = useState(false);
  // prefilled names to show in upload boxes (from re-upload)
  const [prefilledNames, setPrefilledNames] = useState<Record<number, string>>({});
  const [prefilledS3UrisByIndex, setPrefilledS3UrisByIndex] = useState<Record<number, string>>({});
  const { scheduleTokenRefreshAfterPoll } = useRefreshTokensAfterReconcilePoll();

  const handleNavigateToRecords = (newRecord?: ReconcileNavigationState['newRecord']) => {
    console.log("Navigating to /reconcile-agent/records", newRecord);
    navigate('/reconcile-agent/records', { state: { newRecord } });
  };

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const data = await listJobs();
        setJobOptions(data);
        // Auto-select job from prefill
        if (prefill?.jobId) {
          const match = data.find((j) => j.id === prefill.jobId);
          if (match) setJobName(match.id);
        }
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : 'Failed to load jobs';
        message.error(errorMsg);
        setJobOptions([]);
      } finally {
        setJobsLoading(false);
      }
    };
    void fetchJobs();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selectedJob = useMemo(
    () => jobOptions.find((job) => job.id === jobName) ?? null,
    [jobName, jobOptions]
  );

  const selectedUploadFields = useMemo(() => {
    if (!selectedJob) return [];
    const fields: Array<{ key: string; label: string }> = [];
    const names = Array.isArray(selectedJob.document_names) ? selectedJob.document_names : [];
    names.forEach((name) => {
      fields.push({ key: String(name), label: toUploadLabel(String(name)) });
    });
    if (selectedJob.reference_document_name) {
      fields.push({
        key: 'reference_document',
        label: toUploadLabel(String(selectedJob.reference_document_name)),
      });
    }
    return fields;
  }, [selectedJob]);

  // When job (and thus upload fields) are ready, map prefilled original names by index
  useEffect(() => {
    if (!prefill || !selectedJob) return;
    const names: Record<number, string> = {};
    const uris: Record<number, string> = {};
    const docNames = Array.isArray(selectedJob.document_names) ? selectedJob.document_names : [];
    
    docNames.forEach((docName, idx) => {
      const key = String(docName).toLowerCase().replace(/\s+/g, '_');
      const match = Object.entries(prefill.originalNames).find(
        ([k]) => k.toLowerCase().replace(/\s+/g, '_') === key
      );
      if (match) {
        names[idx] = match[1];
        const uriMatch = Object.entries(prefill.s3Uris).find(
          ([uk]) => uk.toLowerCase().replace(/\s+/g, '_') === key,
        );
        if (uriMatch) uris[idx] = uriMatch[1];
      }
    });

    // Reference document (last index if present)
    if (selectedJob.reference_document_name) {
      const refIdx = docNames.length;
      const refKey = String(selectedJob.reference_document_name).toLowerCase().replace(/\s+/g, '_');
      const match = Object.entries(prefill.originalNames).find(
        ([k]) => k.toLowerCase().replace(/\s+/g, '_') === refKey
      );
      if (match) {
        names[refIdx] = match[1];
        const uriMatch = Object.entries(prefill.s3Uris).find(
          ([uk]) => uk.toLowerCase().replace(/\s+/g, '_') === refKey,
        );
        if (uriMatch) uris[refIdx] = uriMatch[1];
      }
    }
    setPrefilledNames(names);
    setPrefilledS3UrisByIndex(uris);
  }, [selectedJob, prefill]);

  const allUploadsProvided = useMemo(() => {
    if (!selectedJob) return false;
    // A slot counts as provided if user picked a file OR it has a prefilled name (from re-upload)
    return selectedUploadFields.every(
      (_, index) => Boolean(filesByIndex[index]) || Boolean(prefilledNames[index])
    );
  }, [filesByIndex, selectedJob, selectedUploadFields, prefilledNames]);

  const canSubmit = Boolean(selectedJob && allUploadsProvided && !isSubmitting && !limitReached);
  const uploadCount = selectedUploadFields.length;
  const uploadLocked = isSubmitting || limitReached;
  const uploadGridClass =
    uploadCount <= 2
      ? 'grid-cols-1 md:grid-cols-2'
      : uploadCount === 3
        ? 'grid-cols-1 md:grid-cols-2 xl:grid-cols-3'
        : 'grid-cols-1 md:grid-cols-2 xl:grid-cols-4';

  return (
    <div className="flex w-full flex-col gap-4">
      <TokenUsage onLimitUpdate={setLimitReached} />
      <PageBreadcrumb
        items={[
          { title: 'Home', to: '/dashboard' },
          { title: 'Reconcile Agent', to: '/reconcile-agent/records' },
          { title: 'Reconcile Start' },
        ]}
      />

      <section className="rounded-xl border border-slate-200/80 bg-white p-6 shadow-sm max-md:p-4">
        <div className="space-y-6">
          <div className="max-w-sm space-y-2">
            <label className="text-sm font-semibold text-slate-700" htmlFor="docTypeSelect">
              Job Name
            </label>
            <Select
              id="docTypeSelect"
              placeholder={jobsLoading ? 'Loading jobs...' : 'Select job name'}
              value={jobName}
              loading={jobsLoading}
              disabled={uploadLocked || jobsLoading}
              onChange={(value) => {
                setJobName(value);
                setFilesByIndex({});
                setUploadingByIndex({});
                console.log('Selected job_id:', value);
              }}
              options={jobOptions.map((job) => ({
                value: job.id,
                label: job.job_name,
              }))}
              className="w-full [&_.ant-select-selector]:!h-11 [&_.ant-select-selector]:!items-center [&_.ant-select-selector]:!rounded-lg [&_.ant-select-selector]:!border-slate-300 [&_.ant-select-selector]:!px-2 [&_.ant-select-selection-item]:!leading-[42px] [&_.ant-select-selection-placeholder]:!leading-[42px]"
            />
          </div>

          {selectedJob ? (
            <div className="space-y-4">
              <div className={['grid w-full gap-5', uploadGridClass].join(' ')}>
                {selectedUploadFields.map((field, index) => (
                  <FileUploadZone
                    key={field.key}
                    id={`upload-${index}`}
                    label={field.label}
                    file={filesByIndex[index] ?? null}
                    prefilledName={prefilledNames[index]}
                    isUploading={uploadingByIndex[index]}
                    isLocked={uploadLocked}
                    onValidationError={(msg) => {
                      void message.error(msg);
                    }}
                    onFileSelected={(file) => {
                      setFilesByIndex((prev) => ({ ...prev, [index]: file }));
                    }}
                    onRemove={() => {
                      setFilesByIndex((prev) => ({ ...prev, [index]: null }));
                      setPrefilledNames((prev) => {
                        const next = { ...prev };
                        delete next[index];
                        return next;
                      });
                      setPrefilledS3UrisByIndex((prev) => {
                        const next = { ...prev };
                        delete next[index];
                        return next;
                      });
                    }}
                  />
                ))}
              </div>

              <div className="flex flex-col items-center gap-3">
                <PrimaryButton
                  text={
                    isSubmitting ? (
                      <span className="inline-flex items-center gap-2">
                        <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                        Processing Documents...
                      </span>
                    ) : (
                      'Process Documents'
                    )
                  }
                  disabled={!canSubmit}
                  onClick={async () => {
                    if (!canSubmit || !selectedJob) return;
                  
                    if (!allUploadsProvided) {
                      message.error('Please upload all required documents before processing.');
                      return;
                    }

                    for (let idx = 0; idx < selectedUploadFields.length; idx += 1) {
                      const slotFile = filesByIndex[idx];
                      if (!slotFile) continue;
                      const pageCheck = await validateSinglePageDocument(slotFile);
                      if (!pageCheck.ok) {
                        void message.error(pageCheck.message);
                        return;
                      }
                    }
                  
                    setIsSubmitting(true);

                    let requestFailed = false;
                    try {
                      // Reuse pre-filled session ID if available, otherwise create new
                      const sessionId = prefill?.sessionId || createUniqueSessionId();
                      console.log('Calling reconcile_documents API with session:', sessionId);
                      const documents: Record<string, string> = {};

                      for (let idx = 0; idx < selectedUploadFields.length; idx += 1) {
                        const field = selectedUploadFields[idx];
                        const file = filesByIndex[idx];
                        
                        if (file) {
                          // User uploaded a NEW file for this slot
                          console.log(`Uploading new file for ${field.key}: ${file.name}`);
                          const urlRes = await reconcileGenerateUploadUrl(sessionId, file.name);
                          await uploadReconcileFileToPresignedUrl(urlRes.uploadUrl, file);
                          if (!urlRes.s3Uri) {
                            throw new Error(`Missing s3_uri for ${field.key}`);
                          }
                          documents[field.key] = urlRes.s3Uri;
                        } else if (prefilledS3UrisByIndex[idx]) {
                          // No new file, reuse existing object from session (s3:// URI)
                          console.log(`Using existing pre-filled document for ${field.key}`);
                          documents[field.key] = prefilledS3UrisByIndex[idx];
                        } else {
                          throw new Error(`Missing expected document for ${field.key}`);
                        }
                      }

                      const input: ReconcileDocumentsPayload = {
                        event_type: 'reconcile_documents',
                        job_id: selectedJob.id,
                        session_id: sessionId,
                        created_by: 'admin',
                        documents,
                        module: 'reconcile_agent',
                        type: prefill ? 'reconciliation reupload' : 'reconciliation',
                      };
                      
                      console.log('reconcile_documents input:', input);
                      
                      // Fire and forget the reconciliation process without blocking the UI
                      void reconcileDocuments(input).catch((err) => {
                         console.error('Background reconcile_documents failed:', err);
                      });

                      scheduleTokenRefreshAfterPoll(sessionId);
                     
                      message.success('Reconciliation started successfully. You will be redirected shortly.');
                      
                      const newRecord: ReconcileNavigationState['newRecord'] = {
                         id: sessionId,
                         jobName: selectedJob.job_name,
                         documentTypes: selectedUploadFields.map(f => f.key),
                         uploadedAt: new Date().toISOString(),
                         reconcileStatus: 'processing'
                      };

                      // Wait 5 seconds before routing back
                      setTimeout(() => {
                        handleNavigateToRecords(newRecord);
                      }, 5000);
                      
                    } catch (error) {
                      requestFailed = true;
                      console.error('reconcile_documents failed:', error);
                      message.error('Selection failed. Please try again.');
                    } finally {
                      if (requestFailed) {
                         setIsSubmitting(false);
                      }
                    }
                  }}
                />
                {!allUploadsProvided && (
                  <p className="m-0 text-sm text-slate-500">
                    Please upload all required documents to proceed.
                  </p>
                )}
              </div>
            </div>
          ) : (
            <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 px-4 py-6 text-center text-sm text-slate-500">
              Select a job name to show required uploads.
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
