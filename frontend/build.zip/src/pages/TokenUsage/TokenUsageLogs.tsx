import { useMemo, useState, useEffect } from 'react';
import TableLayout from '../../components/ui/TableLayout/TableLayout';
import type { TableProps } from 'antd';
import { DatePicker, message } from 'antd';
import { Funnel } from 'lucide-react';
import dayjs, { type Dayjs } from 'dayjs';
import DynamicFilterModal, {
  type DynamicFilterField,
  type DynamicFilterValue,
} from '../../components/ui/DynamicFilterModal';
import PageBreadcrumb from '../../components/ui/PageBreadcrumb';
import ListPageTableSkeleton from '../../components/ui/ListPageTableSkeleton';
import TablePagination from '../../components/ui/TablePagination';
import { listTokenUsage, type TokenUsageRecord } from '../../services/tokenUsage';

const { RangePicker } = DatePicker;






export default function TokenUsageLogs() {
  const [isLoading, setIsLoading] = useState(true);
  const [rows, setRows] = useState<TokenUsageRecord[]>([]);
  const [total, setTotal] = useState(0);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Tracks which rows have their Documents list expanded (by row id).
  const [expandedDocs, setExpandedDocs] = useState<Set<string | number>>(new Set());
  const DOCS_PREVIEW_COUNT = 2;

  const [draftSearch, setDraftSearch] = useState('');
  const [draftTypeFilter, setDraftTypeFilter] = useState('');
  const [draftDateRange, setDraftDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);

  const filterFields = useMemo<DynamicFilterField[]>(
    () => [
      {
        key: 'module_name',
        type: 'select',
        label: 'Module',
        placeholder: 'Select module...',
        options: [
          { value: 'doc_type', label: 'Doc Type' },
          { value: 'reconcile_agent', label: 'Reconcile Agent' },
          { value: 'sop_control_center', label: 'Sop Control Center' },
        ],
      },
      {
        key: 'action_performed',
        type: 'select',
        label: 'Action Performed',
        placeholder: 'Select action...',
        options: [
          { value: 'document_testing', label: 'Document Testing' },
          { value: 'ai_key_extraction', label: 'AI Key Extraction' },
          { value: 'reconciliation', label: 'Reconciliation' },
          { value: 'reconciliation_reupload', label: 'Reconciliation Reupload' },
          { value: 'new_sop_testing', label: 'New SOP Testing' },
          { value: 'existing_sop_testing', label: 'Existing SOP Testing' },
          { value: 'sop_version_testing', label: 'SOP Version Testing' },
        ],
      },
    ],
    []
  );

  const draftFilterValues = useMemo(
    () => ({
      module_name: draftSearch,
      action_performed: draftTypeFilter,
    }),
    [draftSearch, draftTypeFilter]
  );

  const handleDraftFilterChange = (key: string, value: DynamicFilterValue) => {
    if (key === 'module_name') {
      setDraftSearch(typeof value === 'string' ? value : '');
    } else if (key === 'action_performed') {
      setDraftTypeFilter(typeof value === 'string' ? value : '');
    }
  };

  const openFilters = () => {
    setDraftSearch(search);
    setDraftTypeFilter(typeFilter);
    setDraftDateRange(dateRange);
    setFiltersOpen(true);
  };

  const hasDraftFilterValue = useMemo(
    () => [draftSearch.trim(), draftTypeFilter.trim(), draftDateRange[0], draftDateRange[1]].some(Boolean),
    [draftSearch, draftTypeFilter, draftDateRange]
  );

  const activeFilterCount = useMemo(
    () => [search.trim(), typeFilter.trim(), dateRange[0]].filter(Boolean).length,
    [search, typeFilter, dateRange]
  );

  const loadLogs = async (params?: {
    page?: number;
    pageSize?: number;
    module?: string;
    type?: string;
    startDate?: string;
    endDate?: string;
  }) => {
    setIsLoading(true);
    try {
      const res = await listTokenUsage({
        page: params?.page ?? currentPage,
        pageSize: params?.pageSize ?? pageSize,
        module: params?.module ?? search,
        type: params?.type ?? typeFilter,
        startDate: params?.startDate ?? dateRange[0]?.format('YYYY-MM-DD'),
        endDate: params?.endDate ?? dateRange[1]?.format('YYYY-MM-DD'),
      });
      setRows(res.rows);
      setTotal(res.total);
    } catch (error) {
      console.error('Failed to load token usage logs:', error);
      message.error('Failed to load logs. Please try again.');
      setRows([]);
      setTotal(0);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void loadLogs({ page: currentPage, pageSize });
  }, [currentPage, pageSize]);

  const applyFilters = async () => {
    const nextSearch = draftSearch.trim();
    const nextType = draftTypeFilter.trim();
    const nextRange = draftDateRange;

    setSearch(nextSearch);
    setTypeFilter(nextType);
    setDateRange(nextRange);
    setCurrentPage(1);

    await loadLogs({
      page: 1,
      module: nextSearch,
      type: nextType,
      startDate: nextRange[0]?.format('YYYY-MM-DD') || '',
      endDate: nextRange[1]?.format('YYYY-MM-DD') || '',
    });
    setFiltersOpen(false);
  };

  const clearFilters = async () => {
    setDraftSearch('');
    setDraftTypeFilter('');
    setDraftDateRange([null, null]);

    setSearch('');
    setTypeFilter('');
    setDateRange([null, null]);
    setCurrentPage(1);

    await loadLogs({ page: 1, module: '', type: '', startDate: '', endDate: '' });
    setFiltersOpen(false);
  };

  const toggleDocExpand = (id: string | number) => {
    setExpandedDocs((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const columns: TableProps<TokenUsageRecord>['columns'] = useMemo(() => [
    {
      title: 'Created At',
      dataIndex: 'created_at',
      key: 'created_at',
      className: 'whitespace-nowrap',
      render: (val: string) => dayjs(val).format('MMM DD, YYYY, h:mm A'),
      sorter: (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime(),
    },
    {
      title: 'Module',
      dataIndex: 'module',
      key: 'module',
      width: 180,
      className: 'whitespace-nowrap',
      render: (val: string) => {
        const getModuleStyles = (module: string) => {
          const m = module.toLowerCase();
          if (m.includes('reconcile')) {
            return 'bg-blue-50 text-blue-700 border-blue-200';
          }
          if (m.includes('doc')) {
            return 'bg-amber-50 text-amber-700 border-amber-200';
          }
          if (m.includes('sop') || m.includes('editor')) {
            return 'bg-emerald-50 text-emerald-700 border-emerald-200';
          }
          return 'bg-slate-50 text-slate-700 border-slate-200';
        };

        return (
          <span
            className={`inline-flex items-center rounded-full border px-3 py-0.5 text-[13px] font-semibold capitalize ${getModuleStyles(val)}`}
          >
            {val.replace(/_/g, ' ')}
          </span>
        );
      },
    },
    {
      title: 'Action Performed',
      dataIndex: 'type',
      key: 'type',
      className: 'whitespace-nowrap',
      render: (val: string) => (
        <span className="capitalize">{val.replace(/_/g, ' ')}</span>
      ),
    },
    {
      title: 'Documents',
      dataIndex: 'documents',
      key: 'documents',
      render: (docs: string[], record) => {
        const isExpanded = expandedDocs.has(record.id);
        const visible = isExpanded ? docs : docs.slice(0, DOCS_PREVIEW_COUNT);
        const hasMore = docs.length > DOCS_PREVIEW_COUNT;
        return (
          <div className="flex flex-wrap gap-2">
            {visible.map((doc) => (
              <span
                key={doc}
                className="inline-flex items-center rounded-[8px] bg-[#e6f4ff] px-3 py-1 text-[13px] font-medium text-[#0066cc] transition-colors hover:bg-[#bae0ff]"
              >
                {doc.replace(/_[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(\.[^.]+)$/i, '$1').toLowerCase()}
              </span>
            ))}
            {hasMore && (
              <button
                type="button"
                onClick={() => toggleDocExpand(record.id)}
                className="inline-flex items-center rounded-[8px] border border-slate-200 bg-slate-50 px-3 py-1 text-[13px] font-medium text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-700"
              >
                {isExpanded ? 'Show less' : `+${docs.length - DOCS_PREVIEW_COUNT} more`}
              </button>
            )}
          </div>
        );
      },
    },
    {
      title: 'Input Tokens',
      dataIndex: 'input_tokens',
      key: 'input_tokens',
      align: 'right',
      render: (val: number) => new Intl.NumberFormat('en-US').format(val),
      sorter: (a, b) => a.input_tokens - b.input_tokens,
    },
    {
      title: 'Output Tokens',
      dataIndex: 'output_tokens',
      key: 'output_tokens',
      align: 'right',
      render: (val: number) => new Intl.NumberFormat('en-US').format(val),
      sorter: (a, b) => a.output_tokens - b.output_tokens,
    },
    {
      title: 'Total Tokens',
      dataIndex: 'total_tokens',
      key: 'total_tokens',
      align: 'right',
      render: (val: number) => (
        <span className="font-semibold text-slate-800">
          {new Intl.NumberFormat('en-US').format(val)}
        </span>
      ),
      sorter: (a, b) => a.total_tokens - b.total_tokens,
    },
  ], [expandedDocs, toggleDocExpand]);

  return (
    <div className="flex flex-col gap-6">
      {/* Header Area */}
      <PageBreadcrumb
        items={[
          { title: 'Home', to: '/dashboard' },
          { title: 'Token Usage Logs' },
        ]}
      />

      <div>
        <h1 className="m-0 text-xl font-semibold tracking-tight text-slate-900 sm:text-2xl">
          Token Usage Logs
        </h1>
        <p className="mt-2 mb-0 text-sm leading-6 text-slate-500">
          Monitor your API token consumption across modules.
        </p>
      </div>

      {/* Table section */}
      {isLoading ? (
        <ListPageTableSkeleton toolbarButtonCount={2} tableColumns={5} tableRows={8} />
      ) : (
        <section className="rounded-xl border border-slate-200/80 bg-white p-6 shadow-sm max-md:p-4">
          <div className="mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="ml-auto flex w-full flex-col items-stretch gap-3 sm:w-auto sm:flex-row sm:flex-wrap sm:items-center sm:justify-end">
              <button
                type="button"
                className="relative inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-[10px] border border-[#c8d4e4] bg-white px-4 text-[15px] font-semibold text-slate-700 transition-all duration-200 hover:border-[#1351cd] hover:text-[#1351cd] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1351cd] sm:w-auto"
                onClick={openFilters}
              >
                <Funnel size={16} strokeWidth={2.25} aria-hidden />
                Filter
                {activeFilterCount > 0 ? (
                  <span className="absolute -right-2 -top-2 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-[#1351cd] px-1.5 text-[11px] font-semibold text-white">
                    {activeFilterCount}
                  </span>
                ) : null}
              </button>

            </div>
          </div>

          <div className="min-w-0 pb-1">
            <TableLayout<TokenUsageRecord>
              card={false}
              columns={columns}
              dataSource={rows}
              rowKey="id"
              pagination={false}
              size="middle"
              loading={isLoading}
            />
          </div>

          <TablePagination
            total={total}
            current={currentPage}
            pageSize={pageSize}
            onChange={(page, nextSize) => {
              setCurrentPage(page);
              setPageSize(nextSize);
            }}
          />
        </section>
      )}

      <DynamicFilterModal
        open={filtersOpen}
        title="Filter Token Usage"
        variant="drawer"
        width={360}
        fields={filterFields}
        values={draftFilterValues}
        onChange={handleDraftFilterChange}
        onCancel={() => setFiltersOpen(false)}
        onApply={applyFilters}
        onReset={clearFilters}
        applyText="Apply Filters"
        resetText="Reset Filters"
        applyDisabled={!hasDraftFilterValue}
        resetDisabled={!hasDraftFilterValue}
        extraContent={
          <div className="flex flex-col gap-1.5">
            <label className="text-[13px] font-semibold text-slate-700">Date Range</label>
            <RangePicker
              value={draftDateRange}
              onChange={(vals) =>
                setDraftDateRange(vals ? [vals[0] ?? null, vals[1] ?? null] : [null, null])
              }
              format="YYYY-MM-DD"
              allowClear
              disabledDate={(d) => d.isAfter(dayjs(), 'day')}
              className="w-full"
              placeholder={['Start date', 'End date']}
            />
          </div>
        }
      />
    </div>
  );
}
