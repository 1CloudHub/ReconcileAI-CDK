import { useEffect, useMemo, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip as RechartsTooltip,
  XAxis,
  YAxis
} from 'recharts';
import { message } from 'antd';
import dayjs from 'dayjs';
import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import DatePickerInput from '../components/ui/DatePickerInput';
import DashboardSkeleton from '../components/ui/DashboardSkeleton';
import {
  fetchDashboardKpiCards,
  fetchDayWiseReconciliationBreakdown,
  fetchReconciliationSummary,
  type DashboardKpiCards,
  type DayWiseBreakdownItem,
  fetchTopJobsByDocuments,
  type TopJobByDocuments,
} from '../services/dashboardapi';

type TrendPoint = { label: string; matched: number; mismatched: number };

type KpiCard = {
  label: string;
  value: string;
  trend?: string;
  positive?: boolean;
};

const piePalette = ['#0B3A99', '#0F4BC5', '#1D5ED8', '#2A72E5', '#4A8FF2'];

const cardShell =
  'rounded-xl border border-slate-200/80 bg-white p-5 shadow-[0_2px_8px_rgba(0,0,0,0.06)]';

function formatCount(value: number): string {
  return value.toLocaleString();
}

export default function Dashboard() {
  const [selectedMonth, setSelectedMonth] = useState(() => dayjs());

  // ── Loading states ────────────────────────────────────────────────────────
  const [summaryLoading, setSummaryLoading] = useState(true);
  const [dayWiseLoading, setDayWiseLoading] = useState(true);

  // ── Data states ───────────────────────────────────────────────────────────
  const [kpiCardsData, setKpiCardsData] = useState<DashboardKpiCards>({
    totalReconciliations: 0,
    totalJobs: 0,
    totalSops: 0,
    totalDocuments: 0,
  });
  const [reconciliationSummary, setReconciliationSummary] = useState<
    { month: string; matched: number; mismatched: number }[]
  >([]);
  const [topJobsByFilesData, setTopJobsByFilesData] = useState<TopJobByDocuments[]>([]);
  const [dayWiseData, setDayWiseData] = useState<DayWiseBreakdownItem[]>([]);

  useEffect(() => {
    window.scrollTo(0, 0);
    const main = document.querySelector('main');
    if (main) main.scrollTo(0, 0);
  }, []);

  // ── Summary + KPI fetch ───────────────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;
    setSummaryLoading(true);
    const date = selectedMonth.format('MM-YYYY');

    void Promise.all([
      fetchDashboardKpiCards(date),
      fetchReconciliationSummary(date),
      fetchTopJobsByDocuments(date),
    ])
      .then(([kpi, summary, topJobs]) => {
        if (cancelled) return;
        setKpiCardsData(kpi);
        setReconciliationSummary(summary);
        setTopJobsByFilesData(topJobs);
      })
      .catch((e) => {
        if (cancelled) return;
        const msg = e instanceof Error ? e.message : 'Failed to load dashboard summary';
        message.error(msg);
      })
      .finally(() => {
        if (!cancelled) setSummaryLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [selectedMonth]);

  // ── Day-wise fetch ────────────────────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;
    setDayWiseLoading(true);
    const date = selectedMonth.format('MM-YYYY');

    void fetchDayWiseReconciliationBreakdown(date)
      .then((data) => {
        if (cancelled) return;
        setDayWiseData(data);
      })
      .catch((e) => {
        if (cancelled) return;
        const msg = e instanceof Error ? e.message : 'Failed to load day-wise breakdown';
        message.error(msg);
      })
      .finally(() => {
        if (!cancelled) setDayWiseLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [selectedMonth]);

  // ── Derived data ──────────────────────────────────────────────────────────
  const trendData = useMemo<TrendPoint[]>(
    () =>
      reconciliationSummary.map((item) => ({
        label: item.month,
        matched: item.matched,
        mismatched: item.mismatched,
      })),
    [reconciliationSummary]
  );

  const dayWiseChartData = useMemo(() => {
    const daysInMonth = selectedMonth.daysInMonth();
    const lookup = new Map(dayWiseData.map((item) => [item.day, item]));
    return Array.from({ length: daysInMonth }, (_, i) => {
      const day = selectedMonth.date(i + 1).format('DD-MM-YYYY');
      const item = lookup.get(day);
      return { label: day, matched: item?.matched ?? 0, mismatched: item?.mismatched ?? 0 };
    });
  }, [dayWiseData, selectedMonth]);

  const kpiCards = useMemo<KpiCard[]>(
    () => [
      { label: 'Reconciliations Ran', value: formatCount(kpiCardsData.totalReconciliations) },
      { label: 'Job Count', value: formatCount(kpiCardsData.totalJobs) },
      { label: 'SOP Count', value: formatCount(kpiCardsData.totalSops) },
      { label: 'Documents Processed', value: formatCount(kpiCardsData.totalDocuments) },
    ],
    [kpiCardsData]
  );

  const topJobsByFiles = useMemo(() => topJobsByFilesData.slice(0, 5), [topJobsByFilesData]);

  // ── Show skeleton for cards/charts while header remains visible ───────────
  const isLoading = summaryLoading || dayWiseLoading;

  // ── Actual dashboard ──────────────────────────────────────────────────────
  return (
    <div className="flex w-full flex-col gap-3">
      <header className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 flex-1">
          <h1 className="m-0 text-2xl font-semibold tracking-tight text-slate-900">
            Reconciliation Dashboard
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Monitor run volume, quality, and operational readiness.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <DatePickerInput
            picker="month"
            value={selectedMonth}
            onChange={(date) =>
              setSelectedMonth(Array.isArray(date) ? dayjs() : (date ?? dayjs()))
            }
            disabledDate={(current) => Boolean(current && current.isAfter(dayjs(), 'month'))}
            placeholder="Select month"
            format="MMM YYYY"
          />
        </div>
      </header>

      {isLoading ? (
        <DashboardSkeleton />
      ) : (
        <>
          {/* KPI Cards */}
          <section className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {kpiCards.map((card) => (
              <article key={card.label} className={cardShell}>
                <p className="text-[13px] font-medium text-slate-500">{card.label}</p>
                <div className="mt-2 flex items-center gap-2">
                  <p className="m-0 text-2xl font-semibold text-slate-900">{card.value}</p>
                  {card.trend && (
                    <span
                      className={`inline-flex items-center gap-1 text-xs font-semibold ${
                        card.positive ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      {card.positive ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                      {card.trend}
                    </span>
                  )}
                </div>
              </article>
            ))}
          </section>

          {/* Charts row */}
          <section className="grid grid-cols-1 gap-3 xl:grid-cols-2">
            {/* Bar chart */}
            <div className={cardShell}>
              <h3 className="mb-2 text-base font-semibold text-slate-900">
                3-Month Reconciliation Trend
              </h3>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={trendData} barCategoryGap="30%">
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                  <XAxis
                    dataKey="label"
                    tick={{ fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                  <RechartsTooltip cursor={{ fill: 'rgba(0,0,0,0.04)' }} />
                  <Legend
                    formatter={(value) => <span style={{ color: '#000000' }}>{value}</span>}
                  />
                  <Bar
                    dataKey="matched"
                    name="Matched"
                    stackId="a"
                    fill="#2563eb"
                    radius={[0, 0, 0, 0]}
                  />
                  <Bar
                    dataKey="mismatched"
                    name="Mismatched"
                    stackId="a"
                    fill="#93c5fd"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Pie chart */}
            <div className={cardShell}>
              <h3 className="mb-2 text-base font-semibold text-slate-900">Most Active Jobs</h3>
              <div className="grid grid-cols-1 gap-4 lg:grid-cols-[1fr_1fr]">
                <ResponsiveContainer width="100%" height={240}>
                  <PieChart>
                    <RechartsTooltip
                      formatter={(value, name) => {
                        const n = Number(value);
                        const uploaded =
                          n === 1
                            ? `${formatCount(n)} file uploaded`
                            : `${formatCount(n)} files uploaded`;
                        return [uploaded, String(name ?? '')];
                      }}
                    />
                    <Pie
                      data={topJobsByFiles}
                      dataKey="count"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={86}
                      innerRadius={44}
                      paddingAngle={2}
                    >
                      {topJobsByFiles.map((entry, index) => (
                        <Cell
                          key={`${entry.name}-${index}`}
                          fill={piePalette[index % piePalette.length]}
                        />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex flex-col gap-1">
                  {topJobsByFiles.map((item, index) => (
                    <div
                      key={item.name}
                      className="flex items-center justify-between px-1 py-0.5"
                    >
                      <div className="flex min-w-0 items-center gap-2">
                        <span
                          className="inline-block h-1.5 w-1.5 shrink-0 rounded-full"
                          style={{ backgroundColor: piePalette[index % piePalette.length] }}
                        />
                        <span
                          className="truncate text-[11px] text-slate-700"
                          title={item.name}
                        >
                          {item.name}
                        </span>
                      </div>
                      <span className="ml-3 shrink-0 text-[11px] font-semibold text-slate-900">
                        {formatCount(item.count)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* Day-wise line chart */}
          <section className={cardShell}>
            <h3 className="mb-2 text-base font-semibold text-slate-900">
              Day-wise Reconciliation Breakdown
            </h3>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={dayWiseChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                  angle={-45}
                  textAnchor="end"
                  height={54}
                  interval={0}
                />
                {/* <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} /> */}
                <YAxis
  tick={{ fontSize: 12 }}
  axisLine={false}
  tickLine={false}
  tickFormatter={(value: number) => Math.floor(value).toString()}
/>
                <RechartsTooltip />
                <Legend
                  formatter={(value) => <span style={{ color: '#000000' }}>{value}</span>}
                />
                <Line
                  type="monotone"
                  dataKey="matched"
                  name="Matched"
                  stroke="#2563eb"
                  strokeWidth={2.5}
                  dot={{ r: 3, stroke: '#2563eb', fill: '#ffffff', strokeWidth: 2 }}
                  activeDot={{ r: 5 }}
                />
                <Line
                  type="monotone"
                  dataKey="mismatched"
                  name="Mismatched"
                  stroke="#93c5fd"
                  strokeWidth={2.5}
                  dot={{ r: 3, stroke: '#93c5fd', fill: '#ffffff', strokeWidth: 2 }}
                  activeDot={{ r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </section>
        </>
      )}
    </div>
  );
}