import React from 'react';
import { Mail, Lock, ArrowRight, Check, X } from 'lucide-react';
import { motion } from 'framer-motion';
import loginLogo from '../assets/Blue ReconcileAI logo.png';
import { useLogin } from '../hooks/useLogin';
import Input from '../components/ui/Input';

export default function Login() {
  const {
    currentStep,
    formData,
    isLoading,
    error,
    fieldErrors,
    otpTimer,
    otpVerified,
    otpInputRefs,
    messageContextHolder,
    passwordRequirements,
    allRequirementsMet,
    handleInputChange,
    handleOtpChange,
    handleOtpKeyDown,
    handlePasteOtp,
    formatTimer,
    handleSubmit,
    handleForgotPassword,
    handleResendOtp,
    handleResetPassword,
    goToLoginStep,
  } = useLogin();

  const renderHeader = (title: string, subtitle: string) => (
    <div className="text-center mb-7">
      <div className="flex justify-center items-center mb-5">
        <img src={loginLogo} alt="ReconcileAI" className="h-11 w-auto object-contain max-w-[210px]" />
      </div>
      <h1 className="text-[23px] font-bold text-gray-900 tracking-tight leading-tight mb-1.5">{title}</h1>
      <p className="text-[14px] text-gray-500 leading-relaxed max-w-[330px] mx-auto">{subtitle}</p>
    </div>
  );

  const renderSubmitButton = (label: React.ReactNode, disabled = false) => (
    <button
      type="submit"
      disabled={disabled || isLoading}
      className="relative overflow-hidden mt-2 min-h-[46px] bg-[#1351cd] text-white border-none rounded-[10px] px-6 text-[15px] font-semibold cursor-pointer flex items-center justify-center gap-2 tracking-wide shadow-[0_1px_3px_rgba(19,81,205,0.25)] transition-all duration-200 hover:enabled:bg-[#0f45b0] hover:enabled:-translate-y-px hover:enabled:shadow-[0_4px_12px_rgba(19,81,205,0.35)] active:enabled:translate-y-0 disabled:opacity-60 disabled:cursor-not-allowed group"
    >
      <span className="absolute top-0 left-[-100%] w-full h-full bg-gradient-to-r from-transparent via-white/15 to-transparent transition-[left] duration-500 group-hover:left-full" />
      {isLoading ? <div className="w-5 h-5 border-2 border-transparent border-t-white rounded-full animate-spin" /> : label}
    </button>
  );

  const renderError = () =>
    error ? (
      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-[10px] text-sm font-medium leading-snug">
        {error}
      </div>
    ) : null;

  const renderLoginScreen = () => (
    <>
      {renderHeader('Sign in with email', 'Access your account to manage your ERP exceptions and reconciliation workflows')}

      <form noValidate onSubmit={handleSubmit} className="flex flex-col gap-5">
        <Input
          label="Email"
          type="email"
          id="email"
          name="email"
          value={formData.email}
          onChange={handleInputChange}
          placeholder="Enter your email"
          icon={<Mail size={17} />}
          required
          error={fieldErrors.email}
          autoComplete="email"
        />

        <Input
          label="Password"
          type="password"
          id="password"
          name="password"
          value={formData.password}
          onChange={handleInputChange}
          placeholder="Enter your password"
          icon={<Lock size={17} />}
          required
          minLength={8}
          error={fieldErrors.password}
          autoComplete="current-password"
        />

        {renderError()}
        {renderSubmitButton('Get Started')}
      </form>
    </>
  );

  const renderForgotPasswordScreen = () => (
    <>
      {renderHeader('Forgot Password', 'Enter your email to receive a password reset link')}

      <form onSubmit={handleForgotPassword} className="flex flex-col gap-5">
        <Input
          label="Email Address"
          type="email"
          id="forgot-email"
          name="email"
          value={formData.email}
          onChange={handleInputChange}
          placeholder="admin@teamedsg.com"
          icon={<Mail size={17} />}
          required
        />

        {renderError()}

        <div className="flex justify-start mt-1 mb-1">
          <a
            href="#"
            className="text-[13px] font-medium text-gray-500 no-underline hover:text-[#1351cd] hover:underline transition-colors"
            onClick={(e) => { e.preventDefault(); goToLoginStep(); }}
          >
            Back to login
          </a>
        </div>

        {renderSubmitButton(<>Send Reset Link <ArrowRight size={17} /></>)}
      </form>
    </>
  );

  const renderOtpScreen = () => (
    <>
      {renderHeader('Reset Password', 'Enter the 6-digit OTP sent to your email')}

      <form onSubmit={handleResetPassword} className="flex flex-col gap-5">
        {/* OTP boxes */}
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-semibold text-gray-800">
            Enter Your 6-Digit OTP <span className="text-red-600 ml-0.5">*</span>
          </label>
          <div className="flex items-center justify-center gap-2 mb-3">
            {formData.otp.map((digit, index) => (
              <React.Fragment key={index}>
                {index === 3 && <span className="text-xl font-semibold text-gray-400 mx-1">-</span>}
                <input
                  ref={(el) => { otpInputRefs.current[index] = el; }}
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleOtpChange(index, e.target.value)}
                  onKeyDown={(e) => handleOtpKeyDown(index, e)}
                  onPaste={index === 0 ? handlePasteOtp : undefined}
                  className="w-12 h-[52px] text-center text-[22px] font-semibold border border-[#dde3f0] rounded-[10px] bg-[#EEF2FF] text-gray-900 transition-all duration-200 focus:outline-none focus:border-[#1351cd] focus:bg-white focus:ring-[3px] focus:ring-[rgba(0,75,145,0.12)]"
                  required
                />
              </React.Fragment>
            ))}
          </div>
          <div className="flex justify-between items-center mt-1">
            <span className="text-[13px] text-gray-500">Resend OTP in: {formatTimer(otpTimer)}</span>
            {otpTimer === 0 && (
              <a
                href="#"
                className="text-[13px] font-medium text-[#0066CC] no-underline hover:text-[#1351cd] hover:underline transition-colors"
                onClick={(e) => { e.preventDefault(); handleResendOtp(); }}
              >
                Resend OTP
              </a>
            )}
          </div>
        </div>

        {/* New + confirm password (after OTP verified) */}
        {otpVerified && (
          <>
            <Input
              label="New Password"
              type="password"
              id="new-password"
              name="newPassword"
              value={formData.newPassword}
              onChange={handleInputChange}
              placeholder="Enter new password"
              icon={<Lock size={17} />}
              required
              minLength={6}
            />

            <Input
              label="Confirm New Password"
              type="password"
              id="confirm-password"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleInputChange}
              placeholder="Confirm new password"
              icon={<Lock size={17} />}
              required
              minLength={6}
            />

            {/* Password requirements */}
            <div className={`mt-2 px-3 py-2.5 rounded-lg text-[13px] transition-all duration-300 ${allRequirementsMet ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
              <div className={`font-semibold text-sm mb-2 ${allRequirementsMet ? 'text-green-700' : 'text-red-600'}`}>
                Password Requirements:
              </div>
              <div className="flex flex-col gap-1.5">
                {[
                  { met: passwordRequirements.minLength, label: 'At least 6 characters long' },
                  { met: passwordRequirements.hasUpperCase && passwordRequirements.hasLowerCase, label: 'Contains uppercase and lowercase letters' },
                  { met: passwordRequirements.hasNumber, label: 'Contains at least one number' },
                  { met: passwordRequirements.hasSpecialChar, label: 'Contains at least one special character' },
                ].map(({ met, label }) => (
                  <div key={label} className={`flex items-center gap-2 ${allRequirementsMet ? 'text-green-800' : 'text-red-800'}`}>
                    {met
                      ? <Check size={16} className="text-green-600 shrink-0" />
                      : <X size={16} className="text-red-500 shrink-0" />}
                    <span>{label}</span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {renderError()}
        {renderSubmitButton(<>Reset Password <ArrowRight size={17} /></>, !otpVerified || formData.otp.join('').length !== 6)}
      </form>
    </>
  );

  return (
    <>
      {messageContextHolder}
      <main className="min-h-screen flex items-center justify-center px-5 py-6 relative overflow-hidden bg-[#1351cd]" aria-label="Sign in">
        {/* Wave layers */}
        <div className="absolute left-0 right-0 bottom-0 pointer-events-none h-[45vh] z-0" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320' preserveAspectRatio='none'%3E%3Cpath fill='rgba(255,255,255,0.03)' d='M0,192L48,197.3C96,203,192,213,288,229.3C384,245,480,267,576,250.7C672,235,768,181,864,181.3C960,181,1056,235,1152,234.7C1248,235,1344,181,1392,154.7L1440,128L1440,320L0,320Z'/%3E%3C/svg%3E")`, backgroundSize: '160% 100%', backgroundPosition: 'bottom center', backgroundRepeat: 'repeat-x', WebkitMaskImage: 'linear-gradient(to top, black 60%, transparent 100%)', maskImage: 'linear-gradient(to top, black 60%, transparent 100%)' }} />
        <div className="absolute left-0 right-0 bottom-0 pointer-events-none h-[30vh] z-0" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320' preserveAspectRatio='none'%3E%3Cpath fill='rgba(255,255,255,0.08)' d='M0,128L48,144C96,160,192,192,288,186.7C384,181,480,139,576,133.3C672,128,768,160,864,176C960,192,1056,192,1152,176C1248,160,1344,128,1392,112L1440,96L1440,320L0,320Z'/%3E%3C/svg%3E")`, backgroundSize: '160% 100%', backgroundPosition: 'bottom center', backgroundRepeat: 'repeat-x', WebkitMaskImage: 'linear-gradient(to top, black 70%, transparent 100%)', maskImage: 'linear-gradient(to top, black 70%, transparent 100%)' }} />

        <motion.div
          className="bg-white rounded-2xl shadow-[0_4px_6px_-1px_rgba(0,0,0,0.06),0_10px_40px_-4px_rgba(0,0,0,0.1),0_0_0_1px_rgba(0,0,0,0.04)] px-10 py-12 w-full max-w-[440px] relative z-[1]"
          role="article"
          aria-label="Sign in form"
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0, transition: { duration: 0.5, ease: [0.4, 0, 0.2, 1] } }}
          exit={{ opacity: 0, scale: 0.9, y: -20, transition: { duration: 0.3 } }}
        >
          {currentStep === 'login' && renderLoginScreen()}
          {currentStep === 'forgot' && renderForgotPasswordScreen()}
          {currentStep === 'otp' && renderOtpScreen()}
        </motion.div>
      </main>
    </>
  );
}
