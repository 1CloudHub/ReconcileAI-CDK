import { useCallback, useEffect, useMemo, useState } from 'react';
import type { TableColumnsType } from 'antd';
import type { UploadFile } from 'antd/es/upload/interface';
import { message, Modal } from 'antd';
import dayjs from 'dayjs';
import type { Dayjs } from 'dayjs';
import { Funnel, Plus, Pencil } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import DeleteConfirmModal from '../../components/ui/DeleteConfirmModal';
import DynamicFilterModal, {
  type DynamicFilterField,
  type DynamicFilterValue,
} from '../../components/ui/DynamicFilterModal';
import PageBreadcrumb from '../../components/ui/PageBreadcrumb';
import PrimaryButton from '../../components/ui/PrimaryButton';
import SecondaryButton from '../../components/ui/SecondaryButton';
import TablePagination from '../../components/ui/TablePagination';
import ListPageTableSkeleton from '../../components/ui/ListPageTableSkeleton';
import {
  TableLayout,
  createActionsColumn,
} from '../../components/ui/TableLayout';
import { fetchSops, deleteSop, listJobs, type SopApiEnvelope, type JobOption } from '../../services/SOP_config';
import { getCookie } from '../../utils/cookies';

type SopExceptionRow = {
  id: string;
  /** Numeric id for delete/update API when present */
  sopId?: number;
  createdAt: string;
  sopName: string;
  exceptionName: string;
  jobName: string;
  /** All job ids from list payload (for SopEditor pre-fill). */
  jobIds: number[];
  /** All job display names from list payload (fallback when ids not in job catalog). */
  jobNames: string[];
  uploadedFile?: UploadFile;
};

function collectSopJobIds(item: Record<string, unknown>): number[] {
  const raw = item.job_id ?? item.job_ids;
  if (Array.isArray(raw)) {
    return raw.map((x) => Number(x)).filter((n) => Number.isFinite(n));
  }
  if (typeof raw === 'number' && Number.isFinite(raw)) return [raw];
  const jobs = item.jobs;
  if (Array.isArray(jobs)) {
    const ids: number[] = [];
    for (const j of jobs) {
      if (isRecord(j)) {
        const id = Number(j.id ?? j.job_id);
        if (Number.isFinite(id)) ids.push(id);
      }
    }
    return ids;
  }
  return [];
}

function collectSopJobNamesList(item: Record<string, unknown>, primaryJobName: string): string[] {
  const jn = item.job_names;
  if (Array.isArray(jn) && jn.length > 0) {
    return jn.map((x) => String(x).trim()).filter(Boolean);
  }
  if (primaryJobName.trim()) return [primaryJobName.trim()];
  const jobs = item.jobs;
  if (Array.isArray(jobs)) {
    const names: string[] = [];
    for (const j of jobs) {
      if (isRecord(j)) {
        const n = String(j.job_name ?? j.name ?? j.label ?? '').trim();
        if (n) names.push(n);
      }
    }
    if (names.length) return names;
  }
  return [];
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null;
}

function updatedByFromSession(user: { email: string; name?: string } | null): string {
  if (user?.email) return user.email;
  if (user?.name) return user.name;
  return getCookie('userlogin')?.trim() || 'admin';
}

/** Numeric `id` from list_sops / fetch_sop `data[]` — sent as `sop_id` on update_sop. */
function pickSopNumericId(item: Record<string, unknown>): number | undefined {
  const candidates = [item.id, item.sop_id, item.sopId];
  for (const c of candidates) {
    if (typeof c === 'number' && Number.isFinite(c)) return c;
    if (typeof c === 'string' && c.trim() !== '') {
      const n = Number(c);
      if (Number.isFinite(n)) return n;
    }
  }
  return undefined;
}

function extractSopList(res: SopApiEnvelope): Record<string, unknown>[] {
  const body = isRecord(res.body) ? res.body : undefined;
  if (isRecord(body) && Array.isArray(body.data)) return body.data as Record<string, unknown>[];
  if (Array.isArray(res.sops)) return res.sops as Record<string, unknown>[];
  if (Array.isArray(res.result)) return res.result as Record<string, unknown>[];
  if (Array.isArray(res.data)) return res.data as Record<string, unknown>[];
  const data = res.data;
  if (isRecord(data) && Array.isArray(data.sops)) return data.sops as Record<string, unknown>[];
  if (isRecord(data) && Array.isArray(data.items)) return data.items as Record<string, unknown>[];
  return [];
}

function extractTotal(res: SopApiEnvelope, listLen: number): number {
  const body = isRecord(res.body) ? res.body : undefined;
  const bodyPagination = isRecord(body?.pagination) ? body.pagination : undefined;
  const pagination = isRecord(res.pagination) ? res.pagination : undefined;
  const candidates = [
    bodyPagination?.total_count,
    bodyPagination?.total,
    res.total,
    res.total_count,
    pagination?.total,
    (res as { page_total?: unknown }).page_total,
  ];
  for (const t of candidates) {
    const n = typeof t === 'number' ? t : typeof t === 'string' ? Number(t) : NaN;
    if (Number.isFinite(n)) return n;
  }
  return listLen;
}

function mapSopItem(item: Record<string, unknown>): SopExceptionRow {
  const sopIdNum = pickSopNumericId(item);
  const id =
    sopIdNum !== undefined
      ? String(sopIdNum)
      : String(item.exception_id ?? item.exceptionId ?? crypto.randomUUID());
  const jobs = item.jobs;
  const rawJobNames = item.job_names;
  let jobName = '';
  if (typeof item.job_name === 'string') jobName = item.job_name;
  else if (typeof item.jobName === 'string') jobName = item.jobName;
  else if (Array.isArray(rawJobNames) && rawJobNames.length > 0) {
    jobName = String(rawJobNames[0] ?? '');
  }
  else if (Array.isArray(jobs) && jobs.length > 0) {
    const first = jobs[0];
    if (isRecord(first)) {
      jobName = String(first.job_name ?? first.name ?? first.label ?? '');
    }
  }

  const sopName = String(item.exception_name ?? item.exceptionName ?? item.sop_name ?? '');
  const exceptionName = String(item.exception_name ?? item.exceptionName ?? sopName);
  const jobIds = collectSopJobIds(item);
  const jobNames = collectSopJobNamesList(item, jobName);

  return {
    id,
    sopId: sopIdNum,
    createdAt: String(item.created_at ?? item.createdAt ?? ''),
    sopName,
    exceptionName,
    jobName,
    jobIds,
    jobNames,
  };
}

/**
 * SOP Control Center — list from Lambda `list_sops` via `fetchSops`.
 */
export default function SopControlCenter() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [sopNameFilter, setSopNameFilter] = useState('');
  const [jobFilter, setJobFilter] = useState<number | undefined>(undefined);
  const [createdAtFilter, setCreatedAtFilter] = useState<Dayjs | null>(null);
  const [draftSopNameFilter, setDraftSopNameFilter] = useState('');
  const [draftJobFilter, setDraftJobFilter] = useState<number | undefined>(undefined);
  const [draftCreatedAtFilter, setDraftCreatedAtFilter] = useState<Dayjs | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [rows, setRows] = useState<SopExceptionRow[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [deleteRow, setDeleteRow] = useState<SopExceptionRow | null>(null);
  const [deletePopupPosition, setDeletePopupPosition] = useState<{ top: number; left: number } | undefined>(undefined);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [jobsModal, setJobsModal] = useState<string[]>([]);
  const [jobList, setJobList] = useState<JobOption[]>([]);

  const loadSops = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetchSops(currentPage, pageSize, {
        exceptionName: sopNameFilter.trim() || undefined,
        jobId: jobFilter,
        createdAt: createdAtFilter ? createdAtFilter.format('YYYY-MM-DD') : undefined,
      });
      const list = extractSopList(res);
      const mapped = list.map(mapSopItem);
      setRows(mapped);
      setTotal(extractTotal(res, mapped.length));
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Failed to load SOPs';
      message.error(msg);
      setRows([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  }, [createdAtFilter, currentPage, jobFilter, pageSize, sopNameFilter]);

  useEffect(() => {
    void loadSops();
  }, [loadSops]);
  console.log("check");

  useEffect(() => {
    listJobs()
      .then(setJobList)
      .catch(() => setJobList([]));
  }, []);

  const columns: TableColumnsType<SopExceptionRow> = useMemo(
    () => [
      {
        title: 'Created At',
        dataIndex: 'createdAt',
        key: 'createdAt',
        render: (value: string) =>
          value ? dayjs(value).format('MMM D, YYYY, h:mm A') : '—',
      },
      {
        title: 'SOP Name',
        dataIndex: 'sopName',
        key: 'sopName',
        render: (value?: string) => (
          <span className="text-sm font-normal text-slate-900">{value?.trim() || '—'}</span>
        ),
      },
      {
        title: 'Job Name',
        dataIndex: 'jobNames',
        key: 'jobNames',
        render: (names: string[]) => {
          const list = Array.isArray(names) ? names.filter(Boolean) : [];
          if (list.length === 0) return null;
          const visible = list.slice(0, 2);
          const hidden = list.slice(2);
          return (
            <span className="flex flex-wrap items-center gap-1 text-sm font-normal text-slate-900">
              {visible.join(', ')}
              {hidden.length > 0 && (
                <button
                  type="button"
                  className="cursor-pointer rounded bg-slate-100 px-1.5 py-0.5 text-xs font-medium text-slate-600 hover:bg-slate-200 border-0"
                  onClick={() => setJobsModal(list)}
                >
                  +{hidden.length} more
                </button>
              )}
            </span>
          );
        },
      },
      createActionsColumn<SopExceptionRow>({
        viewTooltip: 'Edit SOP',
        viewIcon: Pencil,
        deleteTooltip: 'Delete SOP',
        onView: (r) => {
          const key = r.exceptionName || r.sopName || r.id;
          const fromRow =
            typeof r.sopId === 'number' && Number.isFinite(r.sopId) ? r.sopId : undefined;
          const fromIdKey = Number(r.id);
          const sopIdForEdit =
            fromRow !== undefined ? fromRow : Number.isFinite(fromIdKey) ? fromIdKey : undefined;
          navigate(`/${encodeURIComponent(key)}/edit`, {
            state: {
              sopId: sopIdForEdit,
              jobIds: r.jobIds,
              jobNames: r.jobNames,
            },
          });
        },
        onDelete: (r, event) => {
          const rect = event.currentTarget.getBoundingClientRect(); 5
          setDeletePopupPosition({
            top: rect.bottom + 8,
            left: Math.max(16, rect.left - 350),
          });
          setDeleteRow(r);
        },
      }),
    ],
    [navigate]
  );

  const openFilters = () => {
    setDraftSopNameFilter(sopNameFilter);
    setDraftJobFilter(jobFilter);
    setDraftCreatedAtFilter(createdAtFilter);
    setFiltersOpen(true);
  };

  const applyFilters = () => {
    setSopNameFilter(draftSopNameFilter.trim());
    setJobFilter(draftJobFilter);
    setCreatedAtFilter(draftCreatedAtFilter);
    setCurrentPage(1);
    setFiltersOpen(false);
  };

  const clearFilters = async () => {
    setDraftSopNameFilter('');
    setDraftJobFilter(undefined);
    setDraftCreatedAtFilter(null);
    setSopNameFilter('');
    setJobFilter(undefined);
    setCreatedAtFilter(null);
    setCurrentPage(1);
    setFiltersOpen(false);

    // Explicitly reload unfiltered list_sops payload (page + page_size only).
    setLoading(true);
    try {
      const res = await fetchSops(1, pageSize);
      const list = extractSopList(res);
      const mapped = list.map(mapSopItem);
      setRows(mapped);
      setTotal(extractTotal(res, mapped.length));
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Failed to load SOPs';
      message.error(msg);
      setRows([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  };

  const jobOptions = useMemo(
    () => jobList.map((j) => ({ value: j.id, label: j.job_name })),
    [jobList]
  );

  const filterFields = useMemo<DynamicFilterField[]>(
    () => [
      {
        key: 'sopName',
        type: 'input',
        label: 'SOP Name',
        placeholder: 'Search SOP name',
      },
      {
        key: 'jobName',
        type: 'select',
        label: 'Job',
        placeholder: 'Select job',
        options: jobOptions,
        allowClear: true,
      },
      {
        key: 'createdAt',
        type: 'date',
        label: 'Date',
        placeholder: 'Select date',
      },
    ],
    [jobOptions]
  );

  const draftFilterValues = useMemo(
    () => ({
      sopName: draftSopNameFilter,
      jobName: draftJobFilter,
      createdAt: draftCreatedAtFilter,
    }),
    [draftSopNameFilter, draftJobFilter, draftCreatedAtFilter]
  );

  const hasDraftFilterValue = useMemo(
    () => Boolean(draftSopNameFilter.trim() || draftJobFilter !== undefined || draftCreatedAtFilter),
    [draftSopNameFilter, draftJobFilter, draftCreatedAtFilter]
  );

  const handleDraftFilterChange = (key: string, value: DynamicFilterValue) => {
    if (key === 'sopName') {
      setDraftSopNameFilter(typeof value === 'string' ? value : '');
      return;
    }
    if (key === 'jobName') {
      setDraftJobFilter(
        typeof value === 'number'
          ? value
          : typeof value === 'string' && value.trim() !== '' && Number.isFinite(Number(value))
            ? Number(value)
            : undefined
      );
      return;
    }
    if (key === 'createdAt') {
      setDraftCreatedAtFilter((value as Dayjs | null | undefined) ?? null);
    }
  };

  const appliedFilterCount =
    (sopNameFilter.trim() ? 1 : 0) +
    (jobFilter !== undefined ? 1 : 0) +
    (createdAtFilter ? 1 : 0);
  const showPageSkeleton = loading;

  return (
    <div className="flex w-full flex-col gap-6">
      <PageBreadcrumb
        items={[
          { title: 'Home', to: '/dashboard' },
          { title: 'SOP Control Center' },
        ]}
      />

      <div>
        <h1 className="m-0 text-2xl font-semibold tracking-tight text-slate-900">SOP Control Center</h1>
        <p className="mt-2 mb-0 text-sm text-slate-500">Manage and configure SOP exceptions</p>
      </div>

      {showPageSkeleton ? (
        <ListPageTableSkeleton toolbarButtonCount={2} tableColumns={4} tableRows={pageSize} />
      ) : (
        <section className="rounded-xl border border-slate-200/80 bg-white p-6 shadow-sm max-md:p-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-end">
            <SecondaryButton
              icon={<Funnel size={16} strokeWidth={2.25} />}
              text="Filter"
              badgeCount={appliedFilterCount}
              onClick={openFilters}
            />
            <PrimaryButton
              icon={<Plus strokeWidth={2.5} />}
              text="Create New SOP"
              type="button"
              className="px-[18px]"
              onClick={() => navigate('/new_sop')}
            />
          </div>

          <div className="mt-6 min-w-0">
            <TableLayout<SopExceptionRow>
              card={false}
              loading={loading}
              columns={columns}
              dataSource={rows}
              rowKey="id"
              pagination={false}
            />
          </div>
          <TablePagination
            total={total}
            current={currentPage}
            pageSize={pageSize}
            onChange={(page, nextPageSize) => {
              setCurrentPage(page);
              setPageSize(nextPageSize);
            }}
          />
        </section>
      )}

      <DeleteConfirmModal
        open={Boolean(deleteRow)}
        title="Delete exception"
        description={
          deleteRow
            ? `Delete "${deleteRow.sopName || deleteRow.exceptionName}"? This removes the SOP and cannot be undone.`
            : 'Are you sure you want to delete? This action cannot be undone.'
        }
        position={deletePopupPosition}
        loading={deleteLoading}
        confirmText="Delete"
        onCancel={() => {
          setDeleteRow(null);
        }}
        onConfirm={async () => {
          if (!deleteRow) return;
          const sopId =
            typeof deleteRow.sopId === 'number' && Number.isFinite(deleteRow.sopId)
              ? deleteRow.sopId
              : Number(deleteRow.id);
          if (!Number.isFinite(sopId)) {
            message.error('Missing SOP id for this row. Refresh the list and try again.');
            setDeleteRow(null);
            return;
          }
          setDeleteLoading(true);
          try {
            await deleteSop(sopId, updatedByFromSession(user));
            message.success('SOP deleted');
            setDeleteRow(null);
            await loadSops();
          } catch (e) {
            const msg = e instanceof Error ? e.message : 'Failed to delete';
            message.error(msg);
          } finally {
            setDeleteLoading(false);
          }
        }}
        onAfterClose={() => {
          setDeletePopupPosition(undefined);
        }}
      />

      <Modal
        open={jobsModal.length > 0}
        title="All Jobs"
        footer={null}
        centered
        onCancel={() => setJobsModal([])}
      >
        <ul className="m-0 list-none p-0">
          {jobsModal.map((name) => (
            <li key={name} className="border-b border-slate-100 py-2 text-sm text-slate-800 last:border-0">
              {name}
            </li>
          ))}
        </ul>
      </Modal>

      <DynamicFilterModal
        open={filtersOpen}
        title="Filter Exceptions"
        variant="drawer"
        width={360}
        fields={filterFields}
        values={draftFilterValues}
        onChange={handleDraftFilterChange}
        onCancel={() => setFiltersOpen(false)}
        onApply={applyFilters}
        onReset={() => void clearFilters()}
        applyText="Apply Filters"
        resetText="Reset Filters"
        applyDisabled={!hasDraftFilterValue}
        resetDisabled={!hasDraftFilterValue}
      />

    </div>
  );
}
