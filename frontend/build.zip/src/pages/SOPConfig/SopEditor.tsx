import { Plus } from 'lucide-react';
import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import SOPStepper from '../../layout/SOPConfig/SOPStepper';
import SopDetailsSection from '../../layout/SOPConfig/SopDetailsSection';
import SopDocumentsSection from '../../layout/SOPConfig/SopDocumentsSection';
import DeleteConfirmModal from '../../components/ui/DeleteConfirmModal';
import PageBreadcrumb from '../../components/ui/PageBreadcrumb';
import PrimaryButton from '../../components/ui/PrimaryButton';
import { useSopEditor } from '../../hooks/useSopEditor';
import { useTempSopDraft } from '../../hooks/sopEditor/useTempSopDraft';
import { useSopStepper } from '../../hooks/sopEditor/useSopStepper';
import { useSopVersionColumns } from '../../hooks/sopEditor/useSopVersionColumns';

export type { SopEditLocationState } from '../../hooks/useSopEditor';

export default function SopEditor() {
  const navigate = useNavigate();

  const {
    isEditMode,
    formState,
    loadingState,
    tableState,
    deleteModal,
    jobs,
    jobOptions,
    jobsReadOnlyDisplay,
    filteredVersions,
    pagedVersions,
    updateForm,
    updateTable,
    updateDeleteModal,
    openVersionDocument,
    openVersionDeleteModal,
    confirmVersionDocumentDelete,
    validateAndSave,
    startExceptionDetailsEdit,
    cancelExceptionDetailsEdit,
    sopId,
    handleVersionStatusChange,
    refreshVersions,
  } = useSopEditor();

  const { exceptionName, selectedJobIds, errors, exceptionDetailsEditing } = formState;
  const { jobsLoading, exceptionDetailsSaving, versionUploading, versionsListLoading } = loadingState;
  const { currentPage, pageSize } = tableState;

  const selectedDocumentNames = useMemo(() => {
    const firstJobId = selectedJobIds[0];
    if (firstJobId == null) return [];
    const job = jobs.find((j) => j.id === firstJobId);
    if (!job) return [];
    const names = Array.isArray(job.document_names) ? [...(job.document_names as string[])] : [];
    if (job.reference_document_name) {
      names.push(String(job.reference_document_name));
    }
    return names;
  }, [jobs, selectedJobIds]);

  // ── Temp draft (add mode: holds SOP file until Create SOP is clicked) ────────

  const {
    setTempSopFile,
    setTempSopDraftSaved,
    setTempSopCreatedAt,
    tempSopDraftSavedRef,
    sopCreateFileInputRef,
    sopCreateLoading,
    visibleVersions,
    handleRemoveTempSop,
    handlePreviewTempSop,
    handleCreateSopClick,
    handleDirectFileInputChange,
  } = useTempSopDraft({
    isEditMode,
    exceptionName,
    selectedJobIds,
    pagedVersions,
    errors,
    updateForm,
    navigate,
    sopTestFileNameRef: { current: null },
  });

  // ── Stepper (upload + test flow) ─────────────────────────────────────────────

  const [testingExistingVersion, setTestingExistingVersion] = useState(false);

  const {
    sopStepperOpen,
    setSopStepperOpen,
    onClose,
    onDone,
    onSkip,
    onUploadSop,
    onTestSop,
    onTestExistingVersion,
  } = useSopStepper({
    isEditMode,
    sopId,
    exceptionName,
    selectedJobIds,
    refreshVersions,
    setTempSopFile,
    setTempSopDraftSaved,
    setTempSopCreatedAt,
    tempSopDraftSavedRef,
  });

  // ── Version table columns ────────────────────────────────────────────────────

  const versionColumns = useSopVersionColumns({
    isEditMode,
    handleVersionStatusChange,
    openVersionDocument: (r) => void openVersionDocument(r),
    openVersionDeleteModal: (r, e) => openVersionDeleteModal(r, e),
    handlePreviewTempSop,
    handleRemoveTempSop,
    onTestExistingVersion: isEditMode
      ? (record) => {
          setTestingExistingVersion(true);
          void onTestExistingVersion(record);
        }
      : undefined,
  });

  // ── Upload New SOP Version button handler ────────────────────────────────────

  const handleUploadNewVersion = () => {
    if (!isEditMode) {
      const nextErrors = { ...errors };
      if (!exceptionName.trim()) nextErrors.exceptionName = 'Exception name is required';
      if (selectedJobIds.length === 0) nextErrors.jobId = 'Please select a job';
      if (nextErrors.exceptionName || nextErrors.jobId) {
        updateForm({ errors: nextErrors });
        return;
      }
    }
    setSopStepperOpen(true);
  };

  // ── Render ────────────────────────────────────────────────────────────────────

  return (
    <div className="flex w-full flex-col gap-6">
      <PageBreadcrumb
        items={[
          { title: 'Home', to: '/dashboard' },
          { title: 'SOP Control Center', to: '/sop-control-center' },
          { title: isEditMode ? 'View SOP Config' : 'Create SOP' },
        ]}
      />

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="m-0 text-2xl font-semibold tracking-tight text-slate-900">
          {isEditMode ? 'View SOP Config' : 'Create SOP'}
        </h1>
        {!isEditMode && (
          <>
            <input
              ref={sopCreateFileInputRef}
              type="file"
              accept=".pdf,application/pdf,image/jpeg,image/png,image/jpg"
              className="sr-only"
              onChange={(e) => void handleDirectFileInputChange(e)}
            />
            <PrimaryButton
              icon={<Plus size={16} />}
              text="Create SOP"
              className="min-h-[34px] rounded-[8px] px-3 text-sm"
              disabled={sopCreateLoading}
              onClick={handleCreateSopClick}
            />
          </>
        )}
      </div>

      <SopDetailsSection
        isEditMode={isEditMode}
        exceptionDetailsEditing={exceptionDetailsEditing}
        exceptionName={exceptionName}
        jobsReadOnlyDisplay={jobsReadOnlyDisplay}
        errors={errors}
        jobOptions={jobOptions}
        jobsLoading={jobsLoading}
        selectedJobIds={selectedJobIds}
        exceptionDetailsSaving={exceptionDetailsSaving}
        updateForm={updateForm}
        startExceptionDetailsEdit={startExceptionDetailsEdit}
        cancelExceptionDetailsEdit={cancelExceptionDetailsEdit}
        validateAndSave={validateAndSave}
      />

      <SopDocumentsSection
        isEditMode={isEditMode}
        versionsListLoading={versionsListLoading}
        versionUploading={versionUploading}
        versionColumns={versionColumns}
        visibleVersions={visibleVersions}
        filteredVersions={filteredVersions}
        currentPage={currentPage}
        pageSize={pageSize}
        versionFileError={errors.versionFile}
        updateTable={updateTable}
        refreshVersions={refreshVersions}
        onUploadNewVersion={handleUploadNewVersion}
      />

      <DeleteConfirmModal
        open={Boolean(deleteModal.document)}
        title="Delete document"
        description={
          deleteModal.document
            ? `Remove "${deleteModal.document.sopName}" from this SOP? This cannot be undone.`
            : 'Are you sure you want to delete? This action cannot be undone.'
        }
        position={deleteModal.position}
        loading={deleteModal.loading}
        confirmText="Delete"
        onCancel={() => updateDeleteModal({ document: null })}
        onConfirm={() => void confirmVersionDocumentDelete()}
      />

      <SOPStepper
        open={sopStepperOpen}
        documentNames={selectedDocumentNames}
        sopDisplayName={exceptionName}
        initialStep={testingExistingVersion ? 1 : 0}
        modalTitle={testingExistingVersion ? 'Test the existing SOP' : 'Add & Test SOP'}
        reasonFailureFilterName={testingExistingVersion ? exceptionName : undefined}
        step2Label={
          testingExistingVersion
            ? 'Test Your Current SOP'
            : isEditMode
              ? 'Test New SOP Version'
              : 'Test New SOP'
        }
        onClose={() => { setTestingExistingVersion(false); onClose(); }}
        onDone={() => { setTestingExistingVersion(false); onDone(); }}
        onSkip={testingExistingVersion ? undefined : () => { setTestingExistingVersion(false); onSkip(); }}
        onUploadSop={onUploadSop}
        onTestSop={onTestSop}
      />
    </div>
  );
}
