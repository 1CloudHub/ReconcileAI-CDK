import * as pdfjs from 'pdfjs-dist';

let workerConfigured = false;

function ensurePdfWorker(): void {
  if (workerConfigured || typeof window === 'undefined') return;
  pdfjs.GlobalWorkerOptions.workerSrc = new URL(
    'pdfjs-dist/build/pdf.worker.min.mjs',
    import.meta.url
  ).toString();
  workerConfigured = true;
}

export const PDF_TOO_MANY_PAGES_MESSAGE =
  'This file has too much content to process. Please upload a file with up to 2 pages only.';

export const PDF_READ_ERROR_MESSAGE = 'Could not read this PDF. Please try another file.';

export function isPdfFile(file: File): boolean {
  return file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
}

async function getPdfPageCount(file: File): Promise<number> {
  ensurePdfWorker();
  const data = new Uint8Array(await file.arrayBuffer());
  const loadingTask = pdfjs.getDocument({ data });
  const pdf = await loadingTask.promise;
  try {
    return pdf.numPages;
  } finally {
    await pdf.destroy();
  }
}

export async function validateSinglePageDocument(
  file: File
): Promise<{ ok: true } | { ok: false; message: string }> {
  if (!isPdfFile(file)) {
    return { ok: true };
  }
  try {
    const pages = await getPdfPageCount(file);
    if (pages > 2) {
      return { ok: false, message: PDF_TOO_MANY_PAGES_MESSAGE };
    }
    return { ok: true };
  } catch {
    return { ok: false, message: PDF_READ_ERROR_MESSAGE };
  }
}
