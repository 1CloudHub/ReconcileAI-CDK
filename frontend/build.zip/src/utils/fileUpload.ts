import { API_URLS } from '../config/api.config';
import { apiRequest } from '../services/api';

const MAX_PDF_BYTES = 4 * 1024 * 1024;

function mimeFromExtension(ext: string): string {
  const map: Record<string, string> = {
    pdf: 'application/pdf',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    png: 'image/png',
  };
  return map[ext.toLowerCase()] ?? 'application/octet-stream';
}

async function fileToBase64Payload(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.onload = () => {
      const result = String(reader.result ?? '');
      // Typically: "data:application/pdf;base64,AAA..."
      const base64 = result.includes(',') ? result.split(',', 2)[1] : result;
      resolve(base64);
    };
    reader.readAsDataURL(file);
  });
}

export async function uploadFileToS3ViaLambda(params: {
  file: File;
  s3Key: string;
  maxBytes?: number;
}): Promise<{ s3Uri: string; sizeBytes: number; contentType: string }> {
  const { file, s3Key, maxBytes = MAX_PDF_BYTES } = params;

  if (!file) throw new Error('file is required');
  if (!s3Key || !s3Key.trim()) throw new Error('s3Key is required');

  if (file.size > maxBytes) {
    throw new Error(`File too large (max ${(maxBytes / (1024 * 1024)).toFixed(0)}MB)`);
  }

  const ext = file.name.split('.').pop() ?? '';
  const contentType = mimeFromExtension(ext);
  const fileBase64 = await fileToBase64Payload(file);

  type UploadDocBase64Response = {
    statusCode?: number;
    message?: string;
    body?: { s3_uri?: string; size_bytes?: number; content_type?: string };
  };

  const res = await apiRequest<UploadDocBase64Response, Record<string, unknown>>(API_URLS.CONFIG, {
    method: 'POST',
    body: {
      event_type: 'upload_doc_base64',
      s3_path: s3Key.trim(),
      content_type: contentType,
      file_base64: fileBase64,
      filename: file.name,
    },
  });

  const s3Uri = typeof res.body?.s3_uri === 'string' ? res.body.s3_uri : '';
  if (!s3Uri) {
    const msg = typeof res.message === 'string' ? res.message : 'Upload failed';
    throw new Error(msg);
  }

  return {
    s3Uri,
    sizeBytes: typeof res.body?.size_bytes === 'number' ? res.body.size_bytes : file.size,
    contentType: typeof res.body?.content_type === 'string' ? res.body.content_type : contentType,
  };
}

