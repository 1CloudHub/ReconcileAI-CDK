export function getCookie(name: string): string | null {
  const match = document.cookie.match(new RegExp('(?:^|; )' + name.replace(/([.$?*|{}()[\]\\/+^])/g, '\\$1') + '=([^;]*)'));
  return match ? decodeURIComponent(match[1]) : null;
}

/** `days` (number) or explicit `hours` for shorter sessions */
export function setCookie(
  name: string,
  value: string,
  ttl: number | { hours: number } = 7
): void {
  const maxMs =
    typeof ttl === 'number'
      ? ttl * 864e5
      : ttl.hours * 60 * 60 * 1000;
  const expires = new Date(Date.now() + maxMs).toUTCString();
  document.cookie = `${name}=${encodeURIComponent(value)}; expires=${expires}; path=/`;
}

export function deleteCookie(name: string): void {
  document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`;
}

export function generateRandomSessionId(): string {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}
