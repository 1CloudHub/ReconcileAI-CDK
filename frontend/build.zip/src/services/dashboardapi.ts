import { API_URLS } from '../config/api.config';
import { apiRequest } from './api';

type DashboardEnvelope = Record<string, unknown>;

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null;
}

function parseJsonRecord(raw: string): Record<string, unknown> | undefined {
  try {
    const v = JSON.parse(raw) as unknown;
    return isRecord(v) ? v : undefined;
  } catch {
    return undefined;
  }
}

function unwrapLambdaBody(res: DashboardEnvelope): Record<string, unknown> {
  const r = res as Record<string, unknown>;
  if (!('statusCode' in r) && !('body' in r)) return r;

  const statusCodeRaw = r.statusCode;
  const statusCode =
    typeof statusCodeRaw === 'number'
      ? statusCodeRaw
      : typeof statusCodeRaw === 'string'
        ? Number(statusCodeRaw)
        : NaN;

  if (Number.isFinite(statusCode) && statusCode !== 200) {
    const message =
      typeof r.message === 'string'
        ? r.message
        : typeof r.body === 'string'
          ? r.body
          : `Request failed (${statusCode})`;
    throw new Error(message);
  }

  const body = r.body;
  if (typeof body === 'string') return parseJsonRecord(body) ?? {};
  if (isRecord(body)) return body;
  return {};
}

function toNumber(v: unknown): number {
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  if (typeof v === 'string' && v.trim() !== '') {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return 0;
}

export type DashboardKpiCards = {
  totalReconciliations: number;
  totalJobs: number;
  totalSops: number;
  totalDocuments: number;
};

export type ReconciliationSummaryItem = {
  month: string;
  matched: number;
  mismatched: number;
};

export type TopJobByDocuments = {
  name: string;
  count: number;
};

export type RecentReconciliationActivity = {
  jobName: string;
  status: 'Matched' | 'Mismatched';
  reason: string;
  documents: number;
};

export async function fetchDashboardKpiCards(date: string): Promise<DashboardKpiCards> {
  const res = await apiRequest<DashboardEnvelope, Record<string, unknown>>(API_URLS.CONFIG, {
    method: 'POST',
    body: {
      event_type: 'kpi_cards',
      date,
    },
  });

  const body = unwrapLambdaBody(res);
  return {
    totalReconciliations: toNumber(body.total_reconciliations),
    totalJobs: toNumber(body.total_jobs),
    totalSops: toNumber(body.total_sops),
    totalDocuments: toNumber(body.total_documents),
  };
}

export async function fetchReconciliationSummary(date: string): Promise<ReconciliationSummaryItem[]> {
  const res = await apiRequest<DashboardEnvelope, Record<string, unknown>>(API_URLS.CONFIG, {
    method: 'POST',
    body: {
      event_type: 'get_reconciliation_summary',
      date,
    },
  });

  const raw = (res as Record<string, unknown>).body;
  const arr: unknown[] = Array.isArray(raw)
    ? raw
    : Array.isArray((res as Record<string, unknown>).body)
      ? (raw as unknown[])
      : [];

  return arr
    .filter(isRecord)
    .map((item) => ({
      month: typeof item.month === 'string' ? item.month : '',
      matched: toNumber(item.matched),
      mismatched: toNumber(item.mismatched),
    }));
}

export async function fetchTopJobsByDocuments(date: string): Promise<TopJobByDocuments[]> {
  const res = await apiRequest<DashboardEnvelope, Record<string, unknown>>(API_URLS.CONFIG, {
    method: 'POST',
    body: {
      event_type: 'get_top_jobs_by_documents',
      date,
    },
  });

  const body = unwrapLambdaBody(res);
  const listRaw = Array.isArray(body.data) ? body.data : [];
  return listRaw
    .filter((item): item is Record<string, unknown> => isRecord(item))
    .map((item) => ({
      name: String(item.job_name ?? '').trim(),
      count: toNumber(item.total_documents_uploaded),
    }))
    .filter((row) => row.name.length > 0);
}

export type DayWiseBreakdownItem = {
  day: string;
  matched: number;
  mismatched: number;
};

export async function fetchDayWiseReconciliationBreakdown(date: string): Promise<DayWiseBreakdownItem[]> {
  const res = await apiRequest<DashboardEnvelope, Record<string, unknown>>(API_URLS.CONFIG, {
    method: 'POST',
    body: {
      event_type: 'get_day_wise_reconciliation_breakdown',
      date,
    },
  });

  const body = unwrapLambdaBody(res);
  const dataRaw = Array.isArray(body.data) ? (body.data as unknown[]) : [];

  return dataRaw
    .filter(isRecord)
    .map((item) => ({
      day: typeof item.day === 'string' ? item.day : '',
      matched: toNumber(item.matched),
      mismatched: toNumber(item.mismatched),
    }))
    .filter((row) => row.day.length > 0);
}

export async function fetchRecentReconciliationActivity(): Promise<RecentReconciliationActivity[]> {
  const res = await apiRequest<DashboardEnvelope, Record<string, unknown>>(API_URLS.CONFIG, {
    method: 'POST',
    body: {
      event_type: 'get_recent_reconciliation_activity',
    },
  });

  const body = unwrapLambdaBody(res);
  const listRaw = Array.isArray(body.data) ? body.data : [];
  return listRaw
    .filter((item): item is Record<string, unknown> => isRecord(item))
    .map((item): RecentReconciliationActivity => {
      const rawStatus = String(item.reconcile_status ?? '')
        .trim()
        .toLowerCase();
      const status: RecentReconciliationActivity['status'] =
        rawStatus === 'yes' || rawStatus === 'matched' ? 'Matched' : 'Mismatched';
      return {
        jobName: String(item.job_name ?? '').trim(),
        status,
        reason: String(item.reason_for_failure ?? '').trim() || '-',
        documents: toNumber(item.documents),
      };
    })
    .filter((row) => row.jobName.length > 0);
}
