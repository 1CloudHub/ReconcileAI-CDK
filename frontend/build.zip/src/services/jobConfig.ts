import { API_URLS } from '../config/api.config';
import { apiRequest } from './api';

export type JobListItem = {
  id: number;
  job_name: string;
  document_id?: number[];
  document_names?: string[];
  reference_document_name?: string;
  reference_document_id?: number;
};

type Envelope = Record<string, unknown>;

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null;
}

function extractJobs(res: Envelope): JobListItem[] {
  const root = isRecord(res.body) ? res.body : res;
  if (Array.isArray(root.jobs)) return root.jobs as JobListItem[];
  if (Array.isArray(root.result)) return root.result as JobListItem[];
  const data = root.data;
  if (isRecord(data) && Array.isArray(data.jobs)) return data.jobs as JobListItem[];
  if (Array.isArray(data)) return data as JobListItem[];
  return [];
}

export type ListJobsParams = {
  page?: number;
  page_size?: number;
  job_name?: string;
  created_by?: string;
  document_name?: string;
};

/**
 * Config Lambda: `list_jobs` — same endpoint as Job Config page.
 * Optional `page` / `page_size` enable pagination; filters are optional.
 */
export async function listJobs(params?: ListJobsParams): Promise<JobListItem[]> {
  const res = await apiRequest<Envelope, Record<string, unknown>>(API_URLS.CONFIG, {
    method: 'POST',
    body: { event_type: 'list_jobs', ...params },
  });
  return extractJobs(res);
}
