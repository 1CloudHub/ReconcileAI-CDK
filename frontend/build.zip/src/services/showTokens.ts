import { API_URLS } from '../config/api.config';
import { apiRequest } from './api';

export const TOKEN_USAGE_REFRESH_EVENT = 'reconcile-ai:token-usage-refresh';

export type TokenUsageRefreshDetail = {
  totalTokensUsed?: number;
  availableTokens?: number;
};

/** Normalized token counts for UI (matches previous sidebar defaults). */
export type ShowTokensResult = {
  used: number;
  limit: number;
};

function parseConfigBody(data: unknown): Record<string, unknown> {
  if (data && typeof data === 'object' && 'body' in data) {
    const raw = data as { body?: unknown };
    const b = raw.body;
    if (typeof b === 'string') {
      try {
        return JSON.parse(b) as Record<string, unknown>;
      } catch {
        return {};
      }
    }
    if (b && typeof b === 'object') return b as Record<string, unknown>;
  }
  return (data && typeof data === 'object' ? data : {}) as Record<string, unknown>;
}

export function tokensFromShowTokensBody(body: Record<string, unknown>): ShowTokensResult {
  return {
    used: body.total_tokens_used !== undefined ? Number(body.total_tokens_used) : 0,
    limit: body.available_tokens !== undefined ? Number(body.available_tokens) : 100000,
  };
}

/**
 * Single source for `show_tokens`: same parsing and defaults everywhere.
 */
export async function fetchShowTokens(): Promise<ShowTokensResult | null> {
  try {
    const data = await apiRequest<unknown, { event_type: string }>(API_URLS.CONFIG, {
      body: { event_type: 'show_tokens' },
    });
    const body = parseConfigBody(data);
    return tokensFromShowTokensBody(body);
  } catch (err) {
    console.error('Failed to fetch show_tokens', err);
    return null;
  }
}

/**
 * Fetches token usage and notifies the UI (sidebar bar, limit banner).
 * Dispatches {@link TOKEN_USAGE_REFRESH_EVENT} with both numbers when the request succeeds.
 */
export async function refreshTokenUsageFromApi(): Promise<void> {
  let detail: TokenUsageRefreshDetail | undefined;
  const result = await fetchShowTokens();
  if (result) {
    detail = { totalTokensUsed: result.used, availableTokens: result.limit };
  }

  window.dispatchEvent(
    new CustomEvent<TokenUsageRefreshDetail | undefined>(TOKEN_USAGE_REFRESH_EVENT, { detail })
  );
}
