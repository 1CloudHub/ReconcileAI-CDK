type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
type ResponseType = 'json' | 'text';

export type ApiRequestOptions<TBody = unknown> = {
  method?: HttpMethod;
  body?: TBody;
  headers?: HeadersInit;
  credentials?: RequestCredentials;
  responseType?: ResponseType;
};

export class ApiError extends Error {
  status: number;
  data: unknown;

  constructor(message: string, status: number, data: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

async function parseResponseBody(
  response: Response,
  responseType: ResponseType
): Promise<unknown> {
  if (responseType === 'text') {
    return response.text();
  }

  try {
    return await response.json();
  } catch {
    return {};
  }
}

export async function apiRequest<TResponse = unknown, TBody = unknown>(
  url: string,
  options: ApiRequestOptions<TBody> = {}
): Promise<TResponse> {
  const {
    method = 'POST',
    body,
    headers,
    credentials,
    responseType = 'json',
  } = options;

  const hasBody = body !== undefined && body !== null;

  const finalHeaders: HeadersInit = {
    ...(hasBody ? { 'Content-Type': 'application/json' } : {}),
    ...(headers ?? {}),
  };

  const response = await fetch(url, {
    method,
    headers: finalHeaders,
    credentials,
    body: hasBody ? JSON.stringify(body) : undefined,
  });

  const data = await parseResponseBody(response, responseType);

  if (!response.ok) {
    const errorMessage =
      typeof data === 'object' &&
      data !== null &&
      'message' in data &&
      typeof (data as { message?: unknown }).message === 'string'
        ? (data as { message: string }).message
        : `Request failed with status ${response.status}`;

    throw new ApiError(errorMessage, response.status, data);
  }

  return data as TResponse;
}