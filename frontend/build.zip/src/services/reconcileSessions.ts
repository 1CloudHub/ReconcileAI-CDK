import dayjs from 'dayjs';
import { API_URLS } from '../config/api.config';
import { apiRequest } from './api';
import type { ReconcileRecord, ReconcileRowStatus } from '../components/ReconcileAgent/RecordsTable';

type Envelope = Record<string, unknown>;

type ListAllSessionsPayload = {
  event_type: 'list_all_sessions';
  page: number;
  page_size: number;
  job_name: string;
  reconcile_status: string;
  document_type: string;
  session_id: string;
  created_by: string;
  created_from: string;
  created_to: string;
};

export type SessionListFilters = {
  page?: number;
  pageSize?: number;
  jobName?: string;
  reconcileStatus?: string;
  documentType?: string;
  sessionId?: string;
  createdBy?: string;
  createdFrom?: string;
  createdTo?: string;
};

export type SessionListResult = {
  rows: ReconcileRecord[];
  total: number;
};

export type ReconcileUploadUrlResponse = {
  uploadUrl: string;
  s3Uri?: string;
  s3Key?: string;
  expiry?: number;
};

export type ReconcileDocumentsPayload = {
  event_type: 'reconcile_documents';
  job_id: number;
  session_id: string;
  created_by: string;
  documents: Record<string, string>;
  testing_status?: string;
  sub_flag?: string;
  module: string;
  type: string;
};

function toApiReconcileStatus(value: string | undefined): string {
  const v = String(value ?? '').trim().toLowerCase();
  if (v === 'matched') return 'yes';
  if (v === 'not_matched') return 'no';
  if (v === 'failed') return 'Failed';
  if (v === 'validation failed') return 'Validation Failed';
  return v;
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null;
}

function toRecord(v: unknown): Record<string, unknown> {
  if (typeof v === 'string') {
    try {
      const parsed = JSON.parse(v) as unknown;
      return isRecord(parsed) ? parsed : {};
    } catch {
      return {};
    }
  }
  return isRecord(v) ? v : {};
}

function normalizeStatus(value: unknown): ReconcileRowStatus {
  const v = String(value ?? '').trim().toLowerCase();
  if (v === 'no') return 'not_matched';
  if (v === 'yes') return 'matched';
  if (v === 'failed' || v === 'fail') return 'failed';
  // Handle all validation failed variants: 'validation failed', 'validation_failed', 'validation_status'
  // This includes API responses with capital V (e.g., "Validation Failed") after toLowerCase()
  if (v === 'validation failed' || v === 'validation_failed' || v === 'validation_status') return 'validation failed';
  if (v === 'matched') return 'matched';
  if (v === 'not_matched' || v === 'not matched') return 'not_matched';
  return 'processing';
}

function toDocumentTypes(value: unknown): string[] {
  const normalize = (raw: unknown): string => String(raw).trim().replace(/_/g, ' ');
  if (Array.isArray(value)) {
    return value.map((x) => normalize(x)).filter(Boolean);
  }
  if (typeof value === 'string') {
    const trimmed = normalize(value);
    if (!trimmed) return [];
    if (trimmed.includes(',')) {
      return trimmed.split(',').map((x) => normalize(x)).filter(Boolean);
    }
    return [trimmed];
  }
  return [];
}

function unwrapEnvelope(response: Envelope): Record<string, unknown> {
  if (!('body' in response)) return response;
  return toRecord(response.body);
}

function toNumber(value: unknown): number | undefined {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string') {
    const n = Number(value);
    if (Number.isFinite(n)) return n;
  }
  return undefined;
}

function extractList(root: Record<string, unknown>): Record<string, unknown>[] {
  const candidates = [root.data, root.sessions, root.result, root.items];
  for (const c of candidates) {
    if (Array.isArray(c)) return c.filter(isRecord);
  }
  const dataObj = isRecord(root.data) ? root.data : null;
  if (dataObj) {
    const nested = [dataObj.sessions, dataObj.items, dataObj.result];
    for (const n of nested) {
      if (Array.isArray(n)) return n.filter(isRecord);
    }
  }
  return [];
}

function extractTotal(root: Record<string, unknown>, fallback: number): number {
  const values = [
    root.total,
    root.total_count,
    isRecord(root.pagination) ? root.pagination.total : undefined,
    isRecord(root.pagination) ? root.pagination.total_count : undefined,
  ];
  for (const v of values) {
    const n = typeof v === 'number' ? v : typeof v === 'string' ? Number(v) : NaN;
    if (Number.isFinite(n)) return n;
  }
  return fallback;
}

function toExtractedFieldsByDoc(
  value: unknown,
): Record<string, Array<{ name: string; value: string }>> | undefined {
  const toRowsFromObject = (obj: Record<string, unknown>): Array<{ name: string; value: string }> => {
    const rows: Array<{ name: string; value: string }> = [];
    for (const [k, v] of Object.entries(obj)) {
      const name = String(k ?? '').trim();
      if (!name) continue;
      const val =
        typeof v === 'string'
          ? v.trim()
          : v != null && typeof v === 'object'
            ? JSON.stringify(v)
            : String(v ?? '').trim();
      rows.push({ name, value: val || '—' });
    }
    return rows;
  };

  let raw: unknown = value;
  if (typeof raw === 'string' && raw.trim()) {
    try {
      raw = JSON.parse(raw) as unknown;
    } catch {
      return undefined;
    }
  }

  // Sometimes API wraps this under an alias key.
  if (isRecord(raw)) {
    if ('extracted_fields' in raw) raw = raw.extracted_fields;
    else if ('extracted_response' in raw) raw = raw.extracted_response;
  }

  const out: Record<string, Array<{ name: string; value: string }>> = {};

  // New shape: [{ goods_receipt: { ... } }, { invoice: { ... } }, ...]
  if (Array.isArray(raw)) {
    for (const item of raw) {
      if (!isRecord(item)) continue;
      for (const [docKey, fields] of Object.entries(item)) {
        const key = String(docKey).trim();
        if (!key || !isRecord(fields)) continue;
        const rows = toRowsFromObject(fields);
        if (rows.length) out[key] = rows;
      }
    }
    return Object.keys(out).length > 0 ? out : undefined;
  }

  if (!isRecord(raw)) return undefined;
  for (const [docKey, fields] of Object.entries(raw)) {
    const key = String(docKey).trim();
    if (!key) continue;

    // Existing shape: { doc: [{name,value}, ...] }
    if (Array.isArray(fields)) {
      const rows: Array<{ name: string; value: string }> = [];
      for (const row of fields) {
        if (!isRecord(row)) continue;
        const name = String(row.name ?? row.field ?? row.label ?? row.key ?? '').trim();
        const val = String(row.value ?? row.field_value ?? row.text ?? row.extracted_value ?? '').trim();
        if (name) rows.push({ name, value: val || '—' });
      }
      if (rows.length) out[key] = rows;
      continue;
    }

    // Object-map shape: { doc: { FieldA: "...", FieldB: "..." } }
    if (isRecord(fields)) {
      const rows = toRowsFromObject(fields);
      if (rows.length) out[key] = rows;
    }
  }
  return Object.keys(out).length > 0 ? out : undefined;
}

function toDocumentsMap(value: unknown): Record<string, string> | undefined {
  let raw: unknown = value;
  if (typeof raw === 'string' && raw.trim()) {
    try {
      raw = JSON.parse(raw) as unknown;
    } catch {
      return undefined;
    }
  }
  if (!isRecord(raw)) return undefined;
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(raw)) {
    const uri = typeof v === 'string' ? v.trim() : '';
    if (uri) out[String(k).trim()] = uri;
  }
  return Object.keys(out).length > 0 ? out : undefined;
}

/** Parse list API `reason_for_failure` — string, JSON string, or object map. */
function normalizeReasonForFailure(value: unknown): {
  plainText?: string;
  details?: Record<string, string>;
  entries?: Array<{ sopName: string; status?: 'yes' | 'no'; explanation: string }>;
  /** Per-SOP blocks from array payloads: string keys = SOP name, row `matching` = field map. */
  sections?: Array<{
    sopName: string;
    description: string;
    status?: 'yes' | 'no';
    matching?: Record<string, unknown>;
  }>;
} {
  if (value == null || value === '') return {};
  if (typeof value === 'string') {
    const t = value.trim();
    if (!t) return {};
    if (t.startsWith('{')) {
      try {
        const parsed = JSON.parse(t) as unknown;
        return normalizeReasonForFailure(parsed);
      } catch {
        return { plainText: t };
      }
    }
    return { plainText: t };
  }
  if (Array.isArray(value)) {
    const details: Record<string, string> = {};
    const entries: Array<{ sopName: string; status?: 'yes' | 'no'; explanation: string }> = [];
    const sections: Array<{
      sopName: string;
      description: string;
      status?: 'yes' | 'no';
      matching?: Record<string, unknown>;
    }> = [];
    for (const row of value) {
      if (!isRecord(row)) continue;
      const rowStatusRaw = String(row.status ?? '').trim().toLowerCase();
      const rowStatus: 'yes' | 'no' | undefined =
        rowStatusRaw === 'yes' ? 'yes' : rowStatusRaw === 'no' ? 'no' : undefined;
      const matchingRaw = row.matching;
      const matching = isRecord(matchingRaw) ? matchingRaw : undefined;

      for (const [k, v] of Object.entries(row)) {
        const key = String(k).trim();
        const kl = key.toLowerCase();
        if (!key || kl === 'status' || kl === 'matching') continue;
        // Only string fields are SOP name → message; `matching` is attached at row level for Field Consistency.
        if (typeof v !== 'string') continue;
        const val = v.trim() || '—';
        details[key] = val;
        entries.push({ sopName: key, status: rowStatus, explanation: val });
        sections.push({
          sopName: key,
          description: val,
          status: rowStatus,
          matching,
        });
      }
    }
    if (Object.keys(details).length === 0) return {};
    const plainText = Object.entries(details)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([k, v]) => `${k}: ${v}`)
      .join('\n\n');
    return {
      details,
      plainText,
      entries,
      sections,
    };
  }
  if (!isRecord(value)) {
    const s = String(value).trim();
    return s ? { plainText: s } : {};
  }
  // Handle validation_errors shape: { validation_errors: [{message, expected_key, document_name}] }
  if (Array.isArray(value.validation_errors)) {
    const msgs = (value.validation_errors as Array<Record<string, unknown>>)
      .map((e) => String(e.message ?? '').trim())
      .filter(Boolean);
    if (msgs.length) {
      const plainText = msgs.join('\n');
      const details: Record<string, string> = {};
      const entries: Array<{ sopName: string; explanation: string }> = [];
      msgs.forEach((msg, i) => {
        details[`Validation Error ${i + 1}`] = msg;
        entries.push({ sopName: `Validation Error ${i + 1}`, explanation: msg });
      });
      return { plainText, details, entries };
    }
  }
  const details: Record<string, string> = {};
  const entries: Array<{ sopName: string; status?: 'yes' | 'no'; explanation: string }> = [];
  for (const [k, v] of Object.entries(value)) {
    const key = String(k).trim();
    if (!key) continue;
    const val =
      typeof v === 'string'
        ? v.trim()
        : v != null && typeof v === 'object'
          ? JSON.stringify(v)
          : String(v ?? '').trim();
    details[key] = val || '—';
    entries.push({ sopName: key, explanation: val || '—' });
  }
  if (Object.keys(details).length === 0) return {};
  const plainText = Object.entries(details)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}: ${v}`)
    .join('\n\n');
  return {
    details,
    plainText,
    entries,
  };
}

/** reason_for_failure can be array items with explicit status: yes/no. */
function statusFromReasonForFailure(value: unknown): ReconcileRowStatus | undefined {
  if (!Array.isArray(value)) return undefined;
  const statuses = value
    .filter(isRecord)
    .map((row) => normalizeStatus(row.status))
    .filter((s): s is ReconcileRowStatus => Boolean(s));
  if (!statuses.length) return undefined;
  if (statuses.includes('not_matched')) return 'not_matched';
  if (statuses.every((s) => s === 'matched')) return 'matched';
  if (statuses.includes('failed')) return 'failed';
  return undefined;
}

function mapSession(item: Record<string, unknown>): ReconcileRecord {
  const createdAt = String(item.created_at ?? item.createdAt ?? dayjs().toISOString());
  const documentTypesFromNames = toDocumentTypes(
    item.document_names ?? item.document_type ?? item.document_types
  );
  const documentTypesFromDocuments = isRecord(item.documents) ? toDocumentTypes(Object.keys(item.documents)) : [];
  const documentTypes =
    documentTypesFromNames.length > 0 ? documentTypesFromNames : documentTypesFromDocuments;
  const documentsByType =
    toDocumentsMap(item.documents) ?? toDocumentsMap(item.document_uris ?? item.s3_documents);
  const extractedFieldsByDoc = toExtractedFieldsByDoc(
    item.extracted_fields ??
    item.extracted_response ??
    item.extracted_field_response ??
    item.extracted_data ??
    item.fields_by_document ??
    item.document_extracted_fields ??
    item.reconciliation_fields
  );
  const reasonNorm = normalizeReasonForFailure(
    item.reason_for_failure ?? item.reason ?? item.reason_summary
  );
  const statusFromReasons = statusFromReasonForFailure(item.reason_for_failure);
  const fallbackStatus = normalizeStatus(item.reconcile_status ?? item.status);
  return {
    id: String(item.session_id ?? item.id ?? crypto.randomUUID()),
    jobName: String(item.job_name ?? item.jobName ?? '—'),
    documentTypes: documentTypes.length > 0 ? documentTypes : ['—'],
    uploadedAt: createdAt,
    reconcileStatus: statusFromReasons ?? fallbackStatus,
    reasonForFailure: reasonNorm.plainText,
    reasonForFailureDetails: reasonNorm.details,
    reasonForFailureEntries: reasonNorm.entries,
    reasonForFailureSections: reasonNorm.sections,
    documentsByType,
    extractedFieldsByDoc,
  };
}

export async function listAllSessions(filters: SessionListFilters = {}): Promise<SessionListResult> {
  const payload: ListAllSessionsPayload = {
    event_type: 'list_all_sessions',
    page: filters.page ?? 1,
    page_size: filters.pageSize ?? 10,
    job_name: filters.jobName?.trim() ?? '',
    reconcile_status: toApiReconcileStatus(filters.reconcileStatus),
    document_type: filters.documentType?.trim() ?? '',
    session_id: filters.sessionId?.trim() ?? '',
    created_by: filters.createdBy?.trim() ?? '',
    created_from: filters.createdFrom?.trim() ?? '',
    created_to: filters.createdTo?.trim() ?? '',
  };

  const response = await apiRequest<Envelope, ListAllSessionsPayload>(API_URLS.CONFIG, {
    method: 'POST',
    body: payload,
  });

  const root = unwrapEnvelope(response);
  const list = extractList(root);
  const rows = list.map(mapSession);
  return {
    rows,
    total: extractTotal(root, rows.length),
  };
}

/**
 * Presigned GET URL for an existing object — API: get_doc_upload_url + s3_uri.
 * Handles e.g. { statusCode, body: { upload_url, s3_uri, ... } }, stringified body,
 * or body nested again under statusCode.
 */
function extractUploadUrlFromGetDocResponse(data: unknown): string | undefined {
  if (!data || typeof data !== 'object') return undefined;
  const r = data as Record<string, unknown>;
  const b = r.body;
  if (isRecord(b)) {
    if (typeof b.upload_url === 'string') return b.upload_url.trim();
    const nested = extractUploadUrlFromGetDocResponse(b);
    if (nested) return nested;
  }
  if (typeof b === 'string' && b.trim()) {
    try {
      const parsed = JSON.parse(b) as unknown;
      const fromParsed = extractUploadUrlFromGetDocResponse(parsed);
      if (fromParsed) return fromParsed;
    } catch {
      /* ignore */
    }
  }
  if (typeof r.upload_url === 'string') return r.upload_url.trim();
  for (const key of ['data', 'result'] as const) {
    const wrap = r[key];
    if (isRecord(wrap)) {
      const u = extractUploadUrlFromGetDocResponse(wrap);
      if (u) return u;
    }
  }
  const inner = unwrapEnvelope(r);
  if (inner !== r && typeof inner === 'object' && inner !== null) {
    return extractUploadUrlFromGetDocResponse(inner);
  }
  return undefined;
}

/** Response shape for create_presigned_url — expects download_url (nested body supported). */
function extractDownloadUrlFromPresignResponse(data: unknown): string | undefined {
  if (!data || typeof data !== 'object') return undefined;
  const r = data as Record<string, unknown>;
  const b = r.body;
  if (isRecord(b)) {
    if (typeof b.download_url === 'string') return b.download_url.trim();
    const nested = extractDownloadUrlFromPresignResponse(b);
    if (nested) return nested;
  }
  if (typeof b === 'string' && b.trim()) {
    try {
      const parsed = JSON.parse(b) as unknown;
      const fromParsed = extractDownloadUrlFromPresignResponse(parsed);
      if (fromParsed) return fromParsed;
    } catch {
      /* ignore */
    }
  }
  if (typeof r.download_url === 'string') return r.download_url.trim();
  for (const key of ['data', 'result'] as const) {
    const wrap = r[key];
    if (isRecord(wrap)) {
      const u = extractDownloadUrlFromPresignResponse(wrap);
      if (u) return u;
    }
  }
  const inner = unwrapEnvelope(r);
  if (inner !== r && typeof inner === 'object' && inner !== null) {
    return extractDownloadUrlFromPresignResponse(inner);
  }
  return undefined;
}

/** Presigned GET URL for download — API: create_presigned_url + s3_uri + expiry. */
export async function createPresignedDownloadUrlForS3Uri(
  s3Uri: string,
  expirySeconds = 3600
): Promise<string> {
  const trimmed = s3Uri.trim();
  if (!trimmed) throw new Error('s3_uri is required');

  const response = await apiRequest<Envelope, Record<string, unknown>>(API_URLS.CONFIG, {
    method: 'POST',
    body: {
      event_type: 'create_presigned_url',
      s3_uri: trimmed,
      expiry: expirySeconds,
    },
  });

  const url =
    extractDownloadUrlFromPresignResponse(response) ??
    extractDownloadUrlFromPresignResponse(unwrapEnvelope(response));
  if (!url) {
    throw new Error('No download_url returned from create_presigned_url');
  }
  return url;
}

export async function getDocPresignedUrlForS3Uri(s3Uri: string): Promise<string> {
  const trimmed = s3Uri.trim();
  if (!trimmed) throw new Error('s3_uri is required');

  const response = await apiRequest<Envelope, Record<string, string>>(API_URLS.CONFIG, {
    method: 'POST',
    body: {
      event_type: 'get_doc_upload_url',
      s3_uri: trimmed,
    },
  });

  const url =
    extractUploadUrlFromGetDocResponse(response) ??
    extractUploadUrlFromGetDocResponse(unwrapEnvelope(response));
  if (!url) {
    throw new Error('No presigned URL returned from get_doc_upload_url');
  }
  return url;
}

export async function reconcileGenerateUploadUrl(
  sessionId: string,
  filename: string
): Promise<ReconcileUploadUrlResponse> {
  const response = await apiRequest<Envelope, Record<string, unknown>>(API_URLS.CONFIG, {
    method: 'POST',
    body: {
      event_type: 'reconcile_generate_url',
      session_id: sessionId,
      filename,
    },
  });

  const root = unwrapEnvelope(response);
  const uploadUrl = typeof root.upload_url === 'string' ? root.upload_url.trim() : '';
  if (!uploadUrl) {
    throw new Error('No upload_url returned from reconcile_generate_url');
  }

  return {
    uploadUrl,
    s3Uri: typeof root.s3_uri === 'string' ? root.s3_uri : undefined,
    s3Key: typeof root.s3_key === 'string' ? root.s3_key : undefined,
    expiry: toNumber(root.expiry),
  };
}

export async function uploadReconcileFileToPresignedUrl(
  uploadUrl: string,
  file: File,
  signal?: AbortSignal
): Promise<void> {
  const response = await fetch(uploadUrl, {
    method: 'PUT',
    headers: {
      'Content-Type': file.type || 'application/pdf',
    },
    body: file,
    signal,
  });
  if (!response.ok) {
    const text = await response.text().catch(() => '');
    throw new Error(
      text ? `Upload failed (${response.status}): ${text.slice(0, 200)}` : `Upload failed (${response.status})`
    );
  }
}

export async function reconcileDocuments(payload: ReconcileDocumentsPayload): Promise<Envelope> {
  return apiRequest<Envelope, ReconcileDocumentsPayload>(API_URLS.RECONCILE_AI, {
    method: 'POST',
    body: payload,
  });
}

export async function deleteTestSop(exceptionName: string, updatedBy: string): Promise<Envelope> {
  return apiRequest<Envelope, { event_type: string; exception_name: string; updated_by: string }>(API_URLS.CONFIG, {
    method: 'POST',
    body: { event_type: 'delete_test_sop', exception_name: exceptionName, updated_by: updatedBy },
  });
}

/** Config Lambda: deletes the session row from session_table (existing SOP test runs only). */
export async function removeTestSession(sessionId: string): Promise<Envelope> {
  return apiRequest<Envelope, { event_type: string; session_id: string }>(API_URLS.CONFIG, {
    method: 'POST',
    body: { event_type: 'test_session_removal', session_id: sessionId },
  });
}

export type DocumentPollStatusPayload = {
  event_type: 'document_poll-status';
  session_id: string;
  /** true → session_table (existing SOP test, reconcile agent). false → session_table_test (new / version SOP test). */
  use_session_table: boolean;
};

export async function pollDocumentStatus(
  sessionId: string,
  options?: { useSessionTable?: boolean }
): Promise<Envelope> {
  const useSessionTable = Boolean(options?.useSessionTable);
  return apiRequest<Envelope, DocumentPollStatusPayload>(API_URLS.CONFIG, {
    method: 'POST',
    body: {
      event_type: 'document_poll-status',
      session_id: sessionId,
      use_session_table: useSessionTable,
    },
  });
}

function parsePollBody(raw: Record<string, unknown>): Record<string, unknown> {
  const body =
    typeof raw.body === 'string'
      ? (JSON.parse(raw.body) as Record<string, unknown>)
      : (raw.body as Record<string, unknown> | undefined) ?? raw;
  return body;
}

/** Normalized statuses that stop polling (same rules as SOP test flow). */
export function isTerminalReconcileStatus(status: string): boolean {
  const s = status.toLowerCase();
  return (
    s === 'yes' ||
    s === 'no' ||
    s === 'validation failed' ||
    s === 'validation_failed' ||
    s === 'failed' ||
    s === 'validation_status'
  );
}

/**
 * Polls document_poll-status until reconcile_status is terminal or the promise rejects.
 */
export async function pollReconcileUntilTerminal(
  sessionId: string,
  options?: { intervalMs?: number; useSessionTable?: boolean }
): Promise<Record<string, unknown>> {
  const intervalMs = options?.intervalMs ?? 10000;
  const useSessionTable = Boolean(options?.useSessionTable);
  return new Promise<Record<string, unknown>>((resolve, reject) => {
    const poll = () => {
      void pollDocumentStatus(sessionId, { useSessionTable })
        .then((res) => {
          const raw = res as Record<string, unknown>;
          const body = parsePollBody(raw);
          const status = String(body?.reconcile_status ?? '');
          if (isTerminalReconcileStatus(status)) {
            resolve(body);
          } else {
            setTimeout(poll, intervalMs);
          }
        })
        .catch(reject);
    };
    poll();
  });
}

export type SessionDocumentsResult = {
  sessionId: string;
  jobId: number;
  jobName: string;
  s3Uris: Record<string, string>;
  originalNames: Record<string, string>;
};

export async function getSessionDocuments(sessionId: string): Promise<SessionDocumentsResult> {
  const response = await apiRequest<Envelope, { event_type: string; session_id: string }>(API_URLS.CONFIG, {
    method: 'POST',
    body: { event_type: 'get_session_documents', session_id: sessionId },
  });

  const root = unwrapEnvelope(response);
  return {
    sessionId: String(root.session_id ?? sessionId),
    jobId: toNumber(root.job_id) ?? 0,
    jobName: String(root.job_name ?? ''),
    s3Uris: isRecord(root.s3_uris)
      ? Object.fromEntries(
          Object.entries(root.s3_uris)
            .filter(([, v]) => v != null && String(v) !== 'null')
            .map(([k, v]) => [k, String(v)]),
        )
      : {},
    originalNames: isRecord(root.original_names)
      ? Object.fromEntries(Object.entries(root.original_names).map(([k, v]) => [k, String(v)]))
      : {},
  };
}
