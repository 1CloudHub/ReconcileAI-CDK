import { API_URLS } from '../config/api.config';
import { apiRequest } from './api';

// The raw shape of whatever the SOP Lambda returns — kept loose because
// the backend wraps responses differently depending on the event_type.
export type SopApiEnvelope = Record<string, unknown>;

// Narrow type guard used throughout to safely treat an `unknown` value as a
// plain object before reading properties off it.
function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null;
}

// Safely parse a JSON string into an object. Returns undefined instead of
// throwing so callers can fall back gracefully when the body is malformed.
function parseJsonRecord(raw: string): Record<string, unknown> | undefined {
  try {
    const v = JSON.parse(raw) as unknown;
    return isRecord(v) ? v : undefined;
  } catch {
    return undefined;
  }
}

// The SOP Lambda wraps its real payload inside a { statusCode, body } envelope
// (standard AWS API Gateway / Lambda proxy format).  This function:
//   1. Detects whether the envelope is present (some code paths skip it).
//   2. Throws a human-readable error when statusCode is non-200 so the UI can
//      surface it in a toast/alert rather than crashing silently.
//   3. Unwraps `body` — which may be a JSON string or already-parsed object —
//      and returns the inner payload so callers only deal with real data.
function unwrapSopLambdaBody(res: SopApiEnvelope): Record<string, unknown> {
  const r = res as Record<string, unknown>;
  if (!('statusCode' in r) && !('body' in r)) {
    // No envelope: Lambda returned the payload directly, nothing to unwrap.
    return r;
  }
  const sc = r.statusCode;
  const scNum = typeof sc === 'number' ? sc : typeof sc === 'string' ? Number(sc) : NaN;
  if (Number.isFinite(scNum) && scNum !== 200) {
    // Non-200 → surface the most descriptive message available to the UI.
    const msg =
      typeof r.message === 'string'
        ? r.message
        : typeof r.body === 'string'
          ? r.body
          : `Request failed (${scNum})`;
    throw new Error(msg);
  }
  const b = r.body;
  if (typeof b === 'string') {
    // Lambda serialises the inner JSON as a string — parse it back.
    return parseJsonRecord(b) ?? {};
  }
  if (isRecord(b)) {
    // Already an object, use directly.
    return b;
  }
  return {};
}

// The backend returns presigned S3 PUT URLs in several different shapes
// depending on whether the upload is single-file or multi-file:
//   • { upload_url: "https://…" }           — single string
//   • { upload_url: ["https://…", …] }      — array of strings
//   • { upload_urls: [{ upload_url|presigned_url|url }] } — array of objects
//   • { uploads|presigned_uploads|presigned_urls: [{…}] } — nested arrays
// This function normalises all of those into a flat string array so the
// upload flow in the UI doesn't need to care about which shape arrived.
function collectUploadUrlsFromRoot(root: Record<string, unknown>): string[] {
  const pushString = (out: string[], v: unknown) => {
    if (typeof v === 'string' && v.trim().length > 0) out.push(v.trim());
  };

  const out: string[] = [];

  // Check the singular `upload_url` key first (most common shape).
  const single = root.upload_url;
  if (typeof single === 'string') {
    pushString(out, single);
    return out;
  }
  if (Array.isArray(single)) {
    for (const x of single) pushString(out, x);
    if (out.length > 0) return out;
  }

  // Try the plural key whose items may be plain strings or objects.
  const plural = root.upload_urls;
  if (Array.isArray(plural)) {
    for (const x of plural) {
      if (isRecord(x)) {
        // Object item — try the three common field names in priority order.
        pushString(out, x.upload_url ?? x.presigned_url ?? x.url);
      } else {
        pushString(out, x);
      }
    }
  }
  if (out.length > 0) return out;

  // Last resort: check alternative wrapper keys the backend might use.
  const nestedKeys = ['uploads', 'presigned_uploads', 'presigned_urls'] as const;
  for (const key of nestedKeys) {
    const arr = root[key];
    if (!Array.isArray(arr)) continue;
    for (const item of arr) {
      if (!isRecord(item)) continue;
      const u = item.upload_url ?? item.presigned_url ?? item.url;
      pushString(out, u);
    }
    if (out.length > 0) return out;
  }

  return out;
}

// Pairs a presigned URL with the filename the backend associated with it.
// The filename is shown in the upload progress UI so the user can track
// which file is uploading when multiple files are selected at once.
export type SopUploadTarget = {
  filename?: string;
  uploadUrl: string;
  s3Key?: string;
};

// Same multi-shape normalisation as `collectUploadUrlsFromRoot` but also
// captures the filename alongside each URL.  The UI uses the filename to
// display per-file progress and to label completed uploads in the SOP table.
function collectUploadTargetsFromRoot(root: Record<string, unknown>): SopUploadTarget[] {
  const add = (out: SopUploadTarget[], filename: unknown, uploadUrl: unknown, s3Key: unknown) => {
    if (typeof uploadUrl !== 'string' || uploadUrl.trim() === '') return;
    const name = typeof filename === 'string' && filename.trim() ? filename.trim() : undefined;
    const key = typeof s3Key === 'string' && s3Key.trim() ? s3Key.trim() : undefined;
    out.push({ filename: name, uploadUrl: uploadUrl.trim(), ...(key ? { s3Key: key } : {}) });
  };

  const out: SopUploadTarget[] = [];

  // Iterate the same set of keys as `collectUploadUrlsFromRoot`, but pull the
  // filename fields (filename / file_name / name) from each item too.
  const keys = ['upload_urls', 'uploads', 'presigned_uploads', 'presigned_urls'] as const;
  for (const key of keys) {
    const arr = root[key];
    if (!Array.isArray(arr)) continue;
    for (const item of arr) {
      if (isRecord(item)) {
        add(
          out,
          item.filename ?? item.file_name ?? item.name,
          item.upload_url ?? item.presigned_url ?? item.url,
          item.s3_key ?? item.s3Key ?? item.s3_path,
        );
      } else if (typeof item === 'string') {
        // Plain URL with no filename info — filename will be undefined.
        add(out, undefined, item, undefined);
      }
    }
    if (out.length > 0) return out;
  }

  // Single-url fallback for responses that only contain one file.
  const single = root.upload_url;
  if (typeof single === 'string' && single.trim()) {
    out.push({ uploadUrl: single.trim() });
  }
  return out;
}

/**
 * Extracts all presigned S3 PUT URLs from an `add_sop` / `update_sop` response.
 *
 * The caller (upload flow) iterates the returned array and calls
 * `uploadSopFileToPresignedUrl` once per URL to PUT each file to S3.
 * Throws if no URL is found so the upload flow can surface an error instead
 * of silently skipping the file.
 */
export function parseAddSopUploadUrls(res: SopApiEnvelope): string[] {
  const r = res as Record<string, unknown>;

  // Try the raw response first — some Lambda configurations skip the envelope.
  let urls = collectUploadUrlsFromRoot(r);
  if (urls.length > 0) return urls;

  // Fall back to unwrapping the { statusCode, body } envelope.
  const inner = unwrapSopLambdaBody(res);
  urls = collectUploadUrlsFromRoot(inner);
  if (urls.length === 0) {
    throw new Error('No upload URL in server response');
  }
  return urls;
}

/**
 * Same as `parseAddSopUploadUrls` but returns `SopUploadTarget` objects that
 * include the filename alongside each URL.  Prefer this over the URL-only
 * version when you need to show per-file labels in the upload progress UI.
 */
export function parseAddSopUploadTargets(res: SopApiEnvelope): SopUploadTarget[] {
  const r = res as Record<string, unknown>;
  let targets = collectUploadTargetsFromRoot(r);
  if (targets.length > 0) return targets;
  const inner = unwrapSopLambdaBody(res);
  targets = collectUploadTargetsFromRoot(inner);
  if (targets.length === 0) {
    throw new Error('No upload URL in server response');
  }
  return targets;
}

/**
 * Backward-compatible helper for single-file upload flows.
 * Returns the first presigned URL plus the full unwrapped payload (`raw`) so
 * older UI code that reads metadata fields (e.g. sop_id) off the response
 * doesn't need to be rewritten.
 */
export function parseAddSopResponse(res: SopApiEnvelope): { uploadUrl: string; raw: Record<string, unknown> } {
  const urls = parseAddSopUploadUrls(res);
  const r = res as Record<string, unknown>;

  // Prefer the already-parsed body object; fall back to unwrapping the envelope.
  const raw =
    'body' in r && isRecord(r.body)
      ? r.body
      : 'body' in r && typeof r.body === 'string'
        ? (parseJsonRecord(r.body) ?? {})
        : unwrapSopLambdaBody(res);

  return { uploadUrl: urls[0], raw: isRecord(raw) ? raw : r };
}

export function parseAddSopResponseWithS3Key(res: SopApiEnvelope): {
  uploadUrl?: string;
  s3Key: string;
  raw: Record<string, unknown>;
} {
  const r = res as Record<string, unknown>;
  const raw =
    'body' in r && isRecord(r.body)
      ? r.body
      : 'body' in r && typeof r.body === 'string'
        ? (parseJsonRecord(r.body) ?? {})
        : unwrapSopLambdaBody(res);

  const inner = isRecord(raw) ? raw : r;
  const uploadUrl = typeof inner.upload_url === 'string' ? inner.upload_url : undefined;

  // Prefer s3_key returned by update_sop (single), fall back to upload_urls[0].s3_key (add_sop/upload_sop_test)
  const s3KeyDirect = typeof inner.s3_key === 'string' ? inner.s3_key : '';
  const uploadUrls = Array.isArray(inner.upload_urls) ? inner.upload_urls : [];
  const firstItem = uploadUrls[0];
  const s3KeyFromList =
    firstItem && typeof firstItem === 'object' && typeof (firstItem as Record<string, unknown>).s3_key === 'string'
      ? String((firstItem as Record<string, unknown>).s3_key)
      : '';

  const s3Key = (s3KeyDirect || s3KeyFromList).trim();
  if (!s3Key) {
    throw new Error('No s3_key in server response');
  }

  return { uploadUrl, s3Key, raw: inner };
}

/**
 * Streams a local File directly to S3 via a presigned PUT URL.
 * This bypasses our own API server so large PDFs don't time out or exhaust
 * Lambda memory — S3 receives the bytes directly from the browser.
 *
 * `Content-Type` is set so S3 serves the file back with the correct MIME type
 * when the user later downloads it through the presigned GET URL.
 */
export async function uploadSopFileToPresignedUrl(
  uploadUrl: string,
  file: File,
  signal?: AbortSignal
): Promise<void> {
  const response = await fetch(uploadUrl, {
    method: 'PUT',
    headers: {
      'Content-Type': file.type || 'application/octet-stream',
    },
    body: file,
    signal,
  });
  if (!response.ok) {
    // Read S3's XML error body (truncated) so the UI can show something more
    // specific than a generic "upload failed" message.
    const text = await response.text().catch(() => '');
    throw new Error(
      text ? `Upload failed (${response.status}): ${text.slice(0, 200)}` : `Upload failed (${response.status})`
    );
  }
}

// Central POST helper — all SOP operations go to the same API endpoint and
// are differentiated by the `event_type` field in the payload.  This mirrors
// the Lambda router pattern on the backend.
async function postSop(payload: Record<string, unknown>): Promise<SopApiEnvelope> {
  return apiRequest<SopApiEnvelope, Record<string, unknown>>(API_URLS.CONFIG, {
    method: 'POST',
    body: payload,
  });
}

// The backend may return a presigned GET URL under any of these keys.
// Priority order: most specific → most generic so we don't accidentally
// grab an upload (PUT) URL from a response that also contains a `url` field.
const DOWNLOAD_URL_KEYS = [
  'download_url',
  'presigned_url',
  'presigned_download_url',
  'signed_url',
  'url',
] as const;

/**
 * Extracts the presigned S3 GET URL from a `generate_presigned_download_url`
 * Lambda response so the UI can open or iframe the SOP document directly
 * without proxying the file through the server.
 *
 * Handles both the raw payload and the { statusCode, body } envelope.
 */
export function parsePresignedDownloadUrlResponse(res: SopApiEnvelope): string {
  // Try each key name in priority order, return on first hit.
  const pick = (obj: Record<string, unknown>): string | undefined => {
    for (const key of DOWNLOAD_URL_KEYS) {
      const v = obj[key];
      if (typeof v === 'string' && v.trim().length > 0) return v.trim();
    }
    return undefined;
  };

  const r = res as Record<string, unknown>;

  // Fast path: URL is at the top level (no envelope).
  const direct = pick(r);
  if (direct) return direct;

  // Slow path: unwrap the { statusCode, body } envelope manually.
  // (Not reusing `unwrapSopLambdaBody` here so we can call `pick` on `root`
  // without a second function call after the unwrap.)
  let root: Record<string, unknown> = r;
  if ('statusCode' in r || 'body' in r) {
    const sc = r.statusCode;
    const scNum = typeof sc === 'number' ? sc : typeof sc === 'string' ? Number(sc) : NaN;
    if (Number.isFinite(scNum) && scNum !== 200) {
      const msg =
        typeof r.message === 'string'
          ? r.message
          : typeof r.body === 'string'
            ? r.body
            : `Request failed (${scNum})`;
      throw new Error(msg);
    }
    const b = r.body;
    if (typeof b === 'string') {
      root = parseJsonRecord(b) ?? {};
    } else if (isRecord(b)) {
      root = b;
    } else {
      root = {};
    }
  }

  const nested = pick(root);
  if (nested) return nested;
  throw new Error('No download URL in server response');
}

// Requests a short-lived presigned GET URL for an existing SOP document.
// The UI passes this URL to an <iframe> or <a href> so the user can preview
// or download the PDF without exposing the real S3 path.
export async function generatePresignedDownloadUrl(s3Uri: string): Promise<SopApiEnvelope> {
  const uri = s3Uri.trim();
  if (!uri) {
    throw new Error('s3_uri is required');
  }
  return postSop({
    event_type: 'generate_presigned_download_url',
    s3_uri: uri,
  });
}

// Filter shape used by the SOP list page.  All fields are optional — only
// the ones with values are included in the Lambda payload so the backend
// can combine them with AND logic.
export type ListSopsFilters = {
  exceptionName?: string;
  jobId?: number;
  createdAt?: string;
  s3Uri?: string;
};

/**
 * Fetches a paginated list of SOPs.
 *
 * `searchOrFilters` is intentionally a union type:
 *   - string  → free-text search (sent as `search` in the payload)
 *   - object  → structured filters (exception_name, job_id, etc.)
 * This lets the search bar and the filter panel share one API call.
 */
export const listSops = async (
  page = 1,
  pageSize = 10,
  searchOrFilters?: string | ListSopsFilters
): Promise<SopApiEnvelope> => {
  const payload: Record<string, unknown> = {
    event_type: 'list_sops',
    page,
    page_size: pageSize,
  };

  if (typeof searchOrFilters === 'string') {
    // Free-text search mode — skip structured filter logic.
    const q = searchOrFilters.trim();
    if (q) payload.search = q;
    return postSop(payload);
  }

  if (searchOrFilters) {
    // Structured filter mode — only include fields that have a value so the
    // backend doesn't interpret empty strings as intentional filter values.
    const exceptionName = searchOrFilters.exceptionName?.trim();
    if (exceptionName) payload.exception_name = exceptionName;
    if (typeof searchOrFilters.jobId === 'number' && Number.isFinite(searchOrFilters.jobId)) {
      payload.job_id = searchOrFilters.jobId;
    }
    if (searchOrFilters.createdAt?.trim()) {
      payload.created_at = searchOrFilters.createdAt.trim();
    }
    if (searchOrFilters.s3Uri?.trim()) {
      payload.s3_uri = searchOrFilters.s3Uri.trim();
    }
  }

  return postSop(payload);
};

/** Page alias for `listSops` (same Lambda payload). */
export const fetchSops = listSops;

// Dry-run version of `addSop` — sends the same payload with a different
// event_type so the backend validates the request without persisting anything.
// Used by the upload wizard to preflight filenames before committing.
export const uploadSopTest = async (
  exceptionName: string,
  jobIds: number[],
  filename: string | string[],
  createdBy: string
): Promise<SopApiEnvelope> => {
  // Normalise to an array and strip blank entries so a forgotten trailing
  // comma in a CSV input doesn't create phantom filenames.
  const names = (Array.isArray(filename) ? filename : [filename]).map((s) => s.trim()).filter(Boolean);
  if (names.length === 0) {
    throw new Error('At least one filename is required');
  }
  return postSop({
    event_type: 'upload_sop_test',
    exception_name: exceptionName,
    job_ids: jobIds,
    filename: names,
    created_by: createdBy,
  });
};

/**
 * Step 1 of the SOP upload flow: registers the SOP record in the DB and
 * receives presigned S3 PUT URL(s) in return.
 *
 * The UI calls this first, then calls `uploadSopFileToPresignedUrl` for each
 * returned URL to push the actual bytes to S3.  Separating the two steps
 * means the DB record is created before the file transfer starts, so a failed
 * S3 upload can be retried without duplicating the DB row.
 */
export const addSop = async (
  exceptionName: string,
  jobIds: number[],
  filename: string | string[],
  createdBy: string
): Promise<SopApiEnvelope> => {
  const names = (Array.isArray(filename) ? filename : [filename]).map((s) => s.trim()).filter(Boolean);
  if (names.length === 0) {
    throw new Error('At least one filename is required');
  }
  return postSop({
    event_type: 'add_sop',
    exception_name: exceptionName,
    job_ids: jobIds,
    filename: names,
    created_by: createdBy,
  });
};

// All fields are optional so the edit form can send only the changed values.
// Sending undefined fields is skipped in `updateSop` so the backend
// interprets absence as "no change" rather than "clear this field".
export type UpdateSopOptions = {
  exceptionName?: string;
  jobIds?: number[];
  filename?: string;
};

/**
 * Updates an existing SOP record.  Only the fields present in `options` are
 * included in the payload — this prevents accidentally overwriting fields the
 * user didn't touch in the edit form.
 *
 * Returns the unwrapped inner payload (not the raw envelope) because callers
 * need to read the updated record fields (e.g. new version number) immediately.
 */
export const updateSop = async (
  sopId: number,
  updatedBy: string,
  options: UpdateSopOptions
): Promise<SopApiEnvelope> => {
  const payload: Record<string, unknown> = {
    event_type: 'update_sop',
    sop_id: sopId,
    updated_by: updatedBy,
  };
  if (options.exceptionName !== undefined) payload.exception_name = options.exceptionName;
  if (options.jobIds !== undefined) payload.job_ids = options.jobIds;
  if (options.filename !== undefined) payload.filename = options.filename;
  const res = await postSop(payload);
  // Unwrap here so callers get the real data, not the envelope.
  return unwrapSopLambdaBody(res);
};

/**
 * Soft- or hard-deletes a SOP document.
 *
 * `s3Uri` and `version` are optional:
 *   - Omitting `s3Uri` → delete the entire SOP record (all versions).
 *   - Providing `s3Uri` + `version` → delete only that specific version,
 *     which is what the "Delete version" button in the version history panel does.
 */
export const deleteSop = async (
  sopId: number,
  updatedBy: string,
  s3Uri?: string,
  version?: number
): Promise<SopApiEnvelope> => {
  const payload: Record<string, unknown> = {
    event_type: 'delete_sop',
    sop_id: sopId,
    updated_by: updatedBy,
  };
  // Only include these if meaningful — empty string s3_uri confuses the backend.
  if (s3Uri !== undefined && s3Uri !== '') payload.s3_uri = s3Uri;
  if (version !== undefined) payload.version = version;
  return postSop(payload);
};

/**
 * Marks a specific version of a SOP as the active (live) document.
 * The UI calls this from the version history panel when the user clicks
 * "Set as active" — the backend updates the `is_active` flag and the
 * SOP table re-fetches to reflect the change.
 */
export const setActiveSopDocument = async (
  sopId: number,
  version: number
): Promise<SopApiEnvelope> => {
  return postSop({
    event_type: 'set_active_sop_document',
    sop_id: sopId,
    version,
  });
};

// Shape of a single job option used to populate the "Job" dropdown in the
// SOP upload / edit form.
export type JobOption = { id: number; job_name: string };

/**
 * Fetches all available jobs for the SOP form's job multi-select.
 * The backend may return them under `result` or `jobs` depending on the
 * Lambda version, so both keys are checked before falling back to an empty
 * array (which renders as an empty dropdown rather than crashing).
 */
export async function listJobs(): Promise<JobOption[]> {
  const res = await postSop({ event_type: 'list_jobs' });
  const r = res as Record<string, unknown>;
  // Normalise the two possible wrapper keys to a single array.
  const arr = Array.isArray(r.result) ? r.result : Array.isArray(r.jobs) ? r.jobs : [];
  return (arr as Record<string, unknown>[])
    .filter((j) => typeof j.id === 'number' && typeof j.job_name === 'string')
    .map((j) => ({ id: j.id as number, job_name: j.job_name as string }));
}
