import { API_URLS } from '../config/api.config';
import { apiRequest } from './api';

export interface TokenUsageRecord {
  id: string;
  created_at: string;
  module: string;
  documents: string[];
  input_tokens: number;
  output_tokens: number;
  total_tokens: number;
  type: string;
}

export interface TokenUsageFilters {
  page?: number;
  pageSize?: number;
  module?: string;
  type?: string;
  startDate?: string;
  endDate?: string;
}

export interface TokenUsageResult {
  rows: TokenUsageRecord[];
  total: number;
}

/**
 * Fetches token usage logs from the API.
 * Uses the list_token_usage event_type.
 */
export async function listTokenUsage(filters: TokenUsageFilters = {}): Promise<TokenUsageResult> {
  const payload = {
    event_type: 'list_token_usage',
    page: filters.page ?? 1,
    page_size: filters.pageSize ?? 10,
    module: filters.module?.trim() || undefined,
    type: filters.type?.trim() || undefined,
    start_date: filters.startDate?.trim() || undefined,
    end_date: filters.endDate?.trim() || undefined,
  };

  try {
    const response = await apiRequest<any, any>(API_URLS.CONFIG, {
      method: 'POST',
      body: payload,
    });

    // Handle potential AWS Lambda proxy response wrapper
    const root = response.body 
      ? (typeof response.body === 'string' ? JSON.parse(response.body) : response.body) 
      : (response.result || response);
    
    // Extract list and total with fallbacks
    const list = Array.isArray(root.data) ? root.data : (Array.isArray(root.items) ? root.items : []);
    
    const rows: TokenUsageRecord[] = list.map((item: any) => {
      const input = Number(item.input_tokens ?? 0);
      const output = Number(item.output_tokens ?? 0);
      
      // Map document_name array or document names from various potential keys
      const docsArr = Array.isArray(item.document_name) 
        ? item.document_name 
        : (Array.isArray(item.documents) ? item.documents : []);

      return {
        id: String(item.id || item.log_id || item.session_id || Math.random().toString(36).substr(2, 9)),
        created_at: String(item.created_at || item.timestamp || new Date().toISOString()),
        module: String(item.module || item.module_name || '—'),
        documents: docsArr.map(String),
        input_tokens: input,
        output_tokens: output,
        total_tokens: Number(item.total_tokens ?? (input + output)),
        type: String(item.type || '—'),
      };
    });

    // Extract total from pagination object if present
    const total = Number(
      root.pagination?.total_count ?? 
      root.total ?? 
      root.total_count ?? 
      rows.length
    );

    return { rows, total };
  } catch (error) {
    console.error('API Error in listTokenUsage:', error);
    throw error;
  }
}
