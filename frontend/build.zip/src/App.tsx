import type { ReactNode } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import Layout from './components/Layout/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import SopControlCenter from './pages/SOPConfig/SopControlCenter';
import DocumentTypes from './pages/DocumentTypes';
import JobConfig from './pages/JobConfig';
import SopEditor from './pages/SOPConfig/SopEditor';
import ReconcileRecords from './pages/ReconcileAgent/ReconcileRecords';
import ReconcileSessionDetail from './components/ReconcileAgentSession/ReconcileSessionDetail';
import ReconcileFileUpload from './pages/ReconcileAgent/ReconcileFileUpload';
import TokenUsageLogs from './pages/TokenUsage/TokenUsageLogs';


function ProtectedRoute({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  return children;
}

function RootRedirect() {
  const { user } = useAuth();
  return <Navigate to={user ? '/dashboard' : '/login'} replace />;
}

function App() {
  return (
    <Routes>
      <Route path="/" element={<RootRedirect />} />
      <Route path="/login" element={<Login />} />
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <Layout>
              <Dashboard />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/sop-control-center"
        element={
          <ProtectedRoute>
            <Layout>
              <SopControlCenter />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/new_sop"
        element={
          <ProtectedRoute>
            <Layout>
              <SopEditor />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/:sop_name/edit"
        element={
          <ProtectedRoute>
            <Layout>
              <SopEditor />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/reconcile-agent/records"
        element={
          <ProtectedRoute>
            <Layout>
              <ReconcileRecords />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/reconcile-agent/records/view"
        element={
          <ProtectedRoute>
            <Layout>
              <ReconcileSessionDetail />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/reconcile-agent/file-upload"
        element={
          <ProtectedRoute>
            <Layout>
              <ReconcileFileUpload />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/document-types"
        element={
          <ProtectedRoute>
            <Layout>
              <DocumentTypes />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/job-config"
        element={
          <ProtectedRoute>
            <Layout>
              <JobConfig />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/token-usage"
        element={
          <ProtectedRoute>
            <Layout>
              <TokenUsageLogs />
            </Layout>
          </ProtectedRoute>
        }
      />
      <Route path="*" element={<RootRedirect />} />
    </Routes>
  );
}

export default App;
