import { Pencil } from 'lucide-react';
import { Tooltip } from 'antd';
import Input from '../../components/ui/Input';
import PrimaryButton from '../../components/ui/PrimaryButton';
import SecondaryButton from '../../components/ui/SecondaryButton';
import SelectInput from '../../components/ui/SelectInput';
import type { FormState } from '../../hooks/sopEditor/sopEditorHelpers';

type JobOption = { value: number; label: string };

type Props = {
  isEditMode: boolean;
  exceptionDetailsEditing: boolean;
  exceptionName: string;
  jobsReadOnlyDisplay: string;
  errors: FormState['errors'];
  jobOptions: JobOption[];
  jobsLoading: boolean;
  selectedJobIds: number[];
  exceptionDetailsSaving: boolean;
  updateForm: (partial: Partial<FormState>) => void;
  startExceptionDetailsEdit: () => void;
  cancelExceptionDetailsEdit: () => void;
  validateAndSave: () => void;
};

export default function SopDetailsSection({
  isEditMode,
  exceptionDetailsEditing,
  exceptionName,
  jobsReadOnlyDisplay,
  errors,
  jobOptions,
  jobsLoading,
  selectedJobIds,
  exceptionDetailsSaving,
  updateForm,
  startExceptionDetailsEdit,
  cancelExceptionDetailsEdit,
  validateAndSave,
}: Props) {
  return (
    <section className="rounded-xl border border-slate-200/80 bg-white p-4 shadow-sm">
      <div className="mb-4 flex flex-col gap-3 border-b border-slate-200 pb-3 sm:flex-row sm:items-center sm:justify-between">
        <h3 className="m-0 text-[18px] font-semibold text-slate-800">SOP Details</h3>
        {isEditMode && !exceptionDetailsEditing ? (
          <Tooltip title="Edit">
            <span className="inline-flex">
              <SecondaryButton
                icon={<Pencil size={16} strokeWidth={2} />}
                text="Edit"
                className="self-start min-h-[38px] rounded-[10px] px-4 text-sm sm:self-auto"
                onClick={startExceptionDetailsEdit}
              />
            </span>
          </Tooltip>
        ) : null}
      </div>

      {isEditMode && !exceptionDetailsEditing ? (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <div className="flex flex-col gap-1">
            <span className="text-[14px] font-semibold text-gray-800">SOP Name</span>
            <p className="m-0 text-[15px] leading-6 text-slate-900">
              {exceptionName.trim() ? exceptionName : '—'}
            </p>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-[14px] font-semibold text-gray-800">Jobs</span>
            <p className="m-0 text-[15px] leading-6 text-slate-900">
              {jobsReadOnlyDisplay.trim() ? jobsReadOnlyDisplay : '—'}
            </p>
          </div>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Input
              label="SOP Name"
              value={exceptionName}
              onChange={(e) => {
                updateForm({
                  exceptionName: e.target.value,
                  errors: { ...errors, exceptionName: undefined },
                });
              }}
              error={errors.exceptionName}
              errorClassName="m-0 mt-1 text-[14px] leading-6 text-[#ff4d4f]"
              required
              className="h-10"
            />
            <div className="flex flex-col gap-1.5">
              <label
                className="text-[14px] font-semibold text-gray-800 leading-snug"
                htmlFor="sop-editor-jobs"
              >
                Select Job <span className="ml-0.5 text-red-600">*</span>
              </label>
              <SelectInput<number>
                id="sop-editor-jobs"
                useDefaultWidth={false}
                className="w-full [&_.ant-select-selector]:!h-10 [&_.ant-select-selector]:!min-h-10 [&_.ant-select-selector]:!items-center [&_.ant-select-selector]:!flex"
                allowClear
                value={selectedJobIds[0] ?? undefined}
                options={jobOptions}
                loading={jobsLoading}
                disabled={jobsLoading}
                onChange={(v) => {
                  const ids = v != null && Number.isFinite(Number(v)) ? [Number(v)] : [];
                  updateForm({ selectedJobIds: ids, errors: { ...errors, jobId: undefined } });
                }}
                status={errors.jobId ? 'error' : undefined}
                placeholder={jobsLoading ? 'Loading jobs…' : 'Select job'}
                size="large"
                optionFilterProp="label"
                showSearch
              />
              {errors.jobId ? (
                <p className="m-0 mt-1 text-[14px] leading-6 text-[#ff4d4f]">{errors.jobId}</p>
              ) : null}
            </div>
          </div>

          {isEditMode && exceptionDetailsEditing ? (
            <div className="mt-4 flex justify-end gap-2">
              <button
                type="button"
                className="inline-flex items-center justify-center rounded-[10px] border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                onClick={cancelExceptionDetailsEdit}
              >
                Cancel
              </button>
              <PrimaryButton
                text="Save"
                disabled={exceptionDetailsSaving}
                onClick={validateAndSave}
              />
            </div>
          ) : null}
        </>
      )}
    </section>
  );
}
