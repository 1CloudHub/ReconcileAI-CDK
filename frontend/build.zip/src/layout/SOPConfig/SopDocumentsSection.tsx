import { RefreshCw, Upload } from 'lucide-react';
import PrimaryButton from '../../components/ui/PrimaryButton';
import SecondaryButton from '../../components/ui/SecondaryButton';
import TablePagination from '../../components/ui/TablePagination';
import { TableLayout } from '../../components/ui/TableLayout';
import type { VersionRow } from '../../hooks/sopEditor/sopEditorHelpers';

type Props = {
  isEditMode: boolean;
  versionsListLoading: boolean;
  versionUploading: boolean;
  versionColumns: Array<Record<string, unknown>>;
  visibleVersions: VersionRow[];
  filteredVersions: VersionRow[];
  currentPage: number;
  pageSize: number;
  versionFileError?: string;
  updateTable: (partial: { currentPage?: number; pageSize?: number }) => void;
  refreshVersions: () => void;
  onUploadNewVersion: () => void;
};

export default function SopDocumentsSection({
  isEditMode,
  versionsListLoading,
  versionUploading,
  versionColumns,
  visibleVersions,
  filteredVersions,
  currentPage,
  pageSize,
  versionFileError,
  updateTable,
  refreshVersions,
  onUploadNewVersion,
}: Props) {
  return (
    <section className="rounded-xl border border-slate-200 bg-white p-4">
      <div className="mb-4 flex flex-col gap-3 border-b border-slate-200 pb-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="m-0 text-[18px] font-semibold text-slate-800">SOP Documents</h3>
          <p className="m-0 text-sm text-slate-500">
            Manage SOP documents and the Jobs that are associated with the SOP.
          </p>
          {versionFileError ? (
            <p className="m-0 mt-1 text-[14px] leading-6 text-[#ff4d4f]">{versionFileError}</p>
          ) : null}
        </div>
        <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row sm:items-center">
          <PrimaryButton
            type="button"
            icon={<Upload size={16} />}
            text={isEditMode ? 'Upload New SOP Version' : 'Upload an SOP Document'}
            className="min-h-[38px] rounded-[8px] px-4 text-sm"
            disabled={versionUploading}
            onClick={onUploadNewVersion}
          />
          {isEditMode ? (
            <SecondaryButton
              icon={<RefreshCw size={15} />}
              text="Refresh"
              className="min-h-[38px] rounded-md px-4 text-sm"
              onClick={refreshVersions}
            />
          ) : null}
        </div>
      </div>

      {isEditMode && versionsListLoading ? (
        <TableLayout<VersionRow>
          card={false}
          columns={versionColumns}
          dataSource={[]}
          rowKey="key"
          pagination={false}
          size="middle"
          loading
        />
      ) : visibleVersions.length > 0 ? (
        <>
          <TableLayout<VersionRow>
            card={false}
            columns={versionColumns}
            dataSource={visibleVersions}
            rowKey="key"
            pagination={false}
            size="middle"
          />
          <TablePagination
            total={filteredVersions.length}
            current={currentPage}
            pageSize={pageSize}
            onChange={(page, nextPageSize) => {
              updateTable({ currentPage: page, pageSize: nextPageSize });
              if (nextPageSize !== pageSize) refreshVersions();
            }}
            className="mt-3 flex justify-end"
            showTotal={false}
          />
        </>
      ) : (
        <p className="m-0 text-sm text-slate-500">No documents uploaded yet.</p>
      )}
    </section>
  );
}
