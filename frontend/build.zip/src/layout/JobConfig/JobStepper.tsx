import { Button, Form, Input, Modal, Select, message } from 'antd';
import type { UploadFile } from 'antd/es/upload/interface';
// import { Upload as UploadIcon } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import type { DocumentTypeOption } from '../../hooks/useJobConfig';

// const { Dragger } = Upload;

export type JobStepperSubmitPayload = {
  jobName: string;
  documentCount: number;
  documentIds: number[];
  masterDocumentId?: number;
  testFile?: UploadFile;
};

type JobStepperInitialValues = {
  id?: number;
  jobName?: string;
  documentCount?: number;
  documentIds?: number[];
  masterDocumentId?: number;
};

type JobStepperProps = {
  open: boolean;
  onClose: () => void;
  onDone: (payload: JobStepperSubmitPayload) => Promise<void> | void;
  documentTypeOptions: DocumentTypeOption[];
  initialValues?: JobStepperInitialValues | null;
};

export default function JobStepper({
  open,
  onClose,
  onDone,
  documentTypeOptions,
  initialValues,
}: JobStepperProps) {
  const [current, setCurrent] = useState(0);
  const [detailsForm] = Form.useForm();
  const [testFileList, setTestFileList] = useState<UploadFile[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const documentCount = Form.useWatch('documentCount', detailsForm) as number | undefined;
  const masterDocumentId = Form.useWatch('masterDocumentId', detailsForm) as number | undefined;
  const selectedDocumentIds = (Form.useWatch('documentIds', detailsForm) as number[] | undefined) ?? [];
  const normalizedCount =
    Number.isFinite(Number(documentCount)) && [2, 3, 4].includes(Number(documentCount))
      ? Number(documentCount)
      : 3;
  const requiredDocumentTypeCount = normalizedCount === 4 ? 3 : normalizedCount;
  const showMasterDocumentField = normalizedCount === 4;

  useEffect(() => {
    if (!open) return;
    const inferredCount =
      initialValues?.documentCount ??
      (Array.isArray(initialValues?.documentIds)
        ? Math.min(4, Math.max(2, initialValues!.documentIds!.length))
        : undefined);

    detailsForm.setFieldsValue({
      jobName: initialValues?.jobName ?? '',
      documentCount: inferredCount,
      documentIds: initialValues?.documentIds ?? [],
      masterDocumentId: initialValues?.masterDocumentId,
    });
  }, [detailsForm, initialValues, open]);

  const resetState = () => {
    setCurrent(0);
    setSubmitting(false);
    setTestFileList([]);
    detailsForm.resetFields();
  };

  const closeModal = () => {
    resetState();
    onClose();
  };

  useEffect(() => {
    if (!open) return;
    const maxAllowed = requiredDocumentTypeCount;
    const currentIds = Array.isArray(selectedDocumentIds) ? selectedDocumentIds : [];
    let nextIds = currentIds;

    if (nextIds.length > maxAllowed) {
      nextIds = nextIds.slice(0, maxAllowed);
    }
    if (nextIds.length !== currentIds.length) {
      detailsForm.setFieldValue('documentIds', nextIds);
    }
  }, [open, requiredDocumentTypeCount, selectedDocumentIds, detailsForm]);

  useEffect(() => {
    if (!open) return;
    if (!showMasterDocumentField && masterDocumentId != null) {
      detailsForm.setFieldValue('masterDocumentId', undefined);
      return;
    }
    if (showMasterDocumentField && masterDocumentId != null && selectedDocumentIds.includes(masterDocumentId)) {
      detailsForm.setFieldValue('masterDocumentId', undefined);
    }
  }, [open, showMasterDocumentField, masterDocumentId, selectedDocumentIds, detailsForm]);

  // const testUploadProps: UploadProps = {
  //   fileList: testFileList,
  //   beforeUpload: (file) => {
  //     setTestFileList([file]);
  //     return false;
  //   },
  //   onRemove: () => {
  //     setTestFileList([]);
  //   },
  //   maxCount: 1,
  //   multiple: false,
  //   accept: '.pdf,.jpg,.jpeg,.png',
  // };

  const steps = useMemo(
    () => [
      {
        title: 'Job Details',
        content: (
          <Form form={detailsForm} layout="vertical">
            <Form.Item
              name="jobName"
              label="Job Name"
              rules={[
                { required: true, message: 'Please enter a job name' },
                { min: 3, message: 'Job name should be at least 3 characters' },
              ]}
            >
              <Input placeholder="Job Name" maxLength={120} />
            </Form.Item>
            <Form.Item
              name="documentCount"
              label="No. of Documents"
              rules={[{ required: true, message: 'Please select document count' }]}
            >
              <Select
                placeholder="Select no of document"
                options={[
                  { value: 2, label: '2' },
                  { value: 3, label: '3' },
                  { value: 4, label: '4' },
                ]}
              />
            </Form.Item>
            <Form.Item
              name="documentIds"
              label="Document Types"
              validateTrigger="onSubmit"
              rules={[
                { required: true, message: `Please select document types` },
                {
                  validator: (_, value: number[]) => {
                    const arr = Array.isArray(value) ? value : [];
                    // Empty is handled by `required` above — skip here to avoid duplicate errors.
                    if (arr.length === 0) return Promise.resolve();
                    if (arr.length !== requiredDocumentTypeCount) {
                      return Promise.reject(new Error(`Please select exactly ${requiredDocumentTypeCount} document types`));
                    }
                    return Promise.resolve();
                  },
                },
              ]}
            >
              <Select
                mode="multiple"
                placeholder={`Select document types`}
                options={documentTypeOptions
                  .map((opt) => ({
                    label: opt.name,
                    value: opt.id,
                    disabled:
                      !!masterDocumentId && opt.id === masterDocumentId
                        ? true
                        : selectedDocumentIds.length >= requiredDocumentTypeCount
                          ? !selectedDocumentIds.includes(opt.id)
                          : false,
                  }))}
                optionFilterProp="label"
                maxTagCount="responsive"
                maxCount={requiredDocumentTypeCount}
              />
            </Form.Item>
            {showMasterDocumentField ? (
              <>
                <Form.Item
                  name="masterDocumentId"
                  label="Reference Document"
                  rules={[{ required: true, message: 'Please select reference document' }]}
                >
                  <Select
                    placeholder="Select reference document"
                    options={documentTypeOptions
                      .filter((opt) => !selectedDocumentIds.includes(opt.id))
                      .map((opt) => ({ label: opt.name, value: opt.id }))}
                    optionFilterProp="label"
                  />
                </Form.Item>
              </>
            ) : null}
          </Form>
        ),
      },
      // {
      //   title: 'Test Document',
      //   content: (
      //     <Form layout="vertical">
      //       <Form.Item label="Upload a test document (optional)">
      //         <Dragger {...testUploadProps}>
      //           <p className="ant-upload-drag-icon !mb-4 flex w-full justify-center">
      //             <UploadIcon size={42} aria-hidden className="text-slate-700" />
      //           </p>
      //           <p className="ant-upload-text text-center">Click or drag file to this area to upload</p>
      //           <p className="ant-upload-hint text-center">Only PDF and image files (JPG, PNG) up to 4MB are supported.</p>
      //         </Dragger>
      //       </Form.Item>
      //     </Form>
      //   ),
      // },
    ],
    [detailsForm, documentTypeOptions, requiredDocumentTypeCount, showMasterDocumentField, selectedDocumentIds]
  );

  const next = async () => {
    if (current === 0) {
      await detailsForm.validateFields();
    }
    setCurrent((v) => Math.min(v + 1, steps.length - 1));
  };

  const prev = () => setCurrent((v) => Math.max(v - 1, 0));

  const done = async () => {
    const values = await detailsForm.validateFields();
    setSubmitting(true);
    try {
      await onDone({
        jobName: values.jobName,
        documentCount: Number(values.documentCount),
        documentIds: values.documentIds,
        ...(showMasterDocumentField && values.masterDocumentId != null
          ? { masterDocumentId: Number(values.masterDocumentId) }
          : {}),
        testFile: testFileList[0],
      });
      closeModal();
    } catch (e) {
      const errMsg = e instanceof Error ? e.message : 'Failed to submit job';
      void message.error(errMsg);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      title={<span className="text-xl font-semibold text-slate-900">{initialValues?.id ? 'Edit Job Config' : 'Add Job Config'}</span>}
      open={open}
      onCancel={closeModal}
      footer={null}
      width={500}
      destroyOnHidden
      styles={{ body: { paddingTop: 0 } }}
    >

      <div>{steps[current].content}</div>

      <div className="mt-6 flex items-center justify-end gap-2">
        {current > 0 && (
          <Button onClick={prev} disabled={submitting}>
            Previous
          </Button>
        )}
        {current < steps.length - 1 && (
          <Button type="primary" onClick={next} disabled={submitting}>
            Next
          </Button>
        )}
        {current === steps.length - 1 && (
          <Button type="primary" loading={submitting} onClick={done}>
            Done
          </Button>
        )}
      </div>
    </Modal>
  );
}
