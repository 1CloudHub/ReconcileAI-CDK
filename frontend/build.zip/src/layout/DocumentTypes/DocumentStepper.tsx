import {
  Button,
  Form,
  Input,
  Modal,
  Spin,
  Steps,
  Tabs,
  Tooltip,
  message,
} from 'antd';
import type { UploadFile } from 'antd/es/upload/interface';
import { LoadingOutlined } from '@ant-design/icons';
import { CheckCircle2, Info, Plus, Upload as UploadIcon, X } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import type { DocTypeField } from '../../hooks/useDocumentTypes';
import ToggleSlider from '../../components/ui/ToggleSlider';

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const MAX_FIELDS = 20;
const FILE_SIZE_LIMIT = 4 * 1024 * 1024;

function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type ExtractField = DocTypeField;

export type DocumentStepperProps = {
  open: boolean;
  onClose: () => void;
  mode?: 'add' | 'edit';
  initialValues?: {
    documentType: string;
    documentDescription: string;
    documentKey?: string;
    documentKeyIsEnabled?: boolean;
    fields: ExtractField[];
  } | null;
  onAdd: (p: {
    documentType: string;
    documentDescription: string;
    documentKey?: string;
    documentKeyIsEnabled?: boolean;
    fields: ExtractField[];
  }) => Promise<void>;
  onEdit: (p: {
    documentType: string;
    documentDescription: string;
    documentKey?: string;
    documentKeyIsEnabled?: boolean;
    fields: ExtractField[];
  }) => Promise<void>;
  onSuggestDescription: (documentJson: object, userInput: string) => Promise<string>;
  onInitiateAiExtraction: (file: File, documentType: string, documentDesc: string) => Promise<{ docId: string; docName: string }>;
  onPollAiExtraction: (docId: string, docName: string, docType: string) => Promise<ExtractField[]>;
  onInitiateTestDoc: (file: File, documentJson: object, documentType: string) => Promise<{ docId: string; docName: string }>;
  onPollTestDoc: (docId: string, docName: string) => Promise<{ data: unknown; presigned_url: string }>;
};

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export default function DocumentStepper({
  open,
  onClose,
  mode = 'add',
  initialValues,
  onAdd,
  onEdit,
  onSuggestDescription,
  onInitiateAiExtraction,
  onPollAiExtraction,
  onInitiateTestDoc,
  onPollTestDoc,
}: DocumentStepperProps) {
  // -- step / tab navigation
  const [current, setCurrent] = useState(0);
  const [activeTab, setActiveTab] = useState<'form' | 'ai' | 'test'>('form');

  // -- forms
  const [basicForm] = Form.useForm();
  const [fieldsForm] = Form.useForm();

  // -- basic details
  const [documentType, setDocumentType] = useState('');
  const [documentDesc, setDocumentDesc] = useState('');
  const [documentKeyEnabled, setDocumentKeyEnabled] = useState(false);
  const [documentKey, setDocumentKey] = useState('');

  // -- fields
  const [fields, setFields] = useState<ExtractField[]>([{ name: '', description: '' }]);
  const [jsonInput, setJsonInput] = useState('');
  const [isJsonValid, setIsJsonValid] = useState(true);

  // -- AI suggestion
  const [editAiSuggestion, setEditAiSuggestion] = useState('');
  const [aiSuggestion, setAiSuggestion] = useState<{
    documentType: string;
    documentDesc: string;
    fields: ExtractField[];
  } | null>(null);
  const [aiSuggestLoading, setAiSuggestLoading] = useState(false);

  // -- AI file extraction (step 2)
  const [aiFileList, setAiFileList] = useState<UploadFile[]>([]);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiDone, setAiDone] = useState(false);
  const aiDocRef = useRef<{ docId: string; docName: string; docType: string } | null>(null);

  // -- test doc
  const [testFileList, setTestFileList] = useState<UploadFile[]>([]);
  const [testLoading, setTestLoading] = useState(false);
  const [testDocData, setTestDocData] = useState('');
  const [testDocUrl, setTestDocUrl] = useState('');
  const [testDocDone, setTestDocDone] = useState(false);
  const testDocRef = useRef<{ docId: string; docName: string } | null>(null);

  // -- submit
  const [submitLoading, setSubmitLoading] = useState(false);

  // ---------------------------------------------------------------------------
  // Sync jsonInput when fields / doc info change
  // ---------------------------------------------------------------------------

  useEffect(() => {
    if (!open) return;
    const current = {
      documentType,
      documentDesc,
      ...(documentKeyEnabled && documentKey.trim() ? { documentKey: documentKey.trim() } : {}),
      fields,
    };
    setJsonInput(JSON.stringify(current, null, 2));
    setIsJsonValid(true);
  }, [documentType, documentDesc, documentKeyEnabled, documentKey, fields, open]);

  // ---------------------------------------------------------------------------
  // Pre-fill for edit mode
  // ---------------------------------------------------------------------------

  useEffect(() => {
    if (!open) return;
    if (mode === 'edit' && initialValues) {
      const iv = initialValues;
      setDocumentType(iv.documentType);
      setDocumentDesc(iv.documentDescription);
      const isEnabled = iv.documentKeyIsEnabled ?? Boolean(iv.documentKey && iv.documentKey.trim());
      setDocumentKeyEnabled(isEnabled);
      setDocumentKey(iv.documentKey ?? '');
      const initFields = iv.fields.length > 0 ? iv.fields : [{ name: '', description: '' }];
      setFields(initFields);

      basicForm.setFieldsValue({
        documentType: iv.documentType,
        documentDesc: iv.documentDescription,
        documentKeyEnabled: isEnabled,
        documentKey: iv.documentKey ?? '',
      });
      fieldsForm.setFieldsValue({ fields: initFields });
    } else if (mode === 'add') {
      basicForm.resetFields();
      fieldsForm.resetFields();
      setDocumentType('');
      setDocumentDesc('');
      setDocumentKeyEnabled(false);
      setDocumentKey('');
      setFields([{ name: '', description: '' }]);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, mode]);

  // ---------------------------------------------------------------------------
  // Reset
  // ---------------------------------------------------------------------------

  const resetState = () => {
    setCurrent(0);
    setActiveTab('form');
    setDocumentType('');
    setDocumentDesc('');
    setDocumentKeyEnabled(false);
    setDocumentKey('');
    setFields([{ name: '', description: '' }]);
    setJsonInput('');
    setIsJsonValid(true);
    setEditAiSuggestion('');
    setAiSuggestion(null);
    setAiSuggestLoading(false);
    setAiFileList([]);
    setAiLoading(false);
    setAiDone(false);
    aiDocRef.current = null;
    setTestFileList([]);
    setTestLoading(false);
    setTestDocData('');
    setTestDocUrl('');
    setTestDocDone(false);
    testDocRef.current = null;
    setSubmitLoading(false);
    basicForm.resetFields();
    fieldsForm.resetFields();
  };

  const closeModal = () => {
    resetState();
    onClose();
  };

  // ---------------------------------------------------------------------------
  // Fields helpers
  // ---------------------------------------------------------------------------

  const addField = () => {
    if (fields.length >= MAX_FIELDS) {
      void message.warning(`Maximum of ${MAX_FIELDS} fields allowed`);
      return;
    }
    const next = [...fields, { name: '', description: '' }];
    setFields(next);
    setTimeout(() => {
      fieldsForm.setFieldsValue({ fields: next });
    }, 0);
  };

  const removeField = (index: number) => {
    if (fields.length === 1) {
      void message.warning('At least one field is required');
      return;
    }
    const next = fields.filter((_, i) => i !== index);
    setFields(next);
    setTimeout(() => {
      fieldsForm.setFieldsValue({ fields: next });
    }, 0);
  };

  const updateField = (index: number, key: keyof ExtractField, value: string) => {
    const next = [...fields];
    next[index] = { ...next[index], [key]: value };
    setFields(next);
    setTimeout(() => {
      fieldsForm.setFieldsValue({ fields: next });
    }, 0);
  };

  // ---------------------------------------------------------------------------
  // JSON mode
  // ---------------------------------------------------------------------------

  const handleJsonChange = (value: string) => {
    setJsonInput(value);
    if (!value.trim()) {
      setIsJsonValid(true);
      return;
    }
    try {
      const parsed = JSON.parse(value) as {
        documentType?: string;
        documentDesc?: string;
        documentKey?: string;
        fields?: ExtractField[];
      };
      setIsJsonValid(true);
      if (parsed.documentType && mode !== 'edit') {
        setDocumentType(parsed.documentType);
        basicForm.setFieldValue('documentType', parsed.documentType);
      }
      if (parsed.documentDesc) {
        setDocumentDesc(parsed.documentDesc);
        basicForm.setFieldValue('documentDesc', parsed.documentDesc);
      }
      if (typeof parsed.documentKey === 'string') {
        const nextDocKey = parsed.documentKey.trim();
        setDocumentKeyEnabled(Boolean(nextDocKey));
        setDocumentKey(nextDocKey);
        basicForm.setFieldValue('documentKeyEnabled', Boolean(nextDocKey));
        basicForm.setFieldValue('documentKey', nextDocKey);
      }
      if (Array.isArray(parsed.fields)) {
        setFields(parsed.fields);
        setTimeout(() => {
          fieldsForm.setFieldsValue({ fields: parsed.fields });
        }, 0);
      }
    } catch {
      setIsJsonValid(false);
    }
  };

  // ---------------------------------------------------------------------------
  // AI Suggest
  // ---------------------------------------------------------------------------

  const generateAiDescriptions = async () => {
    if (!jsonInput.trim() || !isJsonValid) {
      void message.warning('Please enter valid JSON first');
      return;
    }
    setAiSuggestLoading(true);
    try {
      let mergedJson: object;
      try {
        const parsed = JSON.parse(jsonInput) as {
          documentType?: string;
          documentDesc?: string;
          fields?: ExtractField[];
        };
        if (aiSuggestion) {
          const existingNames = new Set(aiSuggestion.fields.map((f) => f.name));
          mergedJson = {
            ...aiSuggestion,
            fields: [
              ...aiSuggestion.fields,
              ...(parsed.fields ?? []).filter((f) => !existingNames.has(f.name)),
            ],
          };
        } else {
          mergedJson = parsed;
        }
      } catch {
        void message.error('Invalid JSON');
        return;
      }

      const response = await onSuggestDescription(mergedJson, editAiSuggestion);
      const suggested = JSON.parse(response) as {
        documentType: string;
        documentDesc: string;
        fields: ExtractField[];
      };
      setAiSuggestion(suggested);
      const jsonStr = JSON.stringify(suggested, null, 2);
      setJsonInput(jsonStr);
      setIsJsonValid(true);
      setFields(suggested.fields);
      setDocumentDesc(suggested.documentDesc);
      basicForm.setFieldValue('documentDesc', suggested.documentDesc);
      fieldsForm.setFieldValue('fields', suggested.fields);
      setEditAiSuggestion('');
    } catch {
      void message.error('AI suggestion failed. Please try again.');
    } finally {
      setAiSuggestLoading(false);
    }
  };

  // ---------------------------------------------------------------------------
  // AI extraction (step 2 in Add mode)
  // ---------------------------------------------------------------------------


  const handleAiExtract = async () => {
    if (!aiFileList[0]) {
      void message.error('Please upload a document');
      return;
    }
    // Local state is always in sync with the form via onValuesChange.
    const docType = documentType.trim().toLowerCase().replace(/\s+/g, '_');
    if (!docType) {
      void message.error('Please fill in the Document Type in Step 1 first.');
      return;
    }
    const file = aiFileList[0].originFileObj ?? (aiFileList[0] as unknown as File);
    if (!(file instanceof File)) {
      void message.error('Invalid file. Please re-upload.');
      return;
    }
    setAiLoading(true);
    setAiDone(false);
    try {
      const docDesc = documentDesc;
      const { docId, docName } = await onInitiateAiExtraction(file, docType, docDesc);
      aiDocRef.current = { docId, docName, docType };
      const extractedFields = await onPollAiExtraction(docId, docName, docType);
      if (extractedFields.length > 0) {
        setFields(extractedFields);
        fieldsForm.setFieldsValue({ fields: extractedFields });
        void message.success(`AI extracted ${extractedFields.length} fields successfully!`);
      } else {
        void message.info('AI extraction completed but no fields found. Add them manually.');
      }
      setAiDone(true);
      setCurrent(2);
    } catch (err) {
      void message.error(err instanceof Error ? err.message : 'AI extraction failed');
    } finally {
      setAiLoading(false);
    }
  };

  // ---------------------------------------------------------------------------
  // Test doc
  // ---------------------------------------------------------------------------


  const handleTestDoc = async () => {
    if (!testFileList[0]) {
      void message.warning('Please upload a test document first.');
      return;
    }
    const file = testFileList[0].originFileObj ?? (testFileList[0] as unknown as File);
    if (!(file instanceof File)) {
      void message.error('Invalid file. Please re-upload.');
      return;
    }
    // Local state is always in sync with the form via onValuesChange.
    const docType = documentType.trim().toLowerCase().replace(/\s+/g, '_');
    if (!docType) {
      void message.error('Please fill in the Document Type in Step 1 first.');
      return;
    }
    const activeFields = fields.filter((f) => f.name.trim() !== '');
    const documentJson = {
      documentType: docType,
      documentDesc: documentDesc,
      fields: activeFields,
    };
    setTestLoading(true);
    setTestDocData('');
    setTestDocUrl('');
    setTestDocDone(false);
    try {
      const { docId, docName } = await onInitiateTestDoc(file, documentJson, docType);
      testDocRef.current = { docId, docName };
      const result = await onPollTestDoc(docId, docName);
      setTestDocData(JSON.stringify(result.data, null, 2));
      setTestDocUrl(result.presigned_url);
      setTestDocDone(true);
      void message.success('Test document processed successfully!');
    } catch (err) {
      void message.error(err instanceof Error ? err.message : 'Test document processing failed');
    } finally {
      setTestLoading(false);
    }
  };

  // ---------------------------------------------------------------------------
  // Step nav (Add mode)
  // ---------------------------------------------------------------------------

  const next = async () => {
    if (current === 0) {
      try {
        const basicValues = (await basicForm.validateFields()) as { documentType: string; documentDesc: string };
        setDocumentType(basicValues.documentType ?? '');
        setDocumentDesc(basicValues.documentDesc ?? '');
      } catch {
        return;
      }
    }
    if (current === 2) {
      if (fields.length > MAX_FIELDS) {
        void message.error(`Too many fields. Please remove unnecessary fields — maximum ${MAX_FIELDS} allowed.`);
        return;
      }
      try {
        await fieldsForm.validateFields();
      } catch {
        return;
      }
    }
    setCurrent((v) => Math.min(v + 1, 3));
  };

  const prev = () => setCurrent((v) => Math.max(v - 1, 0));

  // ---------------------------------------------------------------------------
  // Submit
  // ---------------------------------------------------------------------------

  const done = async () => {
    // Local state is always kept in sync with the form via onValuesChange,
    // so we read directly from state — this is safe even when the form is unmounted.
    const normalizedDocType = documentType.trim().toLowerCase().replace(/\s+/g, '_');
    if (!normalizedDocType) {
      void message.error('Please fill document type in Basic Details (Step 1).');
      return;
    }
    try {
      await fieldsForm.validateFields();
    } catch {
      return;
    }

    setSubmitLoading(true);
    try {
      const payload = {
        documentType: normalizedDocType,
        documentDescription: documentDesc,
        documentKey: documentKey.trim(),
        documentKeyIsEnabled: documentKeyEnabled,
        fields,
      };

      if (mode === 'edit') {
        await onEdit(payload);
        void message.success('Document type updated successfully');
      } else {
        await onAdd(payload);
        void message.success('Document type added successfully');
      }
      closeModal();
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Failed to save document type';
      if (mode === 'add' && /already exists/i.test(errorMsg)) {
        void message.info(errorMsg);
        window.setTimeout(() => {
          closeModal();
        }, 1000);
      } else {
        void message.error(errorMsg);
      }
    } finally {
      setSubmitLoading(false);
    }
  };

  // ---------------------------------------------------------------------------
  // Shared sub-sections
  // ---------------------------------------------------------------------------

  const fieldsSection = (
    <div>
      <div className={`flex items-center justify-between ${fields.length > MAX_FIELDS ? 'mb-2' : 'mb-4'}`}>
        <label className="font-semibold text-sm text-slate-800">Fields to Extract</label>
        <Button
          type="default"
          size="small"
          onClick={addField}
          disabled={fields.length >= MAX_FIELDS}
        >
          <Plus size={14} className="mr-1" />
          Add Field {fields.length > 0 && `(${fields.length}/${MAX_FIELDS})`}
        </Button>
      </div>
      {fields.length > MAX_FIELDS && (
        <div className="mb-4 px-3 py-2 bg-red-50 border border-red-300 rounded-md text-[13px] text-red-600 flex items-center gap-1.5">
          <span className="font-medium">Too many fields.</span>
          Please remove {fields.length - MAX_FIELDS} unnecessary field{fields.length - MAX_FIELDS > 1 ? 's' : ''} — maximum {MAX_FIELDS} allowed.
        </div>
      )}

      <Form form={fieldsForm} layout="vertical">
        <div className="max-h-80 overflow-y-auto pr-1">
          {fields.map((field, index) => (
            <div
              key={index}
              className="flex gap-3 items-start mb-3"
            >
              <Form.Item
                name={['fields', index, 'name']}
                label="Field Name"
                className="flex-1 !mb-0 min-h-[88px]"
                rules={[
                  { required: true, message: 'Field name is required', whitespace: true },
                  { min: 2, message: 'At least 2 characters' },
                ]}
              >
                <Input
                  placeholder="Field name"
                  value={field.name}
                  onChange={(e) => updateField(index, 'name', e.target.value)}
                />
              </Form.Item>
              <Form.Item
                name={['fields', index, 'description']}
                label="Field Description"
                className="flex-1 !mb-0 min-h-[88px]"
                rules={[
                  { required: true, message: 'Field description is required', whitespace: true },
                  { min: 5, message: 'At least 5 characters' },
                ]}
              >
                <Input
                  placeholder="Field description"
                  value={field.description}
                  onChange={(e) => updateField(index, 'description', e.target.value)}
                />
              </Form.Item>
              <button
                type="button"
                className="mt-[30px] h-8 w-8 inline-flex items-center justify-center border border-slate-200 rounded-md bg-transparent cursor-pointer text-slate-500 shrink-0"
                onClick={() => removeField(index)}
                aria-label="Remove field"
              >
                <X size={15} />
              </button>
            </div>
          ))}
        </div>
      </Form>
    </div>
  );

  const testDocSection = (
    <div className="grid gap-x-5 gap-y-3 items-stretch h-full" style={{ gridTemplateColumns: '1fr 1fr' }}>

      {/* Header */}
      <div className="self-end">
        {!testDocUrl ? (
          <label className="text-sm font-semibold text-slate-700">
            Upload a Document to test your config <span className="text-red-500">*</span>
          </label>
        ) : (
          <div className="text-sm font-semibold text-slate-700">Document Preview</div>
        )}
      </div>
      <div className="self-end">
        <div className="text-sm font-semibold text-slate-700">Results</div>
      </div>

      {/* LEFT PANEL */}
      <div className="flex flex-col h-full gap-3">
        {testLoading ? (
          <>
            <style>{`
              @keyframes _docBounce {
                0%, 80%, 100% { transform: translateY(0); opacity: 0.4; }
                40% { transform: translateY(-8px); opacity: 1; }
              }
            `}</style>
            <div className="flex-1 border border-dashed border-blue-300 rounded-lg bg-blue-50 flex flex-col items-center justify-center gap-5">
              <div className="flex gap-2">
                {[0, 1, 2].map((i) => (
                  <span
                    key={i}
                    className="w-2.5 h-2.5 rounded-full bg-blue-500"
                    style={{ animation: `_docBounce 1.2s ease-in-out ${i * 0.2}s infinite` }}
                  />
                ))}
              </div>
              <div className="text-center">
                <p className="text-sm font-semibold text-blue-700">
                  Processing your document…
                </p>
                <p className="text-xs text-slate-500">
                  This may take a few moments. Please wait.
                </p>
              </div>
            </div>
            <div className="shrink-0 min-h-[40px]" />
          </>
        ) : !testDocUrl ? (
          <>
            <div className="flex-1 flex flex-col">
              <input
                type="file"
                accept=".pdf"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  if (file.type !== 'application/pdf') { void message.error('Only PDF files are supported'); return; }
                  if (file.size > FILE_SIZE_LIMIT) { void message.error('File exceeds 4MB'); return; }
                  setTestFileList([file as unknown as UploadFile]);
                  setTestDocData(''); setTestDocUrl(''); setTestDocDone(false);
                  e.target.value = '';
                }}
                id="test-file-input"
              />
              {testFileList.length > 0 ? (
                <div className="h-[300px] box-border border border-dashed border-blue-300 rounded-lg bg-blue-50 flex flex-col items-center justify-center text-center px-4 py-6">
                  <CheckCircle2 size={36} className="text-blue-600 mb-2.5" />
                  <p className="text-sm font-medium text-blue-700">
                    File uploaded successfully
                  </p>
                  <p className="text-[13px] text-slate-600">
                    {testFileList[0].name}
                  </p>
                  <p className="text-xs text-slate-400">
                    {formatFileSize(testFileList[0].size ?? 0)}
                  </p>
                  <Button
                    type="link"
                    size="small"
                    onClick={() => { setTestFileList([]); setTestDocData(''); setTestDocUrl(''); setTestDocDone(false); }}
                    className="!mt-2.5 !text-red-500 !p-0 !h-auto !text-[13px]"
                  >
                    Remove
                  </Button>
                </div>
              ) : (
                <div
                  onClick={() => document.getElementById('test-file-input')?.click()}
                  onDragOver={(e) => { e.preventDefault(); }}
                  onDrop={(e) => {
                    e.preventDefault();
                    const file = e.dataTransfer.files?.[0];
                    if (!file) return;
                    if (file.type !== 'application/pdf') { void message.error('Only PDF files are supported'); return; }
                    if (file.size > FILE_SIZE_LIMIT) { void message.error('File exceeds 4MB'); return; }
                    setTestFileList([file as unknown as UploadFile]);
                    setTestDocData(''); setTestDocUrl(''); setTestDocDone(false);
                  }}
                  className="h-[300px] box-border border border-dashed border-slate-300 rounded-lg bg-slate-50 cursor-pointer flex flex-col items-center justify-center text-center px-3.5 py-4 transition-colors duration-200 hover:border-blue-400 hover:bg-blue-50"
                >
                  <UploadIcon size={40} className="text-slate-400" />
                  <p className="mt-3 text-sm text-slate-700">
                    Click or drag file to upload
                  </p>
                  <p className="text-xs text-slate-500">
                    PDF up to 4MB
                  </p>
                </div>
              )}
            </div>
            <div className="shrink-0 min-h-[40px] flex items-center gap-2">
              <Button
                type="primary"
                onClick={() => void handleTestDoc()}
                disabled={testFileList.length === 0}
                loading={testLoading}
              >
                {testLoading ? 'Processing…' : 'Upload & Test'}
              </Button>
              {testDocDone && (
                <span className="text-[13px] text-green-600 inline-flex items-center gap-1">
                  <CheckCircle2 size={14} /> Test completed
                </span>
              )}
            </div>
          </>
        ) : (
          <>
            <iframe
              src={testDocUrl}
              className="flex-1 w-full border border-slate-200 rounded-lg"
              title="Document Preview"
            />
            <div className="shrink-0 min-h-[40px]" aria-hidden />
          </>
        )}
      </div>

      {/* RIGHT PANEL */}
      <div className="flex flex-col h-full gap-3">
        <Input.TextArea
          value={testDocData}
          readOnly
          placeholder="Extracted data will appear here after processing..."
          className="!h-[300px] !font-mono !text-xs !resize-none"
        />
        <div className="shrink-0 min-h-[40px] flex items-center">
          {testDocData ? (
            <Button
              onClick={() => {
                setTestFileList([]);
                setTestDocData('');
                setTestDocUrl('');
                setTestDocDone(false);
              }}
            >
              Re-Upload
            </Button>
          ) : null}
        </div>
      </div>
    </div>
  );

  // ---------------------------------------------------------------------------
  // Basic details form
  // ---------------------------------------------------------------------------

  const basicDetailsForm = (
    <Form
      form={basicForm}
      layout="vertical"
      initialValues={{
        documentType: documentType || '',
        documentDesc: documentDesc || '',
        documentKeyEnabled: documentKeyEnabled,
        documentKey: documentKey || '',
      }}
      onValuesChange={(changedValues: Record<string, unknown>) => {
        if ('documentType' in changedValues)
          setDocumentType((changedValues.documentType as string) ?? '');
        if ('documentDesc' in changedValues)
          setDocumentDesc((changedValues.documentDesc as string) ?? '');
        if ('documentKeyEnabled' in changedValues) {
          const nextEnabled = Boolean(changedValues.documentKeyEnabled);
          setDocumentKeyEnabled(nextEnabled);
        }
        if ('documentKey' in changedValues)
          setDocumentKey((changedValues.documentKey as string) ?? '');
      }}
    >
      
        <Form.Item
          name="documentType"
          label="Document Type"
          className="flex-1 mb-0"
          rules={[
            { required: true, message: 'Please enter the document type', whitespace: true },
            { min: 3, message: 'Document type must be at least 3 characters' },
            { max: 50, message: 'Document type cannot exceed 50 characters' },
          ]}
        >
          <Input
            placeholder="Document Type"
            disabled={mode === 'edit'}
          />
        </Form.Item>
        
        <div className="flex gap-2 items-center mt-2 mb-2">
          <span className="text-sm font-medium text-gray-700 inline-flex items-center gap-1">
            {documentKeyEnabled ? (
              <span className="text-[#ff4d4f] font-sans leading-none" aria-hidden>
                *
              </span>
            ) : null}
            Document Key
          </span>
          <Tooltip title="This will act as the primary identifier for this document type">
            <Info size={14} className="text-gray-400 cursor-pointer" />
          </Tooltip>
          <div className="flex items-center gap-3">
            <Form.Item
              name="documentKeyEnabled"
              valuePropName="checked"
              initialValue={false}
              noStyle
            >
              <ToggleSlider />
            </Form.Item>
          </div>
        </div>

      <Form.Item
        name="documentKey"
        rules={[
          {
            validator: (_, v) => {
              if (!documentKeyEnabled) return Promise.resolve();
              const value = String(v ?? '').trim();
              if (!value) return Promise.reject(new Error('Please enter document key'));
              if (value.length > 100) return Promise.reject(new Error('Document key cannot exceed 100 characters'));
              return Promise.resolve();
            },
          },
        ]}
      >
        <Input
          placeholder="Enter document key"
          disabled={!documentKeyEnabled}
          maxLength={100}
        />
      </Form.Item>

      <Form.Item
        name="documentDesc"
        label="Document Description"
        rules={[
          { required: true, message: 'Please enter the document description', whitespace: true },
          { min: 5, message: 'Description must be at least 5 characters' },
          { max: 500, message: 'Description cannot exceed 500 characters' },
        ]}
      >
        <Input.TextArea
          rows={3}
          placeholder="Description of Document"
        />
      </Form.Item>
    </Form>
  );

  // ---------------------------------------------------------------------------
  // ADD MODE: 4-step stepper
  // ---------------------------------------------------------------------------

  if (mode === 'add') {
    const stepItems = [
      { title: 'Basic Details' },
      { title: 'Go with AI' },
      { title: 'Fields to Extract' },
      { title: 'Test Documents' },
    ];

    const stepContent = [
      basicDetailsForm,

      // Step 2: Go with AI
      <div key="ai-step">
        <label className="block text-sm font-medium text-slate-900">
          Upload Document to Auto Extract Fields <span className="text-red-500">*</span>
        </label>
        <div className="mt-2">
          {aiLoading ? (
            <>
              <style>{`
                @keyframes _docBounce {
                  0%, 80%, 100% { transform: translateY(0); opacity: 0.4; }
                  40% { transform: translateY(-8px); opacity: 1; }
                }
              `}</style>
              <div className="h-[300px] box-border border border-dashed border-blue-300 rounded-lg bg-blue-50 flex flex-col items-center justify-center gap-5">
                <div className="flex gap-2">
                  {[0, 1, 2].map((i) => (
                    <span
                      key={i}
                      className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block"
                      style={{ animation: `_docBounce 1.2s ease-in-out ${i * 0.2}s infinite` }}
                    />
                  ))}
                </div>
                <div className="text-center">
                  <p className="mb-1 text-sm font-semibold text-blue-700">
                    Processing your document…
                  </p>
                  <p className="m-0 text-xs text-slate-500">
                    This may take a few moments. Please wait.
                  </p>
                </div>
              </div>
            </>
          ) : aiFileList.length > 0 ? (
            <div className="h-[300px] px-4 py-6 flex flex-col items-center justify-center text-center border border-dashed border-blue-300 rounded-lg bg-blue-50 box-border">
              <CheckCircle2 size={36} className="text-blue-600 mb-2.5" />
              <p className="text-sm font-medium text-blue-700 mb-1">
                File uploaded successfully
              </p>
              <p className="text-[13px] text-slate-600">
                {aiFileList[0].name}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                {formatFileSize(aiFileList[0].size ?? 0)}
              </p>
              <Button
                type="link"
                size="small"
                onClick={() => { setAiFileList([]); setAiDone(false); }}
                className="!mt-2.5 !text-red-500 !p-0 !h-auto !text-[13px]"
              >
                Remove
              </Button>
            </div>
          ) : (
            <>
              <input
                type="file"
                id="ai-file-input"
                accept=".pdf"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  if (file.type !== 'application/pdf') { void message.error('Only PDF files are supported'); return; }
                  if (file.size > FILE_SIZE_LIMIT) { void message.error('File exceeds 4MB'); return; }
                  setAiFileList([file as unknown as UploadFile]);
                  setAiDone(false);
                  e.target.value = '';
                }}
              />
              <div
                onClick={() => document.getElementById('ai-file-input')?.click()}
                onDragOver={(e) => { e.preventDefault(); }}
                onDrop={(e) => {
                  e.preventDefault();
                  const file = e.dataTransfer.files?.[0];
                  if (!file) return;
                  if (file.type !== 'application/pdf') { void message.error('Only PDF files are supported'); return; }
                  if (file.size > FILE_SIZE_LIMIT) { void message.error('File exceeds 4MB'); return; }
                  setAiFileList([file as unknown as UploadFile]);
                  setAiDone(false);
                }}
                className="h-[300px] box-border border border-dashed border-slate-300 rounded-lg bg-slate-50 cursor-pointer flex flex-col items-center justify-center text-center px-3.5 py-4 transition-colors duration-200 hover:border-blue-400 hover:bg-blue-50"
              >
                <UploadIcon size={40} className="text-slate-400 block mx-auto" />
                <p className="mt-3 mb-1 text-sm text-slate-700">
                  Click or drag file to this area to upload
                </p>
                <p className="text-xs text-slate-500">
                  Only PDF and image files (JPG, PNG) up to 4MB are supported.
                </p>
              </div>
            </>
          )}
        </div>
        {aiDone && (
          <div className="mt-2 flex items-center gap-1.5 text-[13px] text-green-600">
            <CheckCircle2 size={14} /> Fields extracted successfully.
          </div>
        )}
        <div className="mt-2 text-[13px] text-slate-500">
          Click <strong>Next</strong> to run AI extraction, or <strong>Skip</strong> to continue without AI.
        </div>
      </div>,

      // Step 3: Fields to Extract
      <Spin key="fields-step" spinning={aiSuggestLoading} indicator={<LoadingOutlined spin />}>
        {fieldsSection}
      </Spin>,

      // Step 4: Test Documents
      <div key="test-step">{testDocSection}</div>,
    ];

    return (
      <Modal
        title={<span style={{ fontSize: 18, fontWeight: 600, color: '#0f172a' }}>Add Document Type</span>}
        open={open}
        onCancel={closeModal}
        footer={null}
        width={current === 3 ? 1000 : 820}
        destroyOnHidden
        styles={{ body: { paddingTop: 0 } }}
      >
        <div style={{ marginBottom: 24 }}>
          <Steps current={current} items={stepItems} size="small" />
        </div>

        <div>{stepContent[current]}</div>

        <div style={{ marginTop: 24, display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
          {current > 0 && (
            <Button onClick={prev} disabled={submitLoading || aiLoading}>
              Previous
            </Button>
          )}

          {/* Skip only on "Go with AI" step */}
          {current === 1 && (
            <Button
              disabled={aiLoading || submitLoading}
              onClick={() => {
                setCurrent(2);
              }}
            >
              Skip
            </Button>
          )}

          {current < 3 && (
            <Button
              type="primary"
              loading={current === 1 && aiLoading}
              disabled={
                (current === 1 && !aiFileList[0]) ||
                (current !== 1 && (aiLoading || submitLoading))
              }
              onClick={() => void (current === 1 ? handleAiExtract() : next())}
            >
              Next
            </Button>
          )}

          {current === 3 && (
            <Button
              type="primary"
              loading={submitLoading}
              onClick={() => void done()}
            >
              Done
            </Button>
          )}
        </div>
      </Modal>
    );
  }

  // ---------------------------------------------------------------------------
  // EDIT MODE: tabbed modal
  // ---------------------------------------------------------------------------

  const tabItems = [
    {
      key: 'form',
      label: (
        <span className="inline-flex items-center gap-1.5">
          Edit Form
        </span>
      ),
      children: (
        <div className="max-h-[calc(90vh-260px)] overflow-y-auto pr-1">
          {basicDetailsForm}
          <div className="mt-2">
            {fieldsSection}
          </div>
          <div className="mt-5 flex justify-end gap-2">
            <Button onClick={closeModal}>Cancel</Button>
            <Button type="primary" loading={submitLoading} onClick={() => void done()}>
              Save Changes
            </Button>
          </div>
        </div>
      ),
    },
    {
      key: 'ai',
      label: (
        <span className="inline-flex items-center gap-1.5">
           Edit with AI
        </span>
      ),
      children: (
        <Spin spinning={aiSuggestLoading} indicator={<LoadingOutlined spin />}>
          <div className="max-h-[calc(90vh-260px)] overflow-y-auto pr-1">
            {aiSuggestion && (
              <div className="mb-3 text-sm font-semibold text-slate-700">
                Your Configuration
              </div>
            )}
            <Input.TextArea
              value={jsonInput}
              onChange={(e) => handleJsonChange(e.target.value)}
              rows={16}
              className="!font-mono !mb-4"
            />
            <div className="flex items-end gap-2 mb-5">
              <div className="flex-1">
                <label className="block text-[13px] text-slate-500 mb-1">
                  Edit AI Suggestion
                </label>
                <Input
                  value={editAiSuggestion}
                  onChange={(e) => setEditAiSuggestion(e.target.value)}
                  placeholder="How you want to enhance the description..."
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      void generateAiDescriptions();
                    }
                  }}
                />
              </div>
              <Button
                type="primary"
                loading={aiSuggestLoading}
                onClick={() => void generateAiDescriptions()}
              >
                {editAiSuggestion.trim().length > 1 ? 'Edit' : 'Suggest New'}
              </Button>
            </div>
            <div className="flex justify-end gap-2">
              <Button onClick={closeModal}>Cancel</Button>
              <Button type="primary" loading={submitLoading} onClick={() => void done()}>
                Save Changes
              </Button>
            </div>
          </div>
        </Spin>
      ),
    },
    {
      key: 'test',
      label: (
        <span className="inline-flex items-center gap-1.5">
          Test Configuration
        </span>
      ),
      children: (
        <div className="max-h-[calc(90vh-260px)] overflow-y-auto pr-1">
          {testDocSection}
        </div>
      ),
    },
  ];

  const visibleTabItems = tabItems.filter((item) => item.key !== 'ai');

  return (
    <Modal
      title={<span className="text-lg font-semibold text-slate-900">Edit Document Type</span>}
      open={open}
      onCancel={closeModal}
      footer={null}
      width={activeTab === 'test' ? 1100 : 900}
      destroyOnHidden
      styles={{ body: { paddingTop: 0 } }}
    >
      <Tabs
        activeKey={activeTab}
        onChange={(k) => setActiveTab(k as 'form' | 'ai' | 'test')}
        items={visibleTabItems}
      />
    </Modal>
  );
}