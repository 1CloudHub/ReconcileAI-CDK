import { ConfigProvider } from 'antd';
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { store } from './store';
import './index.css';
import App from './App.tsx';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <ConfigProvider
        theme={{
          token: {
            colorPrimary: '#1351CD',
          },
          components: {
            Tabs: {
              itemHoverColor: '#1351CD',
              itemActiveColor: '#1351CD',
              itemSelectedColor: '#1351CD',
            },
            Pagination: {
              itemActiveBg: '#FFFFFF',
              colorPrimary: '#1351CD',
              colorPrimaryHover: '#1351CD',
            },
          },
        }}
      >
        <AuthProvider>
          <Provider store={store}>
            <App />
          </Provider>
        </AuthProvider>
      </ConfigProvider>
    </BrowserRouter>
  </StrictMode>,
);
