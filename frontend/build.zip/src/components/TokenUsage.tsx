import { useEffect, useRef, useState } from 'react';
import { Alert } from 'antd';
import { TOKEN_USAGE_REFRESH_EVENT, type TokenUsageRefreshDetail } from '../services/showTokens';

interface TokenUsageProps {
  onLimitUpdate?: (reached: boolean) => void;
}

function isLimitReached(used: number, limit: number): boolean {
  return limit !== -1 && used >= limit;
}

export default function TokenUsage({ onLimitUpdate }: TokenUsageProps = {}) {
  const [showWarning, setShowWarning] = useState(false);
  const snapshotRef = useRef<{ used?: number; limit?: number }>({});

  useEffect(() => {
    const onRefresh = (e: Event) => {
      const ce = e as CustomEvent<TokenUsageRefreshDetail | undefined>;
      const d = ce.detail;
      if (!d) return;
      if (d.totalTokensUsed !== undefined) {
        snapshotRef.current.used = d.totalTokensUsed;
      }
      if (d.availableTokens !== undefined) {
        snapshotRef.current.limit = d.availableTokens;
      }
      const s = snapshotRef.current;
      if (s.used === undefined || s.limit === undefined) return;
      const reached = isLimitReached(s.used, s.limit);
      setShowWarning(reached);
      onLimitUpdate?.(reached);
    };
    window.addEventListener(TOKEN_USAGE_REFRESH_EVENT, onRefresh);
    return () => window.removeEventListener(TOKEN_USAGE_REFRESH_EVENT, onRefresh);
  }, [onLimitUpdate]);

  if (!showWarning) return null;

  return (
    <div className="mb-4 w-full">
      <Alert
        message="Token Usage Limit Reached"
        description="Your token usage limit has been reached. Please contact your administrator to request additional capacity or for further assistance."
        type="warning"
        showIcon
      />
    </div>
  );
}
