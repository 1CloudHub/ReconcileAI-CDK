import type { ButtonHTMLAttributes, ReactNode } from 'react';

export type PrimaryButtonProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children'> & {
  icon?: ReactNode;
  text: ReactNode;
};

function joinClass(...parts: Array<string | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

/**
 * Solid primary CTA: app blue, rounded-rectangle, soft shadow, icon + label.
 */
export default function PrimaryButton({
  icon,
  text,
  className,
  disabled,
  type = 'button',
  ...rest
}: PrimaryButtonProps) {
  return (
    <button
      type={type}
      disabled={disabled}
      className={joinClass(
        'inline-flex items-center justify-center gap-2 rounded-[10px]',
        'min-h-[44px] px-5 py-2 border-0',
        'bg-[#1351cd] text-white text-[15px] font-semibold tracking-wide',
        'shadow-[0_2px_8px_rgba(19,81,205,0.28)]',
        'transition-all duration-200 cursor-pointer',
        'hover:enabled:bg-[#0f45b0] hover:enabled:-translate-y-px hover:enabled:shadow-[0_4px_14px_rgba(19,81,205,0.35)]',
        'active:enabled:translate-y-0',
        'disabled:opacity-60 disabled:cursor-not-allowed',
        'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1351cd]',
        className
      )}
      {...rest}
    >
      {icon ? (
        <span className="inline-flex shrink-0 items-center justify-center text-white [&_svg]:size-[18px]" aria-hidden>
          {icon}
        </span>
      ) : null}
      <span>{text}</span>
    </button>
  );
}
