import type { ReactNode } from 'react';
import type { Dayjs } from 'dayjs';
import DatePickerInput from './DatePickerInput';
import SelectInput from './SelectInput';

type Option = { value: string | number; label: string };

type BaseField = {
  key: string;
  label?: string;
  className?: string;
};

type InputField = BaseField & {
  type: 'input';
  value: string;
  placeholder?: string;
  ariaLabel?: string;
  onChange: (value: string) => void;
};

type SelectField = BaseField & {
  type: 'select';
  value: string | number | Array<string | number> | undefined;
  placeholder?: string;
  options: Option[];
  mode?: 'multiple';
  allowClear?: boolean;
  onChange: (value: string | number | Array<string | number> | undefined) => void;
};

type DateField = BaseField & {
  type: 'date';
  value: Dayjs | null;
  placeholder?: string;
  allowClear?: boolean;
  onChange: (value: Dayjs | null) => void;
};

export type FilterField = InputField | SelectField | DateField;

export type FilterFieldsProps = {
  fields: FilterField[];
  className?: string;
  actionSlot?: ReactNode;
};

function joinClass(...parts: Array<string | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

function renderField(field: FilterField): ReactNode {
  if (field.type === 'input') {
    return (
      <div className={joinClass('flex flex-col gap-1.5', field.className)}>
        {field.label ? <label className="text-[14px] font-semibold text-gray-800 leading-snug">{field.label}</label> : null}
        <input
          type="text"
          value={field.value}
          placeholder={field.placeholder}
          aria-label={field.ariaLabel ?? field.label ?? field.placeholder ?? 'Filter input'}
          onChange={(e) => field.onChange(e.target.value)}
          className="w-full h-10 rounded-[10px] border border-[#dde3f0] bg-white px-4 text-[15px] text-gray-900 placeholder-gray-400 transition-all duration-200 hover:bg-[#EEF2FF] hover:border-[#1351cd] focus:outline-none focus:border-[#1351cd] focus:bg-white focus:ring-[3px] focus:ring-[rgba(0,75,145,0.12)]"
        />
      </div>
    );
  }

  if (field.type === 'select') {
    return (
      <div className={joinClass('flex flex-col gap-1.5', field.className)}>
        {field.label ? <label className="text-[14px] font-semibold text-gray-800 leading-snug">{field.label}</label> : null}
        <SelectInput
          useDefaultWidth={false}
          className="w-full [&_.ant-select-selector]:!min-h-10 [&_.ant-select-selector]:!h-10 [&_.ant-select-selection-wrap]:!items-center"
          size="large"
          value={field.value as unknown as undefined}
          options={field.options}
          mode={field.mode}
          allowClear={field.allowClear ?? true}
          placeholder={field.placeholder}
          onChange={(v) => field.onChange(v as string | number | Array<string | number> | undefined)}
        />
      </div>
    );
  }

  return (
    <div className={joinClass('flex flex-col gap-1.5', field.className)}>
      {field.label ? <label className="text-[14px] font-semibold text-gray-800 leading-snug">{field.label}</label> : null}
      <DatePickerInput
        useDefaultWidth={false}
        className="w-full !h-10 [&_.ant-picker-input]:!h-full [&_.ant-picker-input>input]:!h-full"
        size="large"
        value={field.value}
        allowClear={field.allowClear ?? true}
        placeholder={field.placeholder}
        onChange={(date) => field.onChange(Array.isArray(date) ? null : date)}
      />
    </div>
  );
}

/**
 * Reusable filter strip: text input, select, and date picker fields (stacked column by default).
 */
export default function FilterFields({ fields, className, actionSlot }: FilterFieldsProps) {
  return (
    <div className={joinClass('flex w-full flex-col gap-4', className)}>
      <div className="flex w-full flex-col gap-3">
        {fields.map((field) => (
          <div key={field.key}>
            {renderField(field)}
          </div>
        ))}
      </div>

      {actionSlot ? <div className="flex shrink-0 justify-end">{actionSlot}</div> : null}
    </div>
  );
}
