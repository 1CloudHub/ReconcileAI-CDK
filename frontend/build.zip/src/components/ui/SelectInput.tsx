import { Select, type SelectProps } from 'antd';
import type { BaseOptionType, DefaultOptionType } from 'antd/es/select';

const defaultWidthClass = 'min-w-[220px] max-w-full sm:min-w-[260px]';

function joinClass(...parts: Array<string | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

export type SelectInputProps<
  ValueType = unknown,
  OptionType extends BaseOptionType | DefaultOptionType = DefaultOptionType,
> = SelectProps<ValueType, OptionType> & {
  /**
   * Keeps the shared filter sizing classes by default.
   * Set `useDefaultWidth={false}` to control full sizing yourself.
   */
  useDefaultWidth?: boolean;
};

/**
 * App-styled Ant Design `Select` with shared width defaults for filters and forms.
 * Forwards all `Select` props; override `className` to extend or replace layout via Tailwind.
 */
export default function SelectInput<
  ValueType = unknown,
  OptionType extends BaseOptionType | DefaultOptionType = DefaultOptionType,
>({
  className,
  useDefaultWidth = true,
  allowClear = false,
  size = 'middle',
  ...rest
}: SelectInputProps<ValueType, OptionType>) {
  return (
    <Select<ValueType, OptionType>
      className={joinClass(useDefaultWidth ? defaultWidthClass : undefined, className)}
      allowClear={allowClear}
      size={size}
      {...rest}
    />
  );
}
