import type { CSSProperties } from 'react';

export type ListPageTableSkeletonProps = {
  toolbarButtonCount?: number;
  tableColumns?: number;
  tableRows?: number;
  showPagination?: boolean;
  className?: string;
};

const pulse = 'animate-pulse bg-slate-200 rounded';

function SkeletonBlock({
  className = '',
  style,
}: {
  className?: string;
  style?: CSSProperties;
}) {
  return <div className={`${pulse} ${className}`} style={style} />;
}

export default function ListPageTableSkeleton({
  toolbarButtonCount = 2,
  tableColumns = 5,
  tableRows = 8,
  showPagination = true,
  className = '',
}: ListPageTableSkeletonProps) {
  const safeToolbarButtons = Math.max(0, toolbarButtonCount);
  const safeColumns = Math.max(1, tableColumns);
  const safeRows = Math.max(1, tableRows);

  return (
    <section
      className={`rounded-xl border border-slate-200/80 bg-white p-6 shadow-sm max-md:p-4 ${className}`.trim()}
    >
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="ml-auto flex w-full flex-col items-stretch gap-3 sm:w-auto sm:flex-row sm:flex-wrap sm:items-center sm:justify-end">
          {Array.from({ length: safeToolbarButtons }).map((_, index) => (
            <SkeletonBlock
              key={`toolbar-skeleton-btn-${index}`}
              className="h-[44px] w-full rounded-[10px] sm:w-[148px]"
            />
          ))}
        </div>
      </div>

      <div className="overflow-hidden rounded-lg border border-slate-200/80">
        <div
          className="grid gap-3 bg-[#f8fafc] px-4 py-3"
          style={{ gridTemplateColumns: `repeat(${safeColumns}, minmax(0, 1fr))` }}
        >
          {Array.from({ length: safeColumns }).map((_, index) => (
            <SkeletonBlock
              key={`header-cell-${index}`}
              className="h-4 w-full"
            />
          ))}
        </div>

        <div className="divide-y divide-slate-100 bg-white">
          {Array.from({ length: safeRows }).map((_, rowIndex) => (
            <div
              key={`row-${rowIndex}`}
              className="grid gap-3 px-4 py-3"
              style={{ gridTemplateColumns: `repeat(${safeColumns}, minmax(0, 1fr))` }}
            >
              {Array.from({ length: safeColumns }).map((__, colIndex) => (
                <SkeletonBlock
                  key={`row-${rowIndex}-col-${colIndex}`}
                  className="h-4 w-full"
                />
              ))}
            </div>
          ))}
        </div>
      </div>

      {showPagination ? (
        <div className="mt-4 flex justify-end gap-2">
          <SkeletonBlock className="h-9 w-9 rounded-full" />
          <SkeletonBlock className="h-9 w-9 rounded-full" />
          <SkeletonBlock className="h-9 w-9 rounded-full" />
        </div>
      ) : null}
    </section>
  );
}
