import { DatePicker, type DatePickerProps } from 'antd';

const defaultWidthClass = 'min-w-[140px]';

function joinClass(...parts: Array<string | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

export type DatePickerInputProps = DatePickerProps & {
  /**
   * Keeps shared width class by default.
   * Set `useDefaultWidth={false}` to fully control width via `className`.
   */
  useDefaultWidth?: boolean;
};

/**
 * Reusable Ant Design date picker with app defaults.
 * Forwards all DatePicker props.
 */
export default function DatePickerInput({
  className,
  useDefaultWidth = true,
  allowClear = true,
  size = 'middle',
  inputReadOnly = true,
  ...rest
}: DatePickerInputProps) {
  return (
    <DatePicker
      className={joinClass(useDefaultWidth ? defaultWidthClass : undefined, className)}
      allowClear={allowClear}
      size={size}
      inputReadOnly={inputReadOnly}
      {...rest}
    />
  );
}

