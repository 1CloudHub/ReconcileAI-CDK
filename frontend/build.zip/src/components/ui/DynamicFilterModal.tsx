import { useCallback, useRef, type KeyboardEvent, type ReactNode } from 'react'; // eslint-disable-line @typescript-eslint/no-unused-vars
import dayjs, { type Dayjs } from 'dayjs';
import { Drawer } from 'antd';
import FilterModal from './FilterModal';
import DatePickerInput from './DatePickerInput';
import SelectInput from './SelectInput';

type SelectOption = { value: string | number; label: string };

type BaseField = {
  key: string;
  label: string;
  className?: string;
};

type InputField = BaseField & {
  type: 'input';
  placeholder?: string;
};

type SelectField = BaseField & {
  type: 'select';
  placeholder?: string;
  options: SelectOption[];
  allowClear?: boolean;
  /** Type-to-filter inside the dropdown (options matched on `label`). */
  showSearch?: boolean;
};

type DateField = BaseField & {
  type: 'date';
  placeholder?: string;
  allowClear?: boolean;
};

export type DynamicFilterField = InputField | SelectField | DateField;

export type DynamicFilterValue = string | number | Dayjs | null | undefined;
export type DynamicFilterValues = Record<string, DynamicFilterValue>;

export type DynamicFilterModalProps = {
  open: boolean;
  title?: string;
  width?: number;
  variant?: 'modal' | 'drawer';
  fields: DynamicFilterField[];
  values: DynamicFilterValues;
  onChange: (key: string, value: DynamicFilterValue) => void;
  onCancel: () => void;
  onApply: () => void;
  onReset: () => void;
  applyDisabled?: boolean;
  resetDisabled?: boolean;
  applyText?: string;
  resetText?: string;
  /** Optional content rendered below the fields (e.g. a date range picker). */
  extraContent?: ReactNode;
};

function joinClass(...parts: Array<string | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

/**
 * Reusable dynamic filter modal driven by API field metadata.
 */
export default function DynamicFilterModal({
  open,
  title = 'Filter',
  width = 900,
  variant = 'modal',
  fields,
  values,
  onChange,
  onCancel,
  onApply,
  onReset,
  applyDisabled = false,
  resetDisabled = false,
  applyText = 'Apply Filters',
  resetText = 'Reset Filters',
  extraContent,
}: DynamicFilterModalProps) {
  const enterApplyLockRef = useRef(false);

  const applyOnEnter = useCallback(
    (e: KeyboardEvent) => {
      if (e.key !== 'Enter' || applyDisabled) return;
      e.preventDefault();
      if (enterApplyLockRef.current) return;
      enterApplyLockRef.current = true;
      onApply();
      window.setTimeout(() => {
        enterApplyLockRef.current = false;
      }, 150);
    },
    [applyDisabled, onApply]
  );

  const fieldsNode = (
    <div className={variant === 'drawer' ? 'flex w-full flex-col gap-4' : 'grid grid-cols-1 gap-x-5 gap-y-4 md:grid-cols-2'}>
      {fields.map((field) => (
        <div key={field.key} className={joinClass('flex flex-col gap-1.5', field.className)}>
          <label className="text-[14px] font-semibold text-gray-800 leading-snug">{field.label}</label>

          {field.type === 'input' ? (
            <input
              type="text"
              value={String(values[field.key] ?? '')}
              placeholder={field.placeholder}
              onChange={(event) => onChange(field.key, event.target.value)}
              onKeyDown={applyOnEnter}
              className="h-10 w-full rounded-[10px] border border-[#dde3f0] bg-white px-4 text-[15px] text-gray-900 placeholder-gray-400 transition-all duration-200 hover:bg-[#EEF2FF] hover:border-[#1351cd] focus:outline-none focus:border-[#1351cd] focus:bg-white focus:ring-[3px] focus:ring-[rgba(0,75,145,0.12)]"
            />
          ) : null}

          {field.type === 'select' ? (
            <SelectInput
              useDefaultWidth={false}
              className="w-full [&_.ant-select-selector]:!min-h-10 [&_.ant-select-selector]:!h-10 [&_.ant-select-selection-item]:!leading-[38px] [&_.ant-select-selection-wrap]:!items-center [&_.ant-select-arrow]:!text-slate-500"
              size="large"
              value={values[field.key] as string | number | undefined}
              allowClear={field.allowClear ?? true}
              placeholder={field.placeholder}
              options={field.options}
              showSearch={field.showSearch}
              optionFilterProp={field.showSearch ? 'label' : undefined}
              filterOption={
                field.showSearch
                  ? (input, option) =>
                      String(option?.label ?? '')
                        .toLowerCase()
                        .includes(input.trim().toLowerCase())
                  : undefined
              }
              popupClassName="rounded-[10px] [&_.ant-select-item]:rounded-md"
              onChange={(value) => onChange(field.key, value as string | number | undefined)}
              onInputKeyDown={applyOnEnter}
              onKeyDown={applyOnEnter}
            />
          ) : null}

          {field.type === 'date' ? (
            <DatePickerInput
              useDefaultWidth={false}
              className="w-full !h-10 [&_.ant-picker-input]:!h-full [&_.ant-picker-input>input]:!h-full"
              size="large"
              value={(values[field.key] as Dayjs | null | undefined) ?? null}
              allowClear={field.allowClear ?? true}
              placeholder={field.placeholder}
              disabledDate={(current) => Boolean(current && current.isAfter(dayjs(), 'day'))}
              onChange={(date) => onChange(field.key, Array.isArray(date) ? null : date)}
              onKeyDown={applyOnEnter}
            />
          ) : null}
        </div>
      ))}
    </div>
  );

  if (variant === 'drawer') {
    return (
      <Drawer
        open={open}
        title={title}
        width={360}
        placement="right"
        onClose={onCancel}
        destroyOnClose
        footer={
          <div className="flex items-center justify-end gap-2">
            <button
              type="button"
              disabled={resetDisabled}
              className="inline-flex min-h-[40px] items-center justify-center rounded-[10px] border border-slate-300 bg-white px-4 text-sm font-medium text-slate-700 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
              onClick={onReset}
            >
              {resetText}
            </button>
            <button
              type="button"
              disabled={applyDisabled}
              className="inline-flex min-h-[40px] items-center justify-center rounded-[10px] bg-[#1351cd] px-4 text-sm font-semibold text-white hover:bg-[#0f45b0] disabled:cursor-not-allowed disabled:opacity-50"
              onClick={onApply}
            >
              {applyText}
            </button>
          </div>
        }
      >
        <div className="flex flex-col gap-4">
          {fieldsNode}
          {extraContent}
        </div>
      </Drawer>
    );
  }

  return (
    <FilterModal
      open={open}
      title={title}
      width={width}
      onCancel={onCancel}
      onApply={onApply}
      onClear={onReset}
      applyText={applyText}
      clearText={resetText}
      applyDisabled={applyDisabled}
      clearDisabled={resetDisabled}
    >
      {fieldsNode}
    </FilterModal>
  );
}
