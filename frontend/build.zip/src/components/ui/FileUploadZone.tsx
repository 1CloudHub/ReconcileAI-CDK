import React, { useRef, useState } from 'react';
import { validateSinglePageDocument } from '../../utils/pdfSinglePageValidation';

interface FileUploadZoneProps {
  id: string;
  label: string;
  file: File | null;
  prefilledName?: string;
  isUploading?: boolean;
  isLocked?: boolean;
  onFileSelected: (file: File) => void;
  onRemove: () => void;
  accept?: string;
  maxSizeMb?: number;
  /** Called when PDF has more than one page or cannot be read. Defaults to `alert`. */
  onValidationError?: (message: string) => void;
}


const formatFileSizeKb = (file: File): string => {
  return `${(file.size / 1024).toFixed(2)} KB`;
};

const FileUploadZone: React.FC<FileUploadZoneProps> = ({
  id,
  label,
  file,
  prefilledName,
  isUploading,
  isLocked,
  onFileSelected,
  onRemove,
  onValidationError,
  accept = '.pdf',
  maxSizeMb = 4,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isValidating, setIsValidating] = useState(false);
  const maxSizeBytes = maxSizeMb * 1024 * 1024;
  const busy = Boolean(isUploading || isValidating);

  const resetInput = () => {
    if (inputRef.current) {
      inputRef.current.value = '';
    }
  };

  const reportValidationError = (msg: string) => {
    if (onValidationError) {
      onValidationError(msg);
    } else {
      alert(msg);
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0] ?? null;
    if (isLocked || busy || !selectedFile) return;

    const isAccepted = 
      selectedFile.type === 'application/pdf' || 
      selectedFile.name.toLowerCase().endsWith('.pdf') ||
      accept.includes(selectedFile.type);

    if (!isAccepted) {
      reportValidationError('Unsupported file type.');
      resetInput();
      return;
    }

    if (selectedFile.size > maxSizeBytes) {
      reportValidationError(`File size must be ${maxSizeMb} MB or less.`);
      resetInput();
      return;
    }

    setIsValidating(true);
    void (async () => {
      const result = await validateSinglePageDocument(selectedFile);
      setIsValidating(false);
      if (!result.ok) {
        reportValidationError(result.message);
        resetInput();
        return;
      }
      onFileSelected(selectedFile);
      resetInput();
    })();
  };

  return (
    <div className="w-full space-y-2">
      <p className="m-0 text-sm font-semibold text-slate-800">{label}</p>
      <div
        className={[
          'box-border flex h-[184px] w-full flex-col overflow-hidden rounded-lg border border-dashed p-3 transition-colors',
          file || prefilledName
            ? 'border-[#93c5fd] bg-[#eff6ff]'
            : isLocked
              ? 'pointer-events-none border-slate-200 bg-slate-100 opacity-80'
              : busy
                ? 'border-[#93c5fd] bg-[#eff6ff]'
                : 'border-slate-300 bg-slate-50 hover:border-[#93c5fd] hover:bg-[#eff6ff]',
          (file || prefilledName) && isLocked ? 'pointer-events-none' : '',
        ].join(' ')}
      >
        {file ? (
          <div className="flex h-full min-h-0 w-full flex-col items-center justify-center gap-1 overflow-hidden text-center">
            <svg
              className="h-7 w-7 shrink-0"
              viewBox="0 0 24 24"
              fill="none"
              aria-hidden
            >
              <circle cx="12" cy="12" r="10" stroke="#2563eb" strokeWidth="1.8" />
              <path
                d="M8.2 12.1L10.9 14.7L15.8 9.8"
                stroke="#2563eb"
                strokeWidth="1.9"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <p className="m-0 max-w-full shrink-0 px-1 text-[13px] font-semibold leading-tight text-[#2563eb]">
              {isLocked ? 'Processing documents…' : 'File uploaded successfully'}
            </p>
            <p
              className="m-0 line-clamp-2 w-full min-w-0 break-all px-1 text-center text-[12px] leading-snug text-slate-700"
              title={file.name}
            >
              {file.name}
            </p>
            <p className="m-0 shrink-0 text-[12px] text-slate-400">
              {formatFileSizeKb(file)}
            </p>
            <button
              type="button"
              className="mt-0.5 shrink-0 text-[12px] font-medium text-rose-500 hover:underline disabled:cursor-not-allowed disabled:opacity-40"
              hidden={isLocked}
              onClick={onRemove}
            >
              Remove
            </button>
          </div>
        ) : prefilledName ? (
          <div className="flex h-full min-h-0 w-full flex-col items-center justify-center gap-1 overflow-hidden text-center">
            <svg className="h-7 w-7 shrink-0" viewBox="0 0 24 24" fill="none" aria-hidden>
              <circle cx="12" cy="12" r="10" stroke="#2563eb" strokeWidth="1.8" />
              <path d="M8.2 12.1L10.9 14.7L15.8 9.8" stroke="#2563eb" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <p className="m-0 max-w-full shrink-0 px-1 text-[13px] font-semibold leading-tight text-[#2563eb]">
              File uploaded successfully
            </p>
            <p
              className="m-0 line-clamp-2 w-full min-w-0 break-all px-1 text-center text-[12px] leading-snug text-slate-700"
              title={prefilledName}
            >
              {prefilledName}
            </p>
            <button
              type="button"
              className="mt-0.5 shrink-0 text-[12px] font-medium text-rose-500 hover:underline"
              onClick={onRemove}
            >
              Remove
            </button>
          </div>
        ) : (
          <label
            htmlFor={id}
            className={[
              'flex h-full min-h-0 w-full flex-col items-center justify-center rounded-md px-2 text-center transition-colors',
              isLocked
                ? 'cursor-not-allowed'
                : busy
                  ? 'cursor-wait'
                  : 'cursor-pointer hover:bg-[#1351cd]/[0.03]',
            ].join(' ')}
          >
            <div className="flex min-h-0 w-full flex-col items-center justify-center gap-2 px-2 text-center">
              <svg className="shrink-0" width="36" height="36" viewBox="0 0 24 24" fill="none" aria-hidden>
                <path
                  d="M12 16V6M12 6L8 10M12 6L16 10"
                  stroke={isLocked ? '#64748b' : '#047857'}
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M6 15V17C6 18.1046 6.89543 19 8 19H16C17.1046 19 18 18.1046 18 17V15"
                  stroke={isLocked ? '#64748b' : '#047857'}
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <p className="m-0 text-[14px] font-normal text-slate-900">
                {isLocked ? 'Processing…' : isValidating ? 'Checking PDF…' : 'Drop your file here or click to browse'}
              </p>
              <p className="m-0 text-[13px] text-slate-500">
                {isLocked ? 'Please wait.' : isValidating ? 'One page only.' : `Supported format: PDF (max ${maxSizeMb} MB)`}
              </p>
            </div>
          </label>
        )}
      </div>
      <input
        ref={inputRef}
        id={id}
        type="file"
        accept={accept}
        className="sr-only"
        disabled={isLocked || busy}
        onChange={handleFileChange}
      />
    </div>
  );
};

export default FileUploadZone;
