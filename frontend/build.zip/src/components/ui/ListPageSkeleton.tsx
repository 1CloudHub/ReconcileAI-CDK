import { Skeleton } from 'antd';

export type ListPageSkeletonProps = {
  /** Table column placeholders */
  tableColumns?: number;
  /** Table body rows */
  tableRows?: number;
  /** Ant Design skeleton buttons in toolbar (0 = hide; keep real toolbar on page) */
  toolbarButtons?: number;
  showPagination?: boolean;
  className?: string;
  /** e.g. mt-6 when table sits below toolbar with margin */
  tableWrapClassName?: string;
};

/**
 * Ant Design skeleton for list/table pages (Document Types, Job Config, SOP Control Center, Reconcile Agent).
 * Use with real toolbar/actions visible and `toolbarButtons={0}` for typical loading UX.
 */
export default function ListPageSkeleton({
  tableColumns = 4,
  tableRows = 10,
  toolbarButtons = 0,
  showPagination = true,
  className = '',
  tableWrapClassName = '',
}: ListPageSkeletonProps) {
  const colTemplate = `repeat(${tableColumns}, minmax(0, 1fr))`;

  return (
    <div className={className}>
      {toolbarButtons > 0 ? (
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-end">
          <div className="ml-auto flex w-full flex-col items-stretch gap-3 sm:w-auto sm:flex-row sm:flex-wrap sm:items-center sm:justify-end">
            {Array.from({ length: toolbarButtons }).map((_, i) => (
              <Skeleton.Button
                key={i}
                active
                size="large"
                className="!flex !h-11 !min-h-[44px] !min-w-[120px] !items-center !justify-center sm:!min-w-[140px]"
              />
            ))}
          </div>
        </div>
      ) : null}

      <div className={`min-w-0 ${tableWrapClassName}`.trim()}>
        <div className="min-w-0 overflow-hidden rounded-lg border border-slate-200/80 bg-white">
          <div
            className="grid gap-3 border-b border-slate-200 bg-[#f8fafc] px-4 py-2.5"
            style={{ gridTemplateColumns: colTemplate }}
          >
            {Array.from({ length: tableColumns }).map((_, i) => (
              <Skeleton.Input
                key={`th-${i}`}
                active
                size="small"
                style={{ width: '70%', minWidth: 64, height: 14 }}
              />
            ))}
          </div>
          <div className="px-4 py-0.5">
            {Array.from({ length: tableRows }).map((_, ri) => (
              <div
                key={`tr-${ri}`}
                className="grid gap-3 border-b border-slate-100 py-2.5 last:border-b-0"
                style={{ gridTemplateColumns: colTemplate }}
              >
                {Array.from({ length: tableColumns }).map((_, ci) => (
                  <Skeleton.Input
                    key={`td-${ri}-${ci}`}
                    active
                    size="small"
                    style={{ width: '100%', height: 18 }}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>

      {showPagination ? (
        <div className="mt-3 flex justify-end sm:mt-4">
          <Skeleton.Input active style={{ width: 280, height: 32, borderRadius: 8 }} />
        </div>
      ) : null}
    </div>
  );
}
