import { Modal } from 'antd';
import type { ReactNode } from 'react';
import PrimaryButton from './PrimaryButton';

export type FilterModalProps = {
  open: boolean;
  title?: string;
  width?: number;
  onCancel: () => void;
  onApply: () => void;
  onClear?: () => void;
  applyDisabled?: boolean;
  clearDisabled?: boolean;
  applyText?: string;
  clearText?: string;
  children: ReactNode;
};

/**
 * Reusable modal shell for custom page filter forms.
 */
export default function FilterModal({
  open,
  title = 'Filters',
  width = 720,
  onCancel,
  onApply,
  onClear,
  applyDisabled = false,
  clearDisabled = false,
  applyText = 'Apply',
  clearText = 'Clear',
  children,
}: FilterModalProps) {
  return (
    <Modal
      open={open}
      title={<span className="text-[20px] font-semibold text-slate-900">{title}</span>}
      onCancel={onCancel}
      footer={null}
      width={width}
      centered
      destroyOnHidden
      styles={{ body: { paddingTop: 0 } }}
    >
      <div className="flex flex-col gap-5">
        {children}

        <div className="flex items-center justify-end gap-2">
          {onClear ? (
            <button
              type="button"
              disabled={clearDisabled}
              className="inline-flex items-center justify-center rounded-[10px] border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
              onClick={onClear}
            >
              {clearText}
            </button>
          ) : null}
          <PrimaryButton text={applyText} onClick={onApply} disabled={applyDisabled} className="min-h-[40px] px-4" />
        </div>
      </div>
    </Modal>
  );
}
