import { Modal } from 'antd';

export type DeleteConfirmModalProps = {
  open: boolean;
  title?: string;
  description?: string;
  confirmText?: string;
  cancelText?: string;
  onConfirm: () => void;
  onCancel: () => void;
  loading?: boolean;
  /** Optional viewport position to anchor near a clicked icon. */
  position?: { top: number; left: number };
  onAfterClose?: () => void;
};

/**
 * Reusable destructive-action confirmation modal.
 */
export default function DeleteConfirmModal({
  open,
  title = 'Delete Item',
  description = 'Are you sure you want to delete? This action cannot be undone.',
  confirmText = 'Yes',
  cancelText = 'No',
  onConfirm,
  onCancel,
  loading = false,
  position,
  onAfterClose,
}: DeleteConfirmModalProps) {
  return (
    <Modal
      open={open}
      footer={null}
      onCancel={onCancel}
      afterOpenChange={(nextOpen) => {
        if (!nextOpen) onAfterClose?.();
      }}
      destroyOnHidden
      width={420}
      centered={false}
      mask={false}
      style={{
        top: position?.top ?? 120,
        left: position?.left,
        margin: 0,
      }}
      styles={{ body: { padding: 0 } }}
    >
      <div className="flex flex-col gap-4">
        <div>
          <h3 className="m-0 text-[20px] leading-[1.2] font-semibold text-slate-900">{title}</h3>
          <p className="mt-2 mb-0 text-[15px] leading-[1.45] text-slate-700">{description}</p>
        </div>

        <div className="flex justify-end gap-2">
          <button
            type="button"
            className="inline-flex h-[32px] items-center justify-center rounded-[10px] border border-slate-300 bg-white px-3 text-[13px] font-medium text-slate-700 transition-colors hover:bg-slate-50"
            onClick={onCancel}
          >
            {cancelText}
          </button>
          <button
            type="button"
            disabled={loading}
            onClick={onConfirm}
            className="inline-flex h-[32px] items-center justify-center rounded-[10px] bg-[#e52323] px-3 text-[13px] font-semibold text-white transition-colors hover:enabled:bg-[#cc1f1f] disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {confirmText}
          </button>
        </div>
      </div>
    </Modal>
  );
}

