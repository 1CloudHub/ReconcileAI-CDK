import type { InputHTMLAttributes } from 'react';

export type ToggleSliderProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'type' | 'onChange'> & {
  checked?: boolean;
  onChange?: (checked: boolean) => void;
  checkedLabel?: string;
  uncheckedLabel?: string;
};

export default function ToggleSlider({
  checked = false,
  onChange,
  checkedLabel,
  uncheckedLabel,
  disabled,
  className,
  ...rest
}: ToggleSliderProps) {
  return (
    <label
      className={[
        'inline-flex items-center gap-2 select-none',
        disabled ? 'cursor-not-allowed opacity-50' : 'cursor-pointer',
        className,
      ]
        .filter(Boolean)
        .join(' ')}
    >
      <span className="relative inline-block w-[52px] h-[26px] shrink-0">
        <input
          type="checkbox"
          className="sr-only peer"
          checked={checked}
          disabled={disabled}
          onChange={(e) => onChange?.(e.target.checked)}
          {...rest}
        />
        {/* Track */}
        <span
          className={[
            'absolute inset-0 rounded-full transition-colors duration-200',
            checked ? 'bg-[#1351cd]' : 'bg-[#d9d9d9]',
          ].join(' ')}
        />
        {/* Thumb */}
        <span
          className={[
            'absolute top-[3px] left-[3px] w-5 h-5 rounded-full bg-white shadow-[0_1px_4px_rgba(0,0,0,0.25)]',
            'transition-transform duration-200',
            checked ? 'translate-x-[26px]' : 'translate-x-0',
          ].join(' ')}
        />
      </span>
      {(checkedLabel || uncheckedLabel) && (
        <span className="text-sm font-medium text-gray-700">
          {checked ? checkedLabel : uncheckedLabel}
        </span>
      )}
    </label>
  );
}
