import { useState, type InputHTMLAttributes, type ReactNode } from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface InputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label: string;
  required?: boolean;
  type?: InputHTMLAttributes<HTMLInputElement>['type'];
  icon?: ReactNode;
  error?: string;
  errorClassName?: string;
}

export default function Input({
  label,
  required,
  type = 'text',
  icon,
  error,
  errorClassName,
  id,
  className,
  ...rest
}: InputProps) {
  const [showPassword, setShowPassword] = useState(false);
  const isPassword = type === 'password';
  const inputType = isPassword ? (showPassword ? 'text' : 'password') : type;
  const inputId = id ?? label.toLowerCase().replace(/\s+/g, '-');

  const hasLeftPadding = !!icon;
  const hasRightPadding = isPassword;

  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={inputId} className="text-[14px] font-semibold text-gray-800 leading-snug">
        {label}
        {required && <span className="text-red-600 ml-0.5">*</span>}
      </label>

      <div className="relative flex items-center">
        {/* Left icon */}
        {icon && (
          <span className="absolute left-4 text-gray-400 pointer-events-none z-10 flex items-center">
            {icon}
          </span>
        )}

        <input
          id={inputId}
          type={inputType}
          required={required}
          className={[
            'w-full h-9 border rounded-[10px] text-[15px] text-gray-900 bg-white',
            'placeholder-gray-400 transition-all duration-200',
            'hover:bg-[#EEF2FF] hover:border-[#1351cd]',
            'focus:outline-none focus:border-[#1351cd] focus:bg-white focus:ring-[3px] focus:ring-[rgba(0,75,145,0.12)]',
            error ? 'border-red-400' : 'border-[#dde3f0]',
            hasLeftPadding ? 'pl-12' : 'pl-4',
            hasRightPadding ? 'pr-12' : 'pr-4',
            className ?? '',
          ].join(' ')}
          {...rest}
        />

        {/* Password toggle */}
        {isPassword && (
          <button
            type="button"
            onClick={() => setShowPassword((v) => !v)}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-gray-400 hover:text-[#1351cd] transition-colors z-10 rounded-md focus:outline-none focus-visible:outline-2 focus-visible:outline-[#1351cd] focus-visible:outline-offset-2"
            aria-label={showPassword ? 'Hide password' : 'Show password'}
          >
            {showPassword ? <Eye size={17} /> : <EyeOff size={17} />}
          </button>
        )}
      </div>

      {/* Error message */}
      {error && (
        <p className={errorClassName ?? 'text-sm text-red-600 font-medium mt-0.5'}>{error}</p>
      )}
    </div>
  );
}
