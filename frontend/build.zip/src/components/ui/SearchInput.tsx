import { Input, type InputRef } from 'antd';
import type { InputProps } from 'antd';
import { Search } from 'lucide-react';
import { forwardRef } from 'react';

export type SearchInputProps = Omit<InputProps, 'prefix'> & {
  /** @default 'Search exception name...' */
  placeholder?: string;
};

function joinClass(...parts: Array<string | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

const affixRootClass = joinClass(
  '!rounded-[10px] !bg-white border border-[#c8d4e4] shadow-none transition-all duration-200',
  'hover:border-[#b0c4d8]',
  '[&:focus-within]:border-[#1351cd] [&:focus-within]:shadow-[0_0_0_3px_rgba(19,81,205,0.1)]',
  'px-3 py-0 min-h-[44px] items-center',
  '[&_input]:text-[15px] [&_input]:text-slate-700 [&_input::placeholder]:text-slate-500'
);

/**
 * Rounded-rectangle search field with left magnifier icon (Ant Design `Input` + Lucide).
 * Forwards all `Input` props except `prefix`. Use `rootClassName` to extend layout.
 */
const SearchInput = forwardRef<InputRef, SearchInputProps>(function SearchInput(
  {
    placeholder = 'Search exception name...',
    allowClear = true,
    size = 'large',
    rootClassName,
    ...rest
  },
  ref
) {
  return (
    <Input
      ref={ref}
      type="search"
      size={size}
      allowClear={allowClear}
      placeholder={placeholder}
      prefix={
        <span className="inline-flex shrink-0 items-center mr-1.5 text-[#64748b]" aria-hidden>
          <Search size={18} strokeWidth={2} />
        </span>
      }
      rootClassName={joinClass(affixRootClass, rootClassName)}
      {...rest}
    />
  );
});

export default SearchInput;
