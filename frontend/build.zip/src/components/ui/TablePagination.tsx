import { Pagination } from 'antd';

export type TablePaginationProps = {
  total: number;
  current: number;
  pageSize: number;
  onChange: (page: number, pageSize: number) => void;
  showSizeChanger?: boolean;
  pageSizeOptions?: Array<number | string>;
  showTotal?: boolean;
  className?: string;
};

/**
 * Reusable table pagination block with app defaults.
 */
export default function TablePagination({
  total,
  current,
  pageSize,
  onChange,
  showSizeChanger = true,
  pageSizeOptions = [10, 15, 20, 25],
  showTotal = true,
  className,
}: TablePaginationProps) {
  return (
    <div className={className ?? 'mt-4 flex justify-end'}>
      <Pagination
        total={total}
        current={current}
        pageSize={pageSize}
        showSizeChanger={showSizeChanger}
        pageSizeOptions={pageSizeOptions}
        showTotal={showTotal ? (count) => `${count} items` : undefined}
        onChange={onChange}
      />
    </div>
  );
}

