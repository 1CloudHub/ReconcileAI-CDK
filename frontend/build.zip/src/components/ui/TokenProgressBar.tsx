import React, { useState, useEffect, useCallback } from 'react';
import { fetchShowTokens, TOKEN_USAGE_REFRESH_EVENT, type TokenUsageRefreshDetail } from '../../services/showTokens';

interface TokenProgressBarProps {
  isCollapsed?: boolean;
}

const TokenProgressBar: React.FC<TokenProgressBarProps> = ({ isCollapsed }) => {
  const [used, setUsed] = useState<number>(0);
  const [total, setTotal] = useState<number>(0);
  const [loading, setLoading] = useState(true);

  const loadTokens = useCallback(async () => {
    const result = await fetchShowTokens();
    if (result) {
      setUsed(result.used);
      setTotal(result.limit);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    void loadTokens();
  }, [loadTokens]);

  useEffect(() => {
    const onRefresh = (e: Event) => {
      const ce = e as CustomEvent<TokenUsageRefreshDetail | undefined>;
      const d = ce.detail;
      if (d && (d.totalTokensUsed !== undefined || d.availableTokens !== undefined)) {
        setUsed((u) => (d.totalTokensUsed !== undefined ? d.totalTokensUsed : u));
        setTotal((t) => (d.availableTokens !== undefined ? d.availableTokens : t));
        setLoading(false);
      } else {
        void loadTokens();
      }
    };

    window.addEventListener(TOKEN_USAGE_REFRESH_EVENT, onRefresh);
    return () => window.removeEventListener(TOKEN_USAGE_REFRESH_EVENT, onRefresh);
  }, [loadTokens]);

  const isUnlimited = total === -1;
  const percentage = isUnlimited ? 100 : Math.min(Math.round((used / total) * 100), 100);
  const available = isUnlimited ? 'Unlimited' : Math.max(total - used, 0);
  const availablePercentage = isUnlimited ? '∞' : Math.max(100 - percentage, 0);

  // Color logic
  let barColorClass = 'bg-[#1351cd]'; // Primary Blue
  if (!isUnlimited) {
    if (percentage >= 90) {
      barColorClass = 'bg-red-500'; // Red
    } else if (percentage >= 70) {
      barColorClass = 'bg-yellow-400'; // Yellow
    }
  } else {
    barColorClass = 'bg-gradient-to-r from-emerald-400 to-emerald-600'; // Unlimited fallback color
  }

  const [showTooltip, setShowTooltip] = useState(false);

  // Formatting large numbers
  const formatNumber = (num: number | string) => {
    if (typeof num === 'string') return num;
    return new Intl.NumberFormat('en-US').format(num);
  };

  const getCircularProgress = () => {
    const size = 36;
    const strokeWidth = 3.5;
    const center = size / 2;
    const radius = (size - strokeWidth) / 2;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (percentage / 100) * circumference;

    // Color mapping for text and stroke
    let strokeColor = '#1351cd';
    if (!isUnlimited) {
      if (percentage >= 90) strokeColor = '#ef4444'; // Red-500
      else if (percentage >= 70) strokeColor = '#facc15'; // Yellow-400
    } else {
      strokeColor = '#10b981'; // Emerald-500
    }

    if (isUnlimited) {
      return (
        <div className="flex items-center justify-center py-2">
          <span className="text-[28px] font-bold text-emerald-500 leading-none hover:scale-110 transition-transform">
            ∞
          </span>
        </div>
      );
    }

    return (
      <div className="flex flex-col items-center justify-center">
        <div className="relative" style={{ width: size, height: size }}>
          <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
            {/* Background Circle */}
            <circle
              cx={center}
              cy={center}
              r={radius}
              fill="transparent"
              stroke="#f3f4f6"
              strokeWidth={strokeWidth}
            />
            {/* Progress Circle */}
            <circle
              cx={center}
              cy={center}
              r={radius}
              fill="transparent"
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeDasharray={circumference}
              style={{
                strokeDashoffset: offset,
                transition: 'stroke-dashoffset 0.5s ease-in-out, stroke 0.3s ease',
              }}
              strokeLinecap="round"
              transform={`rotate(-90 ${center} ${center})`}
            />
          </svg>
          {/* Inner Content */}
          <div className="absolute inset-0 flex items-center justify-center">
            <span 
              className="text-[10px] font-bold tracking-tighter text-gray-700"
              style={{ color: strokeColor }}
            >
              {percentage}%
            </span>
          </div>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className={`mt-auto px-4 py-4 border-t border-gray-100 ${isCollapsed ? 'px-1' : 'px-4'}`}>
        <div className="flex flex-col gap-2 items-center">
          {!isCollapsed ? (
            <>
              <div className="flex justify-between w-full">
                <div className="h-3 w-16 bg-gray-200 rounded animate-pulse"></div>
                <div className="h-3 w-8 bg-gray-200 rounded animate-pulse"></div>
              </div>
              <div className="bg-gray-200 rounded-full h-2.5 w-full animate-pulse"></div>
            </>
          ) : (
            <div className="h-9 w-9 bg-gray-100 rounded-full animate-pulse flex items-center justify-center">
              <div className="h-6 w-6 bg-gray-200 rounded-full opacity-50"></div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div
      className={`mt-auto border-t border-gray-100 ${isCollapsed ? 'px-1 py-4' : 'px-4 py-4'}`}
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
    >
      <div className="relative group grayscale-[0.2] hover:grayscale-0 transition-all cursor-pointer">
        {/* Tooltip */}
        {showTooltip && (
          <div className={`absolute bottom-full mb-3 z-50 transition-all duration-200 ${isCollapsed ? 'left-12' : 'left-0 right-0'}`}>
            <div className="bg-gray-900 text-white text-[12px] p-3 rounded-xl shadow-xl border border-white/10 min-w-[170px]">
              <div className="flex justify-between mb-1 gap-4">
                <span className="text-gray-400">Used {isUnlimited ? '' : `(${percentage}%)`}</span>
                <span className="font-semibold">{formatNumber(used)}</span>
              </div>
              {!isUnlimited && (
                <div className="flex justify-between mb-1 gap-4">
                  <span className="text-gray-400">Available ({availablePercentage}%)</span>
                  <span className="font-semibold">{formatNumber(available as number)}</span>
                </div>
              )}
              <div className="flex justify-between pt-1 border-t border-white/10 mt-1 gap-4">
                <span className="text-gray-400 font-medium tracking-wide">User Limit</span>
                <span className={`font-bold ${isUnlimited ? 'text-emerald-400' : 'text-blue-400'}`}>
                  {isUnlimited ? 'Unlimited' : formatNumber(total)}
                </span>
              </div>
              {/* Arrow */}
              <div className={`absolute top-full border-8 border-transparent border-t-gray-900 ${isCollapsed ? '-left-2 top-1/2 -translate-y-1/2 border-t-transparent border-r-gray-900' : 'left-6'}`}></div>
            </div>
          </div>
        )}

        {!isCollapsed ? (
          <>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[12px] font-bold text-gray-500 uppercase tracking-wider">Token Usage</span>
              <span className={`text-[12px] font-bold ${isUnlimited ? 'text-emerald-500' : percentage >= 90 ? 'text-red-600' : percentage >= 70 ? 'text-yellow-600' : 'text-[#1351cd]'}`}>
                {isUnlimited ? '∞' : `${percentage}%`}
              </span>
            </div>

            <div className="h-2.5 w-full bg-gray-100 rounded-full overflow-hidden shadow-inner">
              <div 
                className={`h-full transition-all duration-700 ease-out rounded-full shadow-sm ${barColorClass}`}
                style={{ width: `${percentage}%` }}
              >
                {/* Glossy overlay */}
                <div className="w-full h-full bg-gradient-to-t from-black/10 to-transparent opacity-50"></div>
              </div>
            </div>
          </>
        ) : (
          getCircularProgress()
        )}
      </div>
    </div>
  );
};

export default TokenProgressBar;
