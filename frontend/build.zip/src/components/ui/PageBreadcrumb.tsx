import { Breadcrumb } from 'antd';
import type { ItemType } from 'antd/es/breadcrumb/Breadcrumb';
import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';

export type PageBreadcrumbItem = {
  key?: React.Key;
  /** Label shown for this segment */
  title: ReactNode;
  /** In-app route (uses react-router `Link`) */
  to?: string;
  /** External or static URL (native `<a>` via Ant Design) */
  href?: string;
};

export type PageBreadcrumbProps = {
  items: PageBreadcrumbItem[];
  /** Root wrapper classes */
  className?: string;
  /** Override default chevron between items */
  separator?: ReactNode;
  /** Classes for segments that act as links (non-last with `to` / `href`) */
  linkClassName?: string;
  /** Classes for the last segment (current page) */
  currentClassName?: string;
  'aria-label'?: string;
};

function joinClass(...parts: Array<string | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

const defaultLinkClass =
  'text-sm font-medium text-[#64748b] transition-colors hover:text-[#1351cd] no-underline';

const defaultCurrentClass = 'text-sm font-semibold text-slate-900';

const defaultSeparator = (
  <span
    className="text-slate-300"
    aria-hidden
    style={{ display: 'inline-flex', alignItems: 'center', verticalAlign: 'middle', lineHeight: 1 }}
  >
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" style={{ display: 'block' }}>
      <path
        d="M6 12L10 8L6 4"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  </span>
);

function toAntdItems(
  items: PageBreadcrumbItem[],
  linkClass: string,
  currentClass: string
): ItemType[] {
  return items.map((item, index) => {
    const isLast = index === items.length - 1;
    const key = item.key ?? index;

    if (isLast) {
      return {
        key,
        title: <span className={currentClass}>{item.title}</span>,
      };
    }

    if (item.to) {
      return {
        key,
        title: (
          <Link to={item.to} className={linkClass}>
            {item.title}
          </Link>
        ),
      };
    }

    if (item.href) {
      return {
        key,
        href: item.href,
        title: <span className={linkClass}>{item.title}</span>,
      };
    }

    return {
      key,
      title: <span className={linkClass}>{item.title}</span>,
    };
  });
}

/**
 * Ant Design `Breadcrumb` with app styling: muted links, dark current page, light chevron.
 * Pass `items` with `title` and optional `to` (SPA) or `href` (document navigation). The **last**
 * item is always treated as the current page (not linked).
 */
export default function PageBreadcrumb({
  items,
  className,
  separator = defaultSeparator,
  linkClassName,
  currentClassName,
  'aria-label': ariaLabel = 'Breadcrumb',
}: PageBreadcrumbProps) {
  const linkClass = joinClass(defaultLinkClass, linkClassName);
  const currentClass = joinClass(defaultCurrentClass, currentClassName);

  return (
    <Breadcrumb
      aria-label={ariaLabel}
      className={joinClass('page-breadcrumb', className)}
      style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', lineHeight: '1.5' }}
      separator={separator}
      items={toAntdItems(items, linkClass, currentClass)}
    />
  );
}
