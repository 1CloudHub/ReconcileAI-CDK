import type { ButtonHTMLAttributes, ReactNode } from 'react';

export type SecondaryButtonProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children'> & {
  icon?: ReactNode;
  text: ReactNode;
  badgeCount?: number;
};

function joinClass(...parts: Array<string | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

/**
 * Neutral outlined action button used for secondary actions.
 */
export default function SecondaryButton({
  icon,
  text,
  badgeCount,
  className,
  disabled,
  type = 'button',
  ...rest
}: SecondaryButtonProps) {
  return (
    <button
      type={type}
      disabled={disabled}
      className={joinClass(
        'relative inline-flex min-h-[44px] items-center justify-center gap-2 rounded-[10px]',
        'border border-[#c8d4e4] bg-white px-4 text-[15px] font-semibold text-slate-700',
        'transition-all duration-200',
        'hover:enabled:border-[#1351cd] hover:enabled:text-[#1351cd]',
        'disabled:opacity-60 disabled:cursor-not-allowed',
        'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1351cd]',
        className
      )}
      {...rest}
    >
      {typeof badgeCount === 'number' && badgeCount > 0 ? (
        <span className="absolute -top-1.5 -right-1.5 inline-flex h-5 w-5 items-center justify-center rounded-full bg-[#1351cd] text-[10px] leading-none font-semibold text-white shadow-[0_2px_8px_rgba(19,81,205,0.28)]">
          {badgeCount}
        </span>
      ) : null}
      {icon ? <span className="inline-flex shrink-0 items-center justify-center" aria-hidden>{icon}</span> : null}
      <span>{text}</span>
    </button>
  );
}
