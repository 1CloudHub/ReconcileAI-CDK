import { Table, Tooltip, type TableColumnType, type TableProps } from 'antd';
import { Eye, Trash2, type LucideIcon } from 'lucide-react';
import { useMemo, type Key, type MouseEvent as ReactMouseEvent, type ReactNode } from 'react';

const defaultTableStyles: NonNullable<TableProps<unknown>['styles']> = {
  header: {
    cell: {
      background: '#f8fafc',
      color: '#334155',
      fontWeight: 600,
      fontSize: 13,
      padding: '14px 20px',
      borderBottom: '1px solid #e2e8f0',
    },
  },
  body: {
    row: { background: '#ffffff' },
    cell: {
      padding: '14px 20px',
      fontSize: 14,
      color: '#1e293b',
      borderBottom: '1px solid #e8ecf1',
    },
  },
};

const defaultTableClassNames: NonNullable<TableProps<unknown>['classNames']> = {
  root: 'table-layout-root',
};

function joinClass(...parts: Array<string | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

function mergeTableStyles<RecordType>(
  user?: TableProps<RecordType>['styles']
): TableProps<RecordType>['styles'] {
  const b = defaultTableStyles;
  if (!user) return b as TableProps<RecordType>['styles'];
  return {
    ...b,
    ...user,
    header: {
      ...b.header,
      ...user.header,
      cell: { ...b.header?.cell, ...user.header?.cell },
      row: { ...b.header?.row, ...user.header?.row },
      wrapper: { ...b.header?.wrapper, ...user.header?.wrapper },
    },
    body: {
      ...b.body,
      ...user.body,
      cell: { ...b.body?.cell, ...user.body?.cell },
      row: { ...b.body?.row, ...user.body?.row },
      wrapper: { ...b.body?.wrapper, ...user.body?.wrapper },
    },
  } as TableProps<RecordType>['styles'];
}

function mergeTableClassNames<RecordType>(
  user?: TableProps<RecordType>['classNames']
): TableProps<RecordType>['classNames'] {
  const b = defaultTableClassNames;
  if (!user) return b as TableProps<RecordType>['classNames'];
  return {
    ...b,
    ...user,
    header: {
      ...b.header,
      ...user.header,
      cell: joinClass(b.header?.cell, user.header?.cell),
      row: joinClass(b.header?.row, user.header?.row),
      wrapper: joinClass(b.header?.wrapper, user.header?.wrapper),
    },
    body: {
      ...b.body,
      ...user.body,
      cell: joinClass(b.body?.cell, user.body?.cell),
      row: joinClass(b.body?.row, user.body?.row),
      wrapper: joinClass(b.body?.wrapper, user.body?.wrapper),
    },
  } as TableProps<RecordType>['classNames'];
}

export type TableLayoutProps<RecordType extends object = Record<string, unknown>> = Omit<
  TableProps<RecordType>,
  'classNames' | 'styles'
> & {
  classNames?: TableProps<RecordType>['classNames'];
  styles?: TableProps<RecordType>['styles'];
  /** Wrapped in a white rounded container (matches dashboard cards). */
  card?: boolean;
  /** Classes on the outer wrapper. */
  wrapperClassName?: string;
};

const defaultRowKey = <RecordType,>(record: RecordType, index?: number): Key => {
  const r = record as Record<string, unknown>;
  if (r && typeof r.id !== 'undefined') return String(r.id);
  if (r && typeof r.key !== 'undefined') return String(r.key);
  return String(index ?? 0);
};

/**
 * Opinionated Ant Design `Table` defaults: slate header row (#f8fafc), white body rows,
 * light row dividers, roomy padding. Pass standard `columns` and `dataSource`; override
 * any `Table` prop as needed.
 */
export default function TableLayout<RecordType extends object = Record<string, unknown>>({
  card = true,
  wrapperClassName,
  classNames: userClassNames,
  styles: userStyles,
  bordered = false,
  size = 'large',
  pagination = false,
  rowKey,
  ...rest
}: TableLayoutProps<RecordType>) {
  const classNames = useMemo(() => mergeTableClassNames(userClassNames), [userClassNames]);
  const styles = useMemo(() => mergeTableStyles(userStyles), [userStyles]);

  const resolvedRowKey = rowKey ?? defaultRowKey;

  const table = (
    <Table<RecordType>
      bordered={bordered}
      size={size}
      pagination={pagination}
      rowKey={resolvedRowKey}
      classNames={classNames}
      styles={styles}
      {...rest}
    />
  );

  const wrapClass = joinClass(
    card ? 'rounded-xl border border-slate-200/80 bg-white shadow-sm overflow-hidden' : undefined,
    wrapperClassName
  );

  if (!wrapClass) return table;

  return <div className={wrapClass}>{table}</div>;
}

/** Tailwind-friendly class for link-style primary keys / IDs in a column `render`. */
export const tableLayoutLinkClass =
  'text-[#1351cd] font-normal bg-transparent border-0 p-0 cursor-pointer hover:underline text-left text-sm';

export type LinkColumnRenderOptions = {
  onClick?: () => void;
  className?: string;
};

/** Use inside a column `render`: `render: (v) => tableLayoutLinkCell(v, { onClick: () => ... })` */
export function tableLayoutLinkCell(
  text: ReactNode,
  options?: LinkColumnRenderOptions
): ReactNode {
  if (options?.onClick) {
    return (
      <button type="button" className={joinClass(tableLayoutLinkClass, options.className)} onClick={options.onClick}>
        {text}
      </button>
    );
  }
  return <span className={joinClass('text-[#1351cd] font-normal text-sm', options?.className)}>{text}</span>;
}

export type ActionIconConfig<RecordType> = {
  icon?: LucideIcon;
  label: string;
  onClick: (record: RecordType) => void;
  hidden?: (record: RecordType) => boolean;
};

export type CreateActionsColumnOptions<RecordType> = {
  /** Shown as column title */
  title?: string;
  width?: number | string;
  fixed?: 'left' | 'right';
  /** Tooltip label for the view/edit button. Default: "View" */
  viewTooltip?: string;
  /** Optional custom icon for the view/edit button. Default: Eye */
  viewIcon?: LucideIcon;
  /** Tooltip label for the delete button. Default: "Delete" */
  deleteTooltip?: string;
  /** Default: view (eye) + delete (trash); omit handlers to hide that action. */
  onView?: (record: RecordType, event: ReactMouseEvent<HTMLButtonElement>) => void;
  onDelete?: (record: RecordType, event: ReactMouseEvent<HTMLButtonElement>) => void;
  /** Extra icon buttons after the defaults. */
  extra?: ActionIconConfig<RecordType>[];
};

const iconBtnClass =
  'inline-flex items-center justify-center rounded-md p-1.5 text-[#1351cd] hover:bg-[#1351cd]/10 transition-colors disabled:opacity-40 disabled:pointer-events-none';
const deleteIconBtnClass =
  'inline-flex items-center justify-center rounded-md p-1.5 text-rose-600 hover:bg-rose-50 hover:text-rose-600 transition-colors disabled:opacity-40 disabled:pointer-events-none';

/**
 * Builds a reusable Actions column (blue icons, matches app chrome).
 *
 * @example
 * columns={[
 *   { title: 'Name', dataIndex: 'name', key: 'name' },
 *   createActionsColumn({ onView: (r) => openRow(r), onDelete: (r) => removeRow(r) }),
 * ]}
 */
export function createActionsColumn<RecordType extends object>(
  options: CreateActionsColumnOptions<RecordType>
): TableColumnType<RecordType> {
  const {
    title = 'Actions',
    width = 128,
    fixed,
    viewTooltip = 'View',
    viewIcon,
    deleteTooltip = 'Delete',
    onView,
    onDelete,
    extra,
  } = options;

  return {
    title,
    key: '__actions',
    width,
    fixed,
    align: 'left',
    render: (_: unknown, record) => (
      <div className="flex flex-wrap items-center gap-0.5">
        {onView && (
          <Tooltip title={viewTooltip}>
            <button
              type="button"
              className={iconBtnClass}
              aria-label="View"
              onClick={(event) => onView(record, event)}
            >
              {(() => {
                const Icon = viewIcon ?? Eye;
                return <Icon size={18} strokeWidth={2} />;
              })()}
            </button>
          </Tooltip>
        )}
        {onDelete && (
          <Tooltip title={deleteTooltip}>
            <button
              type="button"
              className={deleteIconBtnClass}
              aria-label="Delete"
              onClick={(event) => onDelete(record, event)}
            >
              <Trash2 size={18} strokeWidth={2} />
            </button>
          </Tooltip>
        )}
        {extra?.map((cfg) => {
          if (cfg.hidden?.(record)) return null;
          const Icon = cfg.icon;
          return (
            <button
              key={cfg.label}
              type="button"
              className={iconBtnClass}
              aria-label={cfg.label}
              onClick={() => cfg.onClick(record)}
            >
              {Icon ? <Icon size={18} strokeWidth={2} /> : <span className="text-xs px-1">{cfg.label}</span>}
            </button>
          );
        })}
      </div>
    ),
  };
}

/** Primary accent used for links/actions in table cells (matches app shell). */
export const tableLayoutAccentColor = '#1351cd' as const;
