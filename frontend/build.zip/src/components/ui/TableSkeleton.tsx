import { Skeleton } from 'antd';

export type TableSkeletonProps = {
  /** Data rows to mimic under the header */
  rows?: number;
  /** Column placeholders per row */
  columns?: number;
  className?: string;
  /** Match TableLayout slate header strip */
  showHeader?: boolean;
};

/**
 * Ant Design skeleton placeholder for list/table pages (replaces table spinner).
 */
export default function TableSkeleton({
  rows = 8,
  columns = 5,
  className = '',
  showHeader = true,
}: TableSkeletonProps) {
  const colTemplate = `repeat(${columns}, minmax(0, 1fr))`;

  return (
    <div className={`min-w-0 overflow-hidden rounded-lg border border-slate-200/80 bg-white ${className}`}>
      {showHeader ? (
        <div
          className="grid gap-4 border-b border-slate-200 bg-[#f8fafc] px-5 py-4"
          style={{ gridTemplateColumns: colTemplate }}
        >
          {Array.from({ length: columns }).map((_, i) => (
            <Skeleton.Input key={`th-${i}`} active size="small" style={{ width: '72%', minWidth: 72, height: 16 }} />
          ))}
        </div>
      ) : null}
      <div className="px-5 py-1">
        {Array.from({ length: rows }).map((_, ri) => (
          <div
            key={`tr-${ri}`}
            className="grid gap-4 border-b border-slate-100 py-4 last:border-b-0"
            style={{ gridTemplateColumns: colTemplate }}
          >
            {Array.from({ length: columns }).map((_, ci) => (
              <Skeleton.Input
                key={`td-${ri}-${ci}`}
                active
                size="small"
                style={{ width: '100%', height: 20 }}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
