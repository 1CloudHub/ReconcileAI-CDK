// import { useState, useEffect, useCallback, useRef } from 'react';
// import { Link, useLocation } from 'react-router-dom';
// import { getCookie } from '../../utils/cookies';
// import {
//   getNavItemsByRole,
//   getInitialExpandedMenus,
//   isPathInSubmenu,
//   isSopEditorSectionPath,
//   type NavItem,
// } from '../../config/navItems';

// interface SideNavProps {
//   isCollapsed?: boolean;
//   onCollapsedChange?: (collapsed: boolean) => void;
// }

// export default function SideNav({ isCollapsed: controlledCollapsed, onCollapsedChange }: SideNavProps = {}) {
//   const location = useLocation();
//   const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

//   const [localCollapsed, setLocalCollapsed] = useState(() => {
//     return localStorage.getItem('sideNavCollapsed') === 'true';
//   });

//   const isCollapsed = controlledCollapsed !== undefined ? controlledCollapsed : localCollapsed;

//   const role = getCookie('userRole');
//   const navItems = getNavItemsByRole(role);

//   // const [expandedMenus, setExpandedMenus] = useState<string[]>(() =>
//   //   getInitialExpandedMenus(location.pathname, navItems)
//   // );
//   const [expandedMenus, setExpandedMenus] = useState<string[]>(() => {
//     const pathBasedMenus = getInitialExpandedMenus(location.pathname, navItems);
//     try {
//       const saved = localStorage.getItem('sideNavExpandedMenus');
//       if (saved) {
//         const parsed: string[] = JSON.parse(saved);
//         return Array.from(new Set([...pathBasedMenus, ...parsed]));
//       }
//     } catch {
//       // ignore
//     }
//     return pathBasedMenus;
//   });
//   const navRef = useRef<HTMLElement>(null);

//   const toggleCollapsed = useCallback(() => {
//     const newValue = !isCollapsed;
//     if (onCollapsedChange) {
//       onCollapsedChange(newValue);
//     } else {
//       setLocalCollapsed(newValue);
//       localStorage.setItem('sideNavCollapsed', String(newValue));
//     }
//   }, [isCollapsed, onCollapsedChange]);

//   // Listen for mobile menu toggle from TopNav
//   useEffect(() => {
//     const handleToggleMenu = () => {
//       setIsMobileMenuOpen((prev) => {
//         const next = !prev;
//         window.dispatchEvent(new CustomEvent('mobileMenuStateChange', { detail: { isOpen: next } }));
//         return next;
//       });
//     };
//     window.addEventListener('toggleMobileMenu', handleToggleMenu);
//     return () => window.removeEventListener('toggleMobileMenu', handleToggleMenu);
//   }, []);

//   useEffect(() => {
//     window.dispatchEvent(new CustomEvent('mobileMenuStateChange', { detail: { isOpen: isMobileMenuOpen } }));
//   }, [isMobileMenuOpen]);

//   // Expand submenu when route matches
//   // useEffect(() => {
//   //   navItems.forEach((item) => {
//   //     if (item.subItems && isPathInSubmenu(item.subItems, location.pathname)) {
//   //       setExpandedMenus((prev) => (prev.includes(item.label) ? prev : [...prev, item.label]));
//   //     }
//   //   });
//   // }, [location.pathname, navItems]);

//   useEffect(() => {
//     navItems.forEach((item) => {
//       if (item.subItems && isPathInSubmenu(item.subItems, location.pathname)) {
//         setExpandedMenus((prev) => {
//           if (prev.includes(item.label)) return prev;
//           const next = [...prev, item.label];
//           try {
//             localStorage.setItem('sideNavExpandedMenus', JSON.stringify(next));
//           } catch {
//             // ignore
//           }
//           return next;
//         });
//       }
//     });
//   }, [location.pathname, navItems]);

//   // const toggleMenu = useCallback((label: string) => {
//   //   setExpandedMenus((prev) =>
//   //     prev.includes(label) ? prev.filter((i) => i !== label) : [...prev, label]
//   //   );
//   // }, []);
//   const toggleMenu = useCallback((label: string) => {
//     setExpandedMenus((prev) => {
//       const next = prev.includes(label)
//         ? prev.filter((i) => i !== label)
//         : [...prev, label];
//       try {
//         localStorage.setItem('sideNavExpandedMenus', JSON.stringify(next));
//       } catch {
//         // ignore
//       }
//       return next;
//     });
//   }, []);
  
//   const isSubmenuActive = useCallback(
//     (subItems?: NavItem['subItems']) => subItems?.some((s) => location.pathname === s.path) ?? false,
//     [location.pathname]
//   );

//   const getIcon = (iconName: string) => {
//     switch (iconName) {
//       case 'dashboard':
//         return (
//           <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
//             <path d="M2.5 7.5L10 2.5L17.5 7.5V16.25C17.5 16.5815 17.3683 16.8995 17.1339 17.1339C16.8995 17.3683 16.5815 17.5 16.25 17.5H3.75C3.41848 17.5 3.10054 17.3683 2.86612 17.1339C2.6317 16.8995 2.5 16.5815 2.5 16.25V7.5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M7.5 17.5V10H12.5V17.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//           </svg>
//         );
//       case 'exceptions':
//         return (
//           <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
//             <path d="M10 17.5C14.1421 17.5 17.5 14.1421 17.5 10C17.5 5.85786 14.1421 2.5 10 2.5C5.85786 2.5 2.5 5.85786 2.5 10C2.5 14.1421 5.85786 17.5 10 17.5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M10 6.66667V10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M10 13.3333H10.0083" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//           </svg>
//         );
//       case 'drilldown':
//         return (
//           <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
//             <path d="M17.5 12.5V15.8333C17.5 16.2754 17.3244 16.6993 17.0118 17.0118C16.6993 17.3244 16.2754 17.5 15.8333 17.5H4.16667C3.72464 17.5 3.30072 17.3244 2.98816 17.0118C2.67559 16.6993 2.5 16.2754 2.5 15.8333V4.16667C2.5 3.72464 2.67559 3.30072 2.98816 2.98816C3.30072 2.67559 3.72464 2.5 4.16667 2.5H7.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M14.1667 2.5H17.5V5.83333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M8.33333 11.6667L17.5 2.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//           </svg>
//         );
//       case 'analytics':
//         return (
//           <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
//             <path d="M16.6667 2.5L10 9.16667L6.66667 5.83333L1.66667 10.8333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M12.5 2.5H16.6667V6.66667" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//           </svg>
//         );
//       case 'agents':
//         return (
//           <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
//             <path d="M17.5 2.5H2.5V13.3333H17.5V2.5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M6.66667 17.5H13.3333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M10 13.3333V17.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//           </svg>
//         );
//       case 'assistant':
//         return (
//           <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
//             <path d="M17.5 12.5C17.5 12.942 17.3244 13.366 17.0118 13.6785C16.6993 13.9911 16.2754 14.1667 15.8333 14.1667H5.83333L2.5 17.5V4.16667C2.5 3.72464 2.67559 3.30072 2.98816 2.98816C3.30072 2.67559 3.72464 2.5 4.16667 2.5H15.8333C16.2754 2.5 16.6993 2.67559 17.0118 2.98816C17.3244 3.30072 17.5 3.72464 17.5 4.16667V12.5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//           </svg>
//         );
//       case 'users':
//         return (
//           <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
//             <path d="M13.3333 5.83333C13.3333 7.67428 11.8409 9.16667 10 9.16667C8.15905 9.16667 6.66667 7.67428 6.66667 5.83333C6.66667 3.99238 8.15905 2.5 10 2.5C11.8409 2.5 13.3333 3.99238 13.3333 5.83333Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M10 11.6667C6.3181 11.6667 3.33333 12.8252 3.33333 14.1667V16.6667H16.6667V14.1667C16.6667 12.8252 13.6819 11.6667 10 11.6667Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//           </svg>
//         );
//       case 'operations':
//         return (
//           <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
//             <circle cx="10" cy="10" r="7.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M10 5V10L13 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//           </svg>
//         );
//       case 'alerts':
//         return (
//           <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
//             <path d="M15 8.33333C15 5.57191 12.7614 3.33333 10 3.33333C7.23858 3.33333 5 5.57191 5 8.33333C5 11.6667 3.33333 13.3333 3.33333 13.3333H16.6667C16.6667 13.3333 15 11.6667 15 8.33333Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M8.33333 17.5H11.6667" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//           </svg>
//         );
//       case 'document':
//         return (
//           <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
//             <path d="M11.6667 2.5H5.83333C5.39131 2.5 4.96738 2.67559 4.65482 2.98816C4.34226 3.30072 4.16667 3.72464 4.16667 4.16667V15.8333C4.16667 16.2754 4.34226 16.6993 4.65482 17.0118C4.96738 17.3244 5.39131 17.5 5.83333 17.5H14.1667C14.6087 17.5 15.0326 17.3244 15.3452 17.0118C15.6577 16.6993 15.8333 16.2754 15.8333 15.8333V7.5L11.6667 2.5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M11.6667 2.5V7.5H15.8333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M6.66667 11.6667H13.3333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M6.66667 14.1667H10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//           </svg>
//         );
//       case 'vendor':
//         return (
//           <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
//             <path d="M16.6667 17.5V15.8333C16.6667 14.9493 16.3155 14.1014 15.6903 13.4763C15.0652 12.8512 14.2174 12.5 13.3333 12.5H6.66667C5.78261 12.5 4.93477 12.8512 4.30964 13.4763C3.68452 14.1014 3.33333 14.9493 3.33333 15.8333V17.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M10 9.16667C11.8409 9.16667 13.3333 7.67428 13.3333 5.83333C13.3333 3.99238 11.8409 2.5 10 2.5C8.15905 2.5 6.66667 3.99238 6.66667 5.83333C6.66667 7.67428 8.15905 9.16667 10 9.16667Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//           </svg>
//         );
//       case 'chart':
//         return (
//           <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <rect width="7" height="9" x="3" y="3" rx="1"/>
//             <rect width="7" height="5" x="14" y="3" rx="1"/>
//             <rect width="7" height="9" x="14" y="12" rx="1"/>
//             <rect width="7" height="5" x="3" y="16" rx="1"/>
//           </svg>
//         );
//       case 'config':
//         return (
//           <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <path d="M12 20a8 8 0 1 0 0-16 8 8 0 0 0 0 16Z"/>
//             <path d="M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/>
//             <path d="M12 2v2"/>
//             <path d="M12 22v-2"/>
//             <path d="m17 20.66-1-1.73"/>
//             <path d="M11 10.27 7 3.34"/>
//             <path d="m20.66 17-1.73-1"/>
//             <path d="m3.34 7 1.73 1"/>
//             <path d="M14 12h8"/>
//             <path d="M2 12h2"/>
//             <path d="m20.66 7-1.73 1"/>
//             <path d="m3.34 17 1.73-1"/>
//             <path d="m17 3.34-1 1.73"/>
//             <path d="m11 13.73-4 6.93"/>
//           </svg>
//         );
//       case 'job':
//         return (
//           <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
//             <rect x="3" y="7" width="18" height="13" rx="2"/>
//             <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/>
//             <path d="M3 12h18"/>
//           </svg>
//         );
//       case 'monitor':
//         return (
//           <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
//             <rect x="2.5" y="3.33" width="15" height="10" rx="1.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M6.66667 16.6667H13.3333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             <path d="M10 13.3333V16.6667" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//           </svg>
//         );
//       case 'group':
//         return (
//           <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
//             <circle cx="6.66667" cy="6.66667" r="2.5" stroke="currentColor" strokeWidth="2"/>
//             <path d="M3.33333 13.3333C3.33333 11.4924 4.82572 10 6.66667 10C8.50762 10 10 11.4924 10 13.3333V15.8333H3.33333V13.3333Z" stroke="currentColor" strokeWidth="2"/>
//             <circle cx="13.3333" cy="6.66667" r="2.5" stroke="currentColor" strokeWidth="2"/>
//             <path d="M10 13.3333C10 11.4924 11.4924 10 13.3333 10C15.1743 10 16.6667 11.4924 16.6667 13.3333V15.8333H10V13.3333Z" stroke="currentColor" strokeWidth="2"/>
//           </svg>
//         );
//       default:
//         return null;
//     }
//   };

//   // ─── Derived helpers ────────────────────────────────────────────────────────
//   const showLabels = !isCollapsed || (typeof window !== 'undefined' && window.innerWidth <= 768 && isMobileMenuOpen);

//   return (
//     <>
//       {/* Mobile overlay */}
//       {isMobileMenuOpen && (
//         <div
//           className="fixed inset-0 bg-black/50 z-[999] md:hidden"
//           onClick={() => setIsMobileMenuOpen(false)}
//         />
//       )}

//       <aside
//         className={[
//           'bg-white border-r border-gray-200 flex flex-col',
//           isCollapsed ? 'overflow-visible' : 'overflow-y-auto overflow-x-hidden',
//           'scrollbar-none [scrollbar-width:none] [-ms-overflow-style:none]',
//           'transition-[width,transform] duration-300 ease-in-out',
//           // Desktop sizing
//           isCollapsed ? 'w-[68px]' : 'w-[240px]',
//           // Mobile: fixed drawer
//           'max-md:fixed max-md:top-0 max-md:left-0 max-md:h-screen max-md:w-[280px] max-md:max-w-[85vw] max-md:z-[1000] max-md:shadow-xl',
//           isMobileMenuOpen ? 'max-md:translate-x-0' : 'max-md:-translate-x-full',
//           // Desktop: sticky below topnav
//           'md:sticky md:top-16 md:h-[calc(100vh-64px)]',
//         ].join(' ')}
//       >
//         {/* ── Collapse Header ─────────────────────────────────────────────── */}
//         <div
//           className={[
//             'flex items-center gap-2 border-b border-gray-200 flex-shrink-0 min-h-[44px]',
//             isCollapsed ? 'justify-center px-2 py-3' : 'justify-between px-3 py-3',
//             'max-md:open:justify-between max-md:px-4 max-md:py-4 max-md:min-h-[56px]',
//           ].join(' ')}
//         >
//           {/* Logo + module name */}
//           {(!isCollapsed || isMobileMenuOpen) && (
//             <div className="flex items-center gap-2.5 flex-1 min-w-0">
//               <span className="font-bold text-[17px] text-gray-900 truncate tracking-wide leading-snug">
//                 ReconcileAI
//               </span>
//             </div>
//           )}

//           {/* Mobile close button */}
//           {isMobileMenuOpen && (
//             <button
//               className="md:hidden flex-shrink-0 w-9 h-9 rounded-lg bg-[#1351cd] text-white flex items-center justify-center hover:bg-[#0f45b0] transition-colors ml-auto"
//               onClick={() => setIsMobileMenuOpen(false)}
//               aria-label="Close sidebar"
//             >
//               <svg width="18" height="18" viewBox="0 0 20 20" fill="none">
//                 <path d="M15 5L5 15M5 5L15 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//               </svg>
//             </button>
//           )}

//           {/* Desktop collapse toggle */}
//           <button
//             className={[
//               'max-md:hidden flex-shrink-0 w-8 h-8 border border-gray-200 rounded-md bg-gray-100 text-[#1351cd]',
//               'flex items-center justify-center hover:bg-gray-200 hover:border-gray-300 transition-all duration-200 hover:scale-105',
//             ].join(' ')}
//             onClick={toggleCollapsed}
//             aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
//           >
//             <svg
//               width="16" height="16" viewBox="0 0 16 16" fill="none"
//               className={`transition-transform duration-300 ${isCollapsed ? 'rotate-180' : ''}`}
//             >
//               <path d="M10 12L6 8L10 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//             </svg>
//           </button>
//         </div>

//         {/* ── Nav Items ───────────────────────────────────────────────────── */}
//         <nav ref={navRef} className="flex-1 py-3 flex flex-col overflow-visible">
//           {navItems.map((item) => (
//             <div key={item.path ?? item.label}>
//               {item.subItems ? (
//                 <>
//                   {/* Parent with sub-items */}
//                   <div
//                     className={[
//                       'flex items-center gap-3 mx-3 my-0.5 py-3 rounded-lg cursor-pointer select-none',
//                       'text-sm font-medium transition-all duration-200',
//                       isCollapsed && !isMobileMenuOpen ? 'justify-center px-3' : 'px-6',
//                       isSubmenuActive(item.subItems)
//                         ? 'bg-[#1351cd] text-white'
//                         : 'text-gray-500 hover:bg-gray-100 hover:text-gray-900',
//                       // Tooltip when collapsed
//                       isCollapsed && !isMobileMenuOpen ? 'group/tip relative' : '',
//                     ].join(' ')}
//                     onClick={() => {
//                       if (!isCollapsed || isMobileMenuOpen) toggleMenu(item.label);
//                     }}
//                     data-tooltip={item.label}
//                   >
//                     <span className="flex items-center justify-center w-5 h-5 flex-shrink-0">
//                       {getIcon(item.icon)}
//                     </span>
//                     {showLabels && (
//                       <>
//                         <span className="flex-1">{item.label}</span>
//                         <span className={`flex items-center transition-transform duration-200 ${expandedMenus.includes(item.label) ? 'rotate-180' : ''}`}>
//                           <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
//                             <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//                           </svg>
//                         </span>
//                       </>
//                     )}
//                     {/* Collapsed tooltip */}
//                     {isCollapsed && !isMobileMenuOpen && (
//                       <span className="pointer-events-none absolute left-[calc(100%+12px)] top-1/2 -translate-y-1/2 bg-gray-800 text-white text-[13px] font-medium px-3 py-2 rounded-lg whitespace-nowrap opacity-0 invisible group-hover/tip:opacity-100 group-hover/tip:visible transition-all duration-200 z-[9999] shadow-lg">
//                         {item.label}
//                         <span className="absolute right-full top-1/2 -translate-y-1/2 border-[6px] border-transparent border-r-gray-800" />
//                       </span>
//                     )}
//                   </div>

//                   {/* Sub-items */}
//                   {showLabels && expandedMenus.includes(item.label) && (
//                     <div className="relative pl-6 flex flex-col before:absolute before:left-[22px] before:top-0 before:bottom-0 before:w-px before:bg-gray-200 before:opacity-60">
//                       {item.subItems.map((sub) => (
//                         <Link
//                           key={sub.path}
//                           to={sub.path}
//                           onClick={() => { if (window.innerWidth <= 768) setIsMobileMenuOpen(false); }}
//                           className={[
//                             'relative flex items-center gap-3 mr-3 my-0.5 pl-8 pr-4 py-1.5 rounded-lg',
//                             'text-[13px] font-medium transition-all duration-200 no-underline select-none',
//                             'before:absolute before:-left-3.5 before:top-1/2 before:-translate-y-1/2 before:w-3.5 before:h-px before:bg-gray-200 before:opacity-60',
//                             location.pathname === sub.path
//                               ? 'bg-[#1351cd] text-white before:bg-white/60'
//                               : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900',
//                           ].join(' ')}
//                         >
//                           <span className="flex items-center justify-center w-5 h-5 flex-shrink-0">
//                             {getIcon(sub.icon)}
//                           </span>
//                           <span className="flex-1">{sub.label}</span>
//                         </Link>
//                       ))}
//                     </div>
//                   )}
//                 </>
//               ) : (
//                 /* Regular nav item */
//                 <Link
//                   to={item.path!}
//                   onClick={() => { if (window.innerWidth <= 768) setIsMobileMenuOpen(false); }}
//                   className={[
//                     'flex items-center gap-3 mx-3 my-0.5 py-3 rounded-lg no-underline select-none',
//                     'text-sm font-medium transition-all duration-200',
//                     isCollapsed && !isMobileMenuOpen ? 'justify-center px-3 group/tip relative' : 'px-6',
//                     (item.path === '/reconcile-agent/records' && location.pathname.startsWith('/reconcile-agent')) ||
//                     (item.path === '/sop-control-center' && isSopEditorSectionPath(location.pathname)) ||
//                     location.pathname === item.path
//                       ? 'bg-[#1351cd] text-white'
//                       : 'text-gray-500 hover:bg-gray-100 hover:text-gray-900',
//                   ].join(' ')}
//                   data-tooltip={item.label}
//                 >
//                   <span className="flex items-center justify-center w-5 h-5 flex-shrink-0">
//                     {getIcon(item.icon)}
//                   </span>
//                   {showLabels && <span className="flex-1">{item.label}</span>}
//                   {/* Collapsed tooltip */}
//                   {isCollapsed && !isMobileMenuOpen && (
//                     <span className="pointer-events-none absolute left-[calc(100%+12px)] top-1/2 -translate-y-1/2 bg-gray-800 text-white text-[13px] font-medium px-3 py-2 rounded-lg whitespace-nowrap opacity-0 invisible group-hover/tip:opacity-100 group-hover/tip:visible transition-all duration-200 z-[9999] shadow-lg">
//                       {item.label}
//                       <span className="absolute right-full top-1/2 -translate-y-1/2 border-[6px] border-transparent border-r-gray-800" />
//                     </span>
//                   )}
//                 </Link>
//               )}
//             </div>
//           ))}
//         </nav>

//       </aside>
//     </>
//   );
// }
import { useState, useEffect, useCallback, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { getCookie } from '../../utils/cookies';
import {
  getNavItemsByRole,
  getInitialExpandedMenus,
  isPathInSubmenu,
  isSopEditorSectionPath,
  type NavItem,
} from '../../config/navItems';
import TokenProgressBar from '../ui/TokenProgressBar';

interface SideNavProps {
  isCollapsed?: boolean;
  onCollapsedChange?: (collapsed: boolean) => void;
}

export default function SideNav({ isCollapsed: controlledCollapsed, onCollapsedChange }: SideNavProps = {}) {
  const location = useLocation();
  const currentPath = location.pathname || window.location.pathname;

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [, forceUpdate] = useState(0);

  const [localCollapsed, setLocalCollapsed] = useState(() => {
    return localStorage.getItem('sideNavCollapsed') === 'true';
  });

  const isCollapsed = controlledCollapsed !== undefined ? controlledCollapsed : localCollapsed;

  const role = getCookie('userRole');
  const navItems = getNavItemsByRole(role);

  const [expandedMenus, setExpandedMenus] = useState<string[]>(() => {
    const pathBasedMenus = getInitialExpandedMenus(window.location.pathname, navItems);
    try {
      const saved = localStorage.getItem('sideNavExpandedMenus');
      if (saved) {
        const parsed: string[] = JSON.parse(saved);
        return Array.from(new Set([...pathBasedMenus, ...parsed]));
      }
    } catch {
      // ignore
    }
    return pathBasedMenus;
  });

  const navRef = useRef<HTMLElement>(null);

  // Force re-render after mount so window.location is fully synced with React Router
  useEffect(() => {
    forceUpdate(n => n + 1);
  }, []);

  const isActivePath = useCallback((path?: string) => {
    if (!path) return false;
    const current = window.location.pathname;
    return (
      current === path ||
      current === path + '/' ||
      path === current.replace(/\/$/, '')
    );
  }, []);

  const toggleCollapsed = useCallback(() => {
    const newValue = !isCollapsed;
    if (onCollapsedChange) {
      onCollapsedChange(newValue);
    } else {
      setLocalCollapsed(newValue);
      localStorage.setItem('sideNavCollapsed', String(newValue));
    }
  }, [isCollapsed, onCollapsedChange]);

  // Listen for mobile menu toggle from TopNav
  useEffect(() => {
    const handleToggleMenu = () => {
      setIsMobileMenuOpen((prev) => {
        const next = !prev;
        window.dispatchEvent(new CustomEvent('mobileMenuStateChange', { detail: { isOpen: next } }));
        return next;
      });
    };
    window.addEventListener('toggleMobileMenu', handleToggleMenu);
    return () => window.removeEventListener('toggleMobileMenu', handleToggleMenu);
  }, []);

  useEffect(() => {
    window.dispatchEvent(new CustomEvent('mobileMenuStateChange', { detail: { isOpen: isMobileMenuOpen } }));
  }, [isMobileMenuOpen]);

  // Expand submenu when route matches — also persists to localStorage
  useEffect(() => {
    navItems.forEach((item) => {
      if (item.subItems && isPathInSubmenu(item.subItems, window.location.pathname)) {
        setExpandedMenus((prev) => {
          if (prev.includes(item.label)) return prev;
          const next = [...prev, item.label];
          try {
            localStorage.setItem('sideNavExpandedMenus', JSON.stringify(next));
          } catch {
            // ignore
          }
          return next;
        });
      }
    });
  }, [currentPath, navItems]);

  const toggleMenu = useCallback((label: string) => {
    setExpandedMenus((prev) => {
      const next = prev.includes(label)
        ? prev.filter((i) => i !== label)
        : [...prev, label];
      try {
        localStorage.setItem('sideNavExpandedMenus', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  }, []);

  const isSubmenuActive = useCallback(
    (subItems?: NavItem['subItems']) => subItems?.some((s) => isActivePath(s.path)) ?? false,
    [isActivePath]
  );

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'dashboard':
        return (
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M2.5 7.5L10 2.5L17.5 7.5V16.25C17.5 16.5815 17.3683 16.8995 17.1339 17.1339C16.8995 17.3683 16.5815 17.5 16.25 17.5H3.75C3.41848 17.5 3.10054 17.3683 2.86612 17.1339C2.6317 16.8995 2.5 16.5815 2.5 16.25V7.5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M7.5 17.5V10H12.5V17.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        );
      case 'exceptions':
        return (
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M10 17.5C14.1421 17.5 17.5 14.1421 17.5 10C17.5 5.85786 14.1421 2.5 10 2.5C5.85786 2.5 2.5 5.85786 2.5 10C2.5 14.1421 5.85786 17.5 10 17.5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M10 6.66667V10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M10 13.3333H10.0083" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        );
      case 'drilldown':
        return (
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M17.5 12.5V15.8333C17.5 16.2754 17.3244 16.6993 17.0118 17.0118C16.6993 17.3244 16.2754 17.5 15.8333 17.5H4.16667C3.72464 17.5 3.30072 17.3244 2.98816 17.0118C2.67559 16.6993 2.5 16.2754 2.5 15.8333V4.16667C2.5 3.72464 2.67559 3.30072 2.98816 2.98816C3.30072 2.67559 3.72464 2.5 4.16667 2.5H7.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M14.1667 2.5H17.5V5.83333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M8.33333 11.6667L17.5 2.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        );
      case 'analytics':
        return (
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M16.6667 2.5L10 9.16667L6.66667 5.83333L1.66667 10.8333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M12.5 2.5H16.6667V6.66667" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        );
      case 'agents':
        return (
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M17.5 2.5H2.5V13.3333H17.5V2.5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M6.66667 17.5H13.3333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M10 13.3333V17.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        );
      case 'assistant':
        return (
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M17.5 12.5C17.5 12.942 17.3244 13.366 17.0118 13.6785C16.6993 13.9911 16.2754 14.1667 15.8333 14.1667H5.83333L2.5 17.5V4.16667C2.5 3.72464 2.67559 3.30072 2.98816 2.98816C3.30072 2.67559 3.72464 2.5 4.16667 2.5H15.8333C16.2754 2.5 16.6993 2.67559 17.0118 2.98816C17.3244 3.30072 17.5 3.72464 17.5 4.16667V12.5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        );
      case 'users':
        return (
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M13.3333 5.83333C13.3333 7.67428 11.8409 9.16667 10 9.16667C8.15905 9.16667 6.66667 7.67428 6.66667 5.83333C6.66667 3.99238 8.15905 2.5 10 2.5C11.8409 2.5 13.3333 3.99238 13.3333 5.83333Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M10 11.6667C6.3181 11.6667 3.33333 12.8252 3.33333 14.1667V16.6667H16.6667V14.1667C16.6667 12.8252 13.6819 11.6667 10 11.6667Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        );
      case 'operations':
        return (
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <circle cx="10" cy="10" r="7.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M10 5V10L13 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        );
      case 'alerts':
        return (
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M15 8.33333C15 5.57191 12.7614 3.33333 10 3.33333C7.23858 3.33333 5 5.57191 5 8.33333C5 11.6667 3.33333 13.3333 3.33333 13.3333H16.6667C16.6667 13.3333 15 11.6667 15 8.33333Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M8.33333 17.5H11.6667" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        );
      case 'document':
        return (
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M11.6667 2.5H5.83333C5.39131 2.5 4.96738 2.67559 4.65482 2.98816C4.34226 3.30072 4.16667 3.72464 4.16667 4.16667V15.8333C4.16667 16.2754 4.34226 16.6993 4.65482 17.0118C4.96738 17.3244 5.39131 17.5 5.83333 17.5H14.1667C14.6087 17.5 15.0326 17.3244 15.3452 17.0118C15.6577 16.6993 15.8333 16.2754 15.8333 15.8333V7.5L11.6667 2.5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M11.6667 2.5V7.5H15.8333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M6.66667 11.6667H13.3333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M6.66667 14.1667H10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        );
      case 'vendor':
        return (
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M16.6667 17.5V15.8333C16.6667 14.9493 16.3155 14.1014 15.6903 13.4763C15.0652 12.8512 14.2174 12.5 13.3333 12.5H6.66667C5.78261 12.5 4.93477 12.8512 4.30964 13.4763C3.68452 14.1014 3.33333 14.9493 3.33333 15.8333V17.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M10 9.16667C11.8409 9.16667 13.3333 7.67428 13.3333 5.83333C13.3333 3.99238 11.8409 2.5 10 2.5C8.15905 2.5 6.66667 3.99238 6.66667 5.83333C6.66667 7.67428 8.15905 9.16667 10 9.16667Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        );
      case 'chart':
        return (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect width="7" height="9" x="3" y="3" rx="1"/>
            <rect width="7" height="5" x="14" y="3" rx="1"/>
            <rect width="7" height="9" x="14" y="12" rx="1"/>
            <rect width="7" height="5" x="3" y="16" rx="1"/>
          </svg>
        );
      case 'config':
        return (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 20a8 8 0 1 0 0-16 8 8 0 0 0 0 16Z"/>
            <path d="M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/>
            <path d="M12 2v2"/>
            <path d="M12 22v-2"/>
            <path d="m17 20.66-1-1.73"/>
            <path d="M11 10.27 7 3.34"/>
            <path d="m20.66 17-1.73-1"/>
            <path d="m3.34 7 1.73 1"/>
            <path d="M14 12h8"/>
            <path d="M2 12h2"/>
            <path d="m20.66 7-1.73 1"/>
            <path d="m3.34 17 1.73-1"/>
            <path d="m17 3.34-1 1.73"/>
            <path d="m11 13.73-4 6.93"/>
          </svg>
        );
      case 'job':
        return (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="7" width="18" height="13" rx="2"/>
            <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/>
            <path d="M3 12h18"/>
          </svg>
        );
      case 'monitor':
        return (
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <rect x="2.5" y="3.33" width="15" height="10" rx="1.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M6.66667 16.6667H13.3333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M10 13.3333V16.6667" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        );
      case 'group':
        return (
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <circle cx="6.66667" cy="6.66667" r="2.5" stroke="currentColor" strokeWidth="2"/>
            <path d="M3.33333 13.3333C3.33333 11.4924 4.82572 10 6.66667 10C8.50762 10 10 11.4924 10 13.3333V15.8333H3.33333V13.3333Z" stroke="currentColor" strokeWidth="2"/>
            <circle cx="13.3333" cy="6.66667" r="2.5" stroke="currentColor" strokeWidth="2"/>
            <path d="M10 13.3333C10 11.4924 11.4924 10 13.3333 10C15.1743 10 16.6667 11.4924 16.6667 13.3333V15.8333H10V13.3333Z" stroke="currentColor" strokeWidth="2"/>
          </svg>
        );
      default:
        return null;
    }
  };

  const showLabels = !isCollapsed || (typeof window !== 'undefined' && window.innerWidth <= 768 && isMobileMenuOpen);

  return (
    <>
      {/* Mobile overlay */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-[999] md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      <aside
        className={[
          'bg-white border-r border-gray-200 flex flex-col',
          isCollapsed ? 'overflow-visible' : 'overflow-y-auto overflow-x-hidden',
          'scrollbar-none [scrollbar-width:none] [-ms-overflow-style:none]',
          'transition-[width,transform] duration-300 ease-in-out',
          isCollapsed ? 'w-[68px]' : 'w-[240px]',
          'max-md:fixed max-md:top-0 max-md:left-0 max-md:h-screen max-md:w-[280px] max-md:max-w-[85vw] max-md:z-[1000] max-md:shadow-xl',
          isMobileMenuOpen ? 'max-md:translate-x-0' : 'max-md:-translate-x-full',
          'md:sticky md:top-16 md:h-[calc(100vh-64px)]',
        ].join(' ')}
      >
        {/* ── Collapse Header ─────────────────────────────────────────────── */}
        <div
          className={[
            'flex items-center gap-2 border-b border-gray-200 flex-shrink-0 min-h-[44px]',
            isCollapsed ? 'justify-center px-2 py-3' : 'justify-between px-3 py-3',
            'max-md:open:justify-between max-md:px-4 max-md:py-4 max-md:min-h-[56px]',
          ].join(' ')}
        >
          {(!isCollapsed || isMobileMenuOpen) && (
            <div className="flex items-center gap-2.5 flex-1 min-w-0 ml-4">
              <span className="font-bold text-[17px] text-gray-900 truncate tracking-wide leading-snug">
                ReconcileAI
              </span>
            </div>
          )}

          {isMobileMenuOpen && (
            <button
              className="md:hidden flex-shrink-0 w-9 h-9 rounded-lg bg-[#1351cd] text-white flex items-center justify-center hover:bg-[#0f45b0] transition-colors ml-auto"
              onClick={() => setIsMobileMenuOpen(false)}
              aria-label="Close sidebar"
            >
              <svg width="18" height="18" viewBox="0 0 20 20" fill="none">
                <path d="M15 5L5 15M5 5L15 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          )}

          <button
            className={[
              'max-md:hidden flex-shrink-0 w-8 h-8 border border-gray-200 rounded-md bg-gray-100 text-[#1351cd]',
              'flex items-center justify-center hover:bg-gray-200 hover:border-gray-300 transition-all duration-200 hover:scale-105',
            ].join(' ')}
            onClick={toggleCollapsed}
            aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            <svg
              width="16" height="16" viewBox="0 0 16 16" fill="none"
              className={`transition-transform duration-300 ${isCollapsed ? 'rotate-180' : ''}`}
            >
              <path d="M10 12L6 8L10 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>

        {/* ── Nav Items ───────────────────────────────────────────────────── */}
        <nav ref={navRef} className="flex-1 py-3 flex flex-col overflow-visible">
          {navItems.map((item) => (
            <div key={item.path ?? item.label}>
              {item.subItems ? (
                <>
                  <div
                    className={[
                      'flex items-center gap-3 mx-3 my-0.5 py-3 rounded-lg cursor-pointer select-none',
                      'text-sm font-medium transition-all duration-200',
                      isCollapsed && !isMobileMenuOpen ? 'justify-center px-3' : 'px-6',
                      isSubmenuActive(item.subItems)
                        ? 'bg-[#1351cd] text-white'
                        : 'text-gray-500 hover:bg-gray-100 hover:text-gray-900',
                      isCollapsed && !isMobileMenuOpen ? 'group/tip relative' : '',
                    ].join(' ')}
                    onClick={() => {
                      if (!isCollapsed || isMobileMenuOpen) toggleMenu(item.label);
                    }}
                    data-tooltip={item.label}
                  >
                    <span className="flex items-center justify-center w-5 h-5 flex-shrink-0">
                      {getIcon(item.icon)}
                    </span>
                    {showLabels && (
                      <>
                        <span className="flex-1">{item.label}</span>
                        <span className={`flex items-center transition-transform duration-200 ${expandedMenus.includes(item.label) ? 'rotate-180' : ''}`}>
                          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                            <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                          </svg>
                        </span>
                      </>
                    )}
                    {isCollapsed && !isMobileMenuOpen && (
                      <span className="pointer-events-none absolute left-[calc(100%+12px)] top-1/2 -translate-y-1/2 bg-gray-800 text-white text-[13px] font-medium px-3 py-2 rounded-lg whitespace-nowrap opacity-0 invisible group-hover/tip:opacity-100 group-hover/tip:visible transition-all duration-200 z-[9999] shadow-lg">
                        {item.label}
                        <span className="absolute right-full top-1/2 -translate-y-1/2 border-[6px] border-transparent border-r-gray-800" />
                      </span>
                    )}
                  </div>

                  {showLabels && expandedMenus.includes(item.label) && (
                    <div className="relative pl-6 flex flex-col before:absolute before:left-[22px] before:top-0 before:bottom-0 before:w-px before:bg-gray-200 before:opacity-60">
                      {item.subItems.map((sub) => (
                        <Link
                          key={sub.path}
                          to={sub.path}
                          onClick={() => { if (window.innerWidth <= 768) setIsMobileMenuOpen(false); }}
                          className={[
                            'relative flex items-center gap-3 mr-3 my-0.5 pl-8 pr-4 py-1.5 rounded-lg',
                            'text-[13px] font-medium transition-all duration-200 no-underline select-none',
                            'before:absolute before:-left-3.5 before:top-1/2 before:-translate-y-1/2 before:w-3.5 before:h-px before:bg-gray-200 before:opacity-60',
                            isActivePath(sub.path)
                              ? 'bg-[#1351cd] text-white before:bg-white/60'
                              : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900',
                          ].join(' ')}
                        >
                          <span className="flex items-center justify-center w-5 h-5 flex-shrink-0">
                            {getIcon(sub.icon)}
                          </span>
                          <span className="flex-1">{sub.label}</span>
                        </Link>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <Link
                  to={item.path!}
                  onClick={() => { if (window.innerWidth <= 768) setIsMobileMenuOpen(false); }}
                  className={[
                    'flex items-center gap-3 mx-3 my-0.5 py-3 rounded-lg no-underline select-none',
                    'text-sm font-medium transition-all duration-200',
                    isCollapsed && !isMobileMenuOpen ? 'justify-center px-3 group/tip relative' : 'px-6',
                    (item.path === '/reconcile-agent/records' && window.location.pathname.startsWith('/reconcile-agent')) ||
                    (item.path === '/sop-control-center' && isSopEditorSectionPath(window.location.pathname)) ||
                    isActivePath(item.path)
                      ? 'bg-[#1351cd] text-white'
                      : 'text-gray-500 hover:bg-gray-100 hover:text-gray-900',
                  ].join(' ')}
                  data-tooltip={item.label}
                >
                  <span className="flex items-center justify-center w-5 h-5 flex-shrink-0">
                    {getIcon(item.icon)}
                  </span>
                  {showLabels && <span className="flex-1">{item.label}</span>}
                  {isCollapsed && !isMobileMenuOpen && (
                    <span className="pointer-events-none absolute left-[calc(100%+12px)] top-1/2 -translate-y-1/2 bg-gray-800 text-white text-[13px] font-medium px-3 py-2 rounded-lg whitespace-nowrap opacity-0 invisible group-hover/tip:opacity-100 group-hover/tip:visible transition-all duration-200 z-[9999] shadow-lg">
                      {item.label}
                      <span className="absolute right-full top-1/2 -translate-y-1/2 border-[6px] border-transparent border-r-gray-800" />
                    </span>
                  )}
                </Link>
              )}
            </div>
          ))}
        </nav>

        {/* Token Usage Section */}
        <TokenProgressBar isCollapsed={isCollapsed} />
      </aside>
    </>
  );
}