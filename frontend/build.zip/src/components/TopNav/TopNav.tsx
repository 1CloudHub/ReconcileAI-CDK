import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { User } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { deleteCookie, getCookie, generateRandomSessionId } from '../../utils/cookies';
import { API_URLS } from '../../config/api.config';
import { apiRequest } from '../../services/api';
import topNavLogo from '../../assets/Blue ReconcileAI logo.png';

function formatDisplayName(str: string): string {
  if (!str || str.length === 0) return str;
  return str
    .replace(/_/g, ' ')
    .split(/\s+/)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

function getDashboardTypeFromRoute(pathname: string): string | null {
  const map: Record<string, string> = {
    '/cfo-dashboard': 'cfo_dashboard',
    '/sales-dashboard': 'sales_dashboard',
    '/procurement-dashboard': 'procurement_dashboard',
    '/inventory-dashboard': 'inventory_dashboard',
    '/operations-dashboard': 'operations_dashboard',
    '/alerts-dashboard': 'alerts_dashboard',
  };
  return map[pathname] ?? null;
}

export default function TopNav() {
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuth();
  const userMenuRef = useRef<HTMLDivElement>(null);

  const currentRole = getCookie('role');
  const [displayRole, setDisplayRole] = useState<string>(() => getCookie('userRole') || '');
  const userloginEmail = getCookie('userlogin');
  const displayEmail = userloginEmail || user?.email || '';
  const rawName = user?.name || (displayEmail ? displayEmail.split('@')[0] : '') || 'User';
  const displayName = formatDisplayName(rawName);

  // ── Event listeners ────────────────────────────────────────────────────────
  useEffect(() => {
    const handler = () => setDisplayRole(getCookie('userRole') || '');
    window.addEventListener('userRoleChanged', handler);
    return () => window.removeEventListener('userRoleChanged', handler);
  }, []);

  useEffect(() => {
    const handler = (e: CustomEvent) => setIsMobileMenuOpen(e.detail.isOpen);
    window.addEventListener('mobileMenuStateChange', handler as EventListener);
    return () => window.removeEventListener('mobileMenuStateChange', handler as EventListener);
  }, []);

  useEffect(() => {
    if (!showUserMenu) return;
    const handler = (e: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setShowUserMenu(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [showUserMenu]);

  // ── Handlers ───────────────────────────────────────────────────────────────
  const handleMenuToggle = () => window.dispatchEvent(new CustomEvent('toggleMobileMenu'));

  const handleResetData = async () => {
    setIsResetting(true);
    try {
      const userid = getCookie('userid');
      const isBIOps = currentRole === 'BIOps' || displayRole === 'BIOps';

      if (isBIOps) {
        const dashType = getDashboardTypeFromRoute(location.pathname);
        if (dashType) {
          const sessionId = generateRandomSessionId();
          try {
            const text = await apiRequest<string>(API_URLS.MULTI_DASHBOARD, {
              method: 'POST',
              body: {
                dash_type: dashType,
                userid: userid || null,
                session_id: sessionId,
                meta_status: 1,
              },
              responseType: 'text',
            });
            window.dispatchEvent(new CustomEvent('dashboardDataReset', { detail: text ? JSON.parse(text) : null }));
          } catch (err) {
            console.error('Network error:', err);
          }
          setShowResetConfirm(false);
          setShowUserMenu(false);
          setIsResetting(false);
          return;
        }
      }

      await apiRequest(API_URLS.ERP, {
        method: 'POST',
        body: { event_type: 'reset_user_data', userid: userid || null },
      });
      setShowResetConfirm(false);
      setShowUserMenu(false);
      window.location.reload();
    } catch (err) {
      console.error('Error resetting data:', err);
      setShowResetConfirm(false);
      setShowUserMenu(false);
    } finally {
      setIsResetting(false);
    }
  };

  const handleLogout = () => {
    setShowUserMenu(false);
    logout();
    deleteCookie('userRole');
    deleteCookie('role');
    deleteCookie('userlogin');
    deleteCookie('userid');
    navigate('/login');
  };

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <>
      <nav className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 sticky top-0 z-[100] gap-4 max-md:px-4 max-[480px]:px-3 max-[480px]:min-h-14">

        {/* Left: hamburger + logo */}
        <div className="flex items-center gap-3 flex-1 max-md:gap-2">
          {/* Mobile hamburger */}
          <button
            className="hidden max-md:flex items-center justify-center bg-[#1351cd] hover:bg-[#0f45b0] border-none rounded-lg p-2.5 cursor-pointer shadow-[0_2px_8px_rgba(19,81,205,0.3)] transition-all duration-200 hover:scale-105 flex-shrink-0 max-[480px]:p-2"
            onClick={handleMenuToggle}
            aria-label="Toggle navigation menu"
          >
            <span className="flex flex-col w-5 h-4 justify-between max-[480px]:w-[18px] max-[480px]:h-3.5">
              <span className={`block h-0.5 w-full bg-white rounded-sm transition-all duration-300 origin-center ${isMobileMenuOpen ? 'rotate-45 translate-y-[7px]' : ''}`} />
              <span className={`block h-0.5 w-full bg-white rounded-sm transition-all duration-300 ${isMobileMenuOpen ? 'opacity-0' : ''}`} />
              <span className={`block h-0.5 w-full bg-white rounded-sm transition-all duration-300 origin-center ${isMobileMenuOpen ? '-rotate-45 -translate-y-[7px]' : ''}`} />
            </span>
          </button>

          {/* Logo */}
          <div className="flex items-center flex-shrink-0">
            <img
              src={topNavLogo}
              alt="ReconcileAI"
              className="h-10 w-auto max-w-[200px] object-contain max-md:h-9 max-md:max-w-[120px] max-[480px]:h-8 max-[480px]:max-w-[100px]"
            />
          </div>
        </div>

        {/* Right: Reset Data + user block */}
        <div className="flex items-center justify-end gap-6 flex-1 min-h-[36px] max-md:gap-3 max-[480px]:gap-2">

          {/* Reset Data button (commented out per request) */}
          {/*
          <button
            className="inline-flex items-center justify-center gap-1.5 px-4 min-h-[36px] bg-[#1351cd] hover:enabled:bg-[#0f45b0] text-white border-none rounded-md text-[13px] font-semibold cursor-pointer transition-all duration-200 hover:enabled:-translate-y-px disabled:opacity-60 disabled:cursor-not-allowed max-md:p-2 max-md:w-9 max-md:h-9 max-md:min-w-0 max-md:gap-0 max-[480px]:w-8 max-[480px]:h-8 max-[480px]:p-1.5"
            onClick={() => setShowResetConfirm(true)}
            disabled={isResetting}
            type="button"
          >
            {isResetting ? (
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" className="flex-shrink-0 animate-spin">
                <circle cx="8" cy="8" r="6" stroke="currentColor" strokeWidth="1.5" strokeDasharray="3 3" />
              </svg>
            ) : (
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" className="flex-shrink-0">
                <path d="M2.66667 8C2.66667 5.05448 5.05448 2.66667 8 2.66667C9.6 2.66667 11.0133 3.41333 11.8667 4.53333" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M2.66667 2.66667V5.33333H5.33333" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M13.3333 8C13.3333 10.9455 10.9455 13.3333 8 13.3333C6.4 13.3333 4.98667 12.5867 4.13333 11.4667" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M13.3333 13.3333V10.6667H10.6667" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            )}
            <span className="max-md:hidden">Reset Data</span>
          </button>
          */}

          {/* User block */}
          <div className="flex items-center gap-4 pl-6 border-l border-gray-200 h-9 box-border max-md:pl-4 max-md:gap-3 max-[480px]:pl-3 max-[480px]:gap-2 max-[480px]:h-8">
            {/* Avatar + chevron dropdown */}
            <div className="relative flex items-center gap-2" ref={userMenuRef}>
              <button
                className="flex items-center gap-2 px-2 py-1 border-none bg-transparent rounded-lg hover:bg-gray-100 transition-colors duration-200 cursor-pointer"
                onClick={() => setShowUserMenu((v) => !v)}
              >
                <div className="w-9 h-9 rounded-full bg-[#1351cd] text-white flex items-center justify-center font-semibold text-sm flex-shrink-0 max-[480px]:w-8 max-[480px]:h-8 max-[480px]:text-[13px]">
                  {(displayName || 'U').charAt(0).toUpperCase()}
                </div>
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" className="text-gray-500">
                  <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>

              {/* Dropdown */}
              {showUserMenu && (
                <div className="absolute top-[calc(100%+8px)] right-0 bg-white border border-gray-200 rounded-xl shadow-lg min-w-[200px] z-[1000] overflow-hidden">
                  {/* Email row */}
                  {displayEmail && (
                    <div className="flex items-center gap-2.5 px-4 py-3.5 bg-gradient-to-r from-gray-50 to-gray-100 border-b border-gray-200 text-[13px] font-semibold text-[#1351cd]">
                      <User size={16} className="flex-shrink-0 text-[#1351cd]" />
                      <span className="truncate">{displayEmail}</span>
                    </div>
                  )}

                  {/* Logout */}
                  <div
                    className="group flex items-center gap-3 px-4 py-3.5 cursor-pointer text-sm font-medium text-gray-800 hover:bg-gradient-to-r hover:from-gray-50 hover:to-gray-100 hover:text-[#1351cd] hover:font-semibold transition-all duration-200 active:scale-[0.98]"
                    onClick={handleLogout}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="flex-shrink-0 text-gray-400 group-hover:text-[#1351cd] transition-all duration-200" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                      <path d="M16 17l5-5-5-5"/>
                      <path d="M21 12H9"/>
                    </svg>
                    <span>Logout</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* ── Reset Confirmation Modal ─────────────────────────────────────── */}
      {showResetConfirm && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-[1001]"
          onClick={() => !isResetting && setShowResetConfirm(false)}
        >
          <div
            className="bg-white rounded-xl shadow-2xl w-[90%] max-w-[500px] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="px-6 py-5 border-b border-gray-200 bg-gray-50">
              <h3 className="m-0 text-lg font-semibold text-gray-900">Reset User Data</h3>
            </div>

            {/* Body */}
            <div className="px-6 py-6 text-gray-800 space-y-4 text-sm leading-relaxed">
              <p><strong>Warning:</strong> This operation will reset the system by deleting all user-generated data.</p>
              <p>Default system entries will not be affected.</p>
              <p className="font-semibold text-red-600 mt-5">Are you sure you want to proceed?</p>
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t border-gray-200 bg-gray-50 flex justify-end gap-3">
              <button
                className="px-5 py-2.5 rounded-lg text-sm font-medium bg-white text-gray-800 border border-gray-200 hover:enabled:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors cursor-pointer min-w-[100px]"
                onClick={() => setShowResetConfirm(false)}
                disabled={isResetting}
              >
                Cancel
              </button>
              <button
                className="px-5 py-2.5 rounded-lg text-sm font-medium bg-red-600 text-white hover:enabled:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors cursor-pointer min-w-[100px]"
                onClick={handleResetData}
                disabled={isResetting}
              >
                {isResetting ? 'Resetting...' : 'Reset Data'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
