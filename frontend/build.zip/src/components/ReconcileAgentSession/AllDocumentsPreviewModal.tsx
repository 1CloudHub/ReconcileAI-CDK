import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Download, X, ZoomIn, ZoomOut } from 'lucide-react';
import * as pdfjs from 'pdfjs-dist';
import { createPresignedDownloadUrlForS3Uri } from '../../services/reconcileSessions';

let workerConfigured = false;
function ensurePdfWorker(): void {
  if (workerConfigured || typeof window === 'undefined') return;
  pdfjs.GlobalWorkerOptions.workerSrc = new URL(
    'pdfjs-dist/build/pdf.worker.min.mjs',
    import.meta.url
  ).toString();
  workerConfigured = true;
}

interface DocRow {
  key: string;
  label: string;
  s3Uri?: string;
}

interface AllDocumentsPreviewModalProps {
  documentRows: DocRow[];
  onClose: () => void;
}

function usePresignedUrl(s3Uri?: string) {
  const [url, setUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!s3Uri) { setUrl(null); return; }
    setLoading(true);
    createPresignedDownloadUrlForS3Uri(s3Uri, 3600)
      .then(setUrl)
      .catch(() => setUrl(null))
      .finally(() => setLoading(false));
  }, [s3Uri]);

  return { url, loading };
}

interface SingleDocViewerProps {
  doc: DocRow;
  basePageWidth: number;
}

const SingleDocViewer: React.FC<SingleDocViewerProps> = ({ doc, basePageWidth }) => {
  const { url, loading } = usePresignedUrl(doc.s3Uri);
  const [numPages, setNumPages] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [scale, setScale] = useState(1);
  const [pdfLoading, setPdfLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  const handleDownload = useCallback(async () => {
    if (!doc.s3Uri || downloading) return;
    setDownloading(true);
    try {
      const downloadUrl = await createPresignedDownloadUrlForS3Uri(doc.s3Uri, 3600);
      window.open(downloadUrl, '_blank', 'noopener,noreferrer');
    } catch (e) {
      console.error('Download failed:', e);
    } finally {
      setDownloading(false);
    }
  }, [doc.s3Uri, downloading]);

  useEffect(() => {
    setPdfLoading(true);
    setCurrentPage(1);
    setNumPages(0);
    if (!url) return;

    ensurePdfWorker();
    const task = pdfjs.getDocument({ url });
    task.promise
      .then((pdf) => {
        setNumPages(pdf.numPages);
        setPdfLoading(false);
        return pdf.destroy();
      })
      .catch(() => {
        setPdfLoading(false);
      });
  }, [url]);

  const iframeSrc = useMemo(() => {
    if (!url) return '';
    const page = Math.max(1, currentPage);
    const zoom = Math.round(scale * 100);
    // Most browsers support PDF viewer fragments like #page=2&zoom=125
    return `${url}#page=${page}&zoom=${zoom}`;
  }, [url, currentPage, scale]);

  return (
    <div className="flex flex-col min-h-0 border border-gray-200 rounded-lg overflow-hidden bg-gray-50">
      {/* Toolbar */}
      <div className="px-3 py-2 border-b border-gray-200 bg-white flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-1">
          {numPages > 1 && (
            <>
              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage <= 1}
                className="p-1 rounded hover:bg-gray-100 disabled:opacity-40"
              >
                <ChevronLeft size={16} />
              </button>
              <span className="text-xs text-gray-600 min-w-[40px] text-center">
                {currentPage} / {numPages}
              </span>
              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.min(numPages, p + 1))}
                disabled={currentPage >= numPages}
                className="p-1 rounded hover:bg-gray-100 disabled:opacity-40"
              >
                <ChevronRight size={16} />
              </button>
            </>
          )}
        </div>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setScale((s) => Math.max(0.5, +(s - 0.25).toFixed(2)))}
            disabled={scale <= 0.5}
            className="p-1 rounded hover:bg-gray-100 disabled:opacity-40"
            title="Zoom out"
          >
            <ZoomOut size={16} />
          </button>
          <span className="text-xs text-gray-600 w-10 text-center">{Math.round(scale * 100)}%</span>
          <button
            type="button"
            onClick={() => setScale((s) => Math.min(3, +(s + 0.25).toFixed(2)))}
            disabled={scale >= 3}
            className="p-1 rounded hover:bg-gray-100 disabled:opacity-40"
            title="Zoom in"
          >
            <ZoomIn size={16} />
          </button>
          {doc.s3Uri && (
            <>
              <div className="w-px h-4 bg-gray-200 mx-0.5" />
              <button
                type="button"
                onClick={() => void handleDownload()}
                disabled={downloading}
                className="p-1 rounded hover:bg-gray-100 disabled:opacity-40 text-[#1351cd]"
                title="Download / open in new tab"
              >
                {downloading
                  ? <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-[#1351cd]/30 border-t-[#1351cd] inline-block" />
                  : <Download size={16} />}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 min-h-0 overflow-hidden bg-gray-100 relative">
        {(loading || pdfLoading) && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-50 z-10">
            <div className="flex items-center gap-1.5 mb-2">
              <span className="h-2.5 w-2.5 rounded-full bg-[#1351cd] animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="h-2.5 w-2.5 rounded-full bg-[#1351cd] animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="h-2.5 w-2.5 rounded-full bg-[#1351cd] animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
            <p className="text-xs text-gray-500">Loading document…</p>
          </div>
        )}

        {!loading && !url && (
          <div className="absolute inset-0 flex items-center justify-center">
            <p className="text-sm text-gray-400">No file available</p>
          </div>
        )}

        {url && (
          <div className="h-full w-full bg-white">
            <iframe
              ref={iframeRef}
              key={iframeSrc}
              src={iframeSrc}
              title={doc.label}
              className="h-full w-full"
              style={{ minWidth: basePageWidth }}
            />
          </div>
        )}
      </div>
    </div>
  );
};

const AllDocumentsPreviewModal: React.FC<AllDocumentsPreviewModalProps> = ({ documentRows, onClose }) => {
  const [basePageWidth, setBasePageWidth] = useState(260);

  useEffect(() => {
    const update = () => {
      const modalWidth = window.innerWidth * 0.92;
      const cols = documentRows.length || 1;
      const gutter = 16 * (cols + 1);
      setBasePageWidth(Math.max(180, (modalWidth - gutter) / cols - 24));
    };
    update();
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, [documentRows.length]);

  const docs = useMemo(
    () => documentRows.filter((d) => !!d.s3Uri),
    [documentRows]
  );

  const gridCols =
    docs.length === 1 ? 'grid-cols-1' :
    docs.length === 2 ? 'grid-cols-2' :
    docs.length === 3 ? 'grid-cols-3' :
    'grid-cols-4';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4 pt-16 pb-4"
      onClick={onClose}
    >
      <div
        className="relative flex flex-col bg-white rounded-xl shadow-2xl overflow-hidden"
        style={{ width: '92vw', height: '85vh' }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3 shrink-0">
          <h3 className="m-0 text-base font-semibold text-slate-900">All Documents</h3>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-8 w-8 items-center justify-center rounded-md text-slate-500 hover:bg-slate-100 transition-colors"
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>

        {/* Document labels row */}
        <div className={`grid ${gridCols} gap-4 px-4 pt-3 shrink-0`}>
          {docs.map((doc) => (
            <div key={doc.key} className="text-sm font-semibold text-slate-700 text-center truncate">
              {doc.label}
            </div>
          ))}
        </div>

        {/* Documents grid */}
        <div className={`flex-1 min-h-0 grid ${gridCols} gap-4 p-4`}>
          {docs.length === 0 ? (
            <div className="col-span-4 flex items-center justify-center text-sm text-gray-500">
              No documents available to preview.
            </div>
          ) : (
            docs.map((doc) => (
              <SingleDocViewer key={doc.key} doc={doc} basePageWidth={basePageWidth} />
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default AllDocumentsPreviewModal;
