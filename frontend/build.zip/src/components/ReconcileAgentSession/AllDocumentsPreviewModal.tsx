import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Download, X, ZoomIn, ZoomOut } from 'lucide-react';
import { Document, Page, pdfjs } from 'react-pdf';
import { createPresignedDownloadUrlForS3Uri } from '../../services/reconcileSessions';

pdfjs.GlobalWorkerOptions.workerSrc = new URL(
  'pdfjs-dist/build/pdf.worker.min.mjs',
  import.meta.url
).toString();

interface DocRow {
  key: string;
  label: string;
  s3Uri?: string;
}

interface AllDocumentsPreviewModalProps {
  documentRows: DocRow[];
  onClose: () => void;
}

function usePresignedUrl(s3Uri?: string) {
  const [url, setUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!s3Uri) { setUrl(null); return; }
    setLoading(true);
    createPresignedDownloadUrlForS3Uri(s3Uri, 3600)
      .then(setUrl)
      .catch(() => setUrl(null))
      .finally(() => setLoading(false));
  }, [s3Uri]);

  return { url, loading };
}

interface SingleDocViewerProps {
  doc: DocRow;
  basePageWidth: number;
}

const SingleDocViewer: React.FC<SingleDocViewerProps> = ({ doc, basePageWidth }) => {
  const { url, loading } = usePresignedUrl(doc.s3Uri);
  const [numPages, setNumPages] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [scale, setScale] = useState(1);
  const [pdfLoading, setPdfLoading] = useState(true);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [downloading, setDownloading] = useState(false);
  const dragRef = useRef<{ startX: number; startY: number } | null>(null);

  const handleDownload = useCallback(async () => {
    if (!doc.s3Uri || downloading) return;
    setDownloading(true);
    try {
      const downloadUrl = await createPresignedDownloadUrlForS3Uri(doc.s3Uri, 3600);
      window.open(downloadUrl, '_blank', 'noopener,noreferrer');
    } catch (e) {
      console.error('Download failed:', e);
    } finally {
      setDownloading(false);
    }
  }, [doc.s3Uri, downloading]);

  useEffect(() => { setPdfLoading(true); setCurrentPage(1); setNumPages(0); }, [url]);

  const handleMouseDown = (e: React.MouseEvent) => {
    dragRef.current = { startX: e.clientX, startY: e.clientY };
    const onMove = (ev: MouseEvent) => {
      if (!dragRef.current) return;
      setPos((p) => ({ x: p.x + ev.clientX - dragRef.current!.startX, y: p.y + ev.clientY - dragRef.current!.startY }));
      dragRef.current = { startX: ev.clientX, startY: ev.clientY };
    };
    const onUp = () => {
      dragRef.current = null;
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY < 0 ? 0.1 : -0.1;
    setScale((s) => Math.min(3, Math.max(0.5, +(s + delta).toFixed(2))));
  };

  return (
    <div className="flex flex-col min-h-0 border border-gray-200 rounded-lg overflow-hidden bg-gray-50">
      {/* Toolbar */}
      <div className="px-3 py-2 border-b border-gray-200 bg-white flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-1">
          {numPages > 1 && (
            <>
              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage <= 1}
                className="p-1 rounded hover:bg-gray-100 disabled:opacity-40"
              >
                <ChevronLeft size={16} />
              </button>
              <span className="text-xs text-gray-600 min-w-[40px] text-center">
                {currentPage} / {numPages}
              </span>
              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.min(numPages, p + 1))}
                disabled={currentPage >= numPages}
                className="p-1 rounded hover:bg-gray-100 disabled:opacity-40"
              >
                <ChevronRight size={16} />
              </button>
            </>
          )}
        </div>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setScale((s) => Math.max(0.5, +(s - 0.25).toFixed(2)))}
            disabled={scale <= 0.5}
            className="p-1 rounded hover:bg-gray-100 disabled:opacity-40"
            title="Zoom out"
          >
            <ZoomOut size={16} />
          </button>
          <span className="text-xs text-gray-600 w-10 text-center">{Math.round(scale * 100)}%</span>
          <button
            type="button"
            onClick={() => setScale((s) => Math.min(3, +(s + 0.25).toFixed(2)))}
            disabled={scale >= 3}
            className="p-1 rounded hover:bg-gray-100 disabled:opacity-40"
            title="Zoom in"
          >
            <ZoomIn size={16} />
          </button>
          {doc.s3Uri && (
            <>
              <div className="w-px h-4 bg-gray-200 mx-0.5" />
              <button
                type="button"
                onClick={() => void handleDownload()}
                disabled={downloading}
                className="p-1 rounded hover:bg-gray-100 disabled:opacity-40 text-[#1351cd]"
                title="Download / open in new tab"
              >
                {downloading
                  ? <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-[#1351cd]/30 border-t-[#1351cd] inline-block" />
                  : <Download size={16} />}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 min-h-0 overflow-hidden bg-gray-100 relative">
        {(loading || pdfLoading) && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-50 z-10">
            <div className="flex items-center gap-1.5 mb-2">
              <span className="h-2.5 w-2.5 rounded-full bg-[#1351cd] animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="h-2.5 w-2.5 rounded-full bg-[#1351cd] animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="h-2.5 w-2.5 rounded-full bg-[#1351cd] animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
            <p className="text-xs text-gray-500">Loading document…</p>
          </div>
        )}

        {!loading && !url && (
          <div className="absolute inset-0 flex items-center justify-center">
            <p className="text-sm text-gray-400">No file available</p>
          </div>
        )}

        {url && (
          <div
            className="flex items-center justify-center min-h-full p-2 overflow-hidden cursor-grab active:cursor-grabbing"
            onWheel={handleWheel}
            onMouseDown={handleMouseDown}
          >
            <Document
              file={url}
              onLoadSuccess={({ numPages: n }: { numPages: number }) => { setNumPages(n); setPdfLoading(false); }}
              onLoadError={() => setPdfLoading(false)}
              loading={null}
              error={
                <div className="flex flex-col items-center justify-center px-4 text-center">
                  <p className="text-xs font-medium text-red-600">Failed to load document</p>
                </div>
              }
            >
              <div
                style={{
                  transform: `translate(${pos.x}px, ${pos.y}px) scale(${scale})`,
                  transformOrigin: 'center',
                }}
              >
                <Page
                  pageNumber={currentPage}
                  width={basePageWidth}
                  renderTextLayer={false}
                  renderAnnotationLayer={false}
                />
              </div>
            </Document>
          </div>
        )}
      </div>
    </div>
  );
};

const AllDocumentsPreviewModal: React.FC<AllDocumentsPreviewModalProps> = ({ documentRows, onClose }) => {
  const [basePageWidth, setBasePageWidth] = useState(260);

  useEffect(() => {
    const update = () => {
      const modalWidth = window.innerWidth * 0.92;
      const cols = documentRows.length || 1;
      const gutter = 16 * (cols + 1);
      setBasePageWidth(Math.max(180, (modalWidth - gutter) / cols - 24));
    };
    update();
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, [documentRows.length]);

  const docs = useMemo(
    () => documentRows.filter((d) => !!d.s3Uri),
    [documentRows]
  );

  const gridCols =
    docs.length === 1 ? 'grid-cols-1' :
    docs.length === 2 ? 'grid-cols-2' :
    docs.length === 3 ? 'grid-cols-3' :
    'grid-cols-4';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4 pt-16 pb-4"
      onClick={onClose}
    >
      <div
        className="relative flex flex-col bg-white rounded-xl shadow-2xl overflow-hidden"
        style={{ width: '92vw', height: '85vh' }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3 shrink-0">
          <h3 className="m-0 text-base font-semibold text-slate-900">All Documents</h3>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-8 w-8 items-center justify-center rounded-md text-slate-500 hover:bg-slate-100 transition-colors"
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>

        {/* Document labels row */}
        <div className={`grid ${gridCols} gap-4 px-4 pt-3 shrink-0`}>
          {docs.map((doc) => (
            <div key={doc.key} className="text-sm font-semibold text-slate-700 text-center truncate">
              {doc.label}
            </div>
          ))}
        </div>

        {/* Documents grid */}
        <div className={`flex-1 min-h-0 grid ${gridCols} gap-4 p-4`}>
          {docs.length === 0 ? (
            <div className="col-span-4 flex items-center justify-center text-sm text-gray-500">
              No documents available to preview.
            </div>
          ) : (
            docs.map((doc) => (
              <SingleDocViewer key={doc.key} doc={doc} basePageWidth={basePageWidth} />
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default AllDocumentsPreviewModal;
