import { useEffect, useState, useCallback } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import { Check, Copy, ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Download } from 'lucide-react';
import { createPresignedDownloadUrlForS3Uri } from '../../services/reconcileSessions';

import 'react-pdf/dist/Page/AnnotationLayer.css';
import 'react-pdf/dist/Page/TextLayer.css';

pdfjs.GlobalWorkerOptions.workerSrc = new URL(
  'pdfjs-dist/build/pdf.worker.min.mjs',
  import.meta.url
).toString();

interface ExtractedField {
  name: string;
  value: string;
}

interface DocumentViewerProps {
  s3Uri?: string;
  extractedFields: ExtractedField[];
  docLabel: string;
}

function isPdf(uri: string) {
  return uri.toLowerCase().split('?')[0].endsWith('.pdf');
}

function isImage(uri: string) {
  return /\.(png|jpe?g|gif|webp|bmp|svg)(\?|$)/i.test(uri);
}

export default function DocumentViewer({ s3Uri, extractedFields, docLabel }: DocumentViewerProps) {
  const [presignedUrl, setPresignedUrl] = useState<string | null>(null);
  const [loadingUrl, setLoadingUrl] = useState(false);
  const [urlError, setUrlError] = useState<string | null>(null);
  const [numPages, setNumPages] = useState<number>(0);
  const [pageNumber, setPageNumber] = useState(1);
  const [copied, setCopied] = useState(false);
  const [scale, setScale] = useState(1.5);
  const [pdfLoading, setPdfLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    if (!s3Uri) {
      setPresignedUrl(null);
      return;
    }
    setLoadingUrl(true);
    setUrlError(null);
    setPresignedUrl(null);
    setPageNumber(1);
    setNumPages(0);
    setPdfLoading(true);

    createPresignedDownloadUrlForS3Uri(s3Uri, 3600)
      .then((url) => setPresignedUrl(url))
      .catch((e) => setUrlError(e instanceof Error ? e.message : 'Failed to load document'))
      .finally(() => setLoadingUrl(false));
  }, [s3Uri]);

  const handleDownload = useCallback(async () => {
    if (!s3Uri || downloading) return;
    setDownloading(true);
    try {
      const downloadUrl = await createPresignedDownloadUrlForS3Uri(s3Uri, 3600);
      const filename = s3Uri.split('/').pop() ?? 'document.pdf';
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (e) {
      console.error('Download failed:', e);
    } finally {
      setDownloading(false);
    }
  }, [s3Uri, downloading]);

  const handleCopy = useCallback(() => {
    const json = JSON.stringify(
      Object.fromEntries(extractedFields.map((f) => [f.name, f.value])),
      null,
      2
    );
    void navigator.clipboard.writeText(json).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, [extractedFields]);

  const fileType = presignedUrl
    ? isPdf(presignedUrl)
      ? 'pdf'
      : isImage(presignedUrl)
        ? 'image'
        : 'other'
    : null;

  return (
    <div className="flex gap-4 h-full w-full min-h-[480px]">
      {/* Left: Document Viewer */}
      <div className="w-1/2 min-w-0 border border-gray-200 rounded-lg overflow-hidden shadow-sm bg-gray-50 flex flex-col">
        {loadingUrl ? (
          <div className="flex flex-col items-center justify-center h-full">
            <div className="flex items-center gap-1.5 mb-2">
              <span className="h-2.5 w-2.5 rounded-full bg-[#1351cd] animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="h-2.5 w-2.5 rounded-full bg-[#1351cd] animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="h-2.5 w-2.5 rounded-full bg-[#1351cd] animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
            <p className="text-sm text-gray-500">Loading document…</p>
          </div>
        ) : urlError ? (
          <div className="flex items-center justify-center h-full">
            <p className="text-sm text-rose-500 text-center px-4">{urlError}</p>
          </div>
        ) : !presignedUrl ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <p className="text-gray-400 text-sm">No file linked for {docLabel}</p>
            </div>
          </div>
        ) : fileType === 'pdf' ? (
          <div className="flex flex-col h-full">
            {/* PDF controls */}
            <div className="flex items-center justify-between bg-white border-b border-gray-200 px-3 py-1.5 shrink-0">
              <div className="flex items-center gap-3">
                {numPages > 1 && (
                  <>
                    <button
                      type="button"
                      onClick={() => setPageNumber((p) => Math.max(1, p - 1))}
                      disabled={pageNumber <= 1}
                      className="p-1 rounded hover:bg-gray-100 disabled:opacity-40"
                    >
                      <ChevronLeft size={16} />
                    </button>
                    <span className="text-xs text-gray-600">
                      {pageNumber} / {numPages}
                    </span>
                    <button
                      type="button"
                      onClick={() => setPageNumber((p) => Math.min(numPages, p + 1))}
                      disabled={pageNumber >= numPages}
                      className="p-1 rounded hover:bg-gray-100 disabled:opacity-40"
                    >
                      <ChevronRight size={16} />
                    </button>
                  </>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setScale((s) => Math.max(0.5, +(s - 0.25).toFixed(2)))}
                  disabled={scale <= 0.5}
                  className="p-1 rounded hover:bg-gray-100 disabled:opacity-40"
                  title="Zoom out"
                >
                  <ZoomOut size={16} />
                </button>
                <span className="text-xs text-gray-600 w-10 text-center">{Math.round(scale * 100)}%</span>
                <button
                  type="button"
                  onClick={() => setScale((s) => Math.min(3, +(s + 0.25).toFixed(2)))}
                  disabled={scale >= 3}
                  className="p-1 rounded hover:bg-gray-100 disabled:opacity-40"
                  title="Zoom in"
                >
                  <ZoomIn size={16} />
                </button>
                <div className="w-px h-4 bg-gray-200 mx-1" />
                <button
                  type="button"
                  onClick={() => void handleDownload()}
                  disabled={downloading}
                  className="p-1 rounded hover:bg-gray-100 disabled:opacity-40 text-[#1351cd]"
                  title="Download file"
                >
                  {downloading
                    ? <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-[#1351cd]/30 border-t-[#1351cd] inline-block" />
                    : <Download size={16} />}
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-auto flex justify-center p-2 relative">
              {pdfLoading && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-50 z-10">
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className="h-2.5 w-2.5 rounded-full bg-[#1351cd] animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="h-2.5 w-2.5 rounded-full bg-[#1351cd] animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="h-2.5 w-2.5 rounded-full bg-[#1351cd] animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                  <p className="text-sm text-gray-500">Loading document…</p>
                </div>
              )}
              <Document
                file={presignedUrl}
                onLoadSuccess={({ numPages: n }: { numPages: number }) => { setNumPages(n); setPdfLoading(false); }}
                onLoadError={() => setPdfLoading(false)}
                loading={null}
              >
                <Page
                  pageNumber={pageNumber}
                  width={380 * scale}
                  renderTextLayer
                  renderAnnotationLayer
                />
              </Document>
            </div>
          </div>
        ) : fileType === 'image' ? (
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-end bg-white border-b border-gray-200 px-3 py-1.5 shrink-0">
              <button
                type="button"
                onClick={() => void handleDownload()}
                disabled={downloading}
                className="p-1 rounded hover:bg-gray-100 disabled:opacity-40 text-[#1351cd]"
                title="Download file"
              >
                {downloading
                  ? <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-[#1351cd]/30 border-t-[#1351cd] inline-block" />
                  : <Download size={16} />}
              </button>
            </div>
            <div className="flex items-center justify-center flex-1 w-full p-4 overflow-auto">
              <img src={presignedUrl} alt={docLabel} className="max-w-full max-h-full object-contain" />
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="text-center space-y-2">
              <p className="text-gray-500 text-sm mb-1">Preview not available</p>
              <button
                type="button"
                onClick={() => void handleDownload()}
                disabled={downloading}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-[#1351cd] text-[#1351cd] text-xs font-medium hover:bg-[#eef4ff] transition-colors"
              >
                <Download size={14} />
                {downloading ? 'Downloading…' : 'Download file'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Right: Extracted Fields */}
      <div className="w-1/2 min-w-0 border border-gray-200 rounded-lg overflow-hidden shadow-sm flex flex-col bg-white">
        {/* Header */}
        <div className="bg-gradient-to-r from-gray-50 to-gray-100 px-4 py-3 border-b border-gray-200 shrink-0">
          <div className="flex items-center justify-between gap-2">
            <h3 className="font-semibold text-gray-800 text-sm">Extracted Fields</h3>
            <button
              type="button"
              onClick={handleCopy}
              title={copied ? 'Copied!' : 'Copy JSON'}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md border border-gray-300 bg-white text-xs font-medium text-gray-700 hover:bg-gray-50 hover:border-gray-400 transition-colors shrink-0"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-green-600" />
                  <span className="text-green-600">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 min-h-0 overflow-y-auto p-4">
          {extractedFields.length === 0 ? (
            <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-500">
              No extracted fields for this document.
            </div>
          ) : (
            <div
              className="bg-gray-50 px-3 py-3 rounded-lg text-black whitespace-pre-wrap break-words border border-gray-200 text-left"
              style={{ fontSize: '13px', lineHeight: '1.6' }}
            >
              <div>{'{'}</div>
              {extractedFields.map((field, index) => (
                <div key={field.name} className="ml-3 my-1 text-left">
                  <span className="font-semibold text-blue-600">"{field.name}"</span>
                  <span className="text-gray-700">: </span>
                  <span className="text-gray-900">{JSON.stringify(field.value)}</span>
                  {index < extractedFields.length - 1 && (
                    <span className="text-gray-500">,</span>
                  )}
                </div>
              ))}
              <div>{'}'}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
