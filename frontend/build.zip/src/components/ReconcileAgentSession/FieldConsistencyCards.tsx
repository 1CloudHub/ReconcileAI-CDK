import { AlertTriangle, CheckCircle2, XCircle } from 'lucide-react';
import type { SopSectionCard, ConsistencyRow } from './ReconcileSessionDetail';
import { buildConsistencyRowsFromMatching } from './ReconcileSessionDetail';

type FieldConsistencyCardsProps = {
  sopCards: SopSectionCard[];
  showReferenceColumn?: boolean;
  reconcileStatus?: string;
};

export default function FieldConsistencyCards({ sopCards, showReferenceColumn, reconcileStatus }: FieldConsistencyCardsProps) {
  return (
    <>
      {sopCards.map((card, cardIdx) => {
        const consistencyRows: ConsistencyRow[] = buildConsistencyRowsFromMatching(card.matching);
        const isValidationError = /^Validation Error\s*\d*$/i.test(card.sopName.trim()) || reconcileStatus === 'failed' || reconcileStatus === 'validation failed';
        return (
          <article
            key={`${card.sopName}-${cardIdx}`}
            className="rounded-lg border border-slate-200 bg-white p-3 shadow-[0_1px_2px_rgba(15,23,42,0.04)] sm:p-4"
          >
            {!isValidationError && (
            <dl className="m-0 space-y-2 border-b border-slate-100 pb-3">
              <div className="grid grid-cols-1 gap-0.5 sm:grid-cols-[minmax(0,140px)_minmax(0,1fr)] sm:gap-x-4">
                <dt className="text-sm font-medium text-slate-500">SOP Name</dt>
                <dd className="m-0 text-sm font-semibold text-slate-900">{card.sopName}</dd>
              </div>
              <div className="grid grid-cols-1 gap-0.5 sm:grid-cols-[minmax(0,140px)_minmax(0,1fr)] sm:gap-x-4">
                <dt className="text-sm font-medium text-slate-500">Description</dt>
                <dd className="m-0 min-w-0 whitespace-pre-wrap text-sm leading-snug text-slate-700">
                  {card.description}
                </dd>
              </div>
              <div className="grid grid-cols-1 gap-0.5 sm:grid-cols-[minmax(0,140px)_minmax(0,1fr)] sm:items-center sm:gap-x-4">
                <dt className="text-sm font-medium text-slate-500">SOP Status</dt>
                <dd className="m-0 flex flex-wrap items-center gap-2">
                  {card.status === 'matched' ? (
                    <span className="inline-flex rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-0.5 text-xs font-semibold text-emerald-800">
                      Matched
                    </span>
                  ) : card.status === 'not_matched' ? (
                    <span className="inline-flex rounded-full border border-rose-200 bg-rose-50 px-2.5 py-0.5 text-xs font-semibold text-rose-900">
                      Not Matched
                    </span>
                  ) : (
                    <span className="inline-flex rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-xs font-semibold text-slate-600">
                      —
                    </span>
                  )}
                </dd>
              </div>
            </dl>
            )}

            <div className={isValidationError ? '' : 'pt-3'}>
              {isValidationError ? (
                <div className="flex items-start gap-2.5">
                  <AlertTriangle size={16} className="mt-0.5 shrink-0 text-amber-500" strokeWidth={2} aria-hidden />
                  <p className="m-0 text-sm leading-snug text-amber-800">{card.description}</p>
                </div>
              ) : consistencyRows.length === 0 ? (
                <p className="m-0 rounded-md bg-slate-50 px-2.5 py-2 text-sm text-slate-500">
                  No row-level matching fields for this SOP.
                </p>
              ) : (
                <div className="overflow-x-auto rounded-md border border-slate-200 bg-white">
                  <table className="w-full min-w-[560px] border-collapse text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 bg-[#f8fafc]">
                        <th className="px-2.5 py-2 text-left text-xs font-semibold text-slate-700">Field</th>
                        <th className="px-2.5 py-2 text-left text-xs font-semibold text-slate-700">Purchase Order</th>
                        <th className="px-2.5 py-2 text-left text-xs font-semibold text-slate-700">Invoice</th>
                        <th className="px-2.5 py-2 text-left text-xs font-semibold text-slate-700">Goods Receipt</th>
                        {showReferenceColumn && (
                          <th className="px-2.5 py-2 text-left text-xs font-semibold text-slate-700">
                            Reference Document
                          </th>
                        )}
                        <th className="w-12 px-1.5 py-2 text-center text-xs font-semibold text-slate-700">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {consistencyRows.map((row, idx) => (
                        <tr
                          key={`${row.field}-${idx}`}
                          className="border-b border-slate-100 align-middle last:border-b-0"
                        >
                          <td className="px-2.5 py-2 text-xs font-semibold text-slate-900 sm:text-sm">{row.field}</td>
                          <td className="px-2.5 py-2 tabular-nums text-xs text-slate-700 sm:text-sm">
                            {row.purchaseOrder}
                          </td>
                          <td className="px-2.5 py-2 tabular-nums text-xs text-slate-700 sm:text-sm">
                            {row.supplierInvoice}
                          </td>
                          <td className="px-2.5 py-2 tabular-nums text-xs text-slate-700 sm:text-sm">
                            {row.goodsReceipt}
                          </td>
                          {showReferenceColumn && (
                            <td className="px-2.5 py-2 text-xs text-slate-700 sm:text-sm">
                              Reference document details
                            </td>
                          )}
                          <td className="px-1.5 py-2 text-center">
                            {row.status === 'matched' ? (
                              <CheckCircle2
                                size={16}
                                className="inline text-emerald-500"
                                strokeWidth={2}
                                aria-label="Matched"
                              />
                            ) : (
                              <XCircle
                                size={16}
                                className="inline text-rose-500"
                                strokeWidth={2}
                                aria-label="Not matched"
                              />
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </article>
        );
      })}
    </>
  );
}

