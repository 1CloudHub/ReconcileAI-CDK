import { CheckCircle2, Eye, LayoutGrid, RefreshCw, X, XCircle } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import type { ReconcileRecord, ReconcileRowStatus } from '../ReconcileAgent/RecordsTable';
import PageBreadcrumb from '../ui/PageBreadcrumb';
import DocumentViewer from './DocumentViewer';
import AllDocumentsPreviewModal from './AllDocumentsPreviewModal';
import FieldConsistencyCards from './FieldConsistencyCards';
import { getSessionDocuments } from '../../services/reconcileSessions';

export type ReconcileSessionDetailState = {
  record: ReconcileRecord;
};

function formatDocTypeKey(key: string): string {
  return key
    .replace(/_/g, ' ')
    .split(' ')
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

export type SopSectionCard = {
  sopName: string;
  description: string;
  status: 'matched' | 'not_matched' | 'unknown';
  matching?: Record<string, unknown>;
};

export type ConsistencyRow = {
  field: string;
  matchedValue: string;
  purchaseOrder: string;
  goodsReceipt: string;
  supplierInvoice: string;
  deliveryReceipt: string;
  status: 'matched' | 'not_matched';
};

function reconcileStatusTagClasses(status: ReconcileRowStatus): { label: string; className: string } {
  switch (status) {
    case 'matched':
      return {
        label: 'Matched',
        className:
          'inline-flex rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-0.5 text-xs font-semibold text-emerald-800',
      };
    case 'failed':
      return {
        label: 'Failed',
        className:
          'inline-flex rounded-full border border-rose-200 bg-rose-50 px-2.5 py-0.5 text-xs font-semibold text-rose-800',
      };
    case 'not_matched':
      return {
        label: 'Not Matched',
        className:
          'inline-flex rounded-full border border-rose-200 bg-rose-50 px-2.5 py-0.5 text-xs font-semibold text-rose-800',
      };
    case 'validation failed':
      return {
        label: 'Validation Failed',
        className:
          'inline-flex rounded-full border border-orange-200 bg-orange-50 px-2.5 py-0.5 text-xs font-semibold text-orange-700',
      };
    default:
      return {
        label: 'Processing',
        className:
          'inline-flex rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-xs font-semibold text-slate-700',
      };
  }
}

function uriForDocKey(map: Record<string, string> | undefined, key: string): string | undefined {
  if (!map) return undefined;
  if (map[key]) return map[key];
  const target = key.toLowerCase().replace(/\s+/g, '_');
  for (const [k, v] of Object.entries(map)) {
    const norm = k.toLowerCase().replace(/\s+/g, '_');
    if (norm === target) return v;
  }
  return undefined;
}

function buildDocumentRows(record: ReconcileRecord): Array<{ key: string; label: string; s3Uri?: string }> {
  const map = record.documentsByType ?? {};
  const rows: Array<{ key: string; label: string; s3Uri?: string }> = [];
  const seenKeys = new Set<string>();
  const seenLabels = new Set<string>();

  const addSafeRow = (rawKey: string, uri?: string) => {
    if (!rawKey) return;
    const key = rawKey.trim().toLowerCase().replace(/\s+/g, '_');
    const label = formatDocTypeKey(rawKey);
    const normLabel = label.toLowerCase().trim();

    if (seenKeys.has(key) || seenLabels.has(normLabel)) {
      // If we find a duplicate but it has a URI while the existing one doesn't, update URI
      const existing = rows.find(
        (r) =>
          r.key.toLowerCase().replace(/\s+/g, '_') === key ||
          r.label.toLowerCase().trim() === normLabel
      );
      if (existing && !existing.s3Uri && uri) {
        existing.s3Uri = uri;
      }
      return;
    }

    rows.push({
      key: rawKey,
      label,
      s3Uri: uri || undefined,
    });
    seenKeys.add(key);
    seenLabels.add(normLabel);
  };

  for (const t of record.documentTypes) {
    if (!t || t === '—') continue;
    const uri = uriForDocKey(map, t);
    addSafeRow(t, uri?.trim() || undefined);
  }

  for (const [k, v] of Object.entries(map)) {
    const uri = String(v ?? '').trim();
    addSafeRow(k, uri || undefined);
  }

  return rows.sort((a, b) => {
    const getOrder = (label: string) => {
      const l = label.toLowerCase();
      if (l.includes('purchase order')) return 1;
      if (l.includes('goods receipt') || l.includes('gr')) return 2;
      if (l.includes('invoice')) return 3;
      if (l.includes('delivery receipt') || l.includes('dr')) return 99;
      return 10;
    };
    const orderA = getOrder(a.label);
    const orderB = getOrder(b.label);
    if (orderA !== orderB) return orderA - orderB;
    return a.label.localeCompare(b.label);
  });
}

function normalizeKey(value: string): string {
  return value.toLowerCase().replace(/\s+/g, '_');
}

function compactKey(value: string): string {
  return normalizeKey(value).replace(/[^a-z0-9]/g, '');
}

function titleCaseFromKey(key: string): string {
  return key
    .replace(/_/g, ' ')
    .trim()
    .split(/\s+/)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}

/** Map arbitrary API doc keys (e.g. invoice_v2, purchase_order_v2) to table columns. */
function slotForDocKey(rawKey: string): 'purchaseOrder' | 'goodsReceipt' | 'supplierInvoice' | 'deliveryReceipt' | null {
  const n = rawKey.trim().toLowerCase().replace(/\s+/g, '_');
  if (!n) return null;

  // Goods Receipt patterns
  if (
    n.includes('goods_receipt') ||
    n.includes('good_receipt') ||
    n.includes('goodsreceipt') ||
    n.includes('goodreceipt') ||
    n.includes('gr_amount') ||
    n === 'gr' ||
    n.endsWith('_gr') ||
    n === 'grn' ||
    n.includes('grn_')
  ) {
    return 'goodsReceipt';
  }

  // Purchase Order patterns
  if (
    n.includes('purchase_order') ||
    n.includes('purchaseorder') ||
    n === 'po' ||
    n === 'total_amount' ||
    n.includes('po_')
  ) {
    return 'purchaseOrder';
  }

  // Supplier Invoice patterns
  if (
    n.includes('invoice') ||
    n.includes('supplier_invoice') ||
    n === 'amount' ||
    n.includes('inv_') ||
    n === 'si'
  ) {
    return 'supplierInvoice';
  }

  // Delivery Receipt patterns
  if (
    n.includes('delivery_receipt') ||
    n.includes('delievery_receipt') ||
    n === 'dr' ||
    n.includes('delivery') ||
    n.includes('delievery')
  ) {
    return 'deliveryReceipt';
  }

  return null;
}

function pullDocColumnValues(map: Record<string, unknown>): {
  purchaseOrder: string;
  goodsReceipt: string;
  supplierInvoice: string;
  deliveryReceipt: string;
} {
  let purchaseOrder = '';
  let goodsReceipt = '';
  let supplierInvoice = '';
  let deliveryReceipt = '';

  for (const [k, v] of Object.entries(map)) {
    const val = String(v ?? '').trim();
    const slot = slotForDocKey(k);
    if (!slot || !val) continue;
    if (slot === 'purchaseOrder') purchaseOrder = val;
    else if (slot === 'goodsReceipt') goodsReceipt = val;
    else if (slot === 'supplierInvoice') supplierInvoice = val;
    else if (slot === 'deliveryReceipt') deliveryReceipt = val;
  }

  // Fallback for direct keys if slots not found
  if (!purchaseOrder) purchaseOrder = String(map.purchase_order ?? map.po ?? map.purchaseOrder ?? '').trim();
  if (!goodsReceipt) goodsReceipt = String(map.goods_receipt ?? map.gr ?? map.goodsReceipt ?? '').trim();
  if (!supplierInvoice) supplierInvoice = String(map.invoice ?? map.supplier_invoice ?? map.supplierInvoice ?? '').trim();
  if (!deliveryReceipt) deliveryReceipt = String(map.delivery_receipt ?? map.dr ?? map.deliveryReceipt ?? '').trim();

  const po = purchaseOrder || 'N/A';
  const gr = goodsReceipt || 'N/A';
  const si = supplierInvoice || 'N/A';
  const dr = deliveryReceipt || 'N/A';

  return { purchaseOrder: po, goodsReceipt: gr, supplierInvoice: si, deliveryReceipt: dr };
}

function normalizeCompareValue(value: string): string {
  return value.trim().toLowerCase();
}

/** Robust summing of all numeric sequences in a string. */
function formatValueWithSum(val: string): string {
  if (!val || val === 'N/A' || val === '—') return val;
  
  // Match all components that look like numbers (e.g. "1,200.50", "500", "-10")
  const matches = val.match(/-?\d+[\d,.]*/g);
  if (!matches || matches.length === 0) return val;

  let total = 0;
  let numericCount = 0;
  for (const m of matches) {
    const cleaned = m.replace(/,/g, '');
    const n = parseFloat(cleaned);
    if (!isNaN(n) && isFinite(n)) {
      total += n;
      numericCount++;
    }
  }

  // Only return a sum if we actually found multiple numbers or want to clean/format a single one
  if (numericCount > 1) {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    }).format(total);
  }

  // For single values, return original to preserve non-numeric context/IDs if present
  return val;
}

/** Strip currency/commas/spaces for numeric parse attempts. */
function stripToNumericText(raw: string): string {
  return raw
    .trim()
    .replace(/,/g, '')
    .replace(/^\s*\$\s*/, '')
    .replace(/\s/g, '');
}

function tryParseComparableNumber(raw: string): number | null {
  const t = stripToNumericText(raw);
  if (!t || t === 'n/a' || t === 'na' || t === 'notfound') return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

/** True when two cell values are the same by string (case-insensitive) or numerically (e.g. 15 vs 15.000). */
function valuesComparableEqual(a: string, b: string): boolean {
  const sa = a.trim();
  const sb = b.trim();
  if (sa === sb) return true;
  const la = normalizeCompareValue(sa);
  const lb = normalizeCompareValue(sb);
  if (la === lb) return true;
  const na = tryParseComparableNumber(sa);
  const nb = tryParseComparableNumber(sb);
  if (na !== null && nb !== null) {
    const diff = Math.abs(na - nb);
    const scale = Math.max(Math.abs(na), Math.abs(nb), 1e-9);
    return diff < 1e-9 || diff / scale < 1e-9;
  }
  return false;
}

/** Matched only when all present columns are equal (numeric or string). */
function rowConsistencyStatus(
  purchaseOrder: string,
  goodsReceipt: string,
  supplierInvoice: string,
  deliveryReceipt: string
): 'matched' | 'not_matched' {
  const vals = [purchaseOrder, goodsReceipt, supplierInvoice, deliveryReceipt];
  const present = vals.filter((v) => {
    const n = normalizeCompareValue(v.trim());
    return n && n !== 'n/a' && n !== 'na' && n !== 'not found' && n !== '—';
  });
  
  // If only one document value is present, we consider it matched (consistency) 
  // as there's nothing to conflict with. This was causing false negatives.
  if (present.length <= 1) return 'matched';
  
  const first = present[0];
  for (let i = 1; i < present.length; i++) {
    if (!valuesComparableEqual(first, present[i])) return 'not_matched';
  }
  return 'matched';
}

function sectionStatusToUi(
  status: 'yes' | 'no' | undefined,
  description: string
): 'matched' | 'not_matched' | 'unknown' {
  if (status === 'yes') return 'matched';
  if (status === 'no') return 'not_matched';
  if (description.toLowerCase() === 'none') return 'matched';
  return 'unknown';
}

function buildSopSectionCards(record: ReconcileRecord): SopSectionCard[] {
  const sections = record.reasonForFailureSections;
  if (sections && sections.length > 0) {
    return sections.map((s) => {
      const description = String(s.description ?? '').trim() || '—';
      return {
        sopName: s.sopName,
        description,
        status: sectionStatusToUi(s.status, description),
        matching: s.matching,
      };
    });
  }
  if (record.reasonForFailureEntries && record.reasonForFailureEntries.length > 0) {
    return record.reasonForFailureEntries
      .filter((e) => e.sopName.trim().toLowerCase() !== 'matching')
      .map((e) => {
        const description = String(e.explanation ?? '').trim() || '—';
        return {
          sopName: e.sopName,
          description,
          status: sectionStatusToUi(e.status, description),
          matching: undefined,
        };
      });
  }
  if (record.reasonForFailureDetails) {
    return Object.entries(record.reasonForFailureDetails).map(([sopName, description]) => {
      const text = String(description ?? '').trim() || '—';
      return {
        sopName,
        description: text,
        status: text.toLowerCase() === 'none' ? 'matched' : 'not_matched',
        matching: undefined,
      };
    });
  }
  const fallback = record.reasonForFailure?.trim();
  if (fallback) {
    return [{ sopName: 'Summary', description: fallback, status: 'unknown' as const, matching: undefined }];
  }
  return [];
}

export function buildConsistencyRowsFromMatching(matching: Record<string, unknown> | undefined): ConsistencyRow[] {
  if (!matching || typeof matching !== 'object') return [];

  const out: ConsistencyRow[] = [];
  
  // First, check if the matching object is a flat map of "Doc_Field" or similar
  const hasNestedObjects = Object.values(matching).some(v => v && typeof v === 'object');
  
  if (!hasNestedObjects) {
    // If it's a flat map, we treat the entire object as ONE row or try to group it
    // But usually, we can construct one row for standard keys
    const { purchaseOrder, goodsReceipt, supplierInvoice, deliveryReceipt } = pullDocColumnValues(matching);
    if (purchaseOrder !== 'N/A' || goodsReceipt !== 'N/A' || supplierInvoice !== 'N/A' || deliveryReceipt !== 'N/A') {
      const status = rowConsistencyStatus(purchaseOrder, goodsReceipt, supplierInvoice, deliveryReceipt);
      out.push({
        field: 'Summary Totals',
        matchedValue: status === 'matched' ? 'yes' : 'no',
        purchaseOrder: formatValueWithSum(purchaseOrder),
        goodsReceipt: formatValueWithSum(goodsReceipt),
        supplierInvoice: formatValueWithSum(supplierInvoice),
        deliveryReceipt: formatValueWithSum(deliveryReceipt),
        status,
      });
    }
  }

  for (const [rawField, docMap] of Object.entries(matching)) {
    if (!docMap || typeof docMap !== 'object') continue;
    const map = docMap as Record<string, unknown>;
    const { purchaseOrder, goodsReceipt, supplierInvoice, deliveryReceipt } = pullDocColumnValues(map);

    // Show values as-is from the backend — no summation applied here.
    // Status is driven by the API's explicit 'matched' field (yes/no).
    const matchedVal = String(map.matched ?? map.Matched ?? '').trim().toLowerCase();
    const status: 'matched' | 'not_matched' =
      matchedVal === 'yes' ? 'matched' :
        matchedVal === 'no' ? 'not_matched' :
          rowConsistencyStatus(purchaseOrder, goodsReceipt, supplierInvoice, deliveryReceipt);

    out.push({
      field: titleCaseFromKey(rawField.trim()),
      matchedValue: matchedVal || (status === 'matched' ? 'yes' : 'no'),
      purchaseOrder,
      goodsReceipt,
      supplierInvoice,
      deliveryReceipt,
      status,
    });
  }
  return out;
}

export default function ReconcileSessionDetail() {
  const location = useLocation();
  const navigate = useNavigate();
  const [modalDocKey, setModalDocKey] = useState<string | null>(null);
  const [allDocsModalOpen, setAllDocsModalOpen] = useState(false);
  const [activeDocKey, setActiveDocKey] = useState<string>('');
  const [reuploadLoading, setReuploadLoading] = useState(false);

  const handleReupload = async () => {
    if (!record || reuploadLoading) return;
    setReuploadLoading(true);
    try {
      const sessionDocs = await getSessionDocuments(record.id);
      navigate('/reconcile-agent/file-upload', {
        state: {
          prefill: {
            sessionId: sessionDocs.sessionId,
            jobId: sessionDocs.jobId,
            jobName: sessionDocs.jobName,
            originalNames: sessionDocs.originalNames,
            s3Uris: sessionDocs.s3Uris,
          },
        },
      });
    } catch (e) {
      console.error('get_session_documents failed:', e);
    } finally {
      setReuploadLoading(false);
    }
  };
  const state = location.state as ReconcileSessionDetailState | null;
  const record = state?.record;
  console.log('record value taken from location.state:', record);

  const documentRows = useMemo(() => {
    if (!record) return [];
    let rows = buildDocumentRows(record);
    // Remove Delivery Receipt from UI entirely if it has no file
    rows = rows.filter((row) => !(row.key === 'delivery_receipt' && !row.s3Uri));
    return rows;
  }, [record]);

  const tabRows = useMemo(() => {
    if (!record) return [];
    // Hide 'sop' and 'reference_document' from document tabs
    return buildDocumentRows(record).filter(
      (row) => row.key !== 'reference_document' && row.key !== 'sop'
    );
  }, [record]);

  function fieldsForKey(key: string): Array<{ name: string; value: string }> {
    if (!record) return [];
    const source = record.extractedFieldsByDoc ?? {};
    const target = normalizeKey(key);

    if (target === 'reference_document') {
      for (const [k, fields] of Object.entries(source)) {
        if (slotForDocKey(k) === null && Array.isArray(fields)) {
          return fields;
        }
      }
    }

    for (const [k, fields] of Object.entries(source)) {
      if (normalizeKey(k) === target && Array.isArray(fields)) return fields;
    }
    const targetCompact = compactKey(key);
    for (const [k, fields] of Object.entries(source)) {
      if (compactKey(k) === targetCompact && Array.isArray(fields)) return fields;
    }
    return [];
  }

  const activeDoc = useMemo(() => {
    if (tabRows.length === 0) return undefined;
    return tabRows.find((row) => row.key === activeDocKey) ?? tabRows[0];
  }, [activeDocKey, tabRows]);
  const activeFields = useMemo(
    () => (activeDoc ? fieldsForKey(activeDoc.key) : []),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [activeDoc?.key, record]
  );
  const modalDoc = useMemo(
    () => (modalDocKey ? documentRows.find((r) => r.key === modalDocKey) : undefined),
    [modalDocKey, documentRows]
  );
  const modalFields = useMemo(
    () => (modalDocKey ? fieldsForKey(modalDocKey) : []),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [modalDocKey, record]
  );
  const sopCards = useMemo(() => (record ? buildSopSectionCards(record) : []), [record]);


  const dynamicDeliveryReceiptRows = useMemo(() => {
    if (!record || !record.extractedFieldsByDoc) return [];

    const docKeys = Object.keys(record.extractedFieldsByDoc);
    const drKey = docKeys.find((k) => slotForDocKey(k) === 'deliveryReceipt');
    const poKey = docKeys.find((k) => slotForDocKey(k) === 'purchaseOrder');
    const grKey =
      docKeys.find((k) => slotForDocKey(k) === 'goodsReceipt') ||
      docKeys.find((k) => {
        const l = k.toLowerCase();
        return l.includes('receipt') || l.includes('grn') || l.includes('gr');
      });
    const siKey = docKeys.find((k) => slotForDocKey(k) === 'supplierInvoice');

    if (!drKey) return [];

    const drFields = record.extractedFieldsByDoc[drKey] || [];
    const poFields = poKey ? record.extractedFieldsByDoc[poKey] || [] : [];
    const grFields = grKey ? record.extractedFieldsByDoc[grKey] || [] : [];
    const siFields = siKey ? record.extractedFieldsByDoc[siKey] || [] : [];

    const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');

    const getAliases = (key: string) => {
      const n = norm(key);
      const aliases = new Set<string>([n]);
      if (n.includes('qty') || n.includes('quantity') || n.includes('count')) {
        aliases.add('qty');
        aliases.add('quantity');
        aliases.add('grquantity');
        aliases.add('delivered');
        aliases.add('received');
      }
      if (
        n.includes('amount') &&
        !n.includes('line') &&
        !n.includes('total') &&
        !n.includes('vat') &&
        !n.includes('tax')
      ) {
        aliases.add('amount');
        aliases.add('amtdue');
        aliases.add('gramount');
      }
      if (n.includes('lineamount') || n.includes('subtotal')) {
        aliases.add('lineamount');
        aliases.add('subtotal');
        aliases.add('netamount');
      }
      if (n.includes('total') || n.includes('sales') || n === 'grandtotal') {
        aliases.add('totalamount');
        aliases.add('total');
        aliases.add('totalsales');
      }
      if (n.includes('price') || n.includes('rate')) {
        aliases.add('price');
        aliases.add('unitprice');
        aliases.add('rate');
      }
      if (n.includes('vat') || n.includes('tax')) {
        aliases.add('vat');
        aliases.add('vatamount');
        aliases.add('tax');
      }
      if (n.includes('po') || n.includes('purchaseorder')) {
        aliases.add('po');
        aliases.add('pono');
        aliases.add('ponumber');
      }
      if (n.includes('code') || n.includes('mat') || n.includes('sku') || n.includes('stock')) {
        aliases.add('code');
        aliases.add('matcode');
        aliases.add('stockno');
        aliases.add('sku');
      }
      if (n.includes('unit') && n !== 'unitprice') {
        aliases.add('unit');
        aliases.add('uom');
      }
      if (n.includes('desc') || n.includes('spec')) {
        aliases.add('description');
        aliases.add('specification');
      }
      if (n.includes('dr') || n.includes('delivery')) {
        aliases.add('dr');
        aliases.add('drno');
        aliases.add('deliveryreceipt');
      }
      if (n.includes('si') || n.includes('invoice')) {
        aliases.add('si');
        aliases.add('invoiceno');
        aliases.add('invoice');
      }
      if (n.includes('date')) {
        aliases.add('date');
        aliases.add('receiptdate');
      }
      if (n.includes('term')) {
        aliases.add('terms');
        aliases.add('paymentterms');
      }
      if (n.includes('salesman') || n.includes('salesperson')) {
        aliases.add('salesman');
      }
      if (n.includes('issue') || n.includes('prepared')) {
        aliases.add('issuedby');
        aliases.add('preparedby');
      }
      if (n.includes('check') || n.includes('verify')) {
        aliases.add('checkedby');
        aliases.add('verifiedby');
      }
      return Array.from(aliases);
    };

    const findMatch = (
      targetField: { name: string; value: string },
      searchFields: Array<{ name: string; value: string }>
    ) => {
      const targetAliases = getAliases(targetField.name);

      let bestMatch = null;
      let bestScore = 0;

      for (const f of searchFields) {
        let score = 0;
        const searchAliases = getAliases(f.name);

        if (norm(f.name) === norm(targetField.name)) score += 20; // High score for exact normalized match
        else if (targetAliases.some((ta) => searchAliases.includes(ta))) score += 10;
        else if (
          norm(f.name).includes(norm(targetField.name)) ||
          norm(targetField.name).includes(norm(f.name))
        )
          score += 5;

        // Penalty for amount mismatch if field name is clearly distinct
        if (score > 0 && targetField.name.toLowerCase().includes('total') && !f.name.toLowerCase().includes('total')) {
          score -= 5;
        }

        if (score > bestScore) {
          bestScore = score;
          bestMatch = f;
        }
      }

      return bestMatch ? bestMatch.value : 'N/A';
    };

    return drFields.map((drField) => {
      return {
        field: titleCaseFromKey(drField.name),
        purchaseOrder: poFields.length ? findMatch(drField, poFields) : 'N/A',
        goodsReceipt: grFields.length ? findMatch(drField, grFields) : 'N/A',
        supplierInvoice: siFields.length ? findMatch(drField, siFields) : 'N/A',
        deliveryReceipt: drField.value || 'N/A',
      };
    });
  }, [record]);

  useEffect(() => {
    if (!tabRows.length) {
      setActiveDocKey('');
      return;
    }
    const hasActive = tabRows.some((r) => r.key === activeDocKey);
    if (!hasActive) {
      setActiveDocKey(tabRows[0].key);
    }
  }, [tabRows, activeDocKey]);


  if (!record) {
    return (
      <div className="flex w-full flex-col gap-6">
        <PageBreadcrumb
          items={[
            { title: 'Home', to: '/dashboard' },
            { title: 'Reconcile Agent', to: '/reconcile-agent/records' },
            { title: 'Session details' },
          ]}
        />
        <div className="rounded-xl border border-slate-200/80 bg-white p-6 shadow-sm">
          <p className="m-0 text-sm text-slate-600">
            No session data to show. Open this page from a row on Reconcile Agent records, or use the
            breadcrumb to go back.
          </p>
        </div>
      </div>
    );
  }

  const statusTag = reconcileStatusTagClasses(record.reconcileStatus);

  return (
    <div className="flex w-full flex-col gap-5">
      <PageBreadcrumb
        items={[
          { title: 'Home', to: '/dashboard' },
          { title: 'Reconcile Agent', to: '/reconcile-agent/records' },
          { title: 'Session details' },
        ]}
      />

      <h1 className="m-0 text-xl font-semibold tracking-tight text-slate-900 sm:text-2xl">
        Reconciliation session
      </h1>

      <div className="grid min-h-0 grid-cols-1 gap-5 lg:grid-cols-[minmax(300px,34%)_1fr]">
        <aside className="flex min-h-0 flex-col rounded-xl border border-slate-200/80 bg-white p-3 shadow-sm sm:p-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <h2 className="m-0 text-base font-semibold text-slate-900">File Details</h2>
            {(record.reconcileStatus === 'failed' || record.reconcileStatus === 'not_matched' || record.reconcileStatus === 'validation failed') && (
              <button
                type="button"
                disabled={reuploadLoading}
                onClick={() => void handleReupload()}
                className="inline-flex items-center gap-1.5 rounded-md border border-amber-400 bg-amber-50 px-2.5 py-1 text-xs font-medium text-amber-700 hover:bg-amber-100 transition-colors disabled:opacity-60"
              >
                {reuploadLoading
                  ? <span className="h-3 w-3 animate-spin rounded-full border-2 border-amber-400/30 border-t-amber-600 inline-block" />
                  : <RefreshCw size={12} strokeWidth={2.2} />}
                Re-upload
              </button>
            )}
          </div>

          <div className="divide-y divide-slate-100">
            <div className="grid grid-cols-1 gap-0.5 py-2 sm:grid-cols-[140px_minmax(0,1fr)] sm:gap-3">
              <span className="text-sm font-medium text-slate-500">Session ID</span>
              <span className="min-w-0 break-all text-sm font-medium text-slate-900">
                {record.id}
              </span>
            </div>
            <div className="grid grid-cols-1 gap-0.5 py-2 sm:grid-cols-[140px_minmax(0,1fr)] sm:gap-3">
              <span className="text-sm font-medium text-slate-500">Job name</span>
              <span className="min-w-0 text-sm text-slate-900">{record.jobName}</span>
            </div>

            <div className="grid grid-cols-1 gap-0.5 py-2 sm:grid-cols-[140px_minmax(0,1fr)] sm:items-center sm:gap-3">
              <span className="text-sm font-medium text-slate-500">Reconcile status</span>
              <div>
                <span className={statusTag.className}>{statusTag.label}</span>
              </div>
            </div>

            <div className="py-2">
              {documentRows.length === 0 ? (
                <span className="text-sm text-slate-500">No documents linked.</span>
              ) : (
                <div className="flex min-w-0 flex-col gap-1">
                  {documentRows.map((row) => (
                    <div
                      key={row.key}
                      className="flex items-center justify-between gap-2 rounded-md border border-slate-100 bg-slate-50/80 px-2 py-1.5"
                    >
                      <span className="min-w-0 flex-1 truncate text-sm font-medium text-slate-900" title={row.label}>
                        {row.label}
                      </span>
                      {row.s3Uri ? (
                        <button
                          type="button"
                          className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded text-[#1351cd] transition-colors hover:bg-blue-50"
                          aria-label={`View ${row.label}`}
                          onClick={() => setModalDocKey(row.key)}
                        >
                          <Eye size={15} strokeWidth={2} />
                        </button>
                      ) : (
                        <span className="shrink-0 text-[11px] text-slate-400">No file</span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </aside>

        <main className="flex min-h-[260px] flex-col rounded-xl border border-slate-200/80 bg-white p-4 shadow-sm sm:p-5">
          <div className="border-b border-slate-200 pb-3">
            {documentRows.length === 0 ? (
              <h2 className="m-0 text-base font-semibold text-slate-900">Document Types</h2>
            ) : (
              <div className="flex items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2">
                  {tabRows.map((row) => {
                    const active = activeDoc?.key === row.key;
                    return (
                      <button
                        key={row.key}
                        type="button"
                        onClick={() => setActiveDocKey(row.key)}
                        className={[
                          'inline-flex items-center rounded-md border px-3 py-1.5 text-sm transition-colors',
                          active
                            ? 'border-[#1351cd] bg-[#eef4ff] text-[#1351cd]'
                            : 'border-transparent text-slate-500 hover:border-slate-200 hover:bg-slate-50',
                        ].join(' ')}
                      >
                        {row.label}
                      </button>
                    );
                  })}
                </div>
                <button
                  type="button"
                  onClick={() => setAllDocsModalOpen(true)}
                  className="inline-flex items-center gap-1 rounded-md border border-[#1351cd] px-2 py-1 text-xs font-medium text-[#1351cd] hover:bg-[#eef4ff] transition-colors shrink-0"
                >
                  <LayoutGrid size={12} />
                  View All
                </button>
              </div>
            )}
          </div>

          <div className="pt-4">
            {tabRows.length === 0 ? (
              <p className="m-0 text-sm text-slate-500">No documents to view extracts for.</p>
            ) : (() => {
              const key = activeDoc?.key || '';
              const isDeliveryReceipt = key.includes('delivery') || key.includes('delievery') || key === 'dr';
              
              if (isDeliveryReceipt) {
                return (
                  <div className="max-h-[320px] overflow-auto rounded-lg border border-slate-200 bg-white">
                    <table className="w-full border-collapse text-sm">
                      <thead className="sticky top-0 z-10 bg-slate-50">
                        <tr className="border-b border-slate-200">
                          <th className="px-3 py-2 text-left text-xs font-semibold text-slate-700">Field</th>
                          <th className="px-3 py-2 text-left text-xs font-semibold text-slate-700">Purchase Order</th>
                          <th className="px-3 py-2 text-left text-xs font-semibold text-slate-700">Goods Receipt</th>
                          <th className="px-3 py-2 text-left text-xs font-semibold text-slate-700">Supplier Invoice</th>
                          <th className="px-3 py-2 text-left text-xs font-semibold text-slate-700">Delivery Receipt</th>
                        </tr>
                      </thead>
                      <tbody>
                        {dynamicDeliveryReceiptRows.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="px-3 py-4 text-center text-slate-500 italic">
                              No matching reconciliation data found for these fields.
                            </td>
                          </tr>
                        ) : (
                          dynamicDeliveryReceiptRows.map((row, idx) => (
                            <tr key={`${row.field}-${idx}`} className="border-b border-slate-100 last:border-b-0 hover:bg-slate-50/50">
                              <td className="px-3 py-2.5 font-semibold text-slate-900 border-r border-slate-100">{row.field}</td>
                              <td className="px-3 py-2.5 text-slate-700 tabular-nums break-words min-w-[120px] max-w-[250px]">{formatValueWithSum(row.purchaseOrder)}</td>
                              <td className="px-3 py-2.5 text-slate-700 tabular-nums break-words min-w-[120px] max-w-[250px]">{formatValueWithSum(row.goodsReceipt)}</td>
                              <td className="px-3 py-2.5 text-slate-700 tabular-nums break-words min-w-[120px] max-w-[250px]">{formatValueWithSum(row.supplierInvoice)}</td>
                              <td className="px-3 py-2.5 text-slate-700 tabular-nums break-words min-w-[120px] max-w-[250px] font-medium border-l border-slate-100">{formatValueWithSum(row.deliveryReceipt)}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                );
              }
              
              return (
                <div className="max-h-[280px] space-y-2 overflow-y-auto pr-1">
                  {activeFields.length === 0 ? (
                    <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-500">
                      No sample fields found for this document.
                    </div>
                  ) : (
                    activeFields.map((field, idx) => {
                      const value = String(field.value ?? '').trim();
                      const ok = value !== '' && value.toLowerCase() !== 'none' && value.toLowerCase() !== 'n/a';
                      return (
                        <div
                          key={`${field.name}-${idx}`}
                          className="grid grid-cols-[1fr_auto] items-start gap-3 rounded-lg border border-slate-200 bg-slate-50/70 px-3 py-2"
                        >
                          <div>
                            <div className="text-xs font-medium uppercase tracking-wide text-slate-500">
                              {field.name}
                            </div>
                            <div className="mt-1 text-sm text-slate-800">{value || '—'}</div>
                          </div>
                          {ok ? (
                            <CheckCircle2 size={16} className="mt-1 text-emerald-500" aria-hidden />
                          ) : (
                            <XCircle size={16} className="mt-1 text-rose-500" aria-hidden />
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              );
            })()}
          </div>
        </main>
      </div>

      {/* Document viewer modal */}
      {modalDocKey && modalDoc && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
          onClick={() => setModalDocKey(null)}
        >
          <div
            className="relative flex flex-col bg-white rounded-xl shadow-2xl overflow-hidden w-[75vw] h-[85vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal header */}
            <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3 shrink-0">
              <h3 className="m-0 text-base font-semibold text-slate-900">{modalDoc.label}</h3>
              <button
                type="button"
                onClick={() => setModalDocKey(null)}
                className="inline-flex h-8 w-8 items-center justify-center rounded-md text-slate-500 hover:bg-slate-100 transition-colors"
                aria-label="Close"
              >
                <X size={18} />
              </button>
            </div>
            {/* Modal body */}
            <div className="flex-1 min-h-0 p-4 overflow-hidden">
              <DocumentViewer
                key={modalDocKey}
                s3Uri={modalDoc.s3Uri}
                extractedFields={modalFields}
                docLabel={modalDoc.label}
              />
            </div>
          </div>
        </div>
      )}

      {/* All documents preview modal */}
      {allDocsModalOpen && (
        <AllDocumentsPreviewModal
          documentRows={documentRows}
          onClose={() => setAllDocsModalOpen(false)}
        />
      )}

      <section className="rounded-xl border border-slate-200/80 bg-white p-3 shadow-sm sm:p-4">
        <div className="border-b border-slate-200 pb-2">
          <h2 className="m-0 text-base font-semibold tracking-tight text-slate-900">Field Consistency Check</h2>
        </div>

        <div className="max-h-[min(70vh,680px)] space-y-3 overflow-y-auto pt-3">
          {sopCards.length === 0 ? (
            <div className="rounded-lg border border-dashed border-slate-200 bg-slate-50/80 px-3 py-5 text-center text-sm text-slate-500">
              No SOP field consistency data for this session.
            </div>
          ) : (
            <FieldConsistencyCards sopCards={sopCards} reconcileStatus={record.reconcileStatus} />
          )}
        </div>
      </section>
    </div>
  );
}
