import { Tag, Tooltip, type TableColumnsType } from 'antd';
import dayjs from 'dayjs';
import { Eye } from 'lucide-react';
import { useMemo } from 'react';
import { TableLayout } from '../ui/TableLayout';

export type ReconcileRowStatus = 'processing' | 'matched' | 'not_matched' | 'failed' | 'validation failed';

export interface ReconcileRecord {
  id: string;
  jobName: string;
  documentTypes: string[];
  uploadedAt: string;
  reconcileStatus: ReconcileRowStatus;
  reasonForFailure?: string;
  /** From API `reason_for_failure` when it is an object (e.g. "Price mismatch" → message) */
  reasonForFailureDetails?: Record<string, string>;
  /** Normalized reason rows with optional status from API array/object forms. */
  reasonForFailureEntries?: Array<{
    sopName: string;
    status?: 'yes' | 'no';
    explanation: string;
  }>;
  /** One block per SOP from array `reason_for_failure` (includes row-level `matching`). */
  reasonForFailureSections?: Array<{
    sopName: string;
    description: string;
    status?: 'yes' | 'no';
    matching?: Record<string, unknown>;
  }>;
  /** Document type key → S3 URI from API `documents` map */
  documentsByType?: Record<string, string>;
  /** Optional per-document extracted fields from list API */
  extractedFieldsByDoc?: Record<string, Array<{ name: string; value: string }>>;
}

interface RecordsTableProps {
  rows: ReconcileRecord[];
  loading?: boolean;
  onViewSession?: (record: ReconcileRecord) => void;
}

const actionIconBtnClass =
  'inline-flex items-center justify-center rounded-md p-1.5 text-[#1351cd] hover:bg-[#1351cd]/10 transition-colors disabled:opacity-40 disabled:pointer-events-none';

function ProcessingIcon() {
  return (
    <span className="inline-flex items-center gap-2 text-[#1351cd]">
      <span className="h-4 w-4 animate-spin rounded-full border-2 border-[#1351cd]/30 border-t-[#1351cd]" />
      <span className="text-xs font-semibold">Processing</span>
    </span>
  );
}

export default function RecordsTable({ rows, loading = false, onViewSession }: RecordsTableProps) {
  const sortedRows = useMemo(
    () => [...rows].sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()),
    [rows]
  );

  const columns: TableColumnsType<ReconcileRecord> = useMemo(
    () => [
      {
        title: 'Date & Time',
        dataIndex: 'uploadedAt',
        key: 'uploadedAt',
        width: 200,
        render: (iso: string) => (
          <span className="text-xs text-slate-700">
            {iso && dayjs(iso).isValid() ? dayjs(iso).format('MMM D, YYYY, h:mm A') : '—'}
          </span>
        ),
      },
      {
        title: 'Job Name',
        dataIndex: 'jobName',
        key: 'jobName',
        width: 190,
        render: (text: string) => <span className="text-sm font-semibold text-slate-900">{text}</span>,
      },
      {
        title: 'Document Types',
        dataIndex: 'documentTypes',
        key: 'documentTypes',
        width: 272,
        render: (types: string[]) => {
          const normalized = (types ?? []).map((t) => String(t).trim()).filter(Boolean);
          if (!normalized.length) {
            return <span className="text-sm text-slate-400">—</span>;
          }

          return (
            <div className="min-w-0">
              <div className="flex flex-wrap gap-2">
                {normalized.map((raw, i) => (
                  <Tag key={`dt-${i}-${raw}`} color="blue">
                    {raw}
                  </Tag>
                ))}
              </div>
            </div>
          );
        },
      },
      {
        title: 'Reconcile Status',
        dataIndex: 'reconcileStatus',
        key: 'reconcileStatus-pill',
        width: 180,
        render: (status: ReconcileRowStatus) =>
          status === 'processing' ? (
            <ProcessingIcon />
          ) : status === 'matched' ? (
            <span className="inline-flex rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-0.5 text-xs font-semibold text-emerald-700">
              Matched
            </span>
          ) : status === 'failed' ? (
            <span className="inline-flex rounded-full border border-rose-200 bg-rose-50 px-2.5 py-0.5 text-xs font-semibold text-rose-700">
              Failed
            </span>
          ) : status === 'validation failed' ? (
            <span className="inline-flex rounded-full border border-orange-200 bg-orange-50 px-2.5 py-0.5 text-xs font-semibold text-orange-700">
              Validation Failed
            </span>
          ) : (
            <span className="inline-flex rounded-full border border-rose-200 bg-rose-50 px-2.5 py-0.5 text-xs font-semibold text-rose-700">
              Not Matched
            </span>
          ),
      },
      {
        title: 'Action',
        key: 'action',
        width: 88,
        align: 'center',
        render: (_: unknown, record) => {
          const processing = record.reconcileStatus === 'processing';
          const tooltipTitle = processing
            ? 'Available when reconciliation finishes'
            : 'View session details';
          return (
            <Tooltip title={tooltipTitle}>
              <span>
                <button
                  type="button"
                  className={actionIconBtnClass}
                  aria-label={processing ? 'Session is still processing' : 'View session details'}
                  title={tooltipTitle}
                  disabled={!onViewSession || processing}
                  onClick={() => {
                    if (!onViewSession || processing) return;
                    onViewSession(record);
                  }}
                >
                  <Eye size={18} strokeWidth={2} />
                </button>
              </span>
            </Tooltip>
          );
        },
      },
    ],
    [onViewSession]
  );

  return (
    <TableLayout<ReconcileRecord>
      card={false}
      columns={columns}
      dataSource={sortedRows}
      loading={loading}
      rowKey="id"
      pagination={false}
      tableLayout="fixed"
      locale={{
        emptyText: loading ? '' : 'No records yet. Start a reconciliation to see results here.',
      }}
    />
  );
}
