import { useRef, useState } from 'react';
import PrimaryButton from '../ui/PrimaryButton';
import { validateSinglePageDocument } from '../../utils/pdfSinglePageValidation';

interface FileUploadFormProps {
  onSubmit: (payload: { documentType: string; fileName: string }) => Promise<void>;
}

const documentTypes = ['Invoice', 'Purchase Order', 'Goods Receipt Note', 'Credit Note'];

export default function FileUploadForm({ onSubmit }: FileUploadFormProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [documentType, setDocumentType] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isValidatingFile, setIsValidatingFile] = useState(false);

  const canSubmit = Boolean(documentType && file && !isSubmitting && !isValidatingFile && !fileError);

  const resetFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleFileChange = (selected: File | null) => {
    setFileError(null);
    if (!selected) {
      setFile(null);
      return;
    }
    setFile(null);
    setIsValidatingFile(true);
    void (async () => {
      const result = await validateSinglePageDocument(selected);
      setIsValidatingFile(false);
      if (!result.ok) {
        setFile(null);
        setFileError(result.message);
        resetFileInput();
        return;
      }
      setFile(selected);
    })();
  };

  return (
    <form
      className="w-full space-y-5"
      onSubmit={async (event) => {
        event.preventDefault();
        if (!documentType || !file || isSubmitting || isValidatingFile) return;

        setFileError(null);
        setIsValidatingFile(true);
        const check = await validateSinglePageDocument(file);
        setIsValidatingFile(false);
        if (!check.ok) {
          setFileError(check.message);
          setFile(null);
          resetFileInput();
          return;
        }

        setIsSubmitting(true);
        await onSubmit({ documentType, fileName: file.name });
        setIsSubmitting(false);
      }}
    >
      <div className="space-y-2">
        <label className="text-sm font-semibold text-slate-700" htmlFor="documentType">
          Document Type
        </label>
        <select
          id="documentType"
          value={documentType}
          onChange={(event) => setDocumentType(event.target.value)}
          className="h-11 w-full rounded-lg border border-slate-300 px-3 text-sm text-slate-800 outline-none transition-colors focus:border-[#1351cd] focus:ring-2 focus:ring-[#1351cd]/20"
        >
          <option value="">Select document type</option>
          {documentTypes.map((type) => (
            <option key={type} value={type}>
              {type}
            </option>
          ))}
        </select>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-semibold text-slate-700" htmlFor="uploadFile">
          Upload File
        </label>
        <label
          htmlFor="uploadFile"
          className="block cursor-pointer rounded-lg border border-dashed border-slate-300 bg-slate-50 transition-colors hover:border-[#1351cd]/50 hover:bg-[#1351cd]/[0.03]"
        >
          <div className="flex min-h-[220px] flex-col items-center justify-center px-4 py-8 text-center">
            <svg width="44" height="44" viewBox="0 0 24 24" fill="none" aria-hidden>
              <path
                d="M12 16V6M12 6L8 10M12 6L16 10"
                stroke="#0f172a"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M6 15V17C6 18.1046 6.89543 19 8 19H16C17.1046 19 18 18.1046 18 17V15"
                stroke="#0f172a"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <p className="mt-4 mb-1 text-[16px] font-normal text-slate-900">
              Click or drag file to this area to upload
            </p>
            <p className="m-0 text-[14px] text-slate-500">
              Only PDF and image files (JPG, PNG) up to 4MB are supported.
            </p>
            {isValidatingFile && (
              <p className="mt-3 text-sm text-slate-600">Checking file…</p>
            )}
            {file && !isValidatingFile && (
              <p className="mt-3 text-sm font-medium text-[#1351cd]">Selected: {file.name}</p>
            )}
          </div>
        </label>
        {fileError && (
          <p className="text-sm text-red-600" role="alert">
            {fileError}
          </p>
        )}
        <input
          ref={fileInputRef}
          id="uploadFile"
          type="file"
          accept=".pdf,.jpg,.jpeg,.png"
          onChange={(event) => handleFileChange(event.target.files?.[0] ?? null)}
          className="sr-only"
        />
      </div>

      <PrimaryButton
        type="submit"
        disabled={!canSubmit}
        text={
          isSubmitting ? (
            <span className="inline-flex items-center gap-2">
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
              Submitting...
            </span>
          ) : (
            'Submit'
          )
        }
      />
    </form>
  );
}
