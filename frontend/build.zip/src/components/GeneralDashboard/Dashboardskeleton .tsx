// src/components/GeneralDashboard/DashboardSkeleton.tsx
import type { CSSProperties } from 'react';

const pulse = 'animate-pulse bg-slate-200 rounded';

function SkeletonBlock({
  className = '',
  style,
}: {
  className?: string;
  style?: CSSProperties;
}) {
  return <div className={`${pulse} ${className}`} style={style} />;
}

/** KPI Cards row — 4 cards */
function KpiCardsSkeleton() {
  return (
    <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <div
          key={i}
          className="rounded-xl border border-slate-200/80 bg-white p-5 shadow-[0_2px_8px_rgba(0,0,0,0.06)]"
        >
          <SkeletonBlock className="h-3.5 w-32" />
          <SkeletonBlock className="mt-3 h-7 w-20" />
        </div>
      ))}
    </section>
  );
}

/** Bar chart card skeleton */
function BarChartSkeleton() {
  const bars = [60, 85, 45, 70, 55, 90];
  return (
    <div className="rounded-xl border border-slate-200/80 bg-white p-5 shadow-[0_2px_8px_rgba(0,0,0,0.06)]">
      {/* Title */}
      <SkeletonBlock className="mb-5 h-4 w-52" />

      {/* Chart area */}
      <div className="relative h-[240px] w-full overflow-hidden">
        {/* Y-axis ticks */}
        <div className="absolute left-0 top-0 flex h-full w-8 flex-col justify-between pb-6">
          {[0, 1, 2, 3, 4].map((i) => (
            <SkeletonBlock key={i} className="h-2.5 w-6" />
          ))}
        </div>

        {/* Bars */}
        <div className="ml-10 flex h-full items-end gap-3 pb-6">
          {bars.map((h, i) => (
            <div key={i} className="flex flex-1 flex-col items-center gap-1">
              {/* Stacked bar pair */}
              <div className="flex w-full flex-col items-stretch gap-0.5">
                <SkeletonBlock
                  className="w-full rounded-none"
                  style={{ height: `${h * 0.45}px` }}
                />
                <SkeletonBlock
                  className="w-full rounded-t"
                  style={{ height: `${h * 0.25}px` }}
                />
              </div>
              {/* X label */}
              <SkeletonBlock className="mt-2 h-2 w-10" />
            </div>
          ))}
        </div>

        {/* Horizontal grid lines */}
        <div className="pointer-events-none absolute inset-x-10 inset-y-0 flex flex-col justify-between pb-6">
          {[0, 1, 2, 3, 4].map((i) => (
            <div key={i} className="h-px w-full bg-slate-100" />
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="mt-3 flex items-center gap-4">
        <div className="flex items-center gap-1.5">
          <SkeletonBlock className="h-2.5 w-2.5 rounded-full" />
          <SkeletonBlock className="h-2.5 w-14" />
        </div>
        <div className="flex items-center gap-1.5">
          <SkeletonBlock className="h-2.5 w-2.5 rounded-full" />
          <SkeletonBlock className="h-2.5 w-16" />
        </div>
      </div>
    </div>
  );
}

/** Pie chart + legend card skeleton */
function PieChartSkeleton() {
  return (
    <div className="rounded-xl border border-slate-200/80 bg-white p-5 shadow-[0_2px_8px_rgba(0,0,0,0.06)]">
      {/* Title */}
      <SkeletonBlock className="mb-5 h-4 w-36" />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[1fr_1fr]">
        {/* Donut placeholder */}
        <div className="flex items-center justify-center" style={{ height: 240 }}>
          <div className="relative flex items-center justify-center">
            {/* Outer ring */}
            <div className="h-[172px] w-[172px] animate-pulse rounded-full bg-slate-200" />
            {/* Inner cutout */}
            <div className="absolute h-[88px] w-[88px] rounded-full bg-white" />
          </div>
        </div>

        {/* Legend rows */}
        <div className="flex flex-col justify-center gap-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="flex items-center justify-between px-1">
              <div className="flex items-center gap-2">
                <SkeletonBlock className="h-1.5 w-1.5 rounded-full" />
                <SkeletonBlock className={`h-2.5 ${i % 2 === 0 ? 'w-24' : 'w-32'}`} />
              </div>
              <SkeletonBlock className="ml-3 h-2.5 w-8" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/** Line chart card skeleton */
function LineChartSkeleton() {
  // Simulate a squiggly path with a simple polyline representation via divs
  const points = [40, 60, 35, 80, 50, 70, 45, 90, 55, 65, 40, 75, 50, 85, 60, 70, 45, 80, 55, 65, 50, 75, 40, 85, 60, 70, 50, 80, 45, 65];
  return (
    <div className="rounded-xl border border-slate-200/80 bg-white p-5 shadow-[0_2px_8px_rgba(0,0,0,0.06)]">
      {/* Title */}
      <SkeletonBlock className="mb-5 h-4 w-60" />

      {/* Chart area */}
      <div className="relative h-[280px] w-full overflow-hidden">
        {/* Y-axis */}
        <div className="absolute left-0 top-0 flex h-full w-8 flex-col justify-between pb-10">
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <SkeletonBlock key={i} className="h-2.5 w-6" />
          ))}
        </div>

        {/* SVG wave lines */}
        <svg
          className="absolute inset-0 ml-10"
          width="calc(100% - 40px)"
          height="260"
          viewBox="0 0 600 200"
          preserveAspectRatio="none"
        >
          {/* Horizontal grid lines */}
          {[40, 80, 120, 160, 200].map((y) => (
            <line key={y} x1="0" y1={y} x2="600" y2={y} stroke="#f1f5f9" strokeWidth="1" />
          ))}

          {/* Line 1 (matched) */}
          <polyline
            className="animate-pulse"
            fill="none"
            stroke="#e2e8f0"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            points={points
              .map((h, i) => `${(i / (points.length - 1)) * 600},${200 - h * 1.4}`)
              .join(' ')}
          />

          {/* Line 2 (mismatched) — offset wave */}
          <polyline
            className="animate-pulse"
            fill="none"
            stroke="#e2e8f0"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            points={points
              .map((h, i) => `${(i / (points.length - 1)) * 600},${200 - (h * 0.6 + 20)}`)
              .join(' ')}
          />
        </svg>

        {/* X-axis labels */}
        <div className="absolute bottom-0 left-10 right-0 flex justify-between">
          {Array.from({ length: 10 }).map((_, i) => (
            <SkeletonBlock key={i} className="h-2 w-8" />
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="mt-3 flex items-center gap-4">
        <div className="flex items-center gap-1.5">
          <SkeletonBlock className="h-2.5 w-2.5 rounded-full" />
          <SkeletonBlock className="h-2.5 w-14" />
        </div>
        <div className="flex items-center gap-1.5">
          <SkeletonBlock className="h-2.5 w-2.5 rounded-full" />
          <SkeletonBlock className="h-2.5 w-16" />
        </div>
      </div>
    </div>
  );
}

/** Full dashboard skeleton — mirrors the real Dashboard layout */
export default function DashboardSkeleton() {
  return (
    <div className="flex w-full flex-col gap-6">
      {/* Header */}
      <header className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 flex-1">
          <SkeletonBlock className="h-7 w-64" />
          <SkeletonBlock className="mt-2 h-3.5 w-80" />
        </div>
        {/* Month picker placeholder */}
        <SkeletonBlock className="h-9 w-36 rounded-lg" />
      </header>

      {/* KPI Cards */}
      <KpiCardsSkeleton />

      {/* Charts row */}
      <section className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <BarChartSkeleton />
        <PieChartSkeleton />
      </section>

      {/* Day-wise line chart */}
      <LineChartSkeleton />
    </div>
  );
}