import { Skeleton } from 'antd';
import { motion } from 'framer-motion';

export interface AllInsightCardProps {
  insights: string[];
  loading: boolean;
  animationDelay?: number;
}

/**
 * AI-generated narrative insights for the dashboard.
 */
export default function AllInsightCard({
  insights,
  loading,
  animationDelay = 0.9,
}: AllInsightCardProps) {
  return (
    <motion.div
      className="box-border flex w-full min-w-0 flex-col gap-4 bg-white p-6 transition-all duration-200 max-md:p-4 rounded-[var(--card-radius,12px)] shadow-[var(--card-shadow,0_2px_8px_rgba(0,0,0,0.08))] border border-[var(--border-color,#e2e8f0)] hover:shadow-[0_4px_16px_rgba(0,0,0,0.12)]"
      initial={{ opacity: 0, scale: 0.9, y: 20 }}
      animate={{
        opacity: 1,
        scale: 1,
        y: 0,
        transition: { duration: 0.4, ease: [0.4, 0, 0.2, 1], delay: animationDelay },
      }}
      exit={{
        opacity: 0,
        scale: 0.85,
        y: -20,
        transition: { duration: 0.3 },
      }}
      whileHover={{
        scale: 1.01,
        y: -2,
        transition: { duration: 0.2 },
      }}
      whileTap={{ scale: 0.99 }}
    >
      <div className="mb-2 flex items-center gap-3">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden>
          <path
            d="M12 2L2 7L12 12L22 7L12 2Z"
            stroke="#1351cd"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M2 17L12 22L22 17"
            stroke="#1351cd"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M2 12L12 17L22 12"
            stroke="#1351cd"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
        <h3 className="m-0 text-lg font-semibold text-[var(--text-primary)]">
          AI-Generated Insights
        </h3>
      </div>
      <div className="flex flex-col gap-4">
        {loading ? (
          <Skeleton active paragraph={{ rows: 4 }} />
        ) : insights.length === 0 ? (
          <p className="m-0 text-sm leading-[1.6] text-[var(--text-primary)]">
            No insights available for this period.
          </p>
        ) : (
          insights.map((text, idx) => (
            <p
              key={idx}
              className="m-0 text-sm leading-[1.6] text-[var(--text-primary)] [&_strong]:font-semibold [&_strong]:text-[#1351cd]"
            >
              {text}
            </p>
          ))
        )}
      </div>
    </motion.div>
  );
}
