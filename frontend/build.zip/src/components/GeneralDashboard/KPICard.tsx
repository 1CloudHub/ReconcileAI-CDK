import { motion } from 'framer-motion';

export interface KPICardProps {
  label: string;
  /** Pre-formatted value string */
  value: string;
  /** 0-based index for stagger animation */
  animationIndex: number;
}

const delayForIndex = (i: number): number => 0.1 * (i + 1);

/**
 * Single KPI metric tile on the general dashboard.
 */
export default function KPICard({ label, value, animationIndex }: KPICardProps) {
  return (
    <motion.div
      className="w-full min-w-0 bg-white p-5 rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-slate-200/80 flex flex-col justify-center transition-shadow duration-200 hover:shadow-[0_4px_12px_rgba(0,0,0,0.08)]"
      initial={{ opacity: 0, scale: 0.95, y: 10 }}
      animate={{
        opacity: 1,
        scale: 1,
        y: 0,
        transition: { duration: 0.3, ease: 'easeOut', delay: delayForIndex(animationIndex) },
      }}
      exit={{
        opacity: 0,
        scale: 0.95,
        y: -10,
        transition: { duration: 0.2 },
      }}
    >
      <div className="text-[13px] font-medium text-slate-500">{label}</div>
      <div className="mt-2 text-2xl font-semibold text-slate-900 leading-none tracking-tight">{value}</div>
    </motion.div>
  );
}
