export { default } from '../ui/DashboardSkeleton';
export { default as ListPageTableSkeleton } from '../ui/ListPageTableSkeleton';
export type { ListPageTableSkeletonProps } from '../ui/ListPageTableSkeleton';
