import type { ReactNode } from 'react';
import { motion } from 'framer-motion';

export interface ChartCardProps {
  title: string;
  /** Framer motion stagger delay in seconds */
  animationDelay: number;
  children: ReactNode;
}

/**
 * White card wrapper with title for Recharts blocks on the general dashboard.
 */
export default function ChartCard({ title, animationDelay, children }: ChartCardProps) {
  return (
    <motion.div
      className="box-border w-full min-w-0 bg-white p-6 max-md:p-4 rounded-[var(--card-radius,12px)] shadow-[var(--card-shadow,0_2px_8px_rgba(0,0,0,0.08))] border border-[var(--border-color,#e2e8f0)]"
      initial={{ opacity: 0, scale: 0.9, y: 20 }}
      animate={{
        opacity: 1,
        scale: 1,
        y: 0,
        transition: { duration: 0.4, ease: [0.4, 0, 0.2, 1], delay: animationDelay },
      }}
      exit={{
        opacity: 0,
        scale: 0.85,
        y: -20,
        transition: { duration: 0.3 },
      }}
      whileHover={{
        scale: 1.01,
        y: -2,
        transition: { duration: 0.2 },
      }}
      whileTap={{ scale: 0.99 }}
    >
      <h3 className="text-[16px] font-semibold text-[var(--text-primary)] mb-4">{title}</h3>
      {children}
    </motion.div>
  );
}
