import { type ReactNode } from 'react';
import TopNav from '../TopNav/TopNav';
import SideNav from '../SideNav/SideNav';
// import AppFooter from './AppFooter';

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="flex min-h-screen flex-col bg-[#f3f6fb] text-slate-900">
      <TopNav />
      <div className="flex min-h-0 flex-1 bg-[#f3f6fb]">
        <div className="relative z-10"><SideNav /></div>
        <main className="mx-auto w-full max-w-[1600px] flex-1 overflow-y-auto bg-[#f3f6fb] p-6 pb-[4.5rem] max-md:p-4 max-md:pb-[4.5rem] max-[480px]:p-3 max-[480px]:pb-20">
          {children}
        </main>
      </div>
      {/* <AppFooter /> */}
    </div>
  );
}
