import oneCloudHubLogo from '../../assets/1ch.png';
import reconcileLogo from '../../assets/Blue ReconcileAI logo.png';

export default function AppFooter() {
  return (
    <footer className="fixed bottom-0 left-0 right-0 z-30 border-t border-slate-200/90 bg-white px-4 py-2 shadow-[0_-1px_0_rgba(15,23,42,0.04)] max-[480px]:px-3">
      <div className="mx-auto flex w-full max-w-[1600px] flex-col gap-2 sm:flex-row sm:items-center sm:justify-between sm:gap-4">
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-slate-500 sm:text-xs">Reserved by</span>
          <img
            src={oneCloudHubLogo}
            alt="1cloudhub"
            className="h-5 w-auto max-w-[120px] object-contain object-left sm:h-6 sm:max-w-[140px]"
          />
        </div>
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
          <span className="text-[11px] text-slate-500 sm:text-xs">Powered by</span>
          <img
            src={reconcileLogo}
            alt="ReconcileAI"
            className="h-4 w-auto max-w-[100px] object-contain sm:h-[18px] sm:max-w-[94px]"
          />
        </div>
      </div>
    </footer>
  );
}
