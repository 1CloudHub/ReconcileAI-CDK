import { useCallback, useEffect, useRef, useState } from 'react';
import { API_URLS } from '../config/api.config';
import { apiRequest } from '../services/api';

export type DocumentTypeOption = {
  id: number;
  name: string;
};

export type JobItem = {
  id: number;
  job_name: string;
  document_id: number[];
  document_count?: number;
  master_document_id?: number;
  reference_document_id?: number | null;
  reference_document_name?: string | null;
  document_names?: string[];
  created_at?: string;
  created_by?: string;
  updated_at?: string;
  updated_by?: string;
  delete_status?: boolean;
};

export type ListPaginationMeta = {
  page: number;
  page_size: number;
  total: number;
  total_pages: number;
  has_next?: boolean;
  has_prev?: boolean;
};

export type ListJobsParams = {
  page?: number;
  page_size?: number;
  job_name?: string;
  created_by?: string;
  document_name?: string;
};

export type ListDocumentTypesParams = {
  page?: number;
  page_size?: number;
  document_name?: string;
  document_description?: string;
  created_from?: string;
  created_to?: string;
};

type ApiEnvelope<T> = {
  success?: boolean;
  message?: string;
  data?: T;
  jobs?: JobItem[];
  sops?: unknown;
  result?: unknown;
  pagination?: unknown;
  document_type?: Array<Record<string, unknown>>;
  document_types?: Array<Record<string, unknown>>;
  [key: string]: unknown;
};

async function postConfig<T>(payload: Record<string, unknown>): Promise<ApiEnvelope<T>> {
  return apiRequest<ApiEnvelope<T>, Record<string, unknown>>(API_URLS.CONFIG, {
    method: 'POST',
    body: payload,
  });
}

function normalizeDocumentOption(item: Record<string, unknown>): DocumentTypeOption | null {
  const idCandidate = item.id ?? item.document_id ?? item.doc_id;
  const nameCandidate = item.document_type ?? item.document_name ?? item.name ?? item.label;

  const id = Number(idCandidate);
  if (!Number.isFinite(id) || !nameCandidate) return null;

  return { id, name: String(nameCandidate) };
}

function parseListPagination(raw: unknown): ListPaginationMeta | null {
  if (!raw || typeof raw !== 'object') return null;
  const o = raw as Record<string, unknown>;
  const page = Number(o.page);
  const page_size = Number(o.page_size);
  const total = Number(o.total);
  const total_pages = Number(o.total_pages);
  if (![page, page_size, total, total_pages].every((n) => Number.isFinite(n))) return null;
  return {
    page,
    page_size,
    total,
    total_pages,
    ...(typeof o.has_next === 'boolean' ? { has_next: o.has_next } : {}),
    ...(typeof o.has_prev === 'boolean' ? { has_prev: o.has_prev } : {}),
  };
}

function extractNamesFromBackendMappingList(raw: unknown): string[] {
  const extractFromString = (s: string): string | null => {
    // Backend sends items like: "{'id': 37, 'name': 'SOP name'}"
    const m = s.match(/name'\s*:\s*'([^']*)'/);
    if (m?.[1]) return m[1];

    const m2 = s.match(/name"\s*:\s*"([^"]*)"/);
    if (m2?.[1]) return m2[1];

    return null;
  };

  if (Array.isArray(raw)) {
    return raw
      .map((item) => (typeof item === 'string' ? extractFromString(item) : null))
      .filter((n): n is string => Boolean(n));
  }

  if (typeof raw === 'string') {
    const names: string[] = [];
    for (const match of raw.matchAll(/name'\s*:\s*'([^']*)'/g)) {
      const name = match?.[1];
      if (typeof name === 'string' && name.trim()) names.push(name.trim());
    }
    return names;
  }

  return [];
}

export default function useJobConfig() {
  const [jobs, setJobs] = useState<JobItem[]>([]);
  const [documentTypeOptions, setDocumentTypeOptions] = useState<DocumentTypeOption[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [jobsPagination, setJobsPagination] = useState<ListPaginationMeta | null>(null);
  const [documentTypesPagination, setDocumentTypesPagination] = useState<ListPaginationMeta | null>(null);
  const lastListJobsParamsRef = useRef<ListJobsParams | undefined>(undefined);

  const fetchJobs = useCallback(async (params?: ListJobsParams) => {
    const effective: ListJobsParams =
      params !== undefined ? { ...params } : { ...(lastListJobsParamsRef.current ?? {}) };

    if (params !== undefined) {
      lastListJobsParamsRef.current = effective;
    }

    setLoading(true);
    setError(null);
    try {
      const body: Record<string, unknown> = { event_type: 'list_jobs' };
      const page = effective.page;
      const pageSize = effective.page_size;
      if (page != null && Number.isFinite(page)) body.page = page;
      if (pageSize != null && Number.isFinite(pageSize)) body.page_size = pageSize;
      const jobName = effective.job_name?.trim();
      if (jobName) body.job_name = jobName;
      const createdBy = effective.created_by?.trim();
      if (createdBy) body.created_by = createdBy;
      const documentName = effective.document_name?.trim();
      if (documentName) body.document_name = documentName;

      const result = await postConfig<{ jobs?: JobItem[] }>(body);
      const payloadJobs = Array.isArray(result.jobs)
        ? result.jobs
        : Array.isArray(result.result)
          ? (result.result as JobItem[])
        : Array.isArray(result.data?.jobs)
          ? result.data.jobs
          : [];
      setJobs(payloadJobs);
      setJobsPagination(parseListPagination(result.pagination));
      return payloadJobs;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load jobs';
      setError(message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchDocumentTypes = useCallback(async (params?: ListDocumentTypesParams) => {
    setError(null);
    try {
      const result = await postConfig<{ document_type?: Array<Record<string, unknown>> }>({
        event_type: 'list_document_type',
        ...params,
      });
      const payloadList = Array.isArray(result.document_type)
        ? result.document_type
        : Array.isArray(result.document_types)
          ? result.document_types
          : Array.isArray(result.result)
            ? (result.result as Array<Record<string, unknown>>)
          : Array.isArray(result.data?.document_type)
            ? result.data.document_type
            : [];

      setDocumentTypesPagination(parseListPagination(result.pagination));

      const normalized = payloadList
        .map((item) => normalizeDocumentOption(item))
        .filter((item): item is DocumentTypeOption => Boolean(item));
      setDocumentTypeOptions(normalized);
      return normalized;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load document types';
      setError(message);
      throw err;
    }
  }, []);

  const createJob = useCallback(
    async (
      jobName: string,
      documentIds: number[],
      documentCount: number,
      masterDocumentId: number | undefined,
      createdBy: string,
    ) => {
      const result = await postConfig({
        event_type: 'create_job',
        job_name: jobName,
        document_id: documentIds,
        document_count: documentCount,
        reference_document_id: masterDocumentId ?? null,
        created_by: createdBy,
      });

      const statusCode =
        typeof result.status_code === 'number'
          ? result.status_code
          : typeof result.statusCode === 'number'
            ? result.statusCode
            : undefined;
      const msg = typeof result.message === 'string' ? result.message : '';

      if (statusCode && statusCode >= 400) {
        throw new Error(msg || 'Failed to create job');
      }

      await fetchJobs();
      return result;
    },
    [fetchJobs]
  );

  const editJob = useCallback(
    async (
      id: number,
      jobName: string,
      documentIds: number[],
      documentCount: number,
      masterDocumentId: number | undefined,
      updatedBy: string,
    ) => {
      const result = await postConfig({
        event_type: 'edit_job',
        id,
        job_name: jobName,
        document_id: documentIds,
        document_count: documentCount,
        reference_document_id: masterDocumentId ?? null,
        updated_by: updatedBy,
      });

      const statusCode =
        typeof result.status_code === 'number'
          ? result.status_code
          : typeof result.statusCode === 'number'
            ? result.statusCode
            : undefined;
      const msg = typeof result.message === 'string' ? result.message : '';

      if (statusCode && statusCode >= 400) {
        throw new Error(msg || 'Failed to edit job');
      }

      await fetchJobs();
      return result;
    },
    [fetchJobs]
  );

  const deleteJob = useCallback(
    async (id: number) => {
      const result = await postConfig({
        event_type: 'delete_job',
        id,
      });

      const statusCode =
        typeof result.status_code === 'number'
          ? result.status_code
          : typeof result.statusCode === 'number'
            ? result.statusCode
            : undefined;
      const msg = typeof result.message === 'string' ? result.message : '';

      if (statusCode && statusCode >= 400) {
        if (statusCode === 409) {
          const sopNames = extractNamesFromBackendMappingList(result.sops);
          if (sopNames.length > 0) {
            throw new Error(
              `Job is mapped to sop(s): ${sopNames.join(', ')}. Remove the sop(s) before deleting this job.`,
            );
          }
        }

        throw new Error(msg || 'Failed to delete job');
      }

      await fetchJobs();
      return result;
    },
    [fetchJobs]
  );

  useEffect(() => {
    void fetchDocumentTypes();
  }, [fetchDocumentTypes]);

  return {
    jobs,
    documentTypeOptions,
    loading,
    error,
    jobsPagination,
    documentTypesPagination,
    fetchJobs,
    fetchDocumentTypes,
    createJob,
    editJob,
    deleteJob,
  };
}
