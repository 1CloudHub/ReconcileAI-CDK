import { useCallback, useState } from 'react';
import { pollReconcileUntilTerminal } from '../services/reconcileSessions';
import { refreshTokenUsageFromApi } from '../services/showTokens';
import { useTokenUsageWhileAiRunning } from './useTokenUsageWhileAiRunning';

/**
 * After `reconcile_documents` has been submitted:
 *  - sets `isAiRunning` to true so the token bar polls every 15 s
 *  - polls until a terminal reconcile status
 *  - fires one final token refresh and clears `isAiRunning`
 *
 * Returns `{ scheduleTokenRefreshAfterPoll, isAiRunning }`.
 * Pass `isAiRunning` to any component that needs to know AI is active
 * (the polling hook is wired internally here).
 */
export function useRefreshTokensAfterReconcilePoll() {
  const [isAiRunning, setIsAiRunning] = useState(false);

  useTokenUsageWhileAiRunning(isAiRunning);

  const scheduleTokenRefreshAfterPoll = useCallback((sessionId: string) => {
    setIsAiRunning(true);
    void pollReconcileUntilTerminal(sessionId, { useSessionTable: true }).finally(() => {
      setIsAiRunning(false);
      void refreshTokenUsageFromApi();
    });
  }, []);

  return { scheduleTokenRefreshAfterPoll, isAiRunning };
}
