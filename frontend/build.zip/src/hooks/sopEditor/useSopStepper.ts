import { message } from 'antd';
import { useRef, useState } from 'react';
import {
  deleteTestSop,
  pollReconcileUntilTerminal,
  reconcileDocuments,
  removeTestSession,
  type ReconcileDocumentsPayload,
  reconcileUploadFileViaLambda,
} from '../../services/reconcileSessions';
import { refreshTokenUsageFromApi } from '../../services/showTokens';
import {
  parseAddSopResponseWithS3Key,
  updateSop,
  uploadSopTest,
} from '../../services/SOP_config';
import { uploadFileToS3ViaLambda } from '../../utils/fileUpload';
import { createdByFromSession } from './sopEditorHelpers';
import type { VersionRow } from './sopEditorHelpers';
import type { PollStatusResult } from '../../layout/SOPConfig/SOPStepper';

type Deps = {
  isEditMode: boolean;
  sopId: number | null;
  exceptionName: string;
  selectedJobIds: number[];
  refreshVersions: () => void;
  setTempSopFile: (f: File | null) => void;
  setTempSopDraftSaved: (v: boolean) => void;
  setTempSopCreatedAt: (v: string | null) => void;
  tempSopDraftSavedRef: React.MutableRefObject<boolean>;
};

/**
 * useSopStepper — drives the multi-step "Test SOP" stepper modal.
 *
 * The stepper lets the user:
 *  1. Upload a (possibly new) SOP file.
 *  2. Upload sample documents to reconcile against it.
 *  3. See the reconciliation result.
 *  4. Click Done / Skip to persist or discard the test.
 *
 * There are two contexts this hook is used in:
 *  ADD mode  — the test is a preflight. If the user clicks Done, the file
 *              is remembered as a "draft" (tempSopDraftSaved=true). The
 *              actual addSop() call happens later in useTempSopDraft when
 *              the user clicks "Create SOP".
 *  EDIT mode — "Upload New SOP Version" opens the stepper. If the user
 *              clicks Done, we call updateSop() immediately to persist the
 *              new version. Row-level "Test SOP" (onTestExistingVersion)
 *              does NOT persist on Done.
 *
 * shouldPersistEditSopOnDoneRef controls whether Done → saveEditMode().
 * It's set to true only when the user uploaded a new file inside the stepper
 * (onUploadSop), not when testing an existing saved version.
 *
 * WHY refs instead of state for session/file tracking:
 *   These values are read inside async callbacks (onDone, onClose, onTestSop).
 *   Using state would capture stale closures; refs always reflect the latest value.
 */
export function useSopStepper({
  isEditMode,
  sopId,
  exceptionName,
  selectedJobIds,
  refreshVersions,
  setTempSopFile,
  setTempSopDraftSaved,
  setTempSopCreatedAt,
  tempSopDraftSavedRef,
}: Deps) {
  const [sopStepperOpen, setSopStepperOpen] = useState(false);

  // Refs hold volatile state that must be current inside async event handlers.
  const testSessionIdRef = useRef<string | null>(null);
  const sopTestFileNameRef = useRef<string | null>(null);
  const sopTestFileRef = useRef<File | null>(null);       // null when testing an existing version
  const sopTestS3UriRef = useRef<string | null>(null);    // set when testing an existing saved version
  // True only when the test flow came from "Upload New SOP Version" (edit mode).
  const shouldPersistEditSopOnDoneRef = useRef(false);
  const stepperDoneRef = useRef(false);

  /**
   * In add mode, marks the drafted file as ready so the "Create SOP" button
   * becomes active. The file isn't sent to the real SOP endpoint yet — it was
   * only tested via the uploadSopTest preflight endpoint.
   */
  const markAddModeDraft = () => {
    tempSopDraftSavedRef.current = true;
    setTempSopDraftSaved(true);
    setTempSopCreatedAt(new Date().toLocaleString());
    void message.info('SOP ready. Click Create SOP to save it permanently.');
  };

  /**
   * In edit mode, persists the new version by calling updateSop() to get a
   * presigned S3 PUT URL, uploading the file bytes to S3, then refreshing the
   * version history table to show the new row.
   */
  const saveEditMode = (fileName: string, file: File | null) => {
    if (sopId == null) return;
    void updateSop(sopId, createdByFromSession(), { filename: fileName })
      .then(async (res) => {
        if (file) {
          const { s3Key } = parseAddSopResponseWithS3Key(res);
          await uploadFileToS3ViaLambda({ file, s3Key });
        }
        void message.success('SOP document saved.');
        refreshVersions();
      })
      .catch((err: unknown) => {
        void message.error(err instanceof Error ? err.message : 'Failed to save SOP');
      });
  };

  /**
   * Called when the user closes the stepper without completing it (X button).
   * - Clears the draft state if they hadn't already clicked Done.
   * - Calls deleteTestSop() to remove the temporary test file from S3 / DB.
   *   This is a cleanup-only call; its failure won't block the UI.
   */
  const onClose = () => {
    stepperDoneRef.current = false;
    if (!tempSopDraftSavedRef.current) {
      // User closed without finishing — discard the in-progress file.
      sopTestFileNameRef.current = null;
      setTempSopFile(null);
      setTempSopCreatedAt(null);
    }
    // Reset all volatile refs for the next stepper open.
    tempSopDraftSavedRef.current = false;
    testSessionIdRef.current = null;
    sopTestS3UriRef.current = null;
    shouldPersistEditSopOnDoneRef.current = false;
    void deleteTestSop(exceptionName.trim(), createdByFromSession());
    setSopStepperOpen(false);
  };

  /**
   * Called when the user clicks Done (completed the test).
   * - Cleans up the test session.
   * - In edit mode: persists the new version if this was an "Upload New SOP Version" flow.
   * - In add mode: marks the draft so the Create SOP button activates.
   */
  const onDone = () => {
    stepperDoneRef.current = true;
    testSessionIdRef.current = null;
    sopTestS3UriRef.current = null;
    void deleteTestSop(exceptionName.trim(), createdByFromSession());
    if (isEditMode) {
      const fileName = sopTestFileNameRef.current;
      const file = sopTestFileRef.current;
      sopTestFileNameRef.current = null;
      sopTestFileRef.current = null;
      // Only persist if this was the "Upload New Version" path, not row-level test.
      if (shouldPersistEditSopOnDoneRef.current && fileName) {
        saveEditMode(fileName, file);
      }
      shouldPersistEditSopOnDoneRef.current = false;
    } else {
      markAddModeDraft();
    }
  };

  /**
   * Called when the user clicks Skip (runs the stepper without testing).
   * Behaves like Done for persistence purposes — the file is still saved
   * if it was an "Upload New Version" flow.
   */
  const onSkip = () => {
    if (isEditMode) {
      const fileName = sopTestFileNameRef.current;
      const file = sopTestFileRef.current;
      sopTestFileNameRef.current = null;
      sopTestFileRef.current = null;
      if (shouldPersistEditSopOnDoneRef.current && fileName) {
        saveEditMode(fileName, file);
      }
      shouldPersistEditSopOnDoneRef.current = false;
    } else {
      markAddModeDraft();
    }
  };

  /**
   * Step 1 of the stepper: the user picks a file.
   * Uses uploadSopTest() (a preflight endpoint) — NOT addSop() — so the file
   * is staged in a temporary location and can be deleted if the user cancels.
   * The real addSop() / updateSop() only runs when the user confirms.
   */
  const onUploadSop = async (file: File) => {
    setTempSopFile(file);
    // Flag that Done/Skip should persist this file via saveEditMode (edit mode).
    shouldPersistEditSopOnDoneRef.current = true;
    const res = await uploadSopTest(
      exceptionName.trim(),
      selectedJobIds,
      [file.name],
      createdByFromSession()
    );
    const { s3Key } = parseAddSopResponseWithS3Key(res);
    await uploadFileToS3ViaLambda({ file, s3Key });
    sopTestFileNameRef.current = file.name;
    sopTestFileRef.current = file;
  };

  /**
   * Opens the stepper to test an already-saved version (row action button).
   * shouldPersistEditSopOnDoneRef is left false because the version is already
   * saved — Done should NOT trigger another updateSop() call.
   */
  const onTestExistingVersion = async (record: VersionRow) => {
    // Row-level "Test SOP" should not overwrite current SOP on Done.
    shouldPersistEditSopOnDoneRef.current = false;
    sopTestFileNameRef.current = record.sopName;
    sopTestFileRef.current = null;
    sopTestS3UriRef.current = record.s3Uri ?? null;
    // Do not call upload_sop_test — the saved S3 URI is used directly in reconcile_documents.
    setSopStepperOpen(true);
  };

  /**
   * The main reconciliation step — runs inside the stepper after files are uploaded.
   *
   * Flow:
   *  1. Generate a unique session ID (UUID) for this test run.
   *  2. Upload the SOP file to the reconcile session bucket via a presigned PUT:
   *     - If a new File was provided (sopTestFileRef), upload it fresh.
   *     - If testing an existing version (sopTestS3UriRef), use the stored S3 URI directly
   *       so we don't re-upload the whole file.
   *  3. Upload all user-provided comparison documents in parallel.
   *  4. Call reconcileDocuments() with sub_flag='testing' to trigger the Lambda.
   *     WHY we swallow the error: API Gateway has a 29 s timeout; the Lambda
   *     often exceeds this for large documents. The call is fire-and-forget —
   *     actual results come from polling.
   *  5. Poll document_poll-status (session_table_test vs session_table via use_session_table) until terminal
   *     ('yes', 'no', 'failed', 'validation_failed', 'validation_status').
   *  6. Return a PollStatusResult so the stepper component can render the outcome.
   */
  const onTestSop = async (
    _filesByDocIndex: Record<number, File>,
    _docNames: string[]
  ): Promise<PollStatusResult> => {
    const sessionId = `test-${crypto.randomUUID()}`;
    testSessionIdRef.current = sessionId;

    const jobId = selectedJobIds[0];
    const createdBy = createdByFromSession();

    const testType = !isEditMode
      ? 'new_sop_testing'
      : shouldPersistEditSopOnDoneRef.current
        ? 'new_sop_version_testing'
        : 'existing_sop_testing';

    const documents: Record<string, string> = {};

    // Upload SOP file to reconcile session (only when a File object is available).
    // For existing versions, use the already-stored S3 URI directly.
    const sopFile = sopTestFileRef.current;
    const existingS3Uri = sopTestS3UriRef.current;
    if (sopFile) {
      const uploaded = await reconcileUploadFileViaLambda(sessionId, sopFile);
      documents['sop'] = uploaded.s3Uri ?? '';
    } else if (existingS3Uri) {
      documents['sop'] = existingS3Uri;
    }

    // Upload all comparison documents in parallel — each gets its own presigned URL.
    await Promise.all(
      Object.entries(_filesByDocIndex).map(async ([idxStr, file]) => {
        const idx = Number(idxStr);
        const docName = _docNames[idx] ?? file.name;
        const uploaded = await reconcileUploadFileViaLambda(sessionId, file);
        documents[docName] = uploaded.s3Uri ?? '';
      })
    );

    try {
      const payload: ReconcileDocumentsPayload = {
        event_type: 'reconcile_documents',
        job_id: jobId,
        session_id: sessionId,
        created_by: createdBy,
        documents,
        module: 'sop_control_center',
        type: testType,
      };

      if (testType !== 'existing_sop_testing') {
        payload.sub_flag = 'testing';
      }

      await reconcileDocuments(payload);
    } catch {
      // Expected: Lambda may exceed API Gateway timeout; polling handles progress.
    }

    try {
      const finalRes = await pollReconcileUntilTerminal(sessionId, {
        useSessionTable: testType === 'existing_sop_testing',
      });
      return {
        session_id: sessionId,
        reconcile_status: String(finalRes.reconcile_status ?? ''),
        message: typeof finalRes.message === 'string' ? finalRes.message : undefined,
        reason_for_failure: finalRes.reason_for_failure as PollStatusResult['reason_for_failure'],
        extracted_fields: Array.isArray(finalRes.extracted_fields)
          ? (finalRes.extracted_fields as Array<Record<string, Record<string, string>>>)
          : [],
      };
    } finally {
      if (testType === 'existing_sop_testing') {
        void removeTestSession(sessionId).catch(() => {
          /* cleanup best-effort */
        });
      }
      void refreshTokenUsageFromApi();
    }
  };

  return {
    sopStepperOpen,
    setSopStepperOpen,
    sopTestFileNameRef,
    onClose,
    onDone,
    onSkip,
    onUploadSop,
    onTestSop,
    onTestExistingVersion,
  };
}
