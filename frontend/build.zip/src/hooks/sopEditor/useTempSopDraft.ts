import { message } from 'antd';
import { useMemo, useRef, useState } from 'react';
import type { NavigateFunction } from 'react-router-dom';
import {
  addSop,
  generatePresignedDownloadUrl,
  parseAddSopResponseWithS3Key,
  parsePresignedDownloadUrlResponse,
} from '../../services/SOP_config';
import { createdByFromSession, type FormState, type VersionRow } from './sopEditorHelpers';
import { uploadFileToS3ViaLambda } from '../../utils/fileUpload';

type Deps = {
  isEditMode: boolean;
  exceptionName: string;
  selectedJobIds: number[];
  pagedVersions: VersionRow[];
  errors: FormState['errors'];
  updateForm: (partial: Partial<FormState>) => void;
  navigate: NavigateFunction;
  sopTestFileNameRef: React.MutableRefObject<string | null>;
};

/**
 * useTempSopDraft — manages the "test-then-create" flow in add mode.
 *
 * Background:
 *   In add mode the user can optionally run the SOP through the stepper
 *   (upload → test → done/skip) before officially creating the SOP record.
 *   The stepper uses the `uploadSopTest` preflight endpoint so the file is
 *   staged temporarily. After the stepper completes, useSopStepper calls
 *   setTempSopDraftSaved(true) to signal that a draft is ready.
 *
 *   This hook then:
 *    - Shows a "Draft" row in the table (tempVersionRow).
 *    - Activates the "Create SOP" button.
 *    - Executes the real addSop() + S3 upload when the user clicks Create.
 *
 *   There is also a "direct upload" path (handleDirectFileInputChange) for
 *   users who want to skip the stepper and upload a file straight to addSop().
 *   Both paths converge in handleCreateSop().
 *
 * WHY tempSopDraftSavedRef (in addition to tempSopDraftSaved state):
 *   useSopStepper's onClose/onDone are async callbacks that close over the ref.
 *   React state captured in those closures would be stale. The ref always
 *   holds the current value and is updated in sync with the state.
 *
 * WHY visibleVersions prepends tempVersionRow:
 *   The draft row doesn't exist in the server-fetched list. We prepend it
 *   directly to pagedVersions so it always appears at the top of the table
 *   regardless of pagination or sort order.
 *
 * WHY handlePreviewTempSop uses URL.createObjectURL + setTimeout revoke:
 *   The file is local (not yet on S3) so there's no presigned URL to use.
 *   A blob URL lets the browser open it as if it were a remote file.
 *   We revoke after 10 s — enough time for the tab to load the content —
 *   to free the memory reference. Revoking too early would break the new tab.
 */
export function useTempSopDraft({
  isEditMode,
  exceptionName,
  selectedJobIds,
  pagedVersions,
  errors,
  updateForm,
  navigate,
  sopTestFileNameRef,
}: Deps) {
  // The file staged by the stepper (or selected via direct upload).
  const [tempSopFile, setTempSopFile] = useState<File | null>(null);
  // True once the stepper's Done/Skip has been clicked — activates Create SOP.
  const [tempSopDraftSaved, setTempSopDraftSaved] = useState(false);
  const [tempSopCreatedAt, setTempSopCreatedAt] = useState<string | null>(null);
  const [sopCreateLoading, setSopCreateLoading] = useState(false);

  // Ref mirrors tempSopDraftSaved for use inside async stepper callbacks.
  const tempSopDraftSavedRef = useRef(false);
  // Hidden <input type="file"> for the direct-upload (no-stepper) path.
  const sopCreateFileInputRef = useRef<HTMLInputElement | null>(null);

  /**
   * Computes the "Draft" row to prepend to the table.
   * Returns null when:
   *   - No file is staged yet.
   *   - We're in edit mode (the stepper persists directly in edit mode).
   *   - The user hasn't completed the stepper (draft not saved yet).
   */
  const tempVersionRow = useMemo(() => {
    if (!tempSopFile || isEditMode || !tempSopDraftSaved) return null;
    return {
      key: 'temp-sop',
      versionLabel: 'Draft',
      sopName: tempSopFile.name,
      createdAt: tempSopCreatedAt ?? new Date().toLocaleString(),
      statusLabel: 'Pending',
      file: tempSopFile,
    } as VersionRow;
  }, [tempSopFile, isEditMode, tempSopDraftSaved, tempSopCreatedAt]);

  /**
   * Merges the draft row at the top of the current page.
   * If there's no draft, returns pagedVersions unchanged.
   */
  const visibleVersions = useMemo(() => {
    if (!tempVersionRow) return pagedVersions;
    return [tempVersionRow, ...pagedVersions];
  }, [pagedVersions, tempVersionRow]);

  /** Discards the staged draft — equivalent to the user clicking Remove on the draft row. */
  const handleRemoveTempSop = () => {
    setTempSopFile(null);
    setTempSopDraftSaved(false);
    tempSopDraftSavedRef.current = false;
    setTempSopCreatedAt(null);
  };

  /**
   * Opens the staged (not-yet-uploaded) file for local preview.
   * Uses a blob URL so the browser renders it like a normal file.
   * Falls back to creating an <a> and clicking it if window.open is blocked
   * by a popup blocker.
   * Revokes the blob URL after 10 s to release memory.
   */
  const handlePreviewTempSop = () => {
    if (!tempSopFile) return;
    const blob = new Blob([tempSopFile], { type: tempSopFile.type || 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const opened = window.open(url, '_blank', 'noopener');
    if (!opened) {
      // Popup blocked — fall back to a programmatic link click.
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.target = '_blank';
      anchor.rel = 'noopener noreferrer';
      anchor.click();
    }
    // Revoke after 10 s — enough time for the new tab to load the file.
    setTimeout(() => URL.revokeObjectURL(url), 10000);
  };

  /**
   * Core create flow shared by both the stepper-draft path and the direct-upload path.
   *
   * Steps:
   *  1. Call addSop() to register the SOP record in the DB and receive presigned
   *     S3 PUT URLs. This is the two-step pattern: DB first, then S3.
   *  2. Upload the file bytes directly to S3 via the presigned PUT URL.
   *     Files bypass Lambda here to avoid the 6 MB payload / 29 s timeout limits.
   *  3. Best-effort: generate a presigned GET URL for the uploaded file and
   *     open it in a new tab so the user can immediately verify the upload.
   *     Failure here doesn't block navigation.
   *  4. Navigate to SOP Control Center.
   */
  const handleCreateSop = async (file: File) => {
    setSopCreateLoading(true);
    try {
      // Step 1: Register SOP in DB, get presigned upload URL.
      const res = await addSop(exceptionName.trim(), selectedJobIds, [file.name], createdByFromSession());
      const { s3Key, raw } = parseAddSopResponseWithS3Key(res);

      // Step 2: Upload file via Lambda to avoid S3 CORS.
      await uploadFileToS3ViaLambda({ file, s3Key });

      // Step 3 (best-effort): open the just-uploaded file for verification.
      const uploadUrls = Array.isArray(raw.upload_urls) ? raw.upload_urls : [];
      const firstTarget = uploadUrls[0];
      const s3Uri =
        firstTarget != null &&
        typeof firstTarget === 'object' &&
        typeof (firstTarget as Record<string, unknown>).s3_uri === 'string'
          ? String((firstTarget as Record<string, unknown>).s3_uri)
          : '';
      if (s3Uri) {
        try {
          const dlRes = await generatePresignedDownloadUrl(s3Uri);
          const dlUrl = parsePresignedDownloadUrlResponse(dlRes);
          window.open(dlUrl, '_blank');
        } catch {
          // Non-fatal — the SOP was created successfully; preview is best-effort.
        }
      }

      // Cleanup and navigate away.
      setTempSopFile(null);
      sopTestFileNameRef.current = null;
      navigate('/sop-control-center', { replace: true });
    } catch (err) {
      void message.error(err instanceof Error ? err.message : 'Failed to create SOP');
    } finally {
      setSopCreateLoading(false);
    }
  };

  /**
   * Called when the "Create SOP" button is clicked.
   * Validates the form fields, then either:
   *  - Uses the staged tempSopFile (from the stepper draft path), or
   *  - Shows an error if no file has been provided yet.
   */
  const handleCreateSopClick = () => {
    const nextErrors: typeof errors = { ...errors };
    if (!exceptionName.trim()) nextErrors.exceptionName = 'Exception name is required';
    if (selectedJobIds.length === 0) nextErrors.jobId = 'Please select a job';
    if (nextErrors.exceptionName || nextErrors.jobId) {
      updateForm({ errors: nextErrors });
      return;
    }
    if (tempSopFile) {
      void handleCreateSop(tempSopFile);
      return;
    }
    void message.error('Please upload an SOP document before creating.');
  };

  /**
   * onChange handler for the hidden <input type="file"> on the direct-upload button.
   * Validates the form before uploading so the user gets field errors immediately
   * rather than after a failed API call.
   * Clears the input value after reading so the same file can be re-selected.
   */
  const handleDirectFileInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // allow re-picking the same file
    if (!file) return;
    const nextErrors: typeof errors = { ...errors };
    if (!exceptionName.trim()) nextErrors.exceptionName = 'Exception name is required';
    if (selectedJobIds.length === 0) nextErrors.jobId = 'Please select a job';
    if (nextErrors.exceptionName || nextErrors.jobId) {
      updateForm({ errors: nextErrors });
      return;
    }
    await handleCreateSop(file);
  };

  return {
    tempSopFile,
    setTempSopFile,
    tempSopDraftSaved,
    setTempSopDraftSaved,
    tempSopCreatedAt,
    setTempSopCreatedAt,
    tempSopDraftSavedRef,
    sopCreateFileInputRef,
    sopCreateLoading,
    tempVersionRow,
    visibleVersions,
    handleRemoveTempSop,
    handlePreviewTempSop,
    handleCreateSopClick,
    handleDirectFileInputChange,
  };
}
