import { FileText, Trash2,InspectionPanel } from 'lucide-react';
import { Tooltip } from 'antd';
import { useMemo } from 'react';
import type { MouseEvent as ReactMouseEvent } from 'react';
import SelectInput from '../../components/ui/SelectInput';
import type { VersionRow } from './sopEditorHelpers';

type Deps = {
  isEditMode: boolean;
  handleVersionStatusChange: (record: VersionRow, status: string) => void;
  openVersionDocument: (record: VersionRow) => void;
  openVersionDeleteModal: (record: VersionRow, e: ReactMouseEvent<HTMLButtonElement>) => void;
  handlePreviewTempSop: () => void;
  handleRemoveTempSop: () => void;
  onTestExistingVersion?: (record: VersionRow) => void;
};

/**
 * useSopVersionColumns — builds the column definitions for the Ant Design
 * Table that shows the SOP version history.
 *
 * WHY a hook instead of a plain constant:
 *   Columns contain render functions that close over action callbacks
 *   (handleVersionStatusChange, openVersionDocument, etc.). useMemo ensures
 *   those column objects are only recreated when the callbacks actually change,
 *   preventing unnecessary re-renders of all table rows.
 *
 * Column structure differs between add mode and edit mode:
 *   ADD mode:   SOP Document Name | Created At | Actions
 *   EDIT mode:  Version | SOP Document Name | Created At | Status | Actions
 *
 *   The Version column is prepended (unshift) and Status is added only in
 *   edit mode because add-mode rows don't have real version numbers yet.
 *
 * Special row key='temp-sop':
 *   The draft row shown after a test-then-skip/done flow uses a stripped-down
 *   Actions cell (preview + remove only) because it has no s3Uri and is not
 *   yet a real saved version. The full Actions cell (view + test + delete)
 *   is shown for all other rows.
 *
 * Status column logic:
 *   Rows with a real numeric version and a non-terminal status (not Deleted,
 *   not Pending) show an interactive SelectInput dropdown so the user can
 *   toggle Active/Inactive inline. All other rows show a read-only badge.
 *   This avoids showing an edit dropdown on rows where the API wouldn't
 *   accept a status change anyway.
 *
 * Test SOP button:
 *   Only rendered when onTestExistingVersion is provided AND the row has an
 *   s3Uri (saved, non-draft version). Draft rows and add-mode rows cannot
 *   be tested via the row action.
 */
export function useSopVersionColumns({
  isEditMode,
  handleVersionStatusChange,
  openVersionDocument,
  openVersionDeleteModal,
  handlePreviewTempSop,
  handleRemoveTempSop,
  onTestExistingVersion,
}: Deps) {
  return useMemo(() => {
    const cols: Array<Record<string, unknown>> = [
      { title: 'SOP Document Name', dataIndex: 'sopName', key: 'sopName' },
      { title: 'Created At', dataIndex: 'createdAt', key: 'createdAt' },
    ];

    if (isEditMode) {
      // Version column only makes sense in edit mode where rows have real version numbers.
      cols.unshift({ title: 'Version', dataIndex: 'versionLabel', key: 'version', width: 96 });

      cols.push({
        title: 'Status',
        key: 'status',
        width: 150,
        render: (_: unknown, record: VersionRow) => {
          const s = record.statusLabel;
          // Only rows with a valid numeric version and non-terminal status can
          // have their status changed via the dropdown.
          const canEditStatus =
            typeof record.version === 'number' &&
            Number.isFinite(record.version) &&
            s !== 'Deleted' &&
            s !== 'Pending';
          const value = s === 'Active' ? 'Active' : 'Inactive';

          if (!canEditStatus) {
            // Read-only badge: colour-coded for quick scanning.
            const cls =
              s === 'Deleted'
                ? 'bg-red-50 text-red-800 ring-red-600/20'
                : s === 'Pending'
                  ? 'bg-amber-50 text-amber-900 ring-amber-600/20'
                  : value === 'Active'
                    ? 'bg-emerald-50 text-emerald-800 ring-emerald-600/20'
                    : 'bg-red-50 text-red-700 ring-red-600/20';
            return (
              <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ${cls}`}>
                {s}
              </span>
            );
          }

          // Interactive dropdown for rows that can be activated/deactivated.
          return (
            <SelectInput
              useDefaultWidth={false}
              value={value}
              options={[
                { label: 'Active', value: 'Active' },
                { label: 'Inactive', value: 'Inactive' },
              ]}
              className={`w-[98px] [&_.ant-select-selector]:!h-8 [&_.ant-select-selector]:!min-h-8 ${
                value === 'Active'
                  ? '[&_.ant-select-selection-item]:text-emerald-700 text-emerald-700'
                  : '[&_.ant-select-selection-item]:text-red-600 text-red-600'
              }`}
              onChange={(next) => {
                handleVersionStatusChange(record, String(next ?? ''));
              }}
            />
          );
        },
      });
    }

    cols.push({
      title: 'Actions',
      key: 'actions',
      render: (_: unknown, record: VersionRow) => {
        // The 'temp-sop' row is a local draft that hasn't been saved yet.
        // It only supports preview and remove — no test or delete API call.
        if (record.key === 'temp-sop') {
          return (
            <div className="flex items-center gap-2 text-slate-500">
              <button
                type="button"
                className="inline-flex rounded p-1 hover:bg-slate-100"
                aria-label="Open temporary SOP"
                onClick={handlePreviewTempSop}
              >
                <FileText size={15} />
              </button>
              <button
                type="button"
                className="inline-flex rounded p-1 hover:bg-slate-100"
                aria-label="Remove temporary SOP"
                onClick={handleRemoveTempSop}
              >
                <Trash2 size={15} />
              </button>
            </div>
          );
        }

        // Standard row: view document, optionally test, and delete.
        return (
          <div className="flex items-center gap-2 text-slate-500">
            <Tooltip title="View document">
              <button
                type="button"
                className="inline-flex rounded p-1 hover:bg-slate-100"
                aria-label="Open document"
                onClick={() => openVersionDocument(record)}
              >
                <FileText size={15} />
              </button>
            </Tooltip>
            {/* Test button: only for saved versions (s3Uri present) in edit mode */}
            {onTestExistingVersion && record.s3Uri && (
              <Tooltip title="Test SOP document">
                <button
                  type="button"
                  className="inline-flex rounded p-1 hover:bg-slate-100"
                  aria-label="Test SOP"
                  onClick={() => void onTestExistingVersion(record)}
                >
                  <InspectionPanel size={15} />
                </button>
              </Tooltip>
            )}
            <button
              type="button"
              className="inline-flex rounded p-1 hover:bg-slate-100"
              aria-label="Delete"
              onClick={(e) => openVersionDeleteModal(record, e)}
            >
              <Tooltip title="Delete">
                <span className="inline-flex">
                  <Trash2 size={15} />
                </span>
              </Tooltip>
            </button>
          </div>
        );
      },
    });

    return cols;
  }, [isEditMode, handleVersionStatusChange, openVersionDocument, openVersionDeleteModal, handlePreviewTempSop, handleRemoveTempSop, onTestExistingVersion]);
}
