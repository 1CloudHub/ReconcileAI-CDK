import { message } from 'antd';
import { useEffect, useMemo, useState } from 'react';
import { listJobs, type JobListItem } from '../../services/jobConfig';

/**
 * useSopJobs — fetches the list of available jobs for the job-association
 * dropdown in the SOP editor form.
 *
 * WHY a separate hook:
 *   The jobs list is loaded once on mount and doesn't change during an edit
 *   session. Isolating it here keeps useSopForm focused on form logic and
 *   avoids prop-drilling the raw job array through multiple components.
 *
 * WHY the `cancelled` flag:
 *   If the component unmounts before the fetch resolves (e.g. the user
 *   navigates away quickly), we must not call setState on the dead component.
 *   The cleanup function sets `cancelled = true`, and every branch checks it
 *   before touching React state.
 *
 * Returns:
 *   jobs        — raw list for any logic that needs full JobListItem fields
 *   jobOptions  — { value, label } pairs ready for an Ant Design Select
 *   jobsLoading — drives a spinner on the dropdown while fetching
 */
export function useSopJobs() {
  const [jobs, setJobs] = useState<JobListItem[]>([]);
  const [jobsLoading, setJobsLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setJobsLoading(true);
    void listJobs()
      .then((list) => {
        if (!cancelled) setJobs(list);
      })
      .catch((e) => {
        if (!cancelled) {
          const msg = e instanceof Error ? e.message : 'Failed to load jobs';
          message.error(msg);
          setJobs([]); // keep the dropdown empty rather than stale
        }
      })
      .finally(() => {
        if (!cancelled) setJobsLoading(false);
      });
    return () => {
      cancelled = true; // prevent setState after unmount
    };
  }, []); // empty deps: fetch once per mount, not on every render

  // Memoised so the Select component doesn't re-render on every parent render.
  const jobOptions = useMemo(
    () => jobs.map((j) => ({ value: j.id, label: j.job_name })),
    [jobs]
  );

  return { jobs, jobOptions, jobsLoading };
}
