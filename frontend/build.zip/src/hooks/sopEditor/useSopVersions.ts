import { message } from 'antd';
import dayjs from 'dayjs';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { fetchSops } from '../../services/SOP_config';
import {
  extractSopList,
  fileNameFromS3Uri,
  isRecord,
  statusLabelFromS3PathItem,
  type TableState,
  type VersionRow,
} from './sopEditorHelpers';

type UseSopVersionsParams = {
  sopId: number | null;
  decodedSopName: string;
  isEditMode: boolean;
};

/**
 * useSopVersions — fetches and exposes the version history list for a single SOP.
 *
 * WHY this hook exists:
 *   The SOP editor in edit mode needs to show all historical versions (with
 *   status, upload time, and S3 URI) so the user can manage them. This hook
 *   owns the fetch, normalisation, search/pagination, and cleanup — keeping
 *   the parent component free of data-fetching concerns.
 *
 * Fetch strategy:
 *   fetchSops() is a list endpoint that returns all SOPs; we filter by name/id
 *   client-side because there's no dedicated "get one SOP versions" endpoint.
 *   The response shape varies across Lambda versions so extractSopList() and
 *   isRecord() normalise it before we process it.
 *
 * versionsRefreshNonce:
 *   An integer that's incremented to force a re-fetch without changing the
 *   other deps. Action hooks call setVersionsRefreshNonce((v) => v + 1) after
 *   mutations (upload, delete, set-active) to keep the table in sync.
 *
 * Blob URL cleanup:
 *   Add-mode rows have blob: previewUrls created via URL.createObjectURL().
 *   These must be revoked when the row is removed or the component unmounts
 *   to avoid memory leaks. The second useEffect handles this.
 *
 * Search and pagination:
 *   Both are done client-side on the already-fetched list. The total number
 *   of versions per SOP is small (rarely > 20) so server-side pagination
 *   would add latency without benefit.
 */
export function useSopVersions({ sopId, decodedSopName, isEditMode }: UseSopVersionsParams) {
  const [uploadedVersions, setUploadedVersions] = useState<VersionRow[]>([]);
  const [versionsListLoading, setVersionsListLoading] = useState(false);
  // Incrementing this triggers a re-fetch without changing other deps.
  const [versionsRefreshNonce, setVersionsRefreshNonce] = useState(0);
  const [tableState, setTableState] = useState<TableState>({
    versionsSearch: '',
    currentPage: 1,
    pageSize: 10,
  });

  const updateTable = useCallback((updates: Partial<TableState>) => {
    setTableState((prev) => ({ ...prev, ...updates }));
  }, []);

  /**
   * Fetches the version list whenever the SOP identity or nonce changes.
   * Skipped entirely in add mode (no sopId yet, no versions to load).
   *
   * The `cancelled` flag prevents setState calls on an unmounted component
   * when the user navigates away while the fetch is in flight.
   *
   * WHY we match by both id and name:
   *   The list endpoint may return items with either `id` or `sop_id` as the
   *   primary key, and the router state may not always include the numeric id.
   *   Matching by name is a fallback for that case.
   *
   * WHY sort s3_path items descending by version:
   *   The API doesn't guarantee order. Newest first is the expected table UX.
   *
   * WHY flatMap with isRecord guard:
   *   s3_path items from the API can occasionally be null or non-objects
   *   (malformed data). flatMap(…) returning [] for bad items silently skips
   *   them instead of crashing.
   */
  useEffect(() => {
    if (!isEditMode) {
      setVersionsListLoading(false);
      return;
    }
    let cancelled = false;
    setVersionsListLoading(true);
    void fetchSops(1, 10, { exceptionName: decodedSopName.trim() })
      .then((res) => {
        if (cancelled) return;
        const list = extractSopList(res);
        // Find the specific SOP by id (preferred) or by name (fallback).
        const matched = list.find((item) => {
          const idNum = Number(item.id ?? item.sop_id);
          if (sopId != null && Number.isFinite(idNum) && idNum === sopId) return true;
          const name = String(item.exception_name ?? item.sop_name ?? '').trim();
          return !!decodedSopName && name.toLowerCase() === decodedSopName.trim().toLowerCase();
        });
        if (!matched) {
          setUploadedVersions([]);
          return;
        }

        // Sort versions newest-first for the table display.
        const pathsRaw = Array.isArray(matched.s3_path) ? matched.s3_path : [];
        const paths = [...pathsRaw].sort((a, b) => {
          const va = isRecord(a) && typeof a.version === 'number' ? a.version : 0;
          const vb = isRecord(b) && typeof b.version === 'number' ? b.version : 0;
          return vb - va;
        });

        const sopKey = String(matched.id ?? matched.sop_id ?? 'sop');
        const mapped: VersionRow[] = paths.flatMap((p, index) => {
          if (!isRecord(p)) return []; // skip malformed items
          const uri = typeof p.s3_uri === 'string' ? p.s3_uri : '';
          if (!uri) return []; // skip items with no S3 path

          // version can be a number or a numeric string from the API.
          const rawV = p.version;
          const versionNum =
            typeof rawV === 'number' && Number.isFinite(rawV)
              ? rawV
              : typeof rawV === 'string' && rawV.trim() !== ''
                ? Number(rawV)
                : NaN;
          const versionLabel = Number.isFinite(versionNum) ? String(versionNum) : '—';

          // Format the timestamp for display; fall back to '—' if missing.
          const uploadedRaw = String(p.uploaded_at ?? '');
          const createdAt = uploadedRaw ? dayjs(uploadedRaw).format('MMM D, h:mm A') : '—';

          return [
            {
              // Key combines sopId + version + index to be unique even if version is NaN.
              key: `${sopKey}-v-${versionLabel}-${index}`,
              version: Number.isFinite(versionNum) ? versionNum : undefined,
              versionLabel,
              sopName: fileNameFromS3Uri(uri),
              createdAt,
              statusLabel: statusLabelFromS3PathItem(p),
              s3Uri: uri,
            },
          ];
        });
        setUploadedVersions(mapped);
      })
      .catch((e) => {
        if (!cancelled) {
          const msg = e instanceof Error ? e.message : 'Failed to load SOP versions';
          message.error(msg);
          setUploadedVersions([]);
        }
      })
      .finally(() => {
        if (!cancelled) setVersionsListLoading(false);
      });
    return () => {
      cancelled = true; // prevent setState after unmount
    };
  }, [isEditMode, sopId, decodedSopName, versionsRefreshNonce]); // eslint-disable-line react-hooks/exhaustive-deps

  /**
   * Cleans up blob: URLs when rows are removed.
   * URL.createObjectURL() allocates browser memory that is NOT freed by GC —
   * revokeObjectURL() must be called explicitly or memory leaks accumulate.
   * This effect runs whenever uploadedVersions changes; the cleanup function
   * revokes URLs for rows that are no longer in the list.
   */
  useEffect(() => {
    return () => {
      uploadedVersions.forEach((v) => {
        if (v.previewUrl?.startsWith('blob:')) URL.revokeObjectURL(v.previewUrl);
      });
    };
  }, [uploadedVersions]);

  /**
   * Client-side search across sopName, versionLabel, and statusLabel.
   * The search is case-insensitive and filters against the full (unpaged) list
   * so results are consistent regardless of the current page.
   */
  const filteredVersions = useMemo(() => {
    const q = tableState.versionsSearch.trim().toLowerCase();
    if (!q) return uploadedVersions;
    return uploadedVersions.filter(
      (row) =>
        row.sopName.toLowerCase().includes(q) ||
        row.versionLabel.toLowerCase().includes(q) ||
        row.statusLabel.toLowerCase().includes(q)
    );
  }, [uploadedVersions, tableState.versionsSearch]);

  /** Slices filteredVersions to the current page for the table. */
  const pagedVersions = useMemo(() => {
    const start = (tableState.currentPage - 1) * tableState.pageSize;
    return filteredVersions.slice(start, start + tableState.pageSize);
  }, [tableState.currentPage, tableState.pageSize, filteredVersions]);

  /**
   * Resets search + pagination and increments the nonce to trigger a re-fetch.
   * Called by action hooks after mutations (upload, delete, set-active) so the
   * table reflects the latest server state.
   */
  const refreshVersions = useCallback(() => {
    updateTable({ versionsSearch: '', currentPage: 1 });
    setVersionsRefreshNonce((v) => v + 1);
  }, [updateTable]);

  return {
    uploadedVersions,
    setUploadedVersions,
    versionsListLoading,
    versionsRefreshNonce,
    setVersionsRefreshNonce,
    tableState,
    updateTable,
    filteredVersions,
    pagedVersions,
    refreshVersions,
  };
}
