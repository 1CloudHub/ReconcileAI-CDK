import { message } from 'antd';
import dayjs from 'dayjs';
import { useCallback, useState, type RefObject, type ChangeEvent, type MouseEvent as ReactMouseEvent } from 'react';
import {
  deleteSop,
  fetchSops,
  generatePresignedDownloadUrl,
  parseAddSopResponse,
  parsePresignedDownloadUrlResponse,
  setActiveSopDocument,
  updateSop,
} from '../../services/SOP_config';
import { parseAddSopResponseWithS3Key } from '../../services/SOP_config';
import { uploadFileToS3ViaLambda } from '../../utils/fileUpload';
import {
  createdByFromSession,
  extractSopList,
  isRecord,
  type DeleteModalState,
  type FormState,
  type TableState,
  type VersionRow,
} from './sopEditorHelpers';

type UseSopVersionActionsParams = {
  sopId: number | null;
  decodedSopName: string;
  isEditMode: boolean;
  uploadedVersions: VersionRow[];
  setUploadedVersions: React.Dispatch<React.SetStateAction<VersionRow[]>>;
  setVersionsRefreshNonce: React.Dispatch<React.SetStateAction<number>>;
  versionFileInputRef: RefObject<HTMLInputElement | null>;
  formErrors: FormState['errors'];
  updateForm: (updates: Partial<FormState>) => void;
  updateTable: (updates: Partial<TableState>) => void;
};

/**
 * useSopVersionActions — all row-level actions for the version history table:
 *   - Open/preview a document
 *   - Open the delete confirmation popover
 *   - Confirm delete (local-only in add mode, API call in edit mode)
 *   - Handle file input change (add/edit differ significantly)
 *   - Set a version as active
 *   - Handle status dropdown change
 *
 * WHY split from useSopVersions:
 *   useSopVersions owns data fetching and pagination state.
 *   This hook owns user-initiated mutations. Keeping them separate prevents
 *   the data-fetch effect from re-running when action callbacks change.
 */
export function useSopVersionActions({
  sopId,
  decodedSopName,
  isEditMode,
  uploadedVersions,
  setUploadedVersions,
  setVersionsRefreshNonce,
  formErrors,
  updateForm,
  updateTable,
}: UseSopVersionActionsParams) {
  const [deleteModal, setDeleteModal] = useState<DeleteModalState>({
    document: null,
    position: undefined,
    loading: false,
  });
  const [versionUploading, setVersionUploading] = useState(false);

  /** Shallow-merges partial updates into the delete modal state. */
  const updateDeleteModal = useCallback((updates: Partial<DeleteModalState>) => {
    setDeleteModal((prev) => ({ ...prev, ...updates }));
  }, []);

  /**
   * Opens the document for preview/download.
   * - If the row has an s3Uri (saved version): generates a presigned GET URL
   *   and opens it in a new tab. Presigned URLs keep the real S3 path hidden
   *   from the browser's address bar and expire automatically.
   * - If the row has a local previewUrl (add mode draft): opens the blob URL
   *   directly — no network round-trip needed.
   */
  const openVersionDocument = useCallback(async (record: VersionRow) => {
    if (record.s3Uri) {
      const close = message.loading('Opening document…', 0);
      try {
        const res = await generatePresignedDownloadUrl(record.s3Uri);
        const url = parsePresignedDownloadUrlResponse(res);
        window.open(url, '_blank', 'noopener,noreferrer');
      } catch (e) {
        const msg = e instanceof Error ? e.message : 'Failed to open document';
        message.error(msg);
      } finally {
        close();
      }
      return;
    }
    if (record.previewUrl) {
      window.open(record.previewUrl, '_blank', 'noopener,noreferrer');
      return;
    }
    message.info('No document available to preview yet.');
  }, []);

  /**
   * Positions the delete confirmation popover next to the clicked button.
   * Using getBoundingClientRect() instead of a fixed position means the
   * popover tracks the row even if the table has been scrolled.
   * The left offset subtracts 350 px to open the popover to the left of the
   * icon (the popover is ~350 px wide), clamped to 16 px to stay on screen.
   */
  const openVersionDeleteModal = useCallback(
    (record: VersionRow, event: ReactMouseEvent<HTMLButtonElement>) => {
      const rect = event.currentTarget.getBoundingClientRect();
      updateDeleteModal({
        document: record,
        position: { top: rect.bottom + 8, left: Math.max(16, rect.left - 350) },
      });
    },
    [updateDeleteModal]
  );

  /**
   * Confirms a document deletion.
   *
   * Edit mode rules:
   *   - If the row being deleted is the last Active document, block the delete.
   *     At least one active document is required so the SOP has a valid active version.
   *
   * Add mode:
   *   - Delete is always allowed — the SOP record doesn't exist yet in the DB.
   *
   * Persistence logic:
   *   - If the row has an s3Uri, it's a saved version → call deleteSop() API,
   *     then remove the row from local state on success.
   *   - If there's no s3Uri, the row is local-only (unsaved draft) → remove from
   *     local state immediately, no API call needed.
   *   - blob: previewUrls are revoked on removal to free browser memory.
   */
  const confirmVersionDocumentDelete = useCallback(async () => {
    const row = deleteModal.document;
    if (!row) return;

    if (isEditMode) {
      // Guard: don't leave the SOP with zero active documents.
      if (row.statusLabel === 'Active') {
        const activeCount = uploadedVersions.filter((v) => v.statusLabel === 'Active').length;
        if (activeCount <= 1) {
          message.error('At least one active document is required. Activate another document first.');
          updateDeleteModal({ document: null });
          return;
        }
      }
    }
    // In add mode: allow deleting any document freely.

    const removeLocally = () => {
      // Revoke blob URL to avoid memory leaks from accumulated object URLs.
      if (row.previewUrl?.startsWith('blob:')) URL.revokeObjectURL(row.previewUrl);
      setUploadedVersions((prev) => prev.filter((v) => v.key !== row.key));
      updateDeleteModal({ document: null });
    };

    if (row.s3Uri) {
      // Saved version — hit the API first.
      if (sopId == null) {
        message.error('Missing SOP id. Open this SOP from SOP Control Center.');
        updateDeleteModal({ document: null });
        return;
      }
      updateDeleteModal({ loading: true });
      try {
        // Passing s3Uri targets the specific version; omitting it would delete
        // the entire SOP record (see deleteSop in SOP_config.ts).
        await deleteSop(sopId, createdByFromSession(), row.s3Uri, typeof row.version === 'number' ? row.version : undefined);
        message.success('Document deleted');
        removeLocally();
      } catch (e) {
        const msg = e instanceof Error ? e.message : 'Failed to delete document';
        message.error(msg);
      } finally {
        updateDeleteModal({ loading: false });
      }
      return;
    }

    // Local-only row (no s3Uri) — just remove it from state.
    removeLocally();
  }, [deleteModal.document, isEditMode, sopId, uploadedVersions, setUploadedVersions, updateDeleteModal]);

  /**
   * Prepends a new local-only row to the version table immediately after the
   * user picks a file in add mode. The row shows status='Pending' so the user
   * knows it hasn't been sent to S3 yet (that happens on Create SOP).
   * Resets pagination to page 1 so the new row is visible.
   * Clears the versionFile error if it was shown (user just satisfied it).
   */
  const appendLocalVersionRow = useCallback(
    (picked: File, previewUrl: string) => {
      const next: VersionRow = {
        key: String(Date.now()),
        versionLabel: '—',
        sopName: picked.name,
        createdAt: dayjs().format('MMM D, h:mm A'),
        statusLabel: 'Pending',
        previewUrl,
        file: picked,
      };
      setUploadedVersions((prev) => [next, ...prev]);
      updateTable({ currentPage: 1 });
      if (formErrors.versionFile) {
        updateForm({ errors: { ...formErrors, versionFile: undefined } });
      }
    },
    [formErrors, setUploadedVersions, updateForm, updateTable]
  );

  /**
   * Handles a newly picked version file.
   *
   * ADD mode:
   *   Creates a local blob URL for immediate preview and adds a Pending row
   *   to the table. The file is NOT uploaded yet — upload happens in handleAddSop().
   *
   * EDIT mode (two-step flow):
   *   1. Call updateSop() with the filename to get a presigned S3 PUT URL.
   *   2. PUT the file directly to S3.
   *   3. Re-fetch the SOP list to find the newly created version's s3Uri and
   *      version number (the API doesn't return these in the update response).
   *   Returns { s3Uri, version } so the caller can update the table row.
   *
   * WHY re-fetch instead of using the API response directly:
   *   updateSop() returns a presigned URL for upload but doesn't include the
   *   new s3Uri or version number. The freshest data lives in the list endpoint.
   */
  const handleVersionFile = useCallback(
    async (picked: File): Promise<{ s3Uri: string; version?: number } | undefined> => {
      if (!isEditMode) {
        // Add mode: stage locally, upload later on Create SOP.
        const previewUrl = URL.createObjectURL(picked);
        appendLocalVersionRow(picked, previewUrl);
        message.success('New document uploaded');
        return undefined;
      }

      if (sopId == null) {
        message.error('Missing SOP id. Open this SOP from SOP Control Center to upload a document.');
        return undefined;
      }

      setVersionUploading(true);
      try {
        // Step 1: Register new version, receive presigned PUT URL.
        const res = await updateSop(sopId, createdByFromSession(), { filename: picked.name });
        const { s3Key } = parseAddSopResponseWithS3Key(res);

        // Step 2: Upload file via Lambda to avoid S3 CORS.
        await uploadFileToS3ViaLambda({ file: picked, s3Key });

        // Step 3: Re-fetch to get the newly created version's s3Uri and version number.
        const listRes = await fetchSops(1, 10, { exceptionName: decodedSopName.trim() });
        const list = extractSopList(listRes);
        const matched = list.find((item) => {
          const idNum = Number(item.id ?? item.sop_id);
          if (sopId != null && Number.isFinite(idNum) && idNum === sopId) return true;
          const name = String(item.exception_name ?? item.sop_name ?? '').trim();
          return !!decodedSopName && name.toLowerCase() === decodedSopName.trim().toLowerCase();
        });

        // Pick the highest-version s3_path item — that's the one just created.
        const paths = Array.isArray(matched?.s3_path) ? (matched!.s3_path as unknown[]) : [];
        const newest = paths
          .filter(isRecord)
          .sort((a, b) => {
            const va = typeof a.version === 'number' ? a.version : 0;
            const vb = typeof b.version === 'number' ? b.version : 0;
            return vb - va; // descending: newest first
          })[0];
        const s3Uri = newest && typeof newest.s3_uri === 'string' ? newest.s3_uri : '';
        const version = newest && typeof newest.version === 'number' ? newest.version : undefined;
        return { s3Uri, version };
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Upload failed';
        message.error(msg);
        return undefined;
      } finally {
        setVersionUploading(false);
      }
    },
    [appendLocalVersionRow, isEditMode, setVersionsRefreshNonce, sopId, updateTable]
  );

  /**
   * onChange handler for the hidden <input type="file"> used to pick version files.
   * Clears the input value after reading so the same file can be picked again
   * (browsers don't fire onChange for the same file twice otherwise).
   */
  const handleVersionFileInputChange = useCallback(
    async (e: ChangeEvent<HTMLInputElement>) => {
      const picked = e.target.files?.[0];
      e.currentTarget.value = ''; // allow re-picking the same file
      if (!picked) return;
      await handleVersionFile(picked);
    },
    [handleVersionFile]
  );

  /**
   * Marks a specific version as active via the API, then updates local state
   * optimistically so the table reflects the change without a re-fetch.
   *
   * Guards:
   *  - Only valid in edit mode (add mode rows have no version number).
   *  - Deleted/Pending rows can't be activated (they aren't stable versions).
   *  - Already Active rows skip the API call silently.
   *
   * WHY optimistic local update:
   *   The API sets exactly one version active and all others inactive. We mirror
   *   that logic locally: mark the target 'Active', all others 'Inactive'
   *   (except Deleted/Pending which should keep their special status).
   *   Then trigger a refresh nonce to re-fetch and confirm server state.
   */
  const setVersionActive = useCallback(
    async (record: VersionRow) => {
      if (!isEditMode) return;
      if (sopId == null) {
        message.error('Missing SOP id. Open this SOP from SOP Control Center.');
        return;
      }
      if (typeof record.version !== 'number' || !Number.isFinite(record.version)) {
        message.info('Version is unavailable for this document.');
        return;
      }
      if (record.statusLabel === 'Deleted') {
        message.info('Deleted documents cannot be activated.');
        return;
      }
      if (record.statusLabel === 'Pending') {
        message.info('Please refresh after upload before setting active.');
        return;
      }
      if (record.statusLabel === 'Active') return; // already active — no-op

      const close = message.loading('Setting active document…', 0);
      try {
        await setActiveSopDocument(sopId, record.version);
        // Optimistic update: flip statuses locally before the re-fetch arrives.
        setUploadedVersions((prev) =>
          prev.map((row) => {
            if (row.statusLabel === 'Deleted' || row.statusLabel === 'Pending') return row;
            if (row.key === record.key) return { ...row, statusLabel: 'Active' };
            return { ...row, statusLabel: 'Inactive' };
          })
        );
        message.success(`Version ${record.version} is now active`);
        // Trigger a background re-fetch to confirm the server accepted the change.
        setVersionsRefreshNonce((v) => v + 1);
      } catch (e) {
        const msg = e instanceof Error ? e.message : 'Failed to set active document';
        message.error(msg);
      } finally {
        close();
      }
    },
    [isEditMode, sopId, setUploadedVersions, setVersionsRefreshNonce]
  );

  /**
   * Routes status dropdown changes to the appropriate action.
   * Currently 'Active' is the only actionable transition — selecting 'Inactive'
   * when the row is already Active shows an error because you can't deactivate
   * without first activating another document.
   */
  const handleVersionStatusChange = useCallback(
    async (record: VersionRow, nextStatus: string) => {
      if (nextStatus === 'Active') {
        await setVersionActive(record);
        return;
      }
      if (nextStatus === 'Inactive' && record.statusLabel === 'Active') {
        message.error('Cannot deactivate active SOP. Set another document as active first.');
      }
    },
    [setVersionActive]
  );

  return {
    deleteModal,
    updateDeleteModal,
    versionUploading,
    openVersionDocument,
    openVersionDeleteModal,
    confirmVersionDocumentDelete,
    handleVersionFile,
    handleVersionFileInputChange,
    handleVersionStatusChange,
  };
}
