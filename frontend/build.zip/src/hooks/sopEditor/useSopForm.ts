import { message } from 'antd';
import { useCallback, useRef, useState } from 'react';
import type { NavigateFunction } from 'react-router-dom';
import {
  addSop,
  parseAddSopUploadTargets,
  updateSop,
  uploadSopFileToPresignedUrl,
} from '../../services/SOP_config';
import {
  createdByFromSession,
  jobIdsEqual,
  type FormState,
  type VersionRow,
} from './sopEditorHelpers';

type UseSopFormParams = {
  sopId: number | null;
  isEditMode: boolean;
  navigate: NavigateFunction;
  decodedSopName: string;
  uploadedVersions: VersionRow[];
  setSavedDetailsRef?: (name: string, jobIds: number[]) => void;
};

/**
 * useSopForm — manages the exception details section (name + job associations)
 * and the "Create SOP" submit flow for add mode.
 *
 * Two distinct save paths live here:
 *  - ADD mode:  handleAddSop() — registers the SOP in the DB, then PUTs files
 *               directly to S3 via presigned URLs (one per file).
 *  - EDIT mode: saveExceptionDetails() — partial update via updateSop();
 *               only sends fields that actually changed to avoid overwriting
 *               server state with stale form values.
 *
 * The "cancel baseline" ref pattern lets the user edit the form and click
 * Cancel to restore exactly what was shown before they started editing,
 * without needing a separate API fetch.
 */
export function useSopForm({
  sopId,
  isEditMode,
  navigate,
  decodedSopName,
  uploadedVersions,
}: UseSopFormParams) {
  const [formState, setFormState] = useState<FormState>({
    exceptionName: decodedSopName,
    selectedJobIds: [],
    errors: {},
    // In add mode the form starts open so the user can fill it immediately.
    // In edit mode it starts read-only; the user clicks Edit to unlock it.
    exceptionDetailsEditing: !isEditMode,
  });
  const [addSopSubmitting, setAddSopSubmitting] = useState(false);
  const [exceptionDetailsSaving, setExceptionDetailsSaving] = useState(false);

  // Stores the state when the user clicked Edit, so Cancel can restore it.
  const exceptionDetailsCancelBaselineRef = useRef({ name: '', jobIds: [] as number[] });
  // Tracks what was last successfully saved to the API (used for dirty-check).
  const savedDetailsForApiRef = useRef({ name: decodedSopName.trim(), jobIds: [] as number[] });

  /** Shallow-merges partial updates into formState — avoids spreading at call sites. */
  const updateForm = useCallback((updates: Partial<FormState>) => {
    setFormState((prev) => ({ ...prev, ...updates }));
  }, []);

  /**
   * Called after the initial data load so that savedDetailsForApiRef reflects
   * what the server actually has, enabling accurate dirty-checking later.
   */
  const initSavedDetails = useCallback((name: string, jobIds: number[]) => {
    savedDetailsForApiRef.current = { name, jobIds: [...jobIds] };
  }, []);

  /**
   * Snapshot the current values as the "cancel baseline" before opening edit
   * mode. This lets Cancel restore the pre-edit state without a round-trip.
   */
  const startExceptionDetailsEdit = useCallback(() => {
    setFormState((prev) => {
      exceptionDetailsCancelBaselineRef.current = {
        name: prev.exceptionName,
        jobIds: [...prev.selectedJobIds],
      };
      return { ...prev, errors: {}, exceptionDetailsEditing: true };
    });
  }, []);

  /** Restores the snapshot taken when edit mode opened and closes the section. */
  const cancelExceptionDetailsEdit = useCallback(() => {
    const b = exceptionDetailsCancelBaselineRef.current;
    updateForm({
      exceptionName: b.name,
      selectedJobIds: b.jobIds,
      errors: {},
      exceptionDetailsEditing: false,
    });
  }, [updateForm]);

  /**
   * Saves only the fields that changed since the last successful save.
   * Name and jobs are sent as separate API calls because the backend update
   * endpoint accepts them independently. Sending both in one payload could
   * cause a partial-failure to silently drop one field.
   */
  const saveExceptionDetails = useCallback(
    async (currentForm: FormState) => {
      if (sopId == null) {
        message.error('Missing SOP id. Open this SOP from SOP Control Center.');
        return;
      }
      const saved = savedDetailsForApiRef.current;
      const nameTrim = currentForm.exceptionName.trim();
      const nameChanged = saved.name !== nameTrim;
      const jobsChanged = !jobIdsEqual(saved.jobIds, currentForm.selectedJobIds);

      // Short-circuit: nothing actually changed — close without an API call.
      if (!nameChanged && !jobsChanged) {
        message.info('No changes to save');
        exceptionDetailsCancelBaselineRef.current = {
          name: nameTrim,
          jobIds: [...currentForm.selectedJobIds],
        };
        updateForm({ exceptionDetailsEditing: false });
        return;
      }

      const actor = createdByFromSession();
      setExceptionDetailsSaving(true);
      try {
        // Fire each changed field as its own request so one failure doesn't
        // silently drop the other change.
        if (nameChanged) await updateSop(sopId, actor, { exceptionName: nameTrim });
        if (jobsChanged) await updateSop(sopId, actor, { jobIds: [...currentForm.selectedJobIds] });
        // Update both refs so the next save computes the correct delta.
        savedDetailsForApiRef.current = { name: nameTrim, jobIds: [...currentForm.selectedJobIds] };
        exceptionDetailsCancelBaselineRef.current = {
          name: nameTrim,
          jobIds: [...currentForm.selectedJobIds],
        };
        message.success('Exception saved');
        updateForm({ exceptionDetailsEditing: false, errors: {} });
      } catch (e) {
        const msg = e instanceof Error ? e.message : 'Failed to save exception';
        message.error(msg);
      } finally {
        setExceptionDetailsSaving(false);
      }
    },
    [sopId, updateForm]
  );

  /**
   * Validate-then-save for edit mode's "Save" button.
   * In add mode this just navigates away (the actual create is triggered by
   * handleAddSop, which is wired to a different button).
   */
  const validateAndSave = useCallback(() => {
    const { exceptionName, selectedJobIds } = formState;
    const nextErrors: FormState['errors'] = {};
    if (!exceptionName.trim()) nextErrors.exceptionName = 'Exception name is required';
    if (selectedJobIds.length === 0) nextErrors.jobId = 'Please select a job';
    updateForm({ errors: nextErrors });
    if (Object.keys(nextErrors).length > 0) return;
    if (!isEditMode) {
      navigate('/sop-control-center');
      return;
    }
    void saveExceptionDetails(formState);
  }, [formState, isEditMode, navigate, saveExceptionDetails, updateForm]);

  /**
   * Full create flow for add mode:
   *  1. Validate form + file presence.
   *  2. Call addSop() to register the SOP record in the DB and get presigned
   *     S3 PUT URLs back (one per file).
   *  3. Match each URL to its file by filename (the server returns them keyed
   *     by name). Fall back to positional ordering if names don't match.
   *  4. PUT each file directly to S3 via its presigned URL.
   *  5. Navigate back to SOP Control Center on success.
   *
   * Files go directly to S3 (not through the API) to avoid Lambda's 6 MB
   * payload limit and the 29 s API Gateway timeout.
   */
  const handleAddSop = useCallback(async () => {
    const { exceptionName, selectedJobIds } = formState;
    const nextErrors: FormState['errors'] = {};
    if (!exceptionName.trim()) nextErrors.exceptionName = 'Exception name is required';
    if (selectedJobIds.length === 0) nextErrors.jobId = 'Please select a job';

    // Only rows with a local File object are actual new uploads.
    const localFiles = uploadedVersions
      .filter((v): v is VersionRow & { file: File } => v.file instanceof File)
      .map((v) => v.file);
    if (localFiles.length === 0) {
      nextErrors.versionFile = 'Upload at least one SOP document';
    }
    updateForm({ errors: nextErrors });
    if (Object.keys(nextErrors).length > 0) return;

    setAddSopSubmitting(true);
    const hide = message.loading('Creating SOP and uploading files…', 0);
    try {
      // Step 1: Register in DB, receive presigned upload URLs keyed by filename.
      const res = await addSop(
        exceptionName.trim(),
        selectedJobIds,
        localFiles.map((f) => f.name),
        createdByFromSession()
      );
      const targets = parseAddSopUploadTargets(res);

      // Build a filename → URL map so we can match URLs to files by name
      // instead of relying on position (order from the server isn't guaranteed).
      const targetByName = new Map(
        targets
          .filter((t) => t.filename && t.filename.trim())
          .map((t) => [String(t.filename).trim(), t.uploadUrl])
      );

      // If we got a name-keyed map, resolve URLs in the same order as localFiles
      // so Promise.all below uploads the right file to the right URL.
      const orderedUrls =
        targetByName.size > 0
          ? localFiles.map((f) => targetByName.get(f.name) || '')
          : targets.map((t) => t.uploadUrl); // fallback: positional

      if (orderedUrls.some((u) => !u) || orderedUrls.length !== localFiles.length) {
        throw new Error(
          `Server returned ${targets.length} upload URL target(s) for ${localFiles.length} file(s). Check filenames match.`
        );
      }

      // Step 2: Upload all files to S3 in parallel (independent PUTs).
      await Promise.all(orderedUrls.map((url, i) => uploadSopFileToPresignedUrl(url, localFiles[i])));
      hide();
      message.success(
        localFiles.length === 1 ? 'SOP created and file uploaded' : 'SOP created and files uploaded'
      );
      navigate('/sop-control-center', { replace: true });
    } catch (e) {
      hide();
      const msg = e instanceof Error ? e.message : 'Failed to add SOP';
      message.error(msg);
    } finally {
      setAddSopSubmitting(false);
    }
  }, [formState, navigate, updateForm, uploadedVersions]);

  return {
    formState,
    updateForm,
    addSopSubmitting,
    exceptionDetailsSaving,
    validateAndSave,
    startExceptionDetailsEdit,
    cancelExceptionDetailsEdit,
    handleAddSop,
    initSavedDetails,
  };
}
