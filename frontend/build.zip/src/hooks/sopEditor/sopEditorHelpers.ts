import type { SopApiEnvelope } from '../../services/SOP_config';

// ─── Shared Types ─────────────────────────────────────────────────────────────
// These types are shared across all sopEditor hooks so that the SOP editor page
// (add mode + edit mode) has a single, consistent data shape to pass around.

/**
 * Represents one row in the version history table.
 * In edit mode rows come from the API (have s3Uri + version number).
 * In add mode rows are local-only (have previewUrl + file, no s3Uri yet).
 */
export type VersionRow = {
  key: string;
  version?: number;          // numeric version from the backend; absent for local drafts
  versionLabel: string;      // display string: '1', '2', … or '—' / 'Draft'
  sopName: string;           // filename shown in the table
  createdAt: string;         // human-readable timestamp
  statusLabel: string;       // 'Active' | 'Inactive' | 'Deleted' | 'Pending'
  s3Uri?: string;            // S3 URI — present only for persisted (server-side) versions
  previewUrl?: string;       // blob: URL for local preview before upload
  file?: File;               // raw File object retained for the actual S3 PUT
};

/**
 * Navigation state passed via React Router when navigating to the SOP editor.
 * The SOP control center passes sopId so the editor knows whether it's in edit
 * mode, and optionally pre-fills job associations.
 */
export type SopEditLocationState = {
  sopId?: number;
  jobIds?: number[];
  jobNames?: string[];
};

/**
 * Drives the top-level exception details section of the form (name + jobs).
 * exceptionDetailsEditing toggles the section between read-only and editable.
 */
export type FormState = {
  exceptionName: string;
  selectedJobIds: number[];
  errors: { exceptionName?: string; jobId?: string; versionFile?: string };
  exceptionDetailsEditing: boolean;
};

/** Controls the version history table's search input and pagination. */
export type TableState = {
  versionsSearch: string;
  currentPage: number;
  pageSize: number;
};

/**
 * Controls the inline delete confirmation popover.
 * position is computed from the clicked button's bounding rect so the popover
 * appears just below and to the left of the delete icon — no separate modal.
 */
export type DeleteModalState = {
  document: VersionRow | null;
  position: { top: number; left: number } | undefined;
  loading: boolean;
};

// ─── Pure Helpers ─────────────────────────────────────────────────────────────

/**
 * Type guard for narrowing `unknown` to a plain object.
 * Used throughout the hooks to safely access keys on API responses whose
 * TypeScript type is `unknown` or `Record<string, unknown>`.
 */
export function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null;
}

/**
 * Extracts the flat array of SOP items from whatever envelope the Lambda
 * happens to return. The backend has returned the list under different keys
 * across deployments: body.data, res.sops, res.result, res.data, data.sops,
 * data.items. Each branch handles one historical shape — order matters because
 * `body.data` is the most specific and should be tried first.
 */
export function extractSopList(res: SopApiEnvelope): Record<string, unknown>[] {
  const body = isRecord(res.body) ? res.body : undefined;
  if (isRecord(body) && Array.isArray(body.data)) return body.data as Record<string, unknown>[];
  if (Array.isArray(res.sops)) return res.sops as Record<string, unknown>[];
  if (Array.isArray(res.result)) return res.result as Record<string, unknown>[];
  if (Array.isArray(res.data)) return res.data as Record<string, unknown>[];
  const data = res.data;
  if (isRecord(data) && Array.isArray(data.sops)) return data.sops as Record<string, unknown>[];
  if (isRecord(data) && Array.isArray(data.items)) return data.items as Record<string, unknown>[];
  return [];
}

/**
 * Derives a clean filename from an S3 URI.
 * S3 URIs may include query-string params (e.g. presigned URL junk), so we
 * strip those first. The filename is the last path segment, URL-decoded so
 * spaces and special characters render correctly in the table.
 */
export function fileNameFromS3Uri(uri: string): string {
  const clean = uri.split('?')[0] ?? uri;
  const last = clean.split('/').pop() || clean;
  try {
    return decodeURIComponent(last);
  } catch {
    return last; // if decoding fails, fall back to raw string
  }
}

/**
 * Maps a raw s3_path item from the API to the status label shown in the table.
 * Priority: deleted > active > inactive.
 * The API uses boolean flags rather than a single status string, so we check
 * each flag in priority order.
 */
export function statusLabelFromS3PathItem(p: Record<string, unknown>): string {
  if (p.document_delete_status === true) return 'Deleted';
  if (p.active_status === true) return 'Active';
  return 'Inactive';
}

/**
 * Returns the actor identifier sent to the API for audit/logging purposes.
 * Currently hardcoded to 'admin'; in a real auth setup this would read from
 * the session/JWT. Centralised here so the switch is a one-line change.
 */
export function createdByFromSession(): string {
  return 'admin';
}

/**
 * Order-insensitive equality check for two job-id arrays.
 * Used by useSopForm to decide whether the job associations changed before
 * sending a partial update — avoids a redundant API call when the user
 * reselects the same jobs in a different order.
 */
export function jobIdsEqual(a: number[], b: number[]): boolean {
  if (a.length !== b.length) return false;
  const sa = [...a].sort((x, y) => x - y);
  const sb = [...b].sort((x, y) => x - y);
  return sa.every((v, i) => v === sb[i]);
}
