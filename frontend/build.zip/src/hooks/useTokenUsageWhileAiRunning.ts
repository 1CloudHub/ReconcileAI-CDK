import { useEffect, useRef } from 'react';
import { refreshTokenUsageFromApi } from '../services/showTokens';

const POLL_INTERVAL_MS = 10_000;

/**
 * Polls token usage every 15 s, but ONLY while `isAiRunning` is true.
 * The interval starts the moment `isAiRunning` flips to true and is
 * cleared immediately when it flips back to false, so there is zero
 * background activity at idle.
 */
export function useTokenUsageWhileAiRunning(isAiRunning: boolean) {
  const intervalRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);

  useEffect(() => {
    if (!isAiRunning) {
      if (intervalRef.current !== undefined) {
        clearInterval(intervalRef.current);
        intervalRef.current = undefined;
      }
      return;
    }

    // Fetch immediately when AI starts, then on every interval tick.
    void refreshTokenUsageFromApi();
    intervalRef.current = setInterval(() => {
      void refreshTokenUsageFromApi();
    }, POLL_INTERVAL_MS);

    return () => {
      if (intervalRef.current !== undefined) {
        clearInterval(intervalRef.current);
        intervalRef.current = undefined;
      }
    };
  }, [isAiRunning]);
}
