import { useCallback, useRef, useState } from 'react';
import { API_URLS } from '../config/api.config';
import { apiRequest } from '../services/api';
import { refreshTokenUsageFromApi } from '../services/showTokens';
import { useTokenUsageWhileAiRunning } from './useTokenUsageWhileAiRunning';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type DocTypeField = {
  name: string;
  description: string;
};

export type DocumentTypeRow = {
  key: string;
  id: number;
  createdAt: string;
  documentType: string;
  description: string;
  documentKey?: string;
  documentKeyIsEnabled?: boolean;
  fields: DocTypeField[];
};

/** Optional query for `list_document_type` (filter + pagination when `page` / `page_size` set). */
export type ListDocumentTypesParams = {
  page?: number;
  page_size?: number;
  document_name?: string;
  document_description?: string;
  created_from?: string;
  created_to?: string;
};

export type ListPaginationMeta = {
  page: number;
  page_size: number;
  total: number;
  total_pages: number;
  has_next?: boolean;
  has_prev?: boolean;
};

type ApiEnvelope = {
  status_code?: number;
  statusCode?: number;
  message?: string;
  jobs?: unknown;
  result?: unknown;
  response?: string;
  status?: string;
  data?: unknown;
  body?: unknown;
  presigned_url?: string;
  pagination?: unknown;
  [key: string]: unknown;
};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

async function postConfig(payload: Record<string, unknown>): Promise<ApiEnvelope> {
  return apiRequest<ApiEnvelope, Record<string, unknown>>(API_URLS.CONFIG, {
    method: 'POST',
    body: payload,
  });
}

function normalizeDocumentType(value: unknown): string {
  if (typeof value !== 'string') return '';
  return value.trim().toLowerCase().replace(/\s+/g, '_');
}

function parseListPagination(raw: unknown): ListPaginationMeta | null {
  if (!raw || typeof raw !== 'object') return null;
  const o = raw as Record<string, unknown>;
  const page = Number(o.page);
  const page_size = Number(o.page_size);
  const total = Number(o.total);
  const total_pages = Number(o.total_pages);
  if (![page, page_size, total, total_pages].every((n) => Number.isFinite(n))) return null;
  return {
    page,
    page_size,
    total,
    total_pages,
    ...(typeof o.has_next === 'boolean' ? { has_next: o.has_next } : {}),
    ...(typeof o.has_prev === 'boolean' ? { has_prev: o.has_prev } : {}),
  };
}

function extractNamesFromBackendMappingList(raw: unknown): string[] {
  const extractFromString = (s: string): string | null => {
    // Backend sends items like: "{'id': 36, 'name': 'Price mismatch'}"
    const m = s.match(/name'\s*:\s*'([^']*)'/);
    if (m?.[1]) return m[1];

    const m2 = s.match(/name"\s*:\s*"([^"]*)"/);
    if (m2?.[1]) return m2[1];

    return null;
  };

  if (Array.isArray(raw)) {
    return raw
      .map((item) => (typeof item === 'string' ? extractFromString(item) : null))
      .filter((n): n is string => Boolean(n));
  }

  if (typeof raw === 'string') {
    const names: string[] = [];
    for (const match of raw.matchAll(/name'\s*:\s*'([^']*)'/g)) {
      const name = match?.[1];
      if (typeof name === 'string' && name.trim()) names.push(name.trim());
    }
    return names;
  }

  return [];
}

function mimeFromExtension(ext: string): string {
  const map: Record<string, string> = {
    pdf: 'application/pdf',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    png: 'image/png',
  };
  return map[ext.toLowerCase()] ?? 'application/octet-stream';
}

async function uploadToS3(file: File, s3Path: string): Promise<void> {
  const ext = file.name.split('.').pop() ?? '';
  const contentType = mimeFromExtension(ext);

  type UploadUrlEnvelope = { statusCode?: number; body?: { upload_url?: string }; upload_url?: string };

  const envelope = await apiRequest<UploadUrlEnvelope>(API_URLS.CONFIG, {
    method: 'POST',
    body: {
      event_type: 'get_doc_upload_url',
      s3_path: s3Path,
      content_type: contentType,
    },
  });

  const uploadUrl =
    (envelope?.body as { upload_url?: string } | undefined)?.upload_url ??
    envelope?.upload_url;

  if (typeof uploadUrl !== 'string' || !uploadUrl) {
    throw new Error('Failed to get upload URL from backend');
  }

  const res = await fetch(uploadUrl, {
    method: 'PUT',
    headers: { 'Content-Type': contentType },
    body: file,
  });
  if (!res.ok) {
    throw new Error(`S3 upload failed: ${res.status}`);
  }
}

async function pollUntilDone(
  makeRequest: () => Promise<ApiEnvelope>,
  intervalMs = 3000,
  maxAttempts = 40,
): Promise<ApiEnvelope> {
  for (let i = 0; i < maxAttempts; i++) {
    const result = await makeRequest();
    const status = (result.status ?? '').toString();
    if (status === 'Completed' || status === 'Failed') {
      return result;
    }
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }
  throw new Error('Polling timed out');
}

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export default function useDocumentTypes() {
  const [rows, setRows] = useState<DocumentTypeRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [listPagination, setListPagination] = useState<ListPaginationMeta | null>(null);
  /** Last list request (used when mutations call `fetchDocumentTypes()` with no args). */
  const lastListParamsRef = useRef<ListDocumentTypesParams | undefined>(undefined);

  // Tracks whether any AI job (key extraction or test doc) is in progress.
  // When true, useTokenUsageWhileAiRunning polls show_tokens every 15 s.
  const [isAiRunning, setIsAiRunning] = useState(false);
  useTokenUsageWhileAiRunning(isAiRunning);

  // ── list ──────────────────────────────────────────────────────────────────

  const fetchDocumentTypes = useCallback(
    async (params?: ListDocumentTypesParams): Promise<DocumentTypeRow[]> => {
      const effective: ListDocumentTypesParams =
        params !== undefined ? { ...params } : { ...(lastListParamsRef.current ?? {}) };

      if (params !== undefined) {
        lastListParamsRef.current = effective;
      }

      setLoading(true);
      setError(null);
      try {
        const body: Record<string, unknown> = { event_type: 'list_document_type' };
        const page = effective.page;
        const pageSize = effective.page_size;
        if (page != null && Number.isFinite(page)) body.page = page;
        if (pageSize != null && Number.isFinite(pageSize)) body.page_size = pageSize;
        const docName = effective.document_name?.trim();
        if (docName) body.document_name = docName;
        const docDesc = effective.document_description?.trim();
        if (docDesc) body.document_description = docDesc;
        if (effective.created_from) body.created_from = effective.created_from;
        if (effective.created_to) body.created_to = effective.created_to;

        const result = await postConfig(body);
        const rawList = Array.isArray(result.result)
          ? (result.result as Record<string, unknown>[])
          : [];

        setListPagination(parseListPagination(result.pagination));

        const normalized: DocumentTypeRow[] = rawList.map((item) => {
          let fields: DocTypeField[] = [];
          const nf = item.needed_fields;
          if (Array.isArray(nf)) {
            fields = nf as DocTypeField[];
          } else if (typeof nf === 'string') {
            try { fields = JSON.parse(nf) as DocTypeField[]; } catch { /* empty */ }
          }

          return {
            key: String(item.document_name ?? item.id ?? ''),
            id: Number(item.id ?? 0),
            createdAt: String(item.created_at ?? ''),
            documentType: String(item.document_name ?? ''),
            description: String(item.document_description ?? ''),
            documentKey: String(item.document_key ?? '').trim() || undefined,
            documentKeyIsEnabled: item.document_key_is_enabled ? Boolean(item.document_key_is_enabled) : undefined,
            fields,
          };
        });

        setRows(normalized);
        return normalized;
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Failed to load document types';
        setError(msg);
        throw err;
      } finally {
        setLoading(false);
      }
    },
    [],
  );

  // ── add ───────────────────────────────────────────────────────────────────

  const addDocumentType = useCallback(
    async (params: {
      documentType: string;
      documentDescription: string;
      documentKey?: string;
      documentKeyIsEnabled?: boolean;
      fields: DocTypeField[];
    }): Promise<void> => {
      const documentJson = JSON.stringify({
        documentType: params.documentType,
        documentDesc: params.documentDescription,
        ...(params.documentKey ? { documentKey: params.documentKey } : {}),
        fields: params.fields,
      });

      const addResponse = await postConfig({
        event_type: 'add_document_type',
        document_type: normalizeDocumentType(params.documentType),
        document_json: documentJson,
        document_description: params.documentDescription,
        document_key: params.documentKey,
        document_key_is_enabled: params.documentKeyIsEnabled,
      });

      const addStatusCode =
        typeof addResponse.status_code === 'number'
          ? addResponse.status_code
          : typeof addResponse.statusCode === 'number'
            ? addResponse.statusCode
            : undefined;
      const addMessage = typeof addResponse.message === 'string' ? addResponse.message : '';

      if (addStatusCode && addStatusCode >= 400) {
        throw new Error(addMessage || 'Failed to add document type');
      }

      await fetchDocumentTypes();
    },
    [fetchDocumentTypes],
  );

  // ── edit ──────────────────────────────────────────────────────────────────

  const editDocumentType = useCallback(
    async (params: {
      documentType: string;
      documentDescription: string;
      documentKey?: string;
      documentKeyIsEnabled?: boolean;
      fields: DocTypeField[];
    }): Promise<void> => {
      const documentJson = JSON.stringify({
        documentType: params.documentType,
        documentDesc: params.documentDescription,
        ...(params.documentKey ? { documentKey: params.documentKey } : {}),
        fields: params.fields,
      });

      await postConfig({
        event_type: 'edit_document_type',
        document_type: normalizeDocumentType(params.documentType),
        document_json: documentJson,
        document_description: params.documentDescription,
        document_key: params.documentKey,
        document_key_is_enabled: params.documentKeyIsEnabled,
      });

      await fetchDocumentTypes();
    },
    [fetchDocumentTypes],
  );

  // ── delete ────────────────────────────────────────────────────────────────

  const deleteDocumentType = useCallback(
    async (id: number): Promise<void> => {
      const delResponse = await postConfig({
        event_type: 'delete_document_type',
        id,
      });

      const delStatusCode =
        typeof delResponse.status_code === 'number'
          ? delResponse.status_code
          : typeof delResponse.statusCode === 'number'
            ? delResponse.statusCode
            : undefined;
      const delMessage = typeof delResponse.message === 'string' ? delResponse.message : '';

      if (delStatusCode && delStatusCode >= 400) {
        if (delStatusCode === 409) {
          const jobNames = extractNamesFromBackendMappingList(delResponse.jobs);
          if (jobNames.length > 0) {
            throw new Error(
              `Doc type is mapped to job(s): ${jobNames.join(', ')}. Remove the job(s) before deleting this doc type.`,
            );
          }
        }

        throw new Error(delMessage || 'Failed to delete document type');
      }

      await fetchDocumentTypes();
    },
    [fetchDocumentTypes],
  );

  // ── suggest description ───────────────────────────────────────────────────

  const suggestDescription = useCallback(
    async (documentJson: object, userInput: string): Promise<string> => {
      const result = await postConfig({
        event_type: 'suggest_description',
        document_json: documentJson,
        user_input: userInput,
      });
      return typeof result.response === 'string' ? result.response : '';
    },
    [],
  );

  // ── AI key extraction (file-based) ────────────────────────────────────────

  const initiateAiExtraction = useCallback(
    async (file: File, documentType: string, documentDescription: string): Promise<{ docId: string; docName: string }> => {
      const normalizedDocType = normalizeDocumentType(documentType);
      const normalizedDescription = String(documentDescription ?? '').trim();
      if (!normalizedDocType) {
        throw new Error('Document type is required before upload');
      }
      const ext = file.name.split('.').pop() ?? 'pdf';
      const baseName = file.name.replace(/\.[^.]+$/, '').replace(/\s+/g, '_');
      const docId = `${baseName}_${crypto.randomUUID()}`;
      const docName = `${docId}.${ext}`;
      const s3Path = `era_demo/${normalizedDocType}/INPUT/${docName}`;

      await uploadToS3(file, s3Path);

      void postConfig({
        event_type: 'ai_key_extraction',
        document_type: normalizedDocType,
        document_description: normalizedDescription,
        doc_id: docId,
        doc_name: docName,
        uploaded_by: 'reconcileai@1cloudhub.com',
      }).catch((err) => {
        console.error('ai_key_extraction trigger failed', err);
      });

      return { docId, docName };
    },
    [],
  );

  const pollAiExtractionStatus = useCallback(
    async (docId: string, docName: string, documentType: string): Promise<DocTypeField[]> => {
      setIsAiRunning(true);
      try {
        const result = await pollUntilDone(
          () =>
            postConfig({
              event_type: 'check_ai_field_extract_status',
              document_id: docId,
              doc_name: docName,
              document_type: documentType,
            }),
          5000,
          40,
        );

        if (result.status !== 'Completed') {
          throw new Error('AI key extraction failed');
        }

        const data = result.data as { fields?: DocTypeField[] } | undefined;
        return Array.isArray(data?.fields) ? (data.fields as DocTypeField[]) : [];
      } finally {
        setIsAiRunning(false);
        void refreshTokenUsageFromApi();
      }
    },
    [],
  );

  // ── test document upload ──────────────────────────────────────────────────

  const initiateTestDoc = useCallback(
    async (
      file: File,
      documentJson: object,
      documentType: string,
    ): Promise<{ docId: string; docName: string }> => {
      const ext = file.name.split('.').pop() ?? 'pdf';
      const baseName = file.name.replace(/\.[^.]+$/, '').replace(/\s+/g, '_');
      const docId = `${baseName}_${crypto.randomUUID()}`;
      const docName = `${docId}.${ext}`;
      const s3Path = `era_demo/Temp/INPUT/${docName}`;

      // uploadToS3 calls get_doc_upload_url which can 504 on API Gateway.
      // The backend may still have processed the request, so swallow timeout
      // errors and fall through to polling check_document_status anyway.
      try {
        await uploadToS3(file, s3Path);
      } catch (err) {
        const isTimeout =
          (err instanceof Error && /504|timeout|gateway/i.test(err.message)) ||
          (err as { status?: number })?.status === 504;
        if (!isTimeout) throw err;
      }

      try {
        await postConfig({
          event_type: 'test_doc_upload',
          document_id: docId,
          document_name: docName,
          document_type: normalizeDocumentType(documentType),
          uploaded_by: 'reconcileai@1cloudhub.com',
          document_prompt_details: JSON.stringify(documentJson),
        });
      } catch (err) {
        const isTimeout =
          (err instanceof Error && /504|timeout|gateway/i.test(err.message)) ||
          (err as { status?: number })?.status === 504;
        if (!isTimeout) throw err;
      }

      return { docId, docName };
    },
    [],
  );

  const pollTestDocStatus = useCallback(
    async (
      docId: string,
      docName: string,
    ): Promise<{ data: unknown; presigned_url: string }> => {
      setIsAiRunning(true);
      try {
        const result = await pollUntilDone(
          () =>
            postConfig({
              event_type: 'check_document_status',
              document_id: docId,
              doc_name: docName,
            }),
          5000,
          40,
        );

        if (result.status !== 'Completed') {
          throw new Error('Test document processing failed');
        }

        return {
          data: result.data,
          presigned_url: typeof result.presigned_url === 'string' ? result.presigned_url : '',
        };
      } finally {
        setIsAiRunning(false);
        void refreshTokenUsageFromApi();
      }
    },
    [],
  );

  return {
    rows,
    loading,
    error,
    listPagination,
    fetchDocumentTypes,
    addDocumentType,
    editDocumentType,
    deleteDocumentType,
    suggestDescription,
    initiateAiExtraction,
    pollAiExtractionStatus,
    initiateTestDoc,
    pollTestDocStatus,
  };
}
