import {
  useState,
  useRef,
  useEffect,
  type ChangeEvent,
  type ClipboardEvent,
  type FormEvent,
  type KeyboardEvent,
} from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { setCookie } from '../utils/cookies';
import { API_URLS } from '../config/api.config';
import { refreshTokenUsageFromApi } from '../services/showTokens';


/** Manual session cookie lifetime until real auth sets it from the server */
const LOGIN_COOKIE_TTL_HOURS = 3;

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type Step = 'login' | 'forgot' | 'otp';

interface FormData {
  email: string;
  password: string;
  otp: string[];
  newPassword: string;
  confirmPassword: string;
}

interface PasswordRequirements {
  minLength: boolean;
  hasUpperCase: boolean;
  hasLowerCase: boolean;
  hasNumber: boolean;
  hasSpecialChar: boolean;
}

export function useLogin() {
  const navigate = useNavigate();
  const { user, setUser } = useAuth();

  const [currentStep, setCurrentStep] = useState<Step>('login');
  const [formData, setFormData] = useState<FormData>({
    email: '',
    password: '',
    otp: Array(6).fill(''),
    newPassword: '',
    confirmPassword: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [fieldErrors, setFieldErrors] = useState<{ email?: string; password?: string }>({});
  const [showPassword, setShowPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [otpTimer, setOtpTimer] = useState(60);
  const [otpVerified, setOtpVerified] = useState(false);
  const otpInputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const messageContextHolder = null; // replace with antd message context if needed

  const passwordRequirements: PasswordRequirements = {
    minLength: formData.newPassword.length >= 6,
    hasUpperCase: /[A-Z]/.test(formData.newPassword),
    hasLowerCase: /[a-z]/.test(formData.newPassword),
    hasNumber: /[0-9]/.test(formData.newPassword),
    hasSpecialChar: /[^A-Za-z0-9]/.test(formData.newPassword),
  };

  const allRequirementsMet = Object.values(passwordRequirements).every(Boolean);

  useEffect(() => {
    if (user && currentStep === 'login') {
      navigate('/dashboard', { replace: true });
    }
  }, [user, currentStep, navigate]);

  const validateLoginFields = (email: string, password: string): boolean => {
    const next: { email?: string; password?: string } = {};
    const trimmed = email.trim();

    if (!trimmed) {
      next.email = 'Email is required.';
    } else if (!EMAIL_REGEX.test(trimmed)) {
      next.email = 'Enter a valid email address.';
    }

    if (!password) {
      next.password = 'Password is required.';
    } else if (password.length < 8) {
      next.password = 'Password must be at least 8 characters.';
    }

    setFieldErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setError('');
    if (name === 'email' || name === 'password') {
      setFieldErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleOtpChange = (index: number, value: string) => {
    if (!/^\d?$/.test(value)) return;
    const newOtp = [...formData.otp];
    newOtp[index] = value;
    setFormData((prev) => ({ ...prev, otp: newOtp }));

    if (value && index < 5) {
      otpInputRefs.current[index + 1]?.focus();
    }

    const filled = newOtp.join('');
    if (filled.length === 6) {
      // Simulate OTP verification
      setOtpVerified(true);
    }
  };

  const handleOtpKeyDown = (index: number, e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !formData.otp[index] && index > 0) {
      otpInputRefs.current[index - 1]?.focus();
    }
  };

  const handlePasteOtp = (e: ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    const newOtp = Array(6).fill('');
    pasted.split('').forEach((char, i) => { newOtp[i] = char; });
    setFormData((prev) => ({ ...prev, otp: newOtp }));
    const nextEmpty = pasted.length < 6 ? pasted.length : 5;
    otpInputRefs.current[nextEmpty]?.focus();
    if (pasted.length === 6) setOtpVerified(true);
  };

  const formatTimer = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const startTimer = () => {
    setOtpTimer(60);
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setOtpTimer((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    if (!validateLoginFields(formData.email, formData.password)) {
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(API_URLS.CONFIG, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event_type: 'login_api',
          email: formData.email,
          password: formData.password,
        }),
      });

      const data = await response.json();

      if (!response.ok || (data.statusCode && data.statusCode !== 200)) {
        let errorMsg = 'Invalid email or password. Please try again.';
        if (data.body) {
          try {
            const bodyParsed = typeof data.body === 'string' ? JSON.parse(data.body) : data.body;
            if (bodyParsed.error) errorMsg = bodyParsed.error;
            else if (bodyParsed.message) errorMsg = bodyParsed.message;
          } catch {
            // ignore
          }
        }
        setError(errorMsg);
        return;
      }

      const responseBody = typeof data.body === 'string' ? JSON.parse(data.body) : data.body;
      const cookieTtl = { hours: LOGIN_COOKIE_TTL_HOURS };

      setCookie('userlogin', responseBody.email || formData.email, cookieTtl);
      setCookie('userRole', 'Admin', cookieTtl);

      if (responseBody.tokens) {
        setCookie('accessToken', responseBody.tokens.access_token, cookieTtl);
        setCookie('idToken', responseBody.tokens.id_token, cookieTtl);
        if (responseBody.tokens.refresh_token) {
          setCookie('refreshToken', responseBody.tokens.refresh_token, cookieTtl);
        }
      }

      setUser({ email: responseBody.email || formData.email, name: responseBody.username || 'User' });
      void refreshTokenUsageFromApi();
      navigate('/dashboard', { replace: true });
    } catch (err) {
      console.error(err);
      setError('Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async (e: FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    try {
      await new Promise((res) => setTimeout(res, 800));
      setCurrentStep('otp');
      startTimer();
    } catch {
      setError('Failed to send reset link. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendOtp = () => {
    setFormData((prev) => ({ ...prev, otp: Array(6).fill('') }));
    setOtpVerified(false);
    startTimer();
  };

  const handleResetPassword = async (e: FormEvent) => {
    e.preventDefault();
    if (formData.newPassword !== formData.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (!allRequirementsMet) {
      setError('Password does not meet all requirements.');
      return;
    }
    setIsLoading(true);
    setError('');
    try {
      await new Promise((res) => setTimeout(res, 800));
      setCurrentStep('login');
    } catch {
      setError('Failed to reset password. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const goToLoginStep = () => {
    setCurrentStep('login');
    setError('');
    setFieldErrors({});
  };

  const goToForgotStep = () => {
    setCurrentStep('forgot');
    setError('');
    setFieldErrors({});
  };

  return {
    currentStep,
    formData,
    isLoading,
    error,
    fieldErrors,
    showPassword,
    setShowPassword,
    showNewPassword,
    setShowNewPassword,
    showConfirmPassword,
    setShowConfirmPassword,
    otpTimer,
    otpVerified,
    otpInputRefs,
    messageContextHolder,
    passwordRequirements,
    allRequirementsMet,
    handleInputChange,
    handleOtpChange,
    handleOtpKeyDown,
    handlePasteOtp,
    formatTimer,
    handleSubmit,
    handleForgotPassword,
    handleResendOtp,
    handleResetPassword,
    goToLoginStep,
    goToForgotStep,
  };
}
