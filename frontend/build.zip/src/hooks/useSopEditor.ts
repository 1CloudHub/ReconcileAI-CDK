import { useEffect, useMemo, useRef } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { useSopJobs } from './sopEditor/useSopJobs';
import { useSopVersions } from './sopEditor/useSopVersions';
import { useSopForm } from './sopEditor/useSopForm';
import { useSopVersionActions } from './sopEditor/useSopVersionActions';
import type { SopEditLocationState } from './sopEditor/sopEditorHelpers';
import { useState } from 'react';

// Re-export types consumed by SopEditor.tsx
export type { VersionRow, SopEditLocationState } from './sopEditor/sopEditorHelpers';

export function useSopEditor() {
  const navigate = useNavigate();
  const location = useLocation();
  const { sop_name } = useParams<{ sop_name: string }>();
  const isEditMode = Boolean(sop_name);
  const decodedSopName = sop_name ? decodeURIComponent(sop_name) : '';

  const [sopId, setSopId] = useState<number | null>(null);

  // ── Sub-hooks ──────────────────────────────────────────────────────────────

  const { jobs, jobOptions, jobsLoading } = useSopJobs();

  const {
    uploadedVersions,
    setUploadedVersions,
    versionsListLoading,
    setVersionsRefreshNonce,
    tableState,
    updateTable,
    filteredVersions,
    pagedVersions,
    refreshVersions,
  } = useSopVersions({ sopId, decodedSopName, isEditMode });

  const {
    formState,
    updateForm,
    addSopSubmitting,
    exceptionDetailsSaving,
    validateAndSave,
    startExceptionDetailsEdit,
    cancelExceptionDetailsEdit,
    handleAddSop,
    initSavedDetails,
  } = useSopForm({ sopId, isEditMode, navigate, decodedSopName, uploadedVersions });

  const versionFileInputRef = useRef<HTMLInputElement>(null);

  const {
    deleteModal,
    updateDeleteModal,
    versionUploading,
    openVersionDocument,
    openVersionDeleteModal,
    confirmVersionDocumentDelete,
    handleVersionFile,
    handleVersionFileInputChange,
    handleVersionStatusChange,
  } = useSopVersionActions({
    sopId,
    decodedSopName,
    isEditMode,
    uploadedVersions,
    setUploadedVersions,
    setVersionsRefreshNonce,
    versionFileInputRef,
    formErrors: formState.errors,
    updateForm,
    updateTable,
  });

  // ── SopId + route state effect ─────────────────────────────────────────────

  useEffect(() => {
    if (!isEditMode) {
      setSopId(null);
      return;
    }
    const st = (location.state as SopEditLocationState | undefined) ?? undefined;
    const rawId = st?.sopId;
    const n = Number(rawId);
    const nextSopId = Number.isFinite(n) ? n : null;
    setSopId(nextSopId);
    const ids = st?.jobIds?.map((x) => Number(x)).filter((id) => Number.isFinite(id)) ?? [];
    updateForm({ selectedJobIds: ids });
    initSavedDetails(decodedSopName.trim(), ids);
  }, [isEditMode, location.key, location.state, decodedSopName]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Merged loading state ───────────────────────────────────────────────────

  const loadingState = useMemo(
    () => ({
      jobsLoading,
      addSopSubmitting,
      exceptionDetailsSaving,
      versionUploading,
      versionsListLoading,
    }),
    [jobsLoading, addSopSubmitting, exceptionDetailsSaving, versionUploading, versionsListLoading]
  );

  // ── Read-only job display ──────────────────────────────────────────────────

  const selectedJobLabels = useMemo(() => {
    const byId = new Map(jobs.map((j) => [j.id, j.job_name]));
    return formState.selectedJobIds.map((id) => byId.get(id)).filter(Boolean) as string[];
  }, [jobs, formState.selectedJobIds]);

  const jobNamesFromListRoute = useMemo(() => {
    const st = (location.state as SopEditLocationState | undefined) ?? undefined;
    const names = st?.jobNames?.map((s) => String(s).trim()).filter(Boolean) ?? [];
    return names.length > 0 ? names.join(', ') : '';
  }, [location.state]);

  const jobsReadOnlyDisplay =
    selectedJobLabels.length > 0 ? selectedJobLabels.join(', ') : jobNamesFromListRoute;

  // ── Return ─────────────────────────────────────────────────────────────────

  return {
    isEditMode,
    decodedSopName,
    formState,
    loadingState,
    tableState,
    deleteModal,
    jobs,
    uploadedVersions,
    sopId,
    versionFileInputRef,
    jobOptions,
    jobsReadOnlyDisplay,
    filteredVersions,
    pagedVersions,
    updateForm,
    updateTable,
    updateDeleteModal,
    openVersionDocument,
    openVersionDeleteModal,
    confirmVersionDocumentDelete,
    validateAndSave,
    startExceptionDetailsEdit,
    cancelExceptionDetailsEdit,
    handleAddSop,
    handleVersionFile,
    handleVersionFileInputChange,
    handleVersionStatusChange,
    refreshVersions,
  };
}
