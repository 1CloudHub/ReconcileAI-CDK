import { createContext, useContext, useState, type ReactNode } from 'react';
import { getCookie } from '../utils/cookies';

interface AuthUser {
  email: string;
  name?: string;
}

interface AuthContextValue {
  user: AuthUser | null;
  logout: () => void;
  setUser: (user: AuthUser | null) => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function userFromSessionCookie(): AuthUser | null {
  const email = getCookie('userlogin')?.trim();
  if (!email) return null;
  return { email, name: email.split('@')[0] };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(() => userFromSessionCookie());

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, logout, setUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
