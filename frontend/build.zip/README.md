# ReconcileAI — Agentic ERP Exception Management Platform

ReconcileAI is a web application that lets you define what fields to extract from documents, group them into jobs, and run those jobs through an AI reconciliation agent — without any ERP (e.g. SAP) integration. Everything from document type configuration to reconciliation session results is managed manually through the UI.

---

## What It Does

The platform solves the problem of reconciling multi-document transactions (e.g. matching a purchase order against an invoice and a delivery note). Instead of relying on an ERP system to define document structure, you:

1. **Define Document Types** — specify what fields the AI should extract from each document category.
2. **Create Jobs** — group document types together and designate one as the reference document.
3. **Configure SOPs** — write Standard Operating Procedures that define exception handling rules for a job.
4. **Run the Agent** — upload a set of documents against a job; the AI agent extracts fields, matches them across documents, and flags exceptions.
5. **Review Results** — inspect matched/unmatched fields, view the original documents, and track token usage.

---

## Main Flows

### Authentication
Email + password login with an OTP-based forgot-password flow. Session state is persisted via a cookie (`userlogin`).

### Document Type Setup
Create a named document type and define the fields the AI should extract from it (e.g. `invoice_number`, `total_amount`). You can test extraction against a sample document before saving.

### Job Configuration
Combine two or more document types into a job and pick one as the reference. Jobs are the unit of work for reconciliation runs.

### SOP Configuration
A multi-step editor for creating Standard Operating Procedures. Each SOP ties to a job and describes how to handle exceptions. SOPs are versioned — you can view history, compare versions, and publish a version.

### Reconciliation (Agent Run)
Upload documents (PDF / images) through the File Upload page. Select the job and document types for each file. The backend dispatches the reconciliation agent, which:
- Extracts fields from every document using the configured document type definitions
- Matches field values across documents according to the job's reference document
- Applies the active SOP rules to flag exceptions

Results appear in the **Reconcile Records** list with a status of `matched`, `not_matched`, `failed`, or `processing`. Click any record to inspect:
- A side-by-side document viewer
- Field consistency cards (which fields matched / mismatched per SOP rule)
- Token consumption for that session

### Token Usage
A paginated log of AI token consumption (input / output / total) per reconciliation session, filterable by module, action type, and date range.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | React 19 + TypeScript 5 |
| Build tool | Vite 8 |
| Routing | React Router 7 |
| State | Redux Toolkit (global) + React Context (auth) + local useState |
| UI components | Ant Design 6 |
| Styling | Tailwind CSS 3 |
| Charts | Recharts 3 |
| Icons | Lucide React |
| Animation | Framer Motion |
| Date utilities | dayjs |
| Backend | AWS Lambda (serverless) + S3 presigned URLs for file storage |

---

## Project Structure

```
src/
├── pages/          # One file per route (Dashboard, DocumentTypes, JobConfig, etc.)
├── components/     # Reusable UI components (tables, modals, inputs, charts, etc.)
├── layout/         # App shell (TopNav, SideNav) and SOP stepper sub-layouts
├── hooks/          # Custom hooks — data fetching + domain logic per feature
├── services/       # Raw API calls (fetch wrappers around Lambda endpoints)
├── context/        # AuthContext — user session state
├── store/          # Redux store (minimal, mostly for future use)
├── config/         # API URL constants and nav item definitions
├── types/          # TypeScript interfaces for all domain models
└── utils/          # Cookie helpers, misc utilities
```

---

## Pages & Routes

| Route | Page | Purpose |
|---|---|---|
| `/login` | Login | Email/password auth, OTP reset |
| `/dashboard` | Dashboard | KPI cards, 3-month reconciliation trend, top jobs chart |
| `/document-types` | Document Types | Create, edit, delete document type definitions and their extraction fields |
| `/job-config` | Job Config | Create and manage reconciliation jobs (document type groupings) |
| `/sop-control-center` | SOP Control Center | List, edit, delete SOPs; view version history |
| `/new_sop` | New SOP | Multi-step SOP creation wizard |
| `/:sop_name/edit` | Edit SOP | Edit an existing SOP by name |
| `/reconcile-agent/file-upload` | File Upload | Upload documents and trigger a reconciliation run |
| `/reconcile-agent/records` | Reconcile Records | List of all reconciliation sessions with status and filters |
| `/reconcile-agent/records/view` | Session Detail | Document viewer, field consistency, matching breakdown |
| `/token-usage` | Token Usage | Token consumption log per session |

---

## Key Domain Models

```typescript
// A named category of document with AI-extractable fields
DocumentType { id, document_name, description, field_names[], created_at, created_by }

// A reconciliation job — groups document types, one is the reference
JobItem { id, job_name, document_names[], reference_document_name, created_at, created_by }

// A Standard Operating Procedure tied to a job
SopException { id, sopId, sopName, exceptionName, jobName, jobIds[], createdAt }

// A single reconciliation session/run
ReconcileRecord {
  id, jobName, documentTypes[], uploadedAt,
  reconcileStatus: 'matched' | 'not_matched' | 'failed' | 'processing' | 'validation failed',
  sopData?, complianceFields?
}

// AI token usage per session
TokenUsageRecord { id, created_at, module, documents[], input_tokens, output_tokens, total_tokens }
```

---

## Environment Variables

The app expects a `.env` file at the project root. The API base URL is read via `VITE_API_BASE_URL` (see [src/config/api.config.ts](src/config/api.config.ts)).

---

## Getting Started

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

---

## Architecture Notes

- **No ERP integration** — document structure and extraction fields are defined entirely within the app.
- **Serverless backend** — all API calls go to AWS Lambda functions. Responses follow a `{ statusCode, body }` Lambda proxy format; the service layer normalises these.
- **S3 presigned URLs** — uploaded documents are stored in S3; the backend returns presigned URLs for viewing.
- **Event-driven API** — request bodies include an `event_type` field (e.g. `list_sops`, `reconcile_documents`) that routes to the correct Lambda handler.
- **SOP versioning** — SOPs have a full version history. Drafts are persisted to `localStorage` to prevent data loss on accidental navigation.
- **Token tracking** — every agent run logs input/output tokens so usage can be audited per session.
