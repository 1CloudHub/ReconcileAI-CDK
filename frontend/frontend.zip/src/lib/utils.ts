/**
 * Generates a unique session ID for chat sessions
 * @returns A unique session ID string
 */
export const generateSessionId = (): string => {
  return 'session_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
};

/**
 * Generates a unique message ID for chat messages
 * @returns A unique message ID string
 */
export const generateMessageId = (): string => {
  return 'msg_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
};

/**
 * Cookie utility functions for managing browser cookies
 */

/**
 * Sets a cookie with the given name, value, and optional expiration days
 * @param name - Cookie name
 * @param value - Cookie value
 * @param days - Number of days until expiration (default: 30 days)
 */
export const setCookie = (name: string, value: string, days: number = 30): void => {
  const date = new Date();
  date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
  const expires = `expires=${date.toUTCString()}`;
  document.cookie = `${name}=${value};${expires};path=/;SameSite=Strict`;
};

/**
 * Sets a cookie with the given name, value, and expiration in minutes
 * Useful for short-lived tokens and authentication tokens
 * @param name - Cookie name
 * @param value - Cookie value
 * @param minutes - Number of minutes until expiration (default: 57 minutes)
 */
export const setCookieMinutes = (name: string, value: string, minutes: number = 57): void => {
  const date = new Date();
  date.setTime(date.getTime() + (minutes * 60 * 1000));
  const expires = `expires=${date.toUTCString()}`;
  document.cookie = `${name}=${value};${expires};path=/;SameSite=Strict`;
};

/**
 * Gets a cookie value by name
 * @param name - Cookie name to retrieve
 * @returns Cookie value or empty string if not found
 */
export const getCookie = (name: string): string => {
  const nameEQ = `${name}=`;
  const cookies = document.cookie.split(';');
  
  for (let i = 0; i < cookies.length; i++) {
    let cookie = cookies[i];
    while (cookie.charAt(0) === ' ') {
      cookie = cookie.substring(1, cookie.length);
    }
    if (cookie.indexOf(nameEQ) === 0) {
      return cookie.substring(nameEQ.length, cookie.length);
    }
  }
  return '';
};

/**
 * Removes a cookie by setting its expiration date to the past
 * @param name - Cookie name to remove
 */
export const deleteCookie = (name: string): void => {
  document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;`;
};

