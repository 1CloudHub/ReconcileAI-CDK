/**
 * Formats a date string to display in IST (Indian Standard Time) timezone
 * Handles various date formats including ISO strings with timezone offsets
 * Since the database stores dates in IST, we preserve the original time
 * 
 * @param dateString - Date string from API (e.g., "2025-11-18 17:41:28.712 +0530")
 * @param includeTime - Whether to include time in the formatted output (default: true)
 * @returns Formatted date string in IST timezone
 */
export function formatDateIST(dateString: string | null | undefined, includeTime: boolean = true): string {
  if (!dateString) return 'N/A';

  try {
    const normalizedDateString = dateString.trim();
    
    // Log original date string
    console.log('formatDateIST - BEFORE conversion:', dateString);
    
    // Handle format: "2025-11-18 18:00:15.892 +0530"
    // Extract date and time directly since it's already in IST
    const timezoneMatch = normalizedDateString.match(/(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2}:\d{2}(?:\.\d+)?)\s+([+-])(\d{2})(\d{2})$/);
    
    if (timezoneMatch) {
      const [, datePart, timePart] = timezoneMatch;
      
      // Extract date components
      const [year, month, day] = datePart.split('-').map(Number);
      
      // Extract time components (remove milliseconds if present)
      const timeWithoutMs = timePart.split('.')[0];
      const [hour, minute, second] = timeWithoutMs.split(':').map(Number);
      
      // Format the date directly from the extracted components
      // Since the database stores time in IST, we display it as-is without conversion
      const formattedDate = `${String(day).padStart(2, '0')}/${String(month).padStart(2, '0')}/${year}`;
      
      if (includeTime) {
        const formattedTime = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}:${String(second).padStart(2, '0')}`;
        const result = `${formattedDate}, ${formattedTime}`;
        console.log('formatDateIST - AFTER conversion:', result);
        return result;
      }
      
      console.log('formatDateIST - AFTER conversion:', formattedDate);
      return formattedDate;
    }
    
    // Fallback: try to parse as ISO or other standard formats
    // Convert space-separated to ISO format if needed
    let isoString = normalizedDateString;
    if (normalizedDateString.includes(' ') && !normalizedDateString.includes('T')) {
      isoString = normalizedDateString.replace(' ', 'T');
      // If no timezone, assume UTC and we'll format in IST
      if (!isoString.includes('+') && !isoString.includes('Z') && !isoString.match(/[+-]\d{2}:\d{2}$/)) {
        isoString += '+05:30'; // Assume IST if no timezone
      }
    }

    const date = new Date(isoString);

    // Check if date is valid
    if (isNaN(date.getTime())) {
      return dateString; // Return original if parsing fails
    }

    // Format in IST timezone (Asia/Kolkata)
    const options: Intl.DateTimeFormatOptions = {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    };

    if (includeTime) {
      options.hour = '2-digit';
      options.minute = '2-digit';
      options.second = '2-digit';
      options.hour12 = false; // Use 24-hour format
    }

    const result = date.toLocaleString('en-IN', options);
    console.log('formatDateIST - AFTER conversion (fallback):', result);
    return result;
  } catch (error) {
    console.error('Error formatting date:', error);
    return dateString; // Return original string on error
  }
}

/**
 * Formats a date string to display date only (without time) in IST
 */
export function formatDateOnlyIST(dateString: string | null | undefined): string {
  return formatDateIST(dateString, false);
}

export default formatDateIST;

