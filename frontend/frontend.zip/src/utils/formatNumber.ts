// Small helper to format large numbers into compact currency strings
// Examples:
//  16125.45 -> "$16.13K"
//  123450.00 -> "$123.45K"
//  2700000 -> "$2.7M"
//  50000000 -> "$50M"

export function formatCompactCurrency(value: number | null | undefined, symbol = '$'): string {
  if (value === null || value === undefined || Number.isNaN(value)) return `${symbol}0.00`;

  const num = Number(value);
  const abs = Math.abs(num);
  const sign = num < 0 ? '-' : '';

  // Millions -> use 1 decimal place when needed (2.7M) but drop trailing .0 (50M)
  if (abs >= 1_000_000) {
    const m = abs / 1_000_000;
    // Show one decimal place if fractional part exists, otherwise integer
    const str = Number.isInteger(m) ? String(m) : Number(m.toFixed(1)).toString();
    return `${sign}${symbol}${str}M`;
  }

  // Thousands -> use up to 2 decimal places, but trim trailing zeros
  if (abs >= 1_000) {
    const k = abs / 1_000;
    const raw = k.toFixed(2); // 2 decimal places max
    const trimmed = raw.replace(/(?:\.0+|(?<=\.[0-9]*?)0+)$/, ''); // remove trailing zeros and optional dot
    return `${sign}${symbol}${trimmed}K`;
  }

  // Less than 1000 -> show full number with 2 decimals
  return `${sign}${symbol}${abs.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export default formatCompactCurrency;
