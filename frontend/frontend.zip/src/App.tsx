import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useEffect, useRef, type ReactNode } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { getCookie } from './lib/utils';
import ProtectedRoute from './components/ProtectedRoute';
import AdminProtectedRoute from './components/AdminProtectedRoute';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Exceptions from './pages/Exceptions';
import Drilldown from './pages/Drilldown';
import SOP_Control_Center from './pages/SOP_Control_Center';
import SAPAssistant from './pages/SAPAssistant';
import ERPAssistant from './pages/ERPAssistant';
import RAGAssistant from './pages/RAGAssistant';
import UserManagement from './pages/UserManagement';

/**
 * RouteGuard component that checks for tokens in cookies before allowing navigation
 * This provides an additional layer of security beyond ProtectedRoute
 * Uses React Router navigation instead of window.location to avoid page reloads
 */
function RouteGuard({ children }: { children: ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { logout, isLoading } = useAuth();
  const redirectingRef = useRef(false);

  useEffect(() => {
    // Skip check on login page
    if (location.pathname === '/login') {
      redirectingRef.current = false;
      return;
    }

    // Skip check while loading
    if (isLoading) {
      return;
    }

    // Prevent multiple redirects
    if (redirectingRef.current) {
      return;
    }

    // Check if access_token exists in cookies
    const accessToken = getCookie('access_token');
    
    // If no token found and not on login page, redirect to login using React Router
    if (!accessToken) {
      console.log('No access token found in cookies - redirecting to login');
      redirectingRef.current = true;
      logout();
      navigate('/login', { replace: true });
    }
  }, [location.pathname, logout, isLoading, navigate]);

  return <>{children}</>;
}

function AppRoutes() {
  return (
    <RouteGuard>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          } />
          <Route path="/exceptions" element={
            <ProtectedRoute>
              <Exceptions />
            </ProtectedRoute>
          } />
          <Route path="/drilldown" element={
            <ProtectedRoute>
              <Drilldown />
            </ProtectedRoute>
          } />
              <Route path="/agents" element={
                <ProtectedRoute>
                  <SOP_Control_Center />
                </ProtectedRoute>
              } />
          <Route path="/sap-assistant" element={
            <ProtectedRoute>
              <SAPAssistant />
            </ProtectedRoute>
          } />
          <Route path="/erp-assistant" element={
            <ProtectedRoute>
              <ERPAssistant />
            </ProtectedRoute>
          } />
          <Route path="/rag-assistant" element={
            <ProtectedRoute>
              <RAGAssistant />
            </ProtectedRoute>
          } />
          <Route path="/user-management" element={
            <AdminProtectedRoute>
              <UserManagement />
            </AdminProtectedRoute>
          } />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </RouteGuard>
  );
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
