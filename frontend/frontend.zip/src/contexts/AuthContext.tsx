import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import { deleteCookie, getCookie } from '../lib/utils';

interface Tokens {
  access_token?: string;
  id_token?: string;
  refresh_token?: string;
}

interface User {
  email: string;
  name?: string;
  loginTime?: string;
  attributes?: any;
}

interface AuthContextType {
  user: User | null;
  tokens: Tokens | null;
  login: (user: User, tokens: Tokens) => void;
  logout: () => void;
  isAuthenticated: boolean;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be inside AuthProvider");
  return ctx;
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [tokens, setTokens] = useState<Tokens | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  /**
   * Restore authentication state from cookies on mount
   * Checks for tokens in cookies to determine if user is authenticated
   */
  useEffect(() => {
    try {
      // Check for tokens in cookies
      const accessToken = getCookie('access_token');
      const idToken = getCookie('id_token');
      const refreshToken = getCookie('refresh_token');
      const userid = getCookie('userid');

      // If access_token exists, user is authenticated
      if (accessToken) {
        // Build tokens object from cookies
        const tokenData: Tokens = {};
        if (accessToken) tokenData.access_token = accessToken;
        if (idToken) tokenData.id_token = idToken;
        if (refreshToken) tokenData.refresh_token = refreshToken;

        setTokens(tokenData);
        setIsAuthenticated(true);

        // Try to restore user data from localStorage (if available)
        // This is a fallback - primary auth is cookie-based
        try {
          const userData = localStorage.getItem("auth.user");
          if (userData) {
            setUser(JSON.parse(userData));
          } else if (userid) {
            // If no user data in localStorage, create minimal user object
            setUser({
              email: '', // Will be populated on next login
              name: '',
              loginTime: new Date().toISOString()
            });
          }
        } catch (err) {
          console.error('Error parsing user data from localStorage:', err);
        }
      } else {
        // No tokens found - user is not authenticated
        setIsAuthenticated(false);
        setTokens(null);
        setUser(null);
      }
    } catch (err) {
      console.error('Error checking authentication state:', err);
      setIsAuthenticated(false);
      setTokens(null);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  /**
   * Logout function that clears all authentication data
   * Clears user state, tokens, removes all auth-related data from localStorage,
   * and clears all authentication cookies (tokens and userid)
   */
  const logout = useCallback(() => {
    // Clear state
    setUser(null);
    setTokens(null);
    setIsAuthenticated(false);
    
    // Clear all auth-related cookies
    deleteCookie('access_token');
    deleteCookie('id_token');
    deleteCookie('refresh_token');
    deleteCookie('userid');
    
    // Clear all auth-related data from localStorage
    localStorage.removeItem("auth.user");
    localStorage.removeItem("auth.tokens");
    
    // Clear any other potential auth-related storage
    // This ensures a complete logout
    try {
      const keys = Object.keys(localStorage);
      keys.forEach(key => {
        if (key.startsWith('auth.')) {
          localStorage.removeItem(key);
        }
      });
    } catch (error) {
      console.error('Error clearing localStorage:', error);
    }
  }, []);

  /**
   * Check authentication status by verifying tokens exist in cookies
   * This function is called on mount and when route changes
   */
  const checkAuthentication = useCallback(() => {
    const accessToken = getCookie('access_token');
    
    if (accessToken) {
      // Token exists - user is authenticated
      if (!isAuthenticated) {
        // Update state if we weren't authenticated before
        const idToken = getCookie('id_token');
        const refreshToken = getCookie('refresh_token');
        
        const tokenData: Tokens = {};
        if (accessToken) tokenData.access_token = accessToken;
        if (idToken) tokenData.id_token = idToken;
        if (refreshToken) tokenData.refresh_token = refreshToken;
        
        setTokens(tokenData);
        setIsAuthenticated(true);
      }
    } else {
      // Token doesn't exist - user is not authenticated
      if (isAuthenticated) {
        console.log('Session expired - access_token cookie not found');
        logout();
      }
    }
  }, [isAuthenticated, logout]);

  /**
   * Continuously check for token expiration by verifying cookies exist
   * Since cookies auto-expire, we just need to check if they still exist
   * This runs whenever authentication state might change
   */
  useEffect(() => {
    checkAuthentication();
  }, [checkAuthentication]);

  /**
   * Login function that stores user data and updates authentication state
   * Note: Tokens are already stored in cookies by Login component
   * This function just updates the React state
   */
  const login = (user: User, tokens: Tokens) => {
    setUser(user);
    setTokens(tokens);
    setIsAuthenticated(true);

    // Store user data in localStorage as backup (tokens are in cookies)
    localStorage.setItem("auth.user", JSON.stringify(user));
  };


  return (
    <AuthContext.Provider value={{ user, tokens, login, logout, isAuthenticated, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};
