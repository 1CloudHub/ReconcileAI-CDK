import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { getCookie } from '../lib/utils';
import styles from './TopNav.module.css';

export default function TopNav() {
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleResetData = async () => {
    setIsResetting(true);
    try {
      const userid = getCookie('userid');
      const API_URL = import.meta.env.VITE_API_URL;

      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          event_type: 'reset_user_data',
          userid: userid || null
        }),
      });

      const data = await response.json();

      if (response.ok) {
        // Close modal and reload to reflect changes (no alert popup)
        setShowResetConfirm(false);
        setShowUserMenu(false);
        window.location.reload();
      } else {
        // On failure, close modal and stop loading (no alert popup)
        console.error('Failed to reset data:', data.error || 'Unknown error');
        setShowResetConfirm(false);
        setShowUserMenu(false);
        setIsResetting(false);
      }
    } catch (error) {
      console.error('Error resetting data:', error);
      // Close modal and stop loading; avoid alert popups
      setShowResetConfirm(false);
      setShowUserMenu(false);
      setIsResetting(false);
    } finally {
      // If we've reloaded the page on success, this code may not run; keep as safeguard
      setIsResetting(false);
    }
  };
  

  return (
    <nav className={styles.topNav}>
      <div className={styles.left}>
        <div className={styles.logo}>
          <img 
            src="/assets/1CloudHub-Logo-horiz-hires-RGB-copy-1.jpg" 
            alt="1CloudHub" 
            className={styles.logoImage}
          />
        </div>
      </div>

      {/* Title section removed as requested */}

      <div className={styles.right}>
        <button
          className={styles.resetBlueButton}
          onClick={() => setShowResetConfirm(true)}
          disabled={isResetting}
          type="button"
        >
          {isResetting ? 'Resetting...' : 'Reset Data'}
        </button>

        <div className={styles.userMenu}>
          <button
            className={styles.userButton}
            onClick={() => setShowUserMenu(!showUserMenu)}
          >
            <div className={styles.avatar}>
              {user 
                ? (user.name || user.email || 'U').charAt(0).toUpperCase()
                : 'U'}
            </div>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>

          {showUserMenu && (
            <div className={styles.dropdown}>
              {/* User Email Display */}
              {user?.email && (
                <div className={styles.userEmail}>
                  {user.email}
                </div>
              )}
              {/* Logout Option */}
              <div className={styles.dropdownItem} onClick={handleLogout}>
                Logout
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <div className={styles.modalOverlay} onClick={() => !isResetting && setShowResetConfirm(false)}>
          <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <h3>Reset User Data</h3>
            </div>
            <div className={styles.modalBody}>
              <p><strong>Warning:</strong> This operation will reset the system by deleting all user-generated data.</p>
              <p>Default system entries will not be affected.</p>
              <p className={styles.confirmQuestion}>Are you sure you want to proceed?</p>
            </div>
            <div className={styles.modalFooter}>
              <button 
                className={styles.cancelButton}
                onClick={() => setShowResetConfirm(false)}
                disabled={isResetting}
              >
                Cancel
              </button>
              <button 
                className={styles.resetButton}
                onClick={handleResetData}
                disabled={isResetting}
              >
                {isResetting ? 'Resetting...' : 'Reset Data'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Search feature removed per user request */}
    </nav>
  );
}
