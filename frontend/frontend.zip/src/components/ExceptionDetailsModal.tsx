import React, { useEffect, useState } from 'react';
import { Spin, Tooltip } from 'antd';
import ReactMarkdown from 'react-markdown';
import formatDateIST from '../utils/formatDate';
import { getCookie } from '../lib/utils';
import styles from './ExceptionDetailsModal.module.css';

interface ExceptionDetailsModalProps {
  onClose: () => void;
  details: any;
  loading: boolean;
  onStatusUpdate?: () => void; // Callback to refresh parent data after status change
  onCardsUpdate?: () => void; // Callback to refresh cards data after status change
  apiUrl: string; // Add API URL prop
  totalCount?: number; // override for total exceptions count (from table's exceptionCount)
}

export default function ExceptionDetailsModal({ details, loading, onClose, onStatusUpdate, onCardsUpdate, apiUrl, totalCount }: ExceptionDetailsModalProps) {
  const [showEscalatePopup, setShowEscalatePopup] = useState(false);
  const [showApprovalPopup, setShowApprovalPopup] = useState(false);
  const [submittingEscalation, setSubmittingEscalation] = useState(false); // Separate state for modal submit button
  const [reRunning, setReRunning] = useState(false);
  const [submittingApproval, setSubmittingApproval] = useState(false); // Separate state for modal submit button
  const [showAdditionalEmail, setShowAdditionalEmail] = useState(false);
  const [additionalEmailInput, setAdditionalEmailInput] = useState('');
  const [additionalEmails, setAdditionalEmails] = useState<string[]>([]);

  /**
   * Check if PO card should have a red border
   * Returns true if there's a pending "Missing PO" exception
   */
  const shouldHighlightPOCard = (): boolean => {
    if (!details?.exceptions) return false;
    
    return details.exceptions.some((exceptionDetail: any) => {
      const exception = exceptionDetail.exception;
      if (!exception) return false;
      
      // Only highlight if status is Pending
      if (exception.exceptionStatus?.toLowerCase() !== 'pending') return false;
      
      // Check if it's a Missing PO exception
      const exceptionName = exception.exceptionName?.toLowerCase() || '';
      return exceptionName.includes('missing po') || exceptionName.includes('missing purchase order');
    });
  };

  /**
   * Check if GRN card should have a red border
   * Returns true if there's a pending "Missing GR" exception
   */
  const shouldHighlightGRNCard = (): boolean => {
    if (!details?.exceptions) return false;
    
    return details.exceptions.some((exceptionDetail: any) => {
      const exception = exceptionDetail.exception;
      if (!exception) return false;
      
      // Only highlight if status is Pending
      if (exception.exceptionStatus?.toLowerCase() !== 'pending') return false;
      
      // Check if it's a Missing GR exception
      const exceptionName = exception.exceptionName?.toLowerCase() || '';
      return exceptionName.includes('missing gr') || 
             exceptionName.includes('missing goods receipt') ||
             exceptionName.includes('missing grn');
    });
  };

  /**
   * Check if Invoice card should have a red border
   * Returns true if there's a pending "Invoice Errors" exception
   */
  const shouldHighlightInvoiceCard = (): boolean => {
    if (!details?.exceptions) return false;
    
    return details.exceptions.some((exceptionDetail: any) => {
      const exception = exceptionDetail.exception;
      if (!exception) return false;
      
      // Only highlight if status is Pending
      if (exception.exceptionStatus?.toLowerCase() !== 'pending') return false;
      
      // Check if it's an Invoice Errors exception
      const exceptionName = exception.exceptionName?.toLowerCase() || '';
      return exceptionName.includes('invoice error') || 
             exceptionName.includes('missing invoice') ||
             exceptionName.includes('duplicate invoice');
    });
  };

  /**
   * Check if exception is item-specific
   * Item-specific: Price Mismatch, Quantity Variance, UoM Issues
   */
  const isItemSpecificException = (exceptionName: string): boolean => {
    const exceptionLower = exceptionName?.toLowerCase() || '';
    return exceptionLower.includes('price mismatch') ||
           exceptionLower.includes('quantity variance') ||
           exceptionLower.includes('uom issue') ||
           exceptionLower.includes('unit of measure');
  };

  /**
   * Check if a specific item should have a red border
   * Returns true if there's a pending item-specific exception for this item
   */
  const shouldHighlightItem = (itemNumber: string): boolean => {
    if (!details?.exceptions) return false;
    
    return details.exceptions.some((exceptionDetail: any) => {
      const exception = exceptionDetail.exception;
      if (!exception) return false;
      
      // Only highlight if status is Pending
      if (exception.exceptionStatus?.toLowerCase() !== 'pending') return false;
      
      // Check if it's an item-specific exception for this item
      const exceptionItemNo = exception.itemNo?.toString().padStart(5, '0');
      const currentItemNo = itemNumber?.toString().padStart(5, '0');
      
      return isItemSpecificException(exception.exceptionName) && exceptionItemNo === currentItemNo;
    });
  };

  // Get trigger emails from the top-level response
  const getTriggerEmails = (): string[] => {
    if (details?.trigger_emails && Array.isArray(details.trigger_emails)) {
      return details.trigger_emails.filter((email: string) => email && email.trim());
    }
    return [];
  };

  const triggerEmails = getTriggerEmails();
  const emailsDisplay = triggerEmails.length > 0 ? triggerEmails.join(', ') : 'No emails configured';
  
  // Simple email validation
  const isValidEmail = (e: string) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(e);
  };

  // Add the email from the input to the additionalEmails array (if valid and not duplicate)
  const addAdditionalEmail = (raw: string) => {
    const val = (raw || '').trim();
    if (!val) return false;
    if (!isValidEmail(val)) return false;
    if (additionalEmails.includes(val)) return false;
    setAdditionalEmails(prev => [...prev, val]);
    setAdditionalEmailInput('');
    return true;
  };

  const removeAdditionalEmail = (email: string) => {
    setAdditionalEmails(prev => prev.filter(e => e !== email));
  };

  // Final email list for display in confirmation (includes any additional emails)
  const getFinalEmailList = (): string => {
    const baseEmails = [...triggerEmails];
    additionalEmails.forEach(e => {
      if (e && e.trim()) baseEmails.push(e.trim());
    });
    // include current input if it's a valid email
    if (additionalEmailInput && additionalEmailInput.trim() && isValidEmail(additionalEmailInput.trim())) {
      baseEmails.push(additionalEmailInput.trim());
    }
    return baseEmails.length > 0 ? Array.from(new Set(baseEmails)).join(', ') : 'No emails configured';
  };

  const getStatusClass = (status?: string) => {
    const key = (status || '').toString().toLowerCase().replace(/\s+/g, '');
    return (styles as any)[key] || '';
  };

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('keydown', handleEscape);
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [onClose]);

  // Note: rendering markdown directly; ensureMarkdown helper removed per request.

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  // Get current bundle-level status from details; fall back to exception-level status if bundle_status missing
  const currentStatus = details?.bundle_status || details?.exceptions?.[0]?.exception?.status || 'Pending';

  // Handle escalate button click
  const handleEscalateClick = () => {
    setShowEscalatePopup(true);
  };

  // Handle escalation confirmation
  const handleEscalateConfirm = async () => {
    console.log('Escalate confirm clicked');
    setSubmittingEscalation(true); // Only set modal submit button loading state
    try {
      // Get userid from cookies for API calls
      const userid = getCookie('userid');
      
      console.log('Sending request with:', {
        event_type: 'update_bundle_status_new_schema',
        bundle_id: details?.bundle_id,
        session_id: details?.session_id,
        status: 'Escalated',
        userid: userid || null
      });
      console.log('API URL:', apiUrl);
      
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          event_type: 'update_bundle_status_new_schema',
          bundle_id: details?.bundle_id,
          session_id: details?.session_id,
          status: 'Escalated',
          userid: userid || null
        }),
      });

      console.log('Response status:', response.status);
      const responseData = await response.json();
      console.log('Response data:', responseData);

      if (response.ok) {
        console.log('Update successful');
        setShowEscalatePopup(false);
        setShowAdditionalEmail(false);
        setAdditionalEmailInput('');
        setAdditionalEmails([]);
        setSubmittingEscalation(false);
        // Call the callback to refresh parent data
        if (onStatusUpdate) {
          onStatusUpdate();
        }
        // Close the modal
        onClose();
      } else {
        console.error('Failed to update status:', responseData);
        alert(`Failed to update status: ${responseData.error || 'Unknown error'}`);
        setSubmittingEscalation(false);
      }
    } catch (error) {
      console.error('Error updating status:', error);
      alert(`Error updating status: ${error}`);
      setSubmittingEscalation(false);
    }
  };

  // Handle Re-run Check (no confirmation popup). Sets bundle status to 'Pending Approval'
  const handleRerunClick = async () => {
    console.log('Re-run check clicked');
    setReRunning(true);
    try {
      // Get userid from cookies for API calls
      const userid = getCookie('userid');
      
      const payload = {
        event_type: 'update_bundle_status_new_schema',
        bundle_id: details?.bundle_id,
        session_id: details?.session_id,
        status: 'Pending Approval',
        userid: userid || null
      };
      console.log('Sending re-run request with:', payload);
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const responseData = await response.json();
      console.log('Re-run response status:', response.status, responseData);

      if (response.ok) {
        // Notify parent to refresh and close modal
        if (onStatusUpdate) onStatusUpdate();
        onClose();
      } else {
        console.error('Failed to update status on re-run:', responseData);
        alert(`Failed to update status: ${responseData.error || 'Unknown error'}`);
      }
    } catch (err) {
      console.error('Error during re-run request:', err);
      alert(`Error updating status: ${err}`);
    } finally {
      setReRunning(false);
    }
  };

  // Handle Approve Resolution: show confirmation popup first
  const handleApproveClick = () => {
    setShowApprovalPopup(true);
  };

  // Handle approval confirmation - actually make the API call
  const handleApprovalConfirm = async () => {
    console.log('Approve resolution confirmed');
    setSubmittingApproval(true); // Only set modal submit button loading state
    try {
      // Get userid from cookies for API calls
      const userid = getCookie('userid');
      
      const payload = {
        event_type: 'update_bundle_status_new_schema',
        bundle_id: details?.bundle_id,
        session_id: details?.session_id,
        status: 'Resolved',
        userid: userid || null
      };
      console.log('Sending approve request with:', payload);
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const responseData = await response.json();
      console.log('Approve response status:', response.status, responseData);

      if (response.ok) {
        setShowApprovalPopup(false);
        setSubmittingApproval(false);
        if (onStatusUpdate) onStatusUpdate();
        if (onCardsUpdate) onCardsUpdate();
        onClose();
      } else {
        console.error('Failed to approve status:', responseData);
        alert(`Failed to update status: ${responseData.error || 'Unknown error'}`);
        setSubmittingApproval(false);
      }
    } catch (err) {
      console.error('Error during approve request:', err);
      alert(`Error updating status: ${err}`);
      setSubmittingApproval(false);
    }
  };

  // Handle cancel approval
  const handleApprovalCancel = () => {
    setShowApprovalPopup(false);
  };

  // Handle cancel escalation
  const handleEscalateCancel = () => {
    setShowEscalatePopup(false);
    setShowAdditionalEmail(false);
    setAdditionalEmailInput('');
    setAdditionalEmails([]);
  };

  return (
    <div className={styles.modalOverlay} onClick={handleBackdropClick}>
      <div className={styles.modalContent}>
        <div className={styles.modalHeader}>
          <div className={styles.headerLeft}>
            <h2 className={styles.exceptionId}>PO: {details?.po_number || 'Unknown'}</h2>
            <div className={styles.headerMeta}>
              <span className={styles.metaItem}>
                <span className={styles.metaLabel}>Total Exceptions:</span> {typeof totalCount === 'number' ? totalCount : (details?.exception_count || details?.exceptions?.length || 0)}
              </span>
              <span className={styles.metaItem}>
                <span className={styles.metaLabel}>PO Number:</span> {details?.po_number || 'N/A'}
              </span>
              <span className={styles.metaItem}>
                <span className={styles.metaLabel}>Status:</span>
                <span className={`${styles.statusTag} ${getStatusClass(currentStatus)}`} style={{ marginLeft: 6, padding: '4px 10px', borderRadius: 12, fontSize: 12, fontWeight: 600, textTransform: 'none' }}>
                  {currentStatus}
                </span>
              </span>
            </div>
          </div>
          <div className={styles.headerRight}>
            <button className={styles.closeButton} onClick={onClose}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          </div>
        </div>

        <div className={styles.modalBody}>
          {loading ? (
            <div style={{ textAlign: 'center', padding: '40px' }}>
              <Spin size="default" style={{ color: '#003d75' }} />
              <p style={{ marginTop: 12 }}>Loading exception details...</p>
            </div>
          ) : !details || !details.exceptions || details.exceptions.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px' }}>
              <p>No exception details available for this PO</p>
            </div>
          ) : (() => {
              // Extract PO, GRN, and Invoice data from the first exception
              // The structure has document numbers as keys (e.g., purchaseOrder["4500016789"])
              const firstException = details.exceptions[0];
              
              // Get PO data - extract first key from purchaseOrder object
              const poKey = firstException?.purchaseOrder ? Object.keys(firstException.purchaseOrder)[0] : null;
              const poData = poKey ? firstException.purchaseOrder[poKey] : null;
              
              // Get GRN data - extract first key from goodsReceipt object
              const grnKey = firstException?.goodsReceipt ? Object.keys(firstException.goodsReceipt)[0] : null;
              const grnData = grnKey ? firstException.goodsReceipt[grnKey] : null;
              
              // Get Invoice data - extract first key from invoice object
              const invoiceKey = firstException?.invoice ? Object.keys(firstException.invoice)[0] : null;
              const invoiceData = invoiceKey ? firstException.invoice[invoiceKey] : null;

              return (
                <>
                  {/* Show PO, GR, Invoice details once at the top */}
                  <div className={styles.dataSection}>
                    {/* Purchase Order Card */}
                    <div 
                      className={`${styles.dataCard} ${shouldHighlightPOCard() ? styles.dataCardError : ''}`}
                    >
                      <div className={`${styles.cardHeader} ${shouldHighlightPOCard() ? styles.cardHeaderError : ''}`}>
                        <h3 className={styles.cardTitle}>Purchase Order (PO)</h3>
                      </div>
                      <div className={`${styles.cardContent} ${styles.scrollableContent}`}>
                        {poData ? (
                          <>
                            {/* PO Header Information */}
                            <div className={styles.headerSection}>
                              <div className={styles.dataRow}>
                                <span className={styles.dataLabel}>PO Number:</span>
                                <span className={styles.dataValue}>{poData.PurchaseOrder || poKey || 'N/A'}</span>
                              </div>
                              <div className={styles.dataRow}>
                                <span className={styles.dataLabel}>Vendor:</span>
                                <span className={styles.dataValue}>{poData.Vendor || 'N/A'}</span>
                              </div>
                              <div className={styles.dataRow}>
                                <span className={styles.dataLabel}>Currency:</span>
                                <span className={styles.dataValue}>{poData.DocumentCurrency || 'N/A'}</span>
                              </div>
                              <div className={styles.dataRow}>
                                <span className={styles.dataLabel}>Total Amount:</span>
                                <span className={styles.dataValue}>
                                  {poData.DocumentCurrency || ''} {poData.POHeaderNetValue?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || 'N/A'}
                                </span>
                              </div>
                              <div className={styles.dataRow}>
                                <span className={styles.dataLabel}>PO Date:</span>
                                <span className={styles.dataValue}>
                                  {poData.CreatedOn ? new Date(poData.CreatedOn).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : 'N/A'}
                                </span>
                              </div>
                            </div>

                            {/* Item-wise Details */}
                            {poData.Items && poData.Items.length > 0 && (
                              <div className={styles.itemsSection}>
                                <h4 className={styles.itemsTitle}>Item Details</h4>
                                <div className={styles.itemsList}>
                                  {poData.Items.map((item: any, idx: number) => (
                                    <div 
                                      key={idx} 
                                      className={`${styles.itemCard} ${shouldHighlightItem(item.PurchaseOrderItem) ? styles.itemCardError : ''}`}
                                    >
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Item:</span>
                                        <span className={styles.dataValue}>{item.PurchaseOrderItem || 'N/A'}</span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Material:</span>
                                        <span className={styles.dataValue}>{item.Material || 'N/A'}</span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Order Quantity:</span>
                                        <span className={styles.dataValue}>{item.OrderQuantity || 'N/A'}</span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Unit of Measure:</span>
                                        <span className={styles.dataValue}>{item.OrderUnit || 'N/A'}</span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Unit Price:</span>
                                        <span className={styles.dataValue}>
                                          {poData.DocumentCurrency || ''} {item.OrderPrice?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || 'N/A'}
                                        </span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Net Amount:</span>
                                        <span className={styles.dataValue}>
                                          {poData.DocumentCurrency || ''} {item.NetAmount?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || 'N/A'}
                                        </span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Delivery Date:</span>
                                        <span className={styles.dataValue}>
                                          {item.DeliveryDate ? new Date(item.DeliveryDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : 'N/A'}
                                        </span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </>
                        ) : (
                          <p>No purchase order data available</p>
                        )}
                      </div>
                    </div>

                    {/* Goods Receipt Card */}
                    <div 
                      className={`${styles.dataCard} ${shouldHighlightGRNCard() ? styles.dataCardError : ''}`}
                    >
                      <div className={`${styles.cardHeader} ${shouldHighlightGRNCard() ? styles.cardHeaderError : ''}`}>
                        <h3 className={styles.cardTitle}>Goods Receipt (GR)</h3>
                      </div>
                      <div className={`${styles.cardContent} ${styles.scrollableContent}`}>
                        {grnData ? (
                          <>
                            {/* GRN Header Information */}
                            <div className={styles.headerSection}>
                              <div className={styles.dataRow}>
                                <span className={styles.dataLabel}>GRN Number:</span>
                                <span className={styles.dataValue}>{grnData.MaterialDocument || grnKey || 'N/A'}</span>
                              </div>
                              <div className={styles.dataRow}>
                                <span className={styles.dataLabel}>GRN Date:</span>
                                <span className={styles.dataValue}>
                                  {grnData.PostingDate ? new Date(grnData.PostingDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : 'N/A'}
                                </span>
                              </div>
                            </div>

                            {/* Item-wise Details */}
                            {grnData.Items && grnData.Items.length > 0 && (
                              <div className={styles.itemsSection}>
                                <h4 className={styles.itemsTitle}>Item Details</h4>
                                <div className={styles.itemsList}>
                                  {grnData.Items.map((item: any, idx: number) => (
                                    <div 
                                      key={idx} 
                                      className={`${styles.itemCard} ${shouldHighlightItem(item.PurchaseOrderItem) ? styles.itemCardError : ''}`}
                                    >
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Item:</span>
                                        <span className={styles.dataValue}>{item.PurchaseOrderItem || 'N/A'}</span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Material:</span>
                                        <span className={styles.dataValue}>{item.Material || 'N/A'}</span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Status:</span>
                                        <span className={styles.dataValue}>{item.GRStatus || 'N/A'}</span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Received Quantity:</span>
                                        <span className={styles.dataValue}>{item.QuantityInEntryUnit || 'N/A'}</span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Entry Unit:</span>
                                        <span className={styles.dataValue}>{item.EntryUnit || 'N/A'}</span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Amount:</span>
                                        <span className={styles.dataValue}>
                                          {item.AmountInDocumentCurrency?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || 'N/A'}
                                        </span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </>
                        ) : (
                          <p>No goods receipt data available</p>
                        )}
                      </div>
                    </div>

                    {/* Invoice Card */}
                    <div 
                      className={`${styles.dataCard} ${shouldHighlightInvoiceCard() ? styles.dataCardError : ''}`}
                    >
                      <div className={`${styles.cardHeader} ${shouldHighlightInvoiceCard() ? styles.cardHeaderError : ''}`}>
                        <h3 className={styles.cardTitle}>Invoice</h3>
                      </div>
                      <div className={`${styles.cardContent} ${styles.scrollableContent}`}>
                        {invoiceData ? (
                          <>
                            {/* Invoice Header Information */}
                            <div className={styles.headerSection}>
                              <div className={styles.dataRow}>
                                <span className={styles.dataLabel}>Invoice Number:</span>
                                <span className={styles.dataValue}>{invoiceData.BillingDocument || invoiceKey || 'N/A'}</span>
                              </div>
                              <div className={styles.dataRow}>
                                <span className={styles.dataLabel}>Invoice Date:</span>
                                <span className={styles.dataValue}>
                                  {invoiceData.PostingDate ? new Date(invoiceData.PostingDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : 'N/A'}
                                </span>
                              </div>
                              <div className={styles.dataRow}>
                                <span className={styles.dataLabel}>Supplier:</span>
                                <span className={styles.dataValue}>{invoiceData.Supplier || 'N/A'}</span>
                              </div>
                              <div className={styles.dataRow}>
                                <span className={styles.dataLabel}>Currency:</span>
                                <span className={styles.dataValue}>{invoiceData.DocumentCurrency || 'N/A'}</span>
                              </div>
                            </div>

                            {/* Item-wise Details */}
                            {invoiceData.Items && invoiceData.Items.length > 0 && (
                              <div className={styles.itemsSection}>
                                <h4 className={styles.itemsTitle}>Item Details</h4>
                                <div className={styles.itemsList}>
                                  {invoiceData.Items.map((item: any, idx: number) => (
                                    <div 
                                      key={idx} 
                                      className={`${styles.itemCard} ${shouldHighlightItem(item.ReferencePurchaseOrderItem) ? styles.itemCardError : ''}`}
                                    >
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Item:</span>
                                        <span className={styles.dataValue}>{item.ReferencePurchaseOrderItem || 'N/A'}</span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Material:</span>
                                        <span className={styles.dataValue}>{item.Material || 'N/A'}</span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Billing Quantity:</span>
                                        <span className={styles.dataValue}>{item.BillingQuantity || 'N/A'}</span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Billing UoM:</span>
                                        <span className={styles.dataValue}>{item.BillingQuantityUnit || 'N/A'}</span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Unit Price:</span>
                                        <span className={styles.dataValue}>
                                          {invoiceData.DocumentCurrency || ''} {item.InvoiceUnitPrice?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || 'N/A'}
                                        </span>
                                      </div>
                                      <div className={styles.dataRow}>
                                        <span className={styles.dataLabel}>Net Value:</span>
                                        <span className={styles.dataValue}>
                                          {invoiceData.DocumentCurrency || ''} {item.NetValueAmount?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || 'N/A'}
                                        </span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </>
                        ) : (
                          <p>No invoice data available</p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Loop through all exceptions - show only exception details */}
                  {details.exceptions.map((exceptionDetail: any, index: number) => (
                    <div key={index} style={{ marginBottom: index < details.exceptions.length - 1 ? '32px' : '0', paddingBottom: index < details.exceptions.length - 1 ? '32px' : '0', borderBottom: index < details.exceptions.length - 1 ? '2px solid #e0e0e0' : 'none' }}>
                      {/* Exception Header with ID, Status, Severity */}
                      <div style={{ marginBottom: '16px', padding: '16px', backgroundColor: '#f8f9fa', borderRadius: '8px', borderLeft: '4px solid #003d75' }}>
                        <h3 style={{ margin: '0 0 12px 0', fontSize: '18px', fontWeight: 600, color: '#003d75' }}>
                          Exception #{index + 1}: {exceptionDetail.exception?.exceptionId || 'Unknown'}
                        </h3>
                        <div style={{ display: 'flex', gap: '24px', fontSize: '14px', color: '#333', flexWrap: 'wrap' }}>
                          <span><strong>Type:</strong> {exceptionDetail.exception?.exceptionName || 'Unknown'}</span>
                          <span><strong>Status:</strong> <span className={`${styles.statusTag} ${getStatusClass(exceptionDetail.exception?.exceptionStatus)}`} style={{ padding: '2px 8px', borderRadius: '4px', fontSize: '12px' }}>{exceptionDetail.exception?.exceptionStatus || 'Unknown'}</span></span>
                          <span>
                            <strong>Severity:</strong>{' '}
                            <span
                              className={`${styles.statusTag}`}
                              style={{
                                padding: '2px 8px',
                                borderRadius: '4px',
                                fontSize: '12px',
                                // Map severity to colors: Low -> blue, Medium -> orange, High/Critical -> red
                                backgroundColor:
                                  exceptionDetail.exception?.severity === 'Low'
                                    ? '#E8F4FD'
                                    : exceptionDetail.exception?.severity === 'Medium'
                                    ? '#FFF3E0'
                                    : (exceptionDetail.exception?.severity === 'High' || exceptionDetail.exception?.severity === 'Critical')
                                    ? '#FEE2E2'
                                    : '#FFF3E0',
                                color:
                                  exceptionDetail.exception?.severity === 'Low'
                                    ? '#1976D2'
                                    : exceptionDetail.exception?.severity === 'Medium'
                                    ? '#D97706'
                                    : (exceptionDetail.exception?.severity === 'High' || exceptionDetail.exception?.severity === 'Critical')
                                    ? '#DC2626'
                                    : '#D97706'
                              }}
                            >
                              {exceptionDetail.exception?.severity || 'Unknown'}
                            </span>
                          </span>
                          <span><strong>Created:</strong> {exceptionDetail.exception?.createdAt ? formatDateIST(exceptionDetail.exception.createdAt) : 'N/A'}</span>
                          <span><strong>Last Updated:</strong> {exceptionDetail.exception?.updatedAt ? formatDateIST(exceptionDetail.exception.updatedAt) : 'N/A'}</span>
                        </div>
                      </div>

                      {/* Agent Reasoning Summary */}
                      <div className={styles.reasoningSection}>
                        <h3 className={styles.reasoningTitle}>Agent Reasoning Summary</h3>
                        <div className={styles.reasoningCard}>
                          <div className={styles.reasoningContent}>
                            {exceptionDetail.exception?.exceptionSummary ? (
                              <div className={styles.reasoningText}>
                                <ReactMarkdown>{exceptionDetail.exception.exceptionSummary || ''}</ReactMarkdown>
                              </div>
                            ) : (
                              <div className={styles.reasoningText}>
                                No reasoning summary available for this exception.
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </>
              );
            })()}
        </div>

        <div className={styles.modalFooter}>
          <button 
            className={styles.escalateButton}
            onClick={handleEscalateClick}
            disabled={!(currentStatus === 'Pending' || currentStatus === 'Pending Approval') || currentStatus === 'Resolved' || showEscalatePopup || submittingEscalation}
            style={{
              opacity: (!(currentStatus === 'Pending' || currentStatus === 'Pending Approval') || currentStatus === 'Resolved' || showEscalatePopup || submittingEscalation) ? 0.5 : 1,
              cursor: (!(currentStatus === 'Pending' || currentStatus === 'Pending Approval') || currentStatus === 'Resolved' || showEscalatePopup || submittingEscalation) ? 'not-allowed' : 'pointer'
            }}
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M8 14.6667C11.6819 14.6667 14.6667 11.6819 14.6667 8C14.6667 4.3181 11.6819 1.33333 8 1.33333C4.3181 1.33333 1.33333 4.3181 1.33333 8C1.33333 11.6819 4.3181 14.6667 8 14.6667Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M8 5.33333V8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M8 10.6667H8.00667" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Escalate
          </button>
          <button 
            className={styles.rerunButton}
            onClick={handleRerunClick}
            disabled={currentStatus !== 'Escalated' || reRunning || currentStatus === 'Resolved'}
            style={{
              opacity: (currentStatus !== 'Escalated' || reRunning || currentStatus === 'Resolved') ? 0.5 : 1,
              cursor: (currentStatus !== 'Escalated' || reRunning || currentStatus === 'Resolved') ? 'not-allowed' : 'pointer'
            }}
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M14 8C14 11.3137 11.3137 14 8 14C4.68629 14 2 11.3137 2 8C2 4.68629 4.68629 2 8 2C10.3995 2 12.4739 3.31756 13.4713 5.23077" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M14 2V5.33333H10.6667" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            {reRunning ? 'Processing...' : 'Re-run Check'}
          </button>
          <button 
            className={styles.approveButton}
            onClick={handleApproveClick}
            disabled={currentStatus !== 'Pending Approval' || currentStatus === 'Resolved' || showApprovalPopup || submittingApproval}
            style={{
              opacity: (currentStatus !== 'Pending Approval' || currentStatus === 'Resolved' || showApprovalPopup || submittingApproval) ? 0.5 : 1,
              cursor: (currentStatus !== 'Pending Approval' || currentStatus === 'Resolved' || showApprovalPopup || submittingApproval) ? 'not-allowed' : 'pointer'
            }}
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M13.3333 4L6 11.3333L2.66667 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Approve Resolution

          </button>
        </div>
      </div>

      {/* Escalation Confirmation Popup */}
      {showEscalatePopup && (
        <div className={styles.confirmationOverlay} onClick={(e) => e.stopPropagation()}>
          <div className={styles.confirmationPopup} onClick={(e) => e.stopPropagation()}>
            <div className={styles.confirmationHeader}>
              <h3>Confirm Escalation</h3>
            </div>
            <div className={styles.confirmationBody}>
              <p>This will trigger an email notification to:</p>
              <p className={styles.emailList}><strong>{emailsDisplay}</strong></p>
              <p>regarding PO <strong>{details?.po_number}</strong>.</p>
              
              <div className={styles.additionalEmailSection}>
                <label className={styles.checkboxLabel}>
                  <input
                    type="checkbox"
                    checked={showAdditionalEmail}
                    onChange={(e) => setShowAdditionalEmail(e.target.checked)}
                    className={styles.checkbox}
                  />
                  Do you wish to add anyone to the email?
                  <Tooltip title={<span>use the <span className={styles.tooltipTick} aria-hidden="true">✓</span> to add an email</span>}>
                    <svg className={styles.infoIcon} viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                      <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="1.5" />
                      <path d="M12 8v.01" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
                      <path d="M11.5 11.5h1v4h-1z" fill="currentColor" />
                    </svg>
                  </Tooltip>
                </label>
                
                {showAdditionalEmail && (
                  <div className={styles.emailInputContainer}>
                    <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                      <input
                        type="email"
                        value={additionalEmailInput}
                        onChange={(e) => setAdditionalEmailInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ',') {
                            e.preventDefault();
                            addAdditionalEmail(additionalEmailInput);
                          }
                        }}
                        placeholder="additional@email.com"
                        className={styles.additionalEmailInput}
                        autoFocus
                      />
                      <button
                        type="button"
                        className={styles.emailSaveButton}
                        onClick={() => addAdditionalEmail(additionalEmailInput)}
                        disabled={!additionalEmailInput.trim() || !isValidEmail(additionalEmailInput.trim())}
                        aria-label="Add additional recipient"
                        title="Add"
                      >
                        ✓
                      </button>
                    </div>

                    {additionalEmails.length > 0 && (
                      <div className={styles.emailChips} style={{ marginTop: 12 }}>
                        {additionalEmails.map((em) => (
                          <span key={em} className={styles.emailChip}>
                            <span className={styles.emailChipText}>{em}</span>
                            <button type="button" className={styles.chipRemove} onClick={() => removeAdditionalEmail(em)}>✕</button>
                          </span>
                        ))}
                      </div>
                    )}

                    {additionalEmailInput.trim() && !isValidEmail(additionalEmailInput.trim()) && (
                      <div className={styles.emailError} style={{ marginTop: 8, color: '#cf1322' }}>Please enter a valid email address.</div>
                    )}
                  </div>
                )}
              </div>
              
              {showAdditionalEmail && (additionalEmails.length > 0 || (additionalEmailInput.trim() && isValidEmail(additionalEmailInput.trim()))) && (
                <div className={styles.finalEmailPreview}>
                  <p className={styles.previewLabel}>Emails that will receive notification:</p>
                  <p className={styles.previewEmails}><strong>{getFinalEmailList()}</strong></p>
                </div>
              )}
              
              <p className={styles.confirmQuestion}>Do you want to proceed?</p>
            </div>
            <div className={styles.confirmationFooter}>
              <button 
                className={styles.cancelButton}
                onClick={handleEscalateCancel}
                disabled={submittingEscalation}
                type="button"
              >
                Cancel
              </button>
              <button 
                className={styles.proceedButton}
                onClick={handleEscalateConfirm}
                disabled={submittingEscalation}
                type="button"
              >
                {submittingEscalation ? 'Submitting...' : 'Submit'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Approval Confirmation Popup */}
      {showApprovalPopup && (
        <div className={styles.confirmationOverlay} onClick={(e) => e.stopPropagation()}>
          <div className={styles.confirmationPopup} onClick={(e) => e.stopPropagation()}>
            <div className={styles.confirmationHeader}>
              <h3>Confirm Approval</h3>
            </div>
            <div className={styles.confirmationBody}>
              <p>Are you sure you want to approve these resolutions?</p>
              <p>This will mark all exceptions for PO <strong>{details?.po_number}</strong> as <strong>Resolved</strong>.</p>
              <p className={styles.confirmQuestion}>Do you want to proceed?</p>
            </div>
            <div className={styles.confirmationFooter}>
              <button 
                className={styles.cancelButton}
                onClick={handleApprovalCancel}
                disabled={submittingApproval}
                type="button"
              >
                Cancel
              </button>
              <button 
                className={styles.proceedButton}
                onClick={handleApprovalConfirm}
                disabled={submittingApproval}
                type="button"
              >
                {submittingApproval ? 'Processing...' : 'Proceed'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
