import { useState } from 'react';
import styles from './DeleteConfirmationModal.module.css';

interface DeleteConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  email: string;
  isDeleting?: boolean;
}

/**
 * Reusable confirmation modal for user deletion
 * Requires email confirmation for safety
 */
export default function DeleteConfirmationModal({
  isOpen,
  onClose,
  onConfirm,
  email,
  isDeleting = false
}: DeleteConfirmationModalProps) {
  const [emailInput, setEmailInput] = useState('');
  const [error, setError] = useState('');

  // Reset state when modal closes
  const handleClose = () => {
    setEmailInput('');
    setError('');
    onClose();
  };

  // Handle confirmation
  const handleConfirm = () => {
    if (emailInput !== email) {
      setError('Email does not match. Please try again.');
      return;
    }
    setError('');
    onConfirm();
  };

  // Handle Enter key press
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && emailInput === email) {
      handleConfirm();
    }
  };

  if (!isOpen) return null;

  return (
    <div className={styles.overlay} onClick={handleClose}>
      <div className={styles.modal} onClick={(e) => e.stopPropagation()}>
        <div className={styles.header}>
          <div className={styles.iconContainer}>
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
              <circle cx="24" cy="24" r="24" fill="#FEE2E2" />
              <path
                d="M24 16v8m0 4h.01"
                stroke="#EF4444"
                strokeWidth="3"
                strokeLinecap="round"
              />
            </svg>
          </div>
          <h2 className={styles.title}>Delete User</h2>
          <p className={styles.subtitle}>
            Are you sure you want to permanently delete this user?
          </p>
        </div>

        <div className={styles.content}>
          <div className={styles.warningBox}>
            <h4 className={styles.warningTitle}>This action will:</h4>
            <ul className={styles.warningList}>
              <li>Delete the user account permanently</li>
              <li>Remove all associated sessions</li>
              <li>Delete all exception records</li>
              <li>Remove all chat history</li>
              <li><strong>This cannot be undone</strong></li>
            </ul>
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="email-confirm" className={styles.label}>
              Type <strong>{email}</strong> to confirm:
            </label>
            <input
              id="email-confirm"
              type="text"
              className={styles.input}
              value={emailInput}
              onChange={(e) => {
                setEmailInput(e.target.value);
                setError('');
              }}
              onKeyPress={handleKeyPress}
              placeholder="Enter user email"
              disabled={isDeleting}
              autoFocus
            />
            {error && <p className={styles.error}>{error}</p>}
          </div>
        </div>

        <div className={styles.footer}>
          <button
            className={styles.cancelButton}
            onClick={handleClose}
            disabled={isDeleting}
          >
            Cancel
          </button>
          <button
            className={styles.deleteButton}
            onClick={handleConfirm}
            disabled={emailInput !== email || isDeleting}
          >
            {isDeleting ? (
              <>
                <span className={styles.spinner}></span>
                Deleting...
              </>
            ) : (
              <>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M2 4h12M5.5 4V2.5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1V4m2 0v9.5a1 1 0 0 1-1 1h-7a1 1 0 0 1-1-1V4h9z"/>
                  <path d="M6.5 7v4M9.5 7v4"/>
                </svg>
                Delete Permanently
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}










