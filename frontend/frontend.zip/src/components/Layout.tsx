import { type ReactNode } from 'react';
import TopNav from './TopNav';
import SideNav from './SideNav';
import styles from './Layout.module.css';

interface LayoutProps {
  children: ReactNode;
}

/**
 * Layout component that provides the main application structure
 * @param children - The page content to render
 */
export default function Layout({ children }: LayoutProps) {
  return (
    <div className={styles.layout}>
      <TopNav />
      <div className={styles.container}>
        <SideNav />
        <main className={styles.main}>{children}</main>
      </div>
    </div>
  );
}
