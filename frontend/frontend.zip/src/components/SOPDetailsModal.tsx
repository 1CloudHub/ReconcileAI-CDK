import { useState, useEffect } from 'react';
import styles from './SOPDetailsModal.module.css';

interface SOPDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  sopData: {
    exceptionId: string;
    exceptionName: string;
    sopId: string;
    lastRun: string;
    records: number;
  };
  pdfName: string;
}

export default function SOPDetailsModal({ 
  isOpen, 
  onClose, 
  sopData, 
  pdfName
}: SOPDetailsModalProps) {
  const [presignedUrl, setPresignedUrl] = useState<string | null>(null);
  const [loadingUrl, setLoadingUrl] = useState(false);
  const [urlError, setUrlError] = useState<string | null>(null);

  const API_URL = import.meta.env.VITE_API_URL;

  useEffect(() => {
    if (!isOpen || !API_URL) return;

    const fetchPresignedUrl = async () => {
      setLoadingUrl(true);
      setUrlError(null);
      
      try {
        const response = await fetch(API_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            event_type: 'get_sop_presigned_url',
            exception_name: sopData.exceptionName
          }),
        });

        if (response.ok) {
          const result = await response.json();
          setPresignedUrl(result.presigned_url);
        } else {
          const errorData = await response.json();
          setUrlError(errorData.error || 'Failed to load document');
          console.error('Failed to fetch presigned URL:', errorData);
        }
      } catch (err) {
        setUrlError('Error loading document');
        console.error('Error fetching presigned URL:', err);
      } finally {
        setLoadingUrl(false);
      }
    };

    fetchPresignedUrl();
  }, [isOpen, API_URL, sopData.exceptionName]);

  if (!isOpen) return null;

  return (
    <div className={styles.modalOverlay} onClick={onClose}>
      <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
        <div className={styles.modalHeader}>
          <div className={styles.headerContent}>
            <h2 className={styles.modalTitle}>SOP Details</h2>
            <p className={styles.modalSubtitle}>{sopData.exceptionId}</p>
          </div>
          <button className={styles.closeButton} onClick={onClose}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>

        <div className={styles.modalBody}>
          {/* Main Details Section */}
          <div className={styles.detailsSection}>
            <h3 className={styles.sectionTitle}>Exception Information</h3>
            <div className={styles.detailsGrid}>
              <div className={styles.detailItem}>
                <span className={styles.detailLabel}>Exception Type</span>
                <span className={styles.detailValue}>{sopData.exceptionId}</span>
              </div>
              <div className={styles.detailItem}>
                <span className={styles.detailLabel}>Exception Name</span>
                <span className={styles.detailValue}>{sopData.exceptionName}</span>
              </div>
              <div className={styles.detailItem}>
                <span className={styles.detailLabel}>SOP Connected</span>
                <span className={styles.detailValueHighlight}>{pdfName}</span>
              </div>
              <div className={styles.detailItem}>
                <span className={styles.detailLabel}>Last Run</span>
                <span className={styles.detailValue}>{sopData.lastRun}</span>
              </div>
              <div className={styles.detailItem}>
                <span className={styles.detailLabel}>Total Exceptions Processed</span>
                <span className={styles.detailValue}>{sopData.records.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* SOP Document Section */}
          <div className={styles.detailsSection}>
            <h3 className={styles.sectionTitle}>SOP Document</h3>
            <div className={styles.documentSection}>
              <div className={styles.documentInfo}>
                <div className={styles.documentIcon}>
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <line x1="12" y1="11" x2="12" y2="17"></line>
                    <polyline points="9 14 12 17 15 14"></polyline>
                  </svg>
                </div>
                <div className={styles.documentDetails}>
                  <span className={styles.documentName}>{pdfName}.pdf</span>
                  <span className={styles.documentType}>Standard Operating Procedure</span>
                </div>
              </div>
              {loadingUrl ? (
                <button className={styles.downloadButton} disabled>
                  <svg className={styles.spinner} width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="10" strokeOpacity="0.25" />
                    <path d="M12 2a10 10 0 0 1 10 10" strokeOpacity="0.75" />
                  </svg>
                  Loading...
                </button>
              ) : urlError ? (
                <div className={styles.errorMessage}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="8" x2="12" y2="12"></line>
                    <line x1="12" y1="16" x2="12.01" y2="16"></line>
                  </svg>
                  {urlError}
                </div>
              ) : presignedUrl ? (
                <a 
                  href={presignedUrl}
                  download={`${pdfName}.pdf`}
                  className={styles.downloadButton}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="7 10 12 15 17 10"></polyline>
                    <line x1="12" y1="15" x2="12" y2="3"></line>
                  </svg>
                  Download PDF
                </a>
              ) : null}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
