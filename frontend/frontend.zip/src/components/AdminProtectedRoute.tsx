import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { getCookie } from '../lib/utils';
import LoadingSpinner from './LoadingSpinner';

interface AdminProtectedRouteProps {
  children: React.ReactNode;
}

/**
 * AdminProtectedRoute component that checks if user is admin (userid = 1)
 * before rendering children. Redirects to dashboard if not admin.
 */
export default function AdminProtectedRoute({ children }: AdminProtectedRouteProps) {
  const { isAuthenticated, isLoading } = useAuth();
  const userid = getCookie('userid');

  // Show loading state while checking authentication
  if (isLoading) {
    return <LoadingSpinner message="Checking authentication..." fullScreen />;
  }

  // First check if user is authenticated
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Check if user is admin (userid = 1)
  if (!userid || parseInt(userid) !== 1) {
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
}


