import React, { useState, useRef, useEffect } from 'react';
import TopNav from '../components/TopNav';
import SideNav from '../components/SideNav';
import ReactMarkdown from 'react-markdown';
import { getCookie } from '../lib/utils';
import styles from './SAPAssistant.module.css';

interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  contextSource?: string;
}

interface Conversation {
  id: string;
  messages: Message[];
}

// Generate message ID
const generateMessageId = (): string => {
  return 'msg_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
};

// Inline error component
const InlineErrorNotice: React.FC<{ message: string }> = ({ message }) => (
  <div
    role="alert"
    aria-live="assertive"
    className={styles.errorNotice}
  >
    {message}
  </div>
);

const BotTypingLoader: React.FC = () => (
  <span className={styles.typingCursor}>
    <style>{`
      @keyframes cursor-blink {
        0%, 50% { opacity: 1; }
        51%, 100% { opacity: 0; }
      }
    `}</style>
  </span>
);

/**
* Inline streaming cursor component - appears at the end of streaming text
*/
const StreamingCursor: React.FC = () => (
  <span className={styles.typingCursor} style={{ marginLeft: '2px' }} />
);

/**
* Helper function to clean markdown text by removing literal asterisks
* that are not being properly rendered as bold text
*/
const cleanMarkdownText = (text: string): string => {
  let cleaned = text;

  // Remove bold markdown syntax (**text** becomes text)
  // This handles cases where asterisks appear literally instead of being rendered as bold
  cleaned = cleaned.replace(/\*\*(.+?)\*\*/g, '$1');

  // Remove trailing asterisks at the end of lines
  // This handles patterns like "text**" or "text****" at the end of a line
  // Matches one or more asterisks (with optional whitespace) at end of line or string
  cleaned = cleaned.replace(/\*+\s*$/gm, '');

  // Also handle asterisks before newlines (in case they're mid-text)
  cleaned = cleaned.replace(/\*+\s*(\r?\n)/g, '$1');

  return cleaned;
};

/**
* Helper function to ensure proper line breaks between steps
*/
const normalizeStepFormatting = (text: string): string => {
  let normalized = text;

  // Clean markdown asterisks first (before other processing)
  normalized = cleanMarkdownText(normalized);

  // Add line breaks between steps - handle multiple patterns
  // Pattern 1: "text. Step X —" or "text.Step X —" (with or without space after period)
  // This handles: "processed.Step 2" -> "processed.\n\nStep 2"
  normalized = normalized.replace(/\.\s*(Step\s*\d+\s*[—\-])/g, '.\n\n$1');

  // Pattern 2: Steps directly adjacent without any separator (most important for user's case)
  // "Step X textStep Y" -> "Step X text\n\nStep Y"
  // This catches cases where steps are concatenated: "processed.Step 2" (already handled above)
  // and "Step 1 textStep 2" (no period at all)
  normalized = normalized.replace(/(Step\s*\d+\s*[—\-][^\n]*?)(Step\s*\d+\s*[—\-])/g, (match, step1, step2) => {
    // Only add break if step1 doesn't end with a newline and step2 starts with "Step"
    // This prevents double-processing
    if (!step1.endsWith('\n') && step2.startsWith('Step')) {
      return `${step1}\n\n${step2}`;
    }
    return match;
  });

  // Pattern 3: Steps separated by text but no period (fallback for edge cases)
  // "Step X text Step Y" -> "Step X text\n\nStep Y" (only if no newline exists and no period)
  normalized = normalized.replace(/(Step\s*\d+\s*[—\-][^\n\.]*?)(\s+)(Step\s*\d+\s*[—\-])/g, '$1\n\n$3');

  // Ensure double newlines before headings
  normalized = normalized.replace(/([^\n])(## )/g, '$1\n\n$2');

  // Also handle "Exception Details:" or similar section headers
  normalized = normalized.replace(/([^\n])(Exception\s+Details:)/gi, '$1\n\n$2');

  return normalized;
};

export default function SAPAssistant() {
  const emptyConversation: Conversation = { id: 'active-conversation', messages: [] };
  const [conversation, setConversation] = useState<Conversation>(emptyConversation);
  const [inputText, setInputText] = useState('');
  const [streamingMessage, setStreamingMessage] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [isStreaming2, setIsStreaming2] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatTranscriptRef = useRef<HTMLDivElement>(null);

  const [chatEnded, setChatEnded] = useState(false);
  const socketRef = useRef<WebSocket | null>(null);
  const [showFaqs, setShowFaqs] = useState(true);
  const sawTextDeltaRef = useRef(false);
  const currentMessageIdRef = useRef<string | null>(null);
  const messageFlushedRef = useRef(false);
  const [inputDisabled, setInputDisabled] = useState(false);
  const [timeoutNotice, setTimeoutNotice] = useState<string | null>(null);
  const lastWsMessageTimestampRef = useRef<number | null>(null);
  const lastRequestTimestampRef = useRef<number | null>(null);
  const wsGapStartRef = useRef<number | null>(null);
  const wsGapIntervalRef = useRef<number | null>(null);

  const faqs = [
    "3-way match for PO_4500018901",
    "3-way match for PO_4500016789",
    "3-way match for PO_4500017890",
    "3-way match for PO_4500020000",
    "3-way match for PO_450000005",
    "3-way match for PO_4500012345"
  ];


  useEffect(() => {
    if (chatTranscriptRef.current) {
      chatTranscriptRef.current.scrollTop = chatTranscriptRef.current.scrollHeight;
    }
  }, [conversation.messages, streamingMessage]);

  const openWebsocketConnection = (): Promise<string> => {
    return new Promise((resolve, reject) => {
      // Close existing connection if any
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }

      const socket = new WebSocket(import.meta.env.VITE_SAP_CHATBOT_API_URL);

      let accumulatedMessage = '';
      let idleTimer: number | null = null;
      let connectionResolved = false;
      messageFlushedRef.current = false;

      const scheduleIdleFinalize = () => {
        if (idleTimer) {
          clearTimeout(idleTimer);
        }
        idleTimer = window.setTimeout(() => {
          if (sawTextDeltaRef.current) {
            setIsStreaming(false);

            if (accumulatedMessage.trim()) {
              const normalizedFinal = normalizeStepFormatting(accumulatedMessage);
              setConversation((prev) => ({
                ...prev,
                messages: [
                  ...prev.messages,
                  {
                    id: `bot-${Date.now()}`,
                    sender: 'bot',
                    text: normalizedFinal,
                    timestamp: new Date().toISOString(),
                  }
                ]
              }));
            }
            setStreamingMessage('');
            sawTextDeltaRef.current = false;
            currentMessageIdRef.current = null;
          } else {
            setIsStreaming(false);
          }
        }, 2000);
      };
      sawTextDeltaRef.current = false;

      socket.onopen = () => {
        socket.send(JSON.stringify({ type: "connection_init" }));
        setInputDisabled(false);
        setTimeoutNotice(null);
      };

      socket.onmessage = (e) => {
        let isControlMessage = false;
        try {
          const messageData = JSON.parse(e.data);

          if (
            messageData === 'api_end' ||
            messageData?.message === 'api_end' ||
            messageData?.type === 'api_end' ||
            messageData?.type === 'final_message_ff'
          ) {
            if (wsGapIntervalRef.current !== null) {
              clearInterval(wsGapIntervalRef.current);
              wsGapIntervalRef.current = null;
            }
            wsGapStartRef.current = null;
            isControlMessage = true;
            return;
          }

          if (inputDisabled || timeoutNotice) {
            setInputDisabled(false);
            setTimeoutNotice(null);
          }
          if (wsGapIntervalRef.current !== null) {
            clearInterval(wsGapIntervalRef.current);
            wsGapIntervalRef.current = null;
          }
          if (wsGapStartRef.current !== null) {
            wsGapStartRef.current = null;
          }

          const nowTs = performance.now();
          lastWsMessageTimestampRef.current = nowTs;

          if (messageData.connectionid && !connectionResolved) {
            connectionResolved = true;
            resolve(messageData.connectionid);
          }

          if (
            messageData === 'api_start' ||
            messageData?.message === 'api_start' ||
            messageData?.type === 'api_start'
          ) {
            return;
          }

          if (
            messageData === 'api_end' ||
            messageData?.message === 'api_end' ||
            messageData?.type === 'api_end'
          ) {
            return;
          }

          if (messageData.message_id && currentMessageIdRef.current && messageData.message_id !== currentMessageIdRef.current) {
            return;
          }

          if (
            messageData === 'streaming_completed' ||
            messageData?.message === 'streaming_completed' ||
            messageData?.type === 'streaming_completed'
          ) {
            if (idleTimer) {
              clearTimeout(idleTimer);
              idleTimer = null;
            }
            if (!messageFlushedRef.current) {
              if (accumulatedMessage.trim()) {
                const normalizedFinal = normalizeStepFormatting(accumulatedMessage);
                setConversation((prev) => ({
                  ...prev,
                  messages: [
                    ...prev.messages,
                    {
                      id: `bot-${Date.now()}`,
                      sender: 'bot',
                      text: normalizedFinal,
                      timestamp: new Date().toISOString(),
                    }
                  ]
                }));
              }
              messageFlushedRef.current = true;
            }
            setStreamingMessage('');
            setIsStreaming(false);
            sawTextDeltaRef.current = false;
            currentMessageIdRef.current = null;
            return;
          }

          if (typeof messageData.message === 'string') {
            const chunkText = String(messageData.message);
            if (chunkText.trim().toLowerCase() === 'connected') {
              return;
            }

            sawTextDeltaRef.current = true;
            if( chunkText.trim().toLowerCase() === 'message___end'){
              scheduleIdleFinalize();
              return;
            } 

            // Handle complete message from backend (non-streaming)
            if (chunkText.length > 100 && !messageFlushedRef.current) {
              // This appears to be a complete response, finalize it immediately
              setIsStreaming(false);
              setIsStreaming2(false);

              if (idleTimer) {
                clearTimeout(idleTimer);
                idleTimer = null;
              }

              const normalizedChunk = normalizeStepFormatting(chunkText);
              setConversation((prev) => ({
                ...prev,
                messages: [
                  ...prev.messages,
                  {
                    id: `bot-${Date.now()}`,
                    sender: 'bot',
                    text: normalizedChunk,
                    timestamp: new Date().toISOString(),
                  }
                ]
              }));
              messageFlushedRef.current = true;
              setStreamingMessage('');
              sawTextDeltaRef.current = false;
              currentMessageIdRef.current = null;
              return;
            }

            accumulatedMessage += chunkText;
            const normalizedMessage = normalizeStepFormatting(accumulatedMessage);
            setStreamingMessage(normalizedMessage);
            setIsStreaming(true);
            setIsStreaming2(false);
          }

          if (messageData.type === "content_block_delta" && messageData.delta?.type === "text_delta") {
            const deltaText = messageData.delta.text;
            sawTextDeltaRef.current = true;
            accumulatedMessage += deltaText;
            const normalizedMessage = normalizeStepFormatting(accumulatedMessage);
            setStreamingMessage(normalizedMessage);
            setIsStreaming(true);
            setIsStreaming2(false);
            scheduleIdleFinalize();
          }

          if (messageData.done === true || messageData.type === 'done' || messageData.type === 'complete' || messageData.type === "content_block_stop" || messageData.type === "message_stop") {
            setIsStreaming(false);
            if (idleTimer) {
              clearTimeout(idleTimer);
              idleTimer = null;
            }

            if (sawTextDeltaRef.current) {
              if (!messageFlushedRef.current) {
                if (accumulatedMessage.trim()) {
                  const normalizedFinal = normalizeStepFormatting(accumulatedMessage);
                  setConversation((prev) => ({
                    ...prev,
                    messages: [
                      ...prev.messages,
                      {
                        id: `bot-${Date.now()}`,
                        sender: 'bot',
                        text: normalizedFinal, 
                        timestamp: new Date().toISOString(),
                      }
                    ]
                  }));
                }
                messageFlushedRef.current = true;
              }
              setStreamingMessage('');
              socket.close();
              sawTextDeltaRef.current = false;
              currentMessageIdRef.current = null;
            } else {
              accumulatedMessage = '';
              setStreamingMessage('');
            }
          }
        } catch (error) {
          reject(error);
        } finally {
          if (!isControlMessage) {
            wsGapStartRef.current = performance.now();
            wsGapIntervalRef.current = window.setInterval(() => {
              if (wsGapStartRef.current !== null) {
                const elapsed = performance.now() - wsGapStartRef.current;
                if (elapsed >= 300000 && !inputDisabled) {
                  setInputDisabled(true);
                  setTimeoutNotice('Please refresh and try again after 5 minutes');
                  clearInterval(wsGapIntervalRef.current as unknown as number);
                  wsGapIntervalRef.current = null;
                }
              }
            }, 1000);
          }
        }
      };

      socket.onclose = () => {
        if (idleTimer) {
          clearTimeout(idleTimer);
          idleTimer = null;
        }
        lastWsMessageTimestampRef.current = null;
        if (wsGapIntervalRef.current !== null) {
          clearInterval(wsGapIntervalRef.current);
          wsGapIntervalRef.current = null;
        }
        wsGapStartRef.current = null;
        setIsStreaming(false);
      };

      socket.onerror = (error) => {
        if (idleTimer) {
          clearTimeout(idleTimer);
          idleTimer = null;
        }
        setIsStreaming(false);
        reject(error);
      };

      socketRef.current = socket;

      setTimeout(() => {
        if (!connectionResolved) {
          reject(new Error('Connection timeout'));
        }
      }, 10000);
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim() === '') return;
    setIsStreaming2(true);

    if (inputDisabled || timeoutNotice) {
      setInputDisabled(false);
      setTimeoutNotice(null);
    }

    const nowReq = performance.now();
    lastRequestTimestampRef.current = nowReq;

    const newUserMessage: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: inputText,
      timestamp: new Date().toISOString()
    };

    setConversation(prev => ({
      ...prev,
      messages: [...prev.messages, newUserMessage]
    }));

    const currentInput = inputText;
    setInputText('');

    // COMMENTED OUT: Code to hide prompt chips after first message
    // If we uncomment this code, we can bring back the feature where prompt chips disappear after the first message
    // if (conversation.messages.length === 0 && showFaqs) {
    //   setShowFaqs(false);
    // }

    try {

      const newConnectionId = await openWebsocketConnection();
      const messageId = generateMessageId();
      currentMessageIdRef.current = messageId;

      // Get userid from cookies for API calls
      const userid = getCookie('userid');

      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      const raw = JSON.stringify({
        user_question: currentInput,
        connection_id: newConnectionId,
        message_id: messageId,
        userid: userid || null
      });

      const requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow' as const
      };

      fetch(import.meta.env.VITE_THREE_WAY_CHATBOT_API_URL, requestOptions)
        .then(async (response) => {
          try {
            await response.json().catch(() => null);
          } catch {
            // swallow errors
          }
        })
        .catch(() => {
          // Intentionally ignore HTTP errors
        });

    } catch (error) {
      const errorMessage: Message = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: 'Sorry, there was a problem connecting to the SAP assistant service. Please try again.',
        timestamp: new Date().toISOString(),
      };

      setConversation(prev => ({
        ...prev,
        messages: [...prev.messages, errorMessage]
      }));

      setIsStreaming(false);
      setStreamingMessage('');
    }
  };

  const handlePromptChipClick = (text: string) => {
    setInputText(text);
  };

  const handleStartNewChat = () => {
    setChatEnded(false);
    setConversation(emptyConversation); 
    setInputText('');
    setStreamingMessage('');
    setIsStreaming(false);
    setShowFaqs(true);

    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.close();
    }
  };

  // Clean up WebSocket on component unmount
  useEffect(() => {
    return () => {
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }
    };
  }, []);

  return (
    <div className={styles.fullScreenLayout}>
      <TopNav />
      <div className={styles.layoutContainer}>
        <SideNav />
        <main className={styles.fullScreenMain}>
          <div className={styles.chatContainer}>
            <div className={styles.chatHeader}>
              <div className={styles.chatTitleSection}>
                <div className={styles.botIcon}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/>
                    <path d="M12 6v6l4 2"/>
                  </svg>
                </div>
                <h3 className={styles.chatTitle}>ReconcileAI Agent</h3>
              </div>
            </div>

          <div className={styles.chatBody}>
            <div
              className={styles.messagesContainer}
              ref={chatTranscriptRef}
            >
              {/* Opening message */}
              {!chatEnded && (
                <div className={styles.messageContainer}>
                  <div className={styles.botMessage}>
                    <div className={styles.messageText}>
                      Hello! I'm ReconcileAI — your intelligent assistant for reconciling and validating SAP transactions. I can help you with 3-way matching.
                    </div>
                    <div className={styles.messageTime}>
                      {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              )}

              {/* Render conversation messages */}
              {!chatEnded && conversation.messages.map((message) => (
                <div key={message.id} className={`${styles.messageContainer} ${message.sender === 'user' ? styles.userMessage : styles.botMessage}`}>
                  <div className={message.sender === 'user' ? styles.userBubble : styles.botBubble}>
                    <div className={styles.messageContent}>
                      {message.sender === 'bot' ? (
                        <ReactMarkdown>{message.text}</ReactMarkdown>
                      ) : (
                        message.text
                      )}
                    </div>
                    <div className={styles.messageTimestamp}>
                      <span className={styles.timestamp}>
                        {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                </div>
              ))}

              {/* Streaming message */}
              {streamingMessage && isStreaming && !chatEnded && (
                <div className={styles.messageContainer}>
                  <div className={styles.botBubble}>
                    <div className={styles.messageContent}>
                      <div style={{ display: 'inline' }}>
                        <ReactMarkdown>{streamingMessage}</ReactMarkdown>
                        {!timeoutNotice && <StreamingCursor />}
                      </div>
                    </div>
                    {timeoutNotice && !chatEnded && (
                      <InlineErrorNotice message={timeoutNotice} />
                    )}
                    <div className={styles.messageTimestamp}>
                      <span className={styles.timestamp}>
                        {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {isStreaming2 && (
                <div className={styles.messageContainer}>
                  <div className={styles.botBubble}>
                    <div className={styles.messageContent}>
                      {!timeoutNotice && <BotTypingLoader />}
                    </div>
                    {timeoutNotice && !chatEnded && (
                      <InlineErrorNotice message={timeoutNotice} />
                    )}
                  </div>
                </div>
              )}

              {/* Start new chat button when chat ended */}
              {chatEnded && (
                <div className={styles.newChatContainer}>
                  <button
                    className={styles.newChatButton}
                    onClick={handleStartNewChat}
                  >
                    Start New Chat
                  </button>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick Reply Suggestions */}
            {/* COMMENTED OUT: Old condition that only showed chips when no messages exist */}
            {/* If we uncomment the condition below, we can bring back the feature where prompt chips disappear after the first message */}
            {/* {conversation.messages.length === 0 && !chatEnded && showFaqs && ( */}
            {!chatEnded && showFaqs && (
              <div className={styles.suggestionsContainer}>
                <div className={styles.suggestions}>
                  {faqs.map((faq, idx) => (
                    <button
                      key={idx}
                      className={styles.suggestionChip}
                      onClick={() => handlePromptChipClick(faq)}
                    >
                      {faq}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Input Area */}
            <div className={styles.inputContainer}>
              {!chatEnded ? (
                <form onSubmit={handleSubmit} className={styles.inputForm}>
                  <div className={styles.inputWrapper}>
                    <input
                      type="text"
                      placeholder="Type your message here..."
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      disabled={isStreaming || inputDisabled}
                      className={styles.textInput}
                    />
                    <button 
                      type="submit" 
                      disabled={inputDisabled || isStreaming || !inputText.trim()}
                      className={styles.sendButton}
                    >
                      <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <line x1="22" y1="2" x2="11" y2="13"/>
                        <polygon points="22,2 15,22 11,13 2,9 22,2"/>
                      </svg>
                    </button>
                  </div>
                </form>
              ) : (
                <button 
                  className={styles.newChatButton}
                  onClick={() => window.location.reload()}
                >
                  Start a New Chat
                </button>
              )}
            </div>
          </div>
        </div>
      </main>
      </div>
    </div>
  );
}
 