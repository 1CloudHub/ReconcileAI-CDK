import { useState, useEffect, useRef } from 'react';
import { Table, Skeleton } from 'antd';
import Layout from '../components/Layout';
import ExceptionDetailsModal from '../components/ExceptionDetailsModal';
import { getCookie } from '../lib/utils';
import styles from './Exceptions.module.css';
import formatCompactCurrency from '../utils/formatNumber';

interface BundleExceptionData {
  sessionId: string;
  bundleId?: string | null;
  poNumber: string;
  status: string;
  severity: string;
  createdAt: string;
  updatedAt: string;
  exceptionCount: number;
}

export default function Exceptions() {
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedException, setSelectedException] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [exceptionDetails, setExceptionDetails] = useState<any>(null);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [loadingTable, setLoadingTable] = useState(false);

  // API state
  const [totalExceptions, setTotalExceptions] = useState<number | null>(null);
  const [highSeverityExceptions, setHighSeverityExceptions] = useState<number | null>(null);
  const [resolvedToday, setResolvedToday] = useState<number | null>(null);
  const [totalValueAtRisk, setTotalValueAtRisk] = useState<number | null>(null);
  const [exceptionsData, setExceptionsData] = useState<BundleExceptionData[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const pageSize = 10;
  const [refreshTrigger, setRefreshTrigger] = useState(0); // bump to force re-fetch after status updates

  const API_URL = import.meta.env.VITE_API_URL;
  const initialFetchRef = useRef(false);
  const pageDataFetchedRef = useRef<string | null>(null);
  const fetchInProgressRef = useRef<Record<string, boolean>>({});

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
    pageDataFetchedRef.current = null;
  }, [statusFilter, dateRange]);

  // Fetch KPIs and initial data once on mount
  useEffect(() => {
    const fetchInitialData = async () => {
      if (!API_URL || initialFetchRef.current) return;
      initialFetchRef.current = true;

      try {
        // Get userid from cookies for API calls
        const userid = getCookie('userid');

        // Fetch all exception page KPIs in a single API call (consolidated to save costs)
        const exceptionCardsResponse = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            event_type: 'exception_page_cards_new_schema',
            userid: userid || null
          }),
        });
        
        if (exceptionCardsResponse.ok) {
          const cardsData = await exceptionCardsResponse.json();
          setTotalExceptions(cardsData.total_exceptions);
          setHighSeverityExceptions(cardsData.high_severity_exceptions);
          setResolvedToday(cardsData.resolved_today);
          setTotalValueAtRisk(cardsData.total_value_at_risk);
        }

        // Fetch initial paginated bundle exceptions
        const exceptionsResponse = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            event_type: 'session_exceptions',
            page: 1,
            page_size: pageSize,
            status_filter: 'all',
            date_filter: 'all',
            userid: userid || null
          }),
        });
        
        if (exceptionsResponse.ok) {
          const exceptionsResult = await exceptionsResponse.json();
          // Display data in the same order received from backend
          setExceptionsData(exceptionsResult.session_exceptions || []);
          setTotalCount(exceptionsResult.pagination?.total_count || 0);
          pageDataFetchedRef.current = '1-all-all';
        }

        setLoading(false);
      } catch (err) {
        console.error('Error fetching initial data:', err);
        setLoading(false);
      }
    };

    fetchInitialData();
  }, [API_URL]);

  // Fetch paginated exceptions whenever page, statusFilter, or dateRange changes
  useEffect(() => {
    const fetchPageData = async () => {
      if (!API_URL) return;

      // Build a deterministic key for this exact fetch (page + filters)
      const fetchKey = `${currentPage}-${statusFilter}-${dateRange}`;

  // If we've already successfully fetched this key, skip
  if (pageDataFetchedRef.current === fetchKey) return;

  // Use an in-progress guard to prevent concurrent duplicate requests
  // across React strict-mode double-invocations or rapid re-renders.
  if (fetchInProgressRef.current[fetchKey]) return;
  fetchInProgressRef.current[fetchKey] = true;

      try {
        setLoadingTable(true);
        // Get userid from cookies for API calls
        const userid = getCookie('userid');
        
        const exceptionsResponse = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            event_type: 'session_exceptions',
            page: currentPage,
            page_size: pageSize,
            status_filter: statusFilter,
            date_filter: dateRange,
            userid: userid || null
          }),
        });
        if (exceptionsResponse.ok) {
          const exceptionsResult = await exceptionsResponse.json();
          // Display data in the same order received from backend
          setExceptionsData(exceptionsResult.session_exceptions || []);
          setTotalCount(exceptionsResult.pagination?.total_count || 0);

          // Mark this key as fetched successfully
          pageDataFetchedRef.current = fetchKey;
        }
      } catch (err) {
        console.error('Error fetching page data:', err);
      } finally {
        // clear in-progress flag so future requests can run
        fetchInProgressRef.current[fetchKey] = false;
        setLoadingTable(false);
      }
    };

    fetchPageData();
  }, [API_URL, currentPage, statusFilter, dateRange, refreshTrigger]);

  // Fetch exception details using new_po_exception_details (requires bundle_id and session_id)
  const fetchNewPOExceptionDetails = async (bundleId: string | null | undefined, sessionId: string) => {
    if (!API_URL) return;

    setLoadingDetails(true);
    try {
      // Get userid from cookies for API calls
      const userid = getCookie('userid');
      
      const bodyPayload: any = {
        event_type: 'new_po_exception_details',
        session_id: sessionId,
        userid: userid || null
      };
      if (bundleId) bodyPayload.bundle_id = bundleId;

      const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bodyPayload),
      });

      if (response.ok) {
        const data = await response.json();
        setExceptionDetails(data);
      } else {
        console.error('Failed to fetch PO exception details');
        setExceptionDetails(null);
      }
    } catch (error) {
      console.error('Error fetching PO exception details:', error);
      setExceptionDetails(null);
    } finally {
      setLoadingDetails(false);
    }
  };

  const clearFilters = () => {
    setDateRange('all');
    setStatusFilter('all');
    setCurrentPage(1);  // Reset to first page when clearing filters
    pageDataFetchedRef.current = null;  // Force refetch
  };

  // Function to refresh cards data after status update
  const refreshCardsData = async () => {
    if (!API_URL) return;
    
    try {
      const userid = getCookie('userid');
      
      const exceptionCardsResponse = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          event_type: 'exception_page_cards_new_schema',
          userid: userid || null
        }),
      });
      
      if (exceptionCardsResponse.ok) {
        const cardsData = await exceptionCardsResponse.json();
        setTotalExceptions(cardsData.total_exceptions);
        setHighSeverityExceptions(cardsData.high_severity_exceptions);
        setResolvedToday(cardsData.resolved_today);
        setTotalValueAtRisk(cardsData.total_value_at_risk);
      }
    } catch (err) {
      console.error('Error refreshing cards data:', err);
    }
  };

  const exportToCSV = async () => {
    try {
      if (!API_URL) return;

      // Get userid from cookies for API calls
      const userid = getCookie('userid');

      // Call backend to get full export data (no pagination)
      const resp = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          event_type: 'export_csv',
          userid: userid || null
        })
      });

      if (!resp.ok) {
        console.error('Export API failed', resp.statusText);
        return;
      }

      const result = await resp.json();
      const rows: BundleExceptionData[] = result.export_exceptions || [];

      // Build CSV
      const headers = ['PO Number', 'Status', 'Created At', 'Last Updated', 'Exception Count'];
      const csvData = rows.map(r => [
        r.poNumber || '',
        r.status || '',
        r.createdAt || '',
        r.updatedAt || '',
        (r.exceptionCount ?? 0).toString()
      ]);

      const metadata = [
        `Export Date: ${new Date().toLocaleDateString()}`,
        `Total Records: ${rows.length}`,
        `Filters Applied: Status=${statusFilter}, Date=${dateRange}`,
        '',
      ];

      const csvContent = [...metadata, headers, ...csvData]
        .map(row => Array.isArray(row) ? row.map(field => `"${String(field).replace(/"/g, '""') }"`).join(',') : `"${row}"`)
        .join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `bundle_exceptions_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error('Error exporting CSV:', err);
    }
  };

  return (
    <Layout>
      {loading ? (
        <div className={styles.exceptions}>
          <div className={styles.header}>
            <div className={styles.headerInfo}>
              <Skeleton.Input active style={{ width: 250, height: 32, marginBottom: 8 }} />
              <Skeleton.Input active style={{ width: 350, height: 16 }} />
            </div>
            <div className={styles.filters}>
              <Skeleton.Input active style={{ width: 120, height: 36, marginRight: 12 }} />
              <Skeleton.Input active style={{ width: 140, height: 36, marginRight: 12 }} />
              <Skeleton.Input active style={{ width: 100, height: 36 }} />
            </div>
          </div>

          <div className={styles.kpiRow}>
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className={styles.kpiCard}>
                <Skeleton.Input active style={{ width: 150, height: 16, marginBottom: 12 }} />
                <Skeleton.Input active style={{ width: 80, height: 32 }} />
              </div>
            ))}
          </div>

          <div className={styles.tableContainer}>
            <div className={styles.tablePanel}>
              <div className={styles.tableHeader}>
                <Skeleton.Input active style={{ width: 200, height: 24 }} />
                <Skeleton.Input active style={{ width: 120, height: 36 }} />
              </div>
              <Skeleton active paragraph={{ rows: 10 }} />
            </div>
          </div>
        </div>
      ) : (
        <div className={styles.exceptions}>
        <div className={styles.header}>
          <div className={styles.headerInfo}>
            <h2 className={styles.title}>Exception Summary</h2>
            <p className={styles.subtitle}>Monitor and manage detected exceptions across all purchase orders</p>
          </div>
          <div className={styles.filters}>
            <select 
              value={dateRange} 
              onChange={(e) => setDateRange(e.target.value)} 
              className={`${styles.filter} ${dateRange !== 'all' ? styles.active : ''}`}
            >
              <option value="all">Select Date</option>
              <option value="last7days">Last 7 Days</option>
              <option value="last30days">Last 30 Days</option>
            </select>

            <select 
              value={statusFilter} 
              onChange={(e) => setStatusFilter(e.target.value)} 
              className={`${styles.filter} ${statusFilter !== 'all' ? styles.active : ''}`}
            >
              <option value="all">All Statuses</option>
              <option value="pending">Pending</option>
              <option value="resolved">Resolved</option>
              <option value="escalated">Escalated</option>
            </select>

            <button 
              className={`${styles.filter} ${styles.clearButton}`}
              onClick={clearFilters}
            >
              Clear Filters
            </button>
          </div>
        </div>

        <div className={styles.kpiRow}>
          <div className={styles.kpiCard}>
            <div className={styles.kpiLabel}>Total Exceptions</div>
            <div className={styles.kpiValue}>
                {totalExceptions !== null ? totalExceptions : 0}
            </div>
          </div>

          <div className={styles.kpiCard}>
            <div className={styles.kpiLabel}>High Severity Exceptions</div>
            <div className={styles.kpiValue}>
                {highSeverityExceptions !== null ? highSeverityExceptions : 0}
            </div>
          </div>

          <div className={styles.kpiCard}>
            <div className={styles.kpiLabel}>Exceptions Resolved Today</div>
            <div className={styles.kpiValue}>
                {resolvedToday !== null ? resolvedToday : 0}
            </div>
          </div>

          <div className={styles.kpiCard}>
            <div className={styles.kpiLabel}>Total Value at Risk</div>
            <div className={styles.kpiValue}>
                {formatCompactCurrency(totalValueAtRisk)}
            </div>
          </div>
        </div>

        <div className={styles.tableContainer}>
          <div className={styles.tablePanel}>
            <div className={styles.tableHeader}>
              <div className={styles.tableTitleSection}>
                <h3 className={styles.tableTitle}>Purchase Orders with Exceptions</h3>
                {(statusFilter !== 'all' || dateRange !== 'all') && (
                  <div className={styles.filterSummary}>
                    Showing {exceptionsData.length} of {totalCount} purchase orders
                  </div>
                )}
              </div>
              <div className={styles.tableActions}>
                <button className={styles.actionButton} onClick={exportToCSV}>Export CSV</button>
              </div>
            </div>

            <Table
              dataSource={exceptionsData}
              rowKey="sessionId"
              pagination={{
                current: currentPage,
                pageSize: pageSize,
                total: totalCount,
                onChange: (page) => setCurrentPage(page),
                showSizeChanger: false,
                position: ['bottomRight'],
              }}
              loading={loadingTable}
              className={styles.antTable}
              columns={[
                {
                  title: 'Purchase Order',
                  dataIndex: 'poNumber',
                  key: 'poNumber',
                  sorter: false,
                  render: (text: string) => <span className={styles.exceptionId}>{text}</span>,
                },
                {
                  title: 'Created At',
                  dataIndex: 'createdAt',
                  key: 'createdAt',
                  sorter: false,
                  render: (text: string) => <span className={styles.updated}>{text || 'N/A'}</span>,
                },
                {
                  title: 'Last Updated',
                  dataIndex: 'updatedAt',
                  key: 'updatedAt',
                  sorter: false,
                  render: (text: string) => <span className={styles.updated}>{text || 'N/A'}</span>,
                },
                {
                  title: 'Status',
                  dataIndex: 'status',
                  key: 'status',
                  sorter: false,
                  render: (status: string) => {
                    const key = (status || '').toString().toLowerCase().replace(/\s+/g, '');
                    const statusClass = (styles as any)[key] || '';
                    return (
                      <span className={`${styles.statusBadge} ${statusClass}`}>
                        {status}
                      </span>
                    );
                  },
                },
                {
                  title: 'Severity',
                  dataIndex: 'severity',
                  key: 'severity',
                  sorter: false,
                  render: (severity: string) => {
                    const key = (severity || '').toString().toLowerCase().replace(/\s+/g, '');
                    const severityClass = (styles as any)[key] || '';
                    return (
                      <span className={`${styles.severityBadge} ${severityClass}`}>
                        {severity}
                      </span>
                    );
                  },
                },
                {
                  title: 'Exceptions List',
                  dataIndex: 'exceptionCount',
                  key: 'exceptionCount',
                  sorter: false,
                  render: (count: number) => (
                    <span className={styles.exceptionCount}>{count}</span>
                  ),
                },
                {
                  title: 'Actions',
                  key: 'action',
                  sorter: false,
                  render: (_: any, record: BundleExceptionData) => (
                    <button
                      className={styles.actionButton}
                      onClick={() => {
                        setSelectedException(record);
                        setIsModalOpen(true);
                        fetchNewPOExceptionDetails(record.bundleId, record.sessionId);
                      }}
                    >
                      View Details
                    </button>
                  ),
                },
              ]}
            />
          </div>
        </div>


        {isModalOpen && selectedException && (
          <ExceptionDetailsModal
            
            details={exceptionDetails}
            loading={loadingDetails}
            onClose={() => {
              setIsModalOpen(false);
              setSelectedException(null);
              setExceptionDetails(null);
            }}
            onStatusUpdate={() => {
              // Refresh the table data after a status update.
              // Clear the fetched-key so next fetch will run and clear any in-progress guard.
              pageDataFetchedRef.current = null;
              const fetchKey = `${currentPage}-${statusFilter}-${dateRange}`;
              fetchInProgressRef.current[fetchKey] = false;

              // Bump a trigger state to ensure the fetch useEffect runs even if page/filters didn't change.
              setRefreshTrigger((prev) => prev + 1);
            }}
            onCardsUpdate={refreshCardsData}
            apiUrl={API_URL}
            totalCount={selectedException?.exceptionCount}
          />
        )}
      </div>
      )}
    </Layout>
  );
}
