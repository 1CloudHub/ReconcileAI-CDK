import React, { useState, useRef, useEffect } from 'react';
import TopNav from '../components/TopNav';
import SideNav from '../components/SideNav';
import Markdown from 'react-markdown';
import styles from './SAPAssistant.module.css';
import { generateSessionId, generateMessageId, getCookie } from '../lib/utils';

interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  contextSource?: string;
}

interface Conversation {
  id: string;
  messages: Message[];
}

/**
 * Helper function to process markdown text
 * Replaces escaped newlines with actual newlines
 */
const processMarkdownText = (text: string): string => {
  return text.replace(/\\n\\n/g, '\n\n').replace(/\\n/g, '\n');
};

/**
 * Inline error component to show timeouts
 */
const InlineErrorNotice: React.FC<{ message: string }> = ({ message }) => (
  <div
    role="alert"
    aria-live="assertive"
    className={styles.errorNotice}
  >
    {message}
  </div>
);

/**
 * Bot typing loader component with blinking cursor animation
 */
const BotTypingLoader: React.FC = () => (
  <span className={styles.typingCursor}>
    <style>{`
      @keyframes cursor-blink {
        0%, 50% { opacity: 1; }
        51%, 100% { opacity: 0; }
      }
    `}</style>
  </span>
);

/**
 * ERP Assistant component - Main chat interface for ERP exception management
 * Combines RetailAssistantTool logic with SAPAssistant UI styling
 */
export default function ERPAssistant() {
  const emptyConversation: Conversation = { id: 'active-conversation', messages: [] };
  const [conversation, setConversation] = useState<Conversation>(emptyConversation);
  const [inputText, setInputText] = useState('');
  const [streamingMessage, setStreamingMessage] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [isStreaming2, setIsStreaming2] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatTranscriptRef = useRef<HTMLDivElement>(null);

  const [chatEnded, setChatEnded] = useState(false);
  const [sessionId, setSessionId] = useState<string>('');
  const [apiStarted, setApiStarted] = useState(false);
  const socketRef = useRef<WebSocket | null>(null);
  const [showFaqs, setShowFaqs] = useState(true);
  const sawTextDeltaRef = useRef(false);
  const currentMessageIdRef = useRef<string | null>(null);
  const messageFlushedRef = useRef(false);
  const [inputDisabled, setInputDisabled] = useState(false);
  const [timeoutNotice, setTimeoutNotice] = useState<string | null>(null);
  const lastWsMessageTimestampRef = useRef<number | null>(null);
  const lastRequestTimestampRef = useRef<number | null>(null);
  // Continuous WS gap timer between messages
  const wsGapStartRef = useRef<number | null>(null);
  const wsGapIntervalRef = useRef<number | null>(null);

  // FAQ suggestions from RetailAssistantTool
  const faqs = [
    "Do a 2 way comparison between PO 4500000001 and it's Supplier invoice",
    "Do a 3 way comparison between PO 4500000001, it's supplier invoice and it's material goods",
  ];

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (chatTranscriptRef.current) {
      chatTranscriptRef.current.scrollTop = chatTranscriptRef.current.scrollHeight;
    }
  }, [conversation.messages, streamingMessage]);

  // Generate a new session ID on every page load
  useEffect(() => {
    const newId = generateSessionId();
    setSessionId(newId);
  }, []);

  /**
   * Opens a WebSocket connection and returns a promise that resolves with the connection ID
   */
  const openWebsocketConnection = (): Promise<string> => {
    return new Promise((resolve, reject) => {
      // Close existing connection if any
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }

      const socket = new WebSocket(
        import.meta.env.VITE_WEBSOCKET_URL
      );
      
      // Store accumulated message text locally
      let accumulatedMessage = '';
      // Idle timer to auto-finalize when server doesn't send an explicit done
      let idleTimer: number | null = null;
      // Ensure we resolve only once per connection
      let connectionResolved = false;
      // Reset flush flag for this message lifecycle
      messageFlushedRef.current = false;

      /**
       * Schedules idle finalization after 2 seconds of inactivity
       */
      const scheduleIdleFinalize = () => {
        if (idleTimer) {
          clearTimeout(idleTimer);
        }
        idleTimer = window.setTimeout(() => {
          // If we were streaming but no explicit done arrived, finalize now
          if (sawTextDeltaRef.current) {
            setIsStreaming(false);

            if (accumulatedMessage.trim()) {
              setConversation((prev) => ({
                ...prev,
                messages: [
                  ...prev.messages,
                  {
                    id: `bot-${Date.now()}`,
                    sender: 'bot',
                    text: accumulatedMessage,
                    timestamp: new Date().toISOString(),
                  }
                ]
              }));
            }
            setStreamingMessage('');
            sawTextDeltaRef.current = false;
            currentMessageIdRef.current = null;
            // Keep socket open for future messages
          } else {
            // No stream seen; just ensure inputs are enabled
            setIsStreaming(false);
          }
        }, 2000); // 2s idle window after last chunk
      };
      sawTextDeltaRef.current = false; // reset for each new connection
      
      socket.onopen = () => {
        socket.send(JSON.stringify({ type: "connection_init" }));
        // Clear any previous timeout state on a fresh connection
        setInputDisabled(false);
        setTimeoutNotice(null);
      };

      socket.onmessage = (e) => {
        let isControlMessage = false;
        try {
          const messageData = JSON.parse(e.data);
          
          // If this is an api_end signal, treat as control (do not count as a message)
          if (
            messageData === 'api_end' ||
            messageData?.message === 'api_end' ||
            messageData?.type === 'api_end' ||
            messageData?.type === 'final_message_ff'
          ) {
            // Stop and clear any ongoing gap counters and do not log deltas for this control message
            if (wsGapIntervalRef.current !== null) {
              clearInterval(wsGapIntervalRef.current);
              wsGapIntervalRef.current = null;
            }
            wsGapStartRef.current = null;
            // Do not update lastWsMessageTimestampRef here; we explicitly ignore this message for timing
            setApiStarted(false);
            // Mark as control to skip timing in finally
            isControlMessage = true;
            return;
          }

          // Non-control message: clear any previous timeout and close out previous gap and log delta
          if (inputDisabled || timeoutNotice) {
            setInputDisabled(false);
            setTimeoutNotice(null);
          }
          if (wsGapIntervalRef.current !== null) {
            clearInterval(wsGapIntervalRef.current);
            wsGapIntervalRef.current = null;
          }
          if (wsGapStartRef.current !== null) {
            const gapEndMs = performance.now() - wsGapStartRef.current;
            console.log(`[WS] gap ended: ${gapEndMs.toFixed(1)} ms`);
            wsGapStartRef.current = null;
          }

          const nowTs = performance.now();
          if (lastWsMessageTimestampRef.current !== null) {
            const deltaMs = nowTs - lastWsMessageTimestampRef.current;
            console.log(`[WS] Δ since last message: ${deltaMs.toFixed(1)} ms`);
          }
          lastWsMessageTimestampRef.current = nowTs;

          // Handle connection ID (resolve once regardless of prior state)
          if (messageData.connectionid && !connectionResolved) {
            connectionResolved = true;
            resolve(messageData.connectionid);
          }

          // Handle API lifecycle signals - pure backend control
          if (
            messageData === 'api_start' ||
            messageData?.message === 'api_start' ||
            messageData?.type === 'api_start'
          ) {
            setApiStarted(true);
            return;
          }

          if (
            messageData === 'api_end' ||
            messageData?.message === 'api_end' ||
            messageData?.type === 'api_end'
          ) {
            setApiStarted(false);
            return;
          }

          // If backend tags chunks with message_id, ignore others
          if (messageData.message_id && currentMessageIdRef.current && messageData.message_id !== currentMessageIdRef.current) {
            return; // not for current in-flight message
          }

          // Explicit completion signal from backend
          if (
            messageData === 'streaming_completed' ||
            messageData?.message === 'streaming_completed' ||
            messageData?.type === 'streaming_completed'
          ) {
            if (idleTimer) {
              clearTimeout(idleTimer);
              idleTimer = null;
            }
            // finalize any accumulated text into conversation
            if (!messageFlushedRef.current) {
              if (accumulatedMessage.trim()) {
                setConversation((prev) => ({
                  ...prev,
                  messages: [
                    ...prev.messages,
                    {
                      id: `bot-${Date.now()}`,
                      sender: 'bot',
                      text: accumulatedMessage,
                      timestamp: new Date().toISOString(),
                    }
                  ]
                }));
              }
              messageFlushedRef.current = true;
            }
            setStreamingMessage('');
            setIsStreaming(false);
            sawTextDeltaRef.current = false;
            currentMessageIdRef.current = null;
            // keep socket open for subsequent messages
            return;
          }

          // Simple chunk protocol: { message: string, message_id }
          if (typeof messageData.message === 'string') {
            // Ignore connection acknowledgements and system signals
            const chunkText = String(messageData.message);
            if (chunkText.trim().toLowerCase() === 'connected') {
              return;
            }
            
            sawTextDeltaRef.current = true;
            if( chunkText.trim().toLowerCase() === 'message___end'){
              scheduleIdleFinalize();
              return;
            } 
            accumulatedMessage += chunkText;
            setStreamingMessage(accumulatedMessage);
            setIsStreaming(true);
            setIsStreaming2(false);
          }

          // Track if we have seen a text_delta in this stream
          if (messageData.type === "content_block_delta" && messageData.delta?.type === "text_delta") {
            const deltaText = messageData.delta.text;
            
            sawTextDeltaRef.current = true;
            accumulatedMessage += deltaText;
            setStreamingMessage(accumulatedMessage);
            setIsStreaming(true);
            setIsStreaming2(false);
            scheduleIdleFinalize();
          }

          // Handle stream completion
          if (messageData.done === true || messageData.type === 'done' || messageData.type === 'complete' || messageData.type === "content_block_stop" || messageData.type === "message_stop") {
            // Clear streaming state
            setIsStreaming(false);
            if (idleTimer) {
              clearTimeout(idleTimer);
              idleTimer = null;
            }

            if (sawTextDeltaRef.current) {
              if (!messageFlushedRef.current) {
                if (accumulatedMessage.trim()) {
                  setConversation((prev) => ({
                    ...prev,
                    messages: [
                      ...prev.messages,
                      {
                        id: `bot-${Date.now()}`,
                        sender: 'bot',
                        text: accumulatedMessage, 
                        timestamp: new Date().toISOString(),
                      }
                    ]
                  }));
                }
                messageFlushedRef.current = true;
              }
              setStreamingMessage('');
              socket.close();
              sawTextDeltaRef.current = false; // reset for next stream
              currentMessageIdRef.current = null;
            } else {
              // This was just a tool or non-answer completion; keep socket open
              accumulatedMessage = '';
              setStreamingMessage('');
            }
          }
        } catch (error) {
          reject(error);
        } finally {
          // Start a continuous counter until the next message arrives (skip for control messages)
          if (!isControlMessage) {
            wsGapStartRef.current = performance.now();
            wsGapIntervalRef.current = window.setInterval(() => {
              if (wsGapStartRef.current !== null) {
                const elapsed = performance.now() - wsGapStartRef.current;
                console.log(`[WS] waiting ${Math.round(elapsed)} ms since last message`);
                if (elapsed >= 120000 && !inputDisabled) {
                  setInputDisabled(true);
                  setTimeoutNotice('Please refresh and try again after 2 minutes');
                  clearInterval(wsGapIntervalRef.current as unknown as number);
                  wsGapIntervalRef.current = null;
                }
              }
            }, 1000);
          }
        }
      };

      socket.onclose = () => {
        if (idleTimer) {
          clearTimeout(idleTimer);
          idleTimer = null;
        }
        // Reset last WS message timestamp on close
        lastWsMessageTimestampRef.current = null;
        // Clear continuous gap timer on close
        if (wsGapIntervalRef.current !== null) {
          clearInterval(wsGapIntervalRef.current);
          wsGapIntervalRef.current = null;
        }
        wsGapStartRef.current = null;
        setIsStreaming(false);
      };

      socket.onerror = (error) => {
        if (idleTimer) {
          clearTimeout(idleTimer);
          idleTimer = null;
        }
        setIsStreaming(false);
        reject(error);
      };

      socketRef.current = socket;
      
      // Set timeout for connection
      setTimeout(() => {
        if (!connectionResolved) {
          reject(new Error('Connection timeout'));
        }
      }, 10000);
    });
  };

  /**
   * Handles form submission for user messages
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim() === '') return;
    setIsStreaming2(true);
    // Clear any previous timeout state on new submission
    if (inputDisabled || timeoutNotice) {
      setInputDisabled(false);
      setTimeoutNotice(null);
    }
    // Log time between consecutive requests (submissions)
    const nowReq = performance.now();
    if (lastRequestTimestampRef.current !== null) {
      const deltaReqMs = nowReq - lastRequestTimestampRef.current;
      console.log(`[REQ] Δ since last request: ${deltaReqMs.toFixed(1)} ms`);
    }
    lastRequestTimestampRef.current = nowReq;
    
    // Add user message
    const newUserMessage: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: inputText,
      timestamp: new Date().toISOString()
    };
    
    setConversation(prev => ({
      ...prev,
      messages: [...prev.messages, newUserMessage]
    }));
    
    const currentInput = inputText;
    setInputText('');
    
    // Hide FAQ only after first send
    if (conversation.messages.length === 0 && showFaqs) {
      setShowFaqs(false);
    }
    
    try {
      // Generate new connection ID for each API call
      const newConnectionId = await openWebsocketConnection();
      const messageId = generateMessageId();
      currentMessageIdRef.current = messageId;

      // Get userid from cookies for API calls
      const userid = getCookie('userid');

      // Fire-and-forget HTTP initiator; responses come over WebSocket.
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      const raw = JSON.stringify({
        event_type: 'retail_chat_tool',
        chat: currentInput,
        session_id: sessionId || '',
        connectionId: newConnectionId,
        message_id: messageId,
        userid: userid || null
      });

      const requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow' as const
      };

      // Do not await; ignore 504/timeouts and let WS drive UI
      fetch(import.meta.env.VITE_API_BASE_URL, requestOptions)
        .then(async (response) => {
          try {
            const data = await response.json().catch(() => null);
            if (data && data.session_id) {
              setSessionId(data.session_id);
            }
          } catch {
            // swallow errors from parsing or non-JSON bodies
          }
        })
        .catch(() => {
          // Intentionally ignore HTTP errors (e.g., 504) – WS will continue
        });

    } catch (error) {
      // Add error message if WebSocket fails
      const errorMessage: Message = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: 'Sorry, there was a problem connecting to the ERP assistant service. Please try again.',
        timestamp: new Date().toISOString(),
      };
      
      setConversation(prev => ({
        ...prev,
        messages: [...prev.messages, errorMessage]
      }));
      
      setIsStreaming(false);
      setStreamingMessage('');
    }
  };

  /**
   * Handles clicking on FAQ suggestion chips
   */
  const handlePromptChipClick = (text: string) => {
    setInputText(text);
  };

  /**
   * Handles starting a new chat session
   */
  const handleStartNewChat = () => {
    setChatEnded(false);
    setConversation(emptyConversation); 
    setInputText('');
    setStreamingMessage('');
    setIsStreaming(false);
    setShowFaqs(true);
    
    // Close existing WebSocket connection
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.close();
    }
  };

  // Clean up WebSocket on component unmount
  useEffect(() => {
    return () => {
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }
    };
  }, []);

  return (
    <div className={styles.fullScreenLayout}>
      <TopNav />
      <div className={styles.layoutContainer}>
        <SideNav />
        <main className={styles.fullScreenMain}>
          <div className={styles.chatContainer}>
            <div className={styles.chatHeader}>
              <div className={styles.chatTitleSection}>
                <div className={styles.botIcon}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/>
                    <path d="M12 6v6l4 2"/>
                  </svg>
                </div>
                <h3 className={styles.chatTitle}>ERP Assistant</h3>
              </div>
            </div>

          <div className={styles.chatBody}>
            <div
              className={styles.messagesContainer}
              ref={chatTranscriptRef}
            >
              {/* Opening message */}
              {!chatEnded && (
                <div className={styles.messageContainer}>
                  <div className={styles.botMessage}>
                    <div className={styles.botBubble}>
                      <div className={styles.messageContent}>
                        How may I help you with your SAP needs?
                      </div>
                      <div className={styles.messageTimestamp}>
                        <span className={styles.timestamp}>
                          {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Render conversation messages */}
              {!chatEnded && conversation.messages.map((message) => (
                <div key={message.id} className={`${styles.messageContainer} ${message.sender === 'user' ? styles.userMessage : styles.botMessage}`}>
                  <div className={message.sender === 'user' ? styles.userBubble : styles.botBubble}>
                    <div className={styles.messageContent}>
                      {message.sender === 'bot' ? <Markdown>{processMarkdownText(message.text)}</Markdown> : message.text}
                    </div>
                    <div className={styles.messageTimestamp}>
                      <span className={styles.timestamp}>
                        {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                </div>
              ))}

              {/* Streaming message */}
              {streamingMessage && isStreaming && !chatEnded && (
                <div className={styles.messageContainer}>
                  <div className={styles.botBubble}>
                    <div className={styles.messageContent}>
                      <Markdown>{processMarkdownText(streamingMessage)}</Markdown>
                      {apiStarted && !chatEnded && !timeoutNotice && (
                        <div className={styles.typingIndicator}>
                          <BotTypingLoader />
                        </div>
                      )}
                    </div>
                    {timeoutNotice && !chatEnded && (
                      <InlineErrorNotice message={timeoutNotice} />
                    )}
                    <div className={styles.messageTimestamp}>
                      <span className={styles.timestamp}>
                        {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {isStreaming2 && (
                <div className={styles.messageContainer}>
                  <div className={styles.botBubble}>
                    <div className={styles.messageContent}>
                      {!timeoutNotice && <BotTypingLoader />}
                    </div>
                    {timeoutNotice && !chatEnded && (
                      <InlineErrorNotice message={timeoutNotice} />
                    )}
                  </div>
                </div>
              )}

              {/* Start new chat button when chat ended */}
              {chatEnded && (
                <div className={styles.newChatContainer}>
                  <button
                    className={styles.newChatButton}
                    onClick={handleStartNewChat}
                  >
                    Start New Chat
                  </button>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick Reply Suggestions */}
            {conversation.messages.length === 0 && !chatEnded && showFaqs && (
              <div className={styles.suggestionsContainer}>
                <div className={styles.suggestions}>
                  {faqs.map((faq, idx) => (
                    <button
                      key={idx}
                      className={styles.suggestionChip}
                      onClick={() => handlePromptChipClick(faq)}
                    >
                      {faq}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Input Area */}
            <div className={styles.inputContainer}>
              {!chatEnded ? (
                <form onSubmit={handleSubmit} className={styles.inputForm}>
                  <div className={styles.inputWrapper}>
                    <input
                      type="text"
                      placeholder="Type your message here..."
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      disabled={isStreaming || inputDisabled}
                      className={styles.textInput}
                    />
                    <button 
                      type="submit" 
                      disabled={inputDisabled || isStreaming || !inputText.trim()}
                      className={styles.sendButton}
                    >
                      <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <line x1="22" y1="2" x2="11" y2="13"/>
                        <polygon points="22,2 15,22 11,13 2,9 22,2"/>
                      </svg>
                    </button>
                  </div>
                </form>
              ) : (
                <button 
                  className={styles.newChatButton}
                  onClick={() => window.location.reload()}
                >
                  Start a New Chat
                </button>
              )}
            </div>
          </div>
        </div>
      </main>
      </div>
    </div>
  );
}

