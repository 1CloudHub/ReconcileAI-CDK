import { useState, useEffect, useRef, useMemo } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, Legend /*, PieChart, Pie, Cell */ } from 'recharts';
import { Skeleton, Tooltip } from 'antd';
import Layout from '../components/Layout';
import { getCookie } from '../lib/utils';
import styles from './Dashboard.module.css';

// exceptionData will be loaded from the backend

// trendData will be loaded from the backend

// Colors used for the root cause chart. Prefer a name->color map to ensure
// stable, distinct colors for important categories (avoids duplicates when
// the data array grows or ordering changes).
// const ROOT_CAUSE_COLORS = ['#004B91', '#0066CC', '#3399FF', '#F4C542', '#00B386', '#006400', '#8A2BE2'];



export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [exceptionData, setExceptionData] = useState<Array<{ name: string; count: number }>>([]);
  const [maxLabelChars, setMaxLabelChars] = useState<number>(20);
  const [trendData, setTrendData] = useState<Array<{ day: string; detected: number; resolved: number }>>([]);
  // const [rootCauseData, setRootCauseData] = useState<Array<{ name: string; value: number }>>([]);
  const [severityData, setSeverityData] = useState<Array<{ severity: string; count: number }>>([]);
  
  const [totalRecordsProcessed, setTotalRecordsProcessed] = useState<number | null>(null);
  const [totalExceptions, setTotalExceptions] = useState<number | null>(null);
  const [resolvedExceptions, setResolvedExceptions] = useState<number | null>(null);
  const [pendingExceptions, setPendingExceptions] = useState<number | null>(null);
  const [pendingApproval, setPendingApproval] = useState<number | null>(null);

  const API_URL = import.meta.env.VITE_API_URL;
  // Prevent double-fetch in React Strict Mode (development) or duplicate mounts
  const fetchCalledRef = useRef(false);
  const barChartInnerRef = useRef<HTMLDivElement | null>(null);

  // Trim helper: truncate the label and append '...' when it exceeds maxLabelChars.
  const trimLabel = (label: string, maxChars: number) => {
    if (!label) return '';
    if (label.length <= maxChars) return label;
    if (maxChars <= 3) return label.slice(0, maxChars);
    return label.slice(0, maxChars - 3).trimEnd() + '...';
  };

  // Compute trimmed display names based on current container width and number of bars.
  useEffect(() => {
    const computeMaxChars = () => {
      const el = barChartInnerRef.current;
      if (!el) return;
      const width = el.clientWidth || el.getBoundingClientRect().width;
      const num = Math.max(1, exceptionData.length);

      // Approximate character width in px. Empirically ~7-9px depending on font; use 8 for safety.
      const approxCharPx = 8;

      // Allow some horizontal padding between bars for visual breathing room.
      const slot = Math.max(40, width / num * 0.85);
      const max = Math.max(4, Math.floor(slot / approxCharPx));

      // Cap to avoid absurdly long labels on very wide screens
      setMaxLabelChars(Math.min(max, 40));
    };

    // Wait for data to be loaded and chart to render before computing
    if (!loading && exceptionData.length > 0) {
      // Use requestAnimationFrame to ensure we read layout AFTER the chart has painted
      // This fixes the race condition where we try to read width before ResponsiveContainer finishes sizing
      requestAnimationFrame(() => {
        // Double-RAF for extra safety - ensures we're past layout AND paint phases
        requestAnimationFrame(() => {
          computeMaxChars();
        });
      });
    }

    // Listen for resize events
    window.addEventListener('resize', computeMaxChars);
    return () => window.removeEventListener('resize', computeMaxChars);
  }, [exceptionData, loading]);

  // (No truncation) use default axis tick rendering

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        // Get userid from cookies for API calls
        const userid = getCookie('userid');
        
        // Fetch all dashboard KPI cards in a single API call (consolidated to save costs)
        const dashboardCardsResponse = await fetch(API_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          // Use new schema event type to fetch KPI cards from erp.session_table
          body: JSON.stringify({ 
            event_type: 'new_schema_dashboard_cards',
            userid: userid || null
          }),
        });
        
        if (dashboardCardsResponse.ok) {
          const cardsData = await dashboardCardsResponse.json();
          setTotalRecordsProcessed(cardsData.total_records_processed);
          setTotalExceptions(cardsData.total_exceptions);
          setResolvedExceptions(cardsData.resolved_exceptions);
          setPendingExceptions(cardsData.pending_exceptions);
          setPendingApproval(cardsData.pending_approval);
        }

        // Fetch exceptions by type (for bar chart)
        const byTypeResponse = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            event_type: 'exceptions_by_type_new_schema',
            userid: userid || null
          }),
        });

        if (byTypeResponse.ok) {
          const byTypeData = await byTypeResponse.json();
          // backend returns { exceptions_by_type: [ { name, count }, ... ] }
          setExceptionData(byTypeData.exceptions_by_type_new_schema || []);
        }

        // Fetch root cause counts for Pie chart (commented out - replaced with Severity Analysis)
        // const rootCauseResponse = await fetch(API_URL, {
        //   method: 'POST',
        //   headers: { 'Content-Type': 'application/json' },
        //   body: JSON.stringify({ event_type: 'root_cause' }),
        // });

        // if (rootCauseResponse.ok) {
        //   const rootCauseResult = await rootCauseResponse.json();
        //   // backend returns { root_cause: [ { name, value }, ... ] }
        //   setRootCauseData(rootCauseResult.root_cause || []);
        // }

        // Fetch exception trend (last 7 days)
        const trendResponse = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            event_type: 'exception_trend_7days_new_schema',
            userid: userid || null
          }),
        });

        if (trendResponse.ok) {
          const trendDataResult = await trendResponse.json();
          // backend returns { exception_trend_7days_new_schema: [ { day, detected, resolved }, ... ] }
          setTrendData(trendDataResult.exception_trend_7days_new_schema || []);
        }

        // Fetch severity analysis data
        const severityResponse = await fetch(API_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ 
            event_type: 'severity_analysis_new_schema',
            userid: userid || null
          }),
        });

        if (severityResponse.ok) {
          const severityResult = await severityResponse.json();
          // backend returns severity_analysis_new_schema for the new schema endpoint
          setSeverityData(severityResult.severity_analysis_new_schema || []);
        }

        // All data loaded, show the page
        setLoading(false);
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setLoading(false);
      }
    };

    // Guard: avoid running the fetch twice in development with StrictMode
    if (!API_URL) return;
    if (fetchCalledRef.current) return;
    fetchCalledRef.current = true;
    fetchDashboardData();
  }, [API_URL]);

  // Prepare processed data with unique id to prevent Recharts from confusing items with same truncated displayName
  const processedExceptionData = useMemo(() => exceptionData.map((d, idx) => ({ 
    ...d, 
    uniqueId: `${d.name}-${idx}`, // Unique identifier
    displayName: trimLabel(d.name, maxLabelChars) 
  })), [exceptionData, maxLabelChars]);

  // Custom XAxis tick renderer that wraps trimmed label in an Antd Tooltip and looks up the full name by index.
  const renderCustomizedTick = (props: any) => {
    const { x, y, payload } = props;
    // payload.value will be the uniqueId now
    const uniqueId = payload?.value ?? '';
    // Find the matching data point by uniqueId
    const dataPoint = processedExceptionData.find(d => d.uniqueId === uniqueId);
    const display = dataPoint?.displayName ?? '';
    const full = dataPoint?.name ?? display;

    return (
      <g transform={`translate(${x},${y + 16})`}>
        <Tooltip title={full} placement="top">
          <text x={0} y={0} dy={0} textAnchor="middle" style={{ fontSize: 11, pointerEvents: 'auto', cursor: full !== display ? 'pointer' : 'default' }}>
            {display}
          </text>
        </Tooltip>
      </g>
    );
  };

  return (
    <Layout>
      {loading ? (
        <div className={styles.dashboard}>
          <div className={styles.header}>
            <div className={styles.headerInfo}>
              <Skeleton.Input active style={{ width: 300, height: 32, marginBottom: 8 }} />
              <Skeleton.Input active style={{ width: 200, height: 16 }} />
            </div>
          </div>

          <div className={styles.kpiGrid}>
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className={styles.kpiCard}>
                <Skeleton.Input active style={{ width: 150, height: 16, marginBottom: 12 }} />
                <Skeleton.Input active style={{ width: 80, height: 32 }} />
              </div>
            ))}
          </div>

          <div className={styles.chartsGrid}>
            <div className={styles.chartCard}>
              <Skeleton.Input active style={{ width: 200, height: 24, marginBottom: 20 }} />
              <Skeleton active paragraph={{ rows: 8 }} />
            </div>
            <div className={styles.chartCard}>
              <Skeleton.Input active style={{ width: 200, height: 24, marginBottom: 20 }} />
              <Skeleton active paragraph={{ rows: 8 }} />
            </div>
          </div>

          <div className={styles.insightsSection}>
            <div className={styles.chartCard}>
              <Skeleton.Input active style={{ width: 200, height: 24, marginBottom: 20 }} />
              <Skeleton active paragraph={{ rows: 8 }} />
            </div>
            <div className={styles.insightCard}>
              <Skeleton active paragraph={{ rows: 6 }} />
            </div>
          </div>
        </div>
      ) : (
        <div className={styles.dashboard}>
        <div className={styles.header}>
          <div className={styles.headerInfo}>
            <h2 className={styles.title}>Dashboard Overview</h2>
            
          </div>
        </div>

        <div className={styles.kpiGrid}>
          <div className={styles.kpiCard}>
            <div className={styles.kpiLabel}>Total Records Processed</div>
            <div className={styles.kpiValue}>
              {totalRecordsProcessed !== null ? totalRecordsProcessed.toLocaleString() : 0}
            </div>
          </div>

          <div className={styles.kpiCard}>
            <div className={styles.kpiLabel}>Total Exceptions Detected</div>
            <div className={styles.kpiValue}>
              {totalExceptions !== null ? totalExceptions : 0}
            </div>
          </div>

          <div className={styles.kpiCard}>
            <div className={styles.kpiLabel}>Pending Approval</div>
            <div className={styles.kpiValue}>
              {pendingApproval !== null ? pendingApproval : 0}
            </div>
          </div>

          <div className={styles.kpiCard}>
            <div className={styles.kpiLabel}>Pending Review</div>
            <div className={styles.kpiValue}>
              {pendingExceptions !== null ? pendingExceptions : 0}
            </div>
          </div>

          <div className={styles.kpiCard}>
            <div className={styles.kpiLabel}>Resolved</div>
            <div className={styles.kpiValue}>
              {resolvedExceptions !== null ? resolvedExceptions : 0}
            </div>
          </div>
        </div>

        <div className={styles.chartsGrid}>
          <div className={styles.chartCard}>
            <h3 className={styles.chartTitle}>Exceptions by Type</h3>
            <div ref={barChartInnerRef} style={{ width: '100%' }}>
              <ResponsiveContainer width="100%" height={320}>
                {/* Use uniqueId as dataKey to ensure each bar is uniquely identified even if displayName is truncated to same value */}
                <BarChart data={processedExceptionData} margin={{ bottom: 20, left: 0, right: 20, top: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E0E4E8" />
                {/* Keep ticks horizontal (angle=0) and centered. We use uniqueId to prevent confusion when truncated names match */}
                <XAxis dataKey="uniqueId" interval={0} tick={renderCustomizedTick} angle={0} textAnchor="middle" height={50} />
                <YAxis tick={{ fontSize: 12 }} />
                <RechartsTooltip 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div style={{ backgroundColor: 'white', border: '1px solid #ccc', padding: '10px', borderRadius: '4px' }}>
                          <p style={{ margin: 0, fontWeight: 'bold' }}>{payload[0].payload.name}</p>
                          <p style={{ margin: '4px 0 0 0', color: '#004B91' }}>Count: {payload[0].value}</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="count" fill="#004B91" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className={styles.chartCard}>
            <h3 className={styles.chartTitle}>Exception Trend (Last 7 Days)</h3>
            <ResponsiveContainer width="100%" height={320}>
              <LineChart data={trendData} margin = {{top: 0, right: 20, left: -30, bottom: 0}}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E0E4E8" />
                <XAxis dataKey="day" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <RechartsTooltip />
                <Legend />
                <Line type="monotone" dataKey="detected" stroke="#004B91" strokeWidth={2} dot={{ r: 4 }} name="Detected" />
                <Line type="monotone" dataKey="resolved" stroke="#00B386" strokeWidth={2} dot={{ r: 4 }} name="Resolved" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className={styles.insightsSection}>
          <div className={styles.chartCard}>
            <h3 className={styles.chartTitle}>Severity Analysis</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={severityData} layout="vertical" margin={{ left: 20, right: 30 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E0E4E8" />
                <XAxis type="number" tick={{ fontSize: 12 }} />
                <YAxis type="category" dataKey="severity" tick={{ fontSize: 12 }} />
                <RechartsTooltip />
                <Bar dataKey="count" fill="#004B91" radius={[0, 8, 8, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* <div className={styles.chartCard}>
            <h3 className={styles.chartTitle}>Root Cause Analysis</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={rootCauseData.length ? rootCauseData : []}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={(entry: any) => `${(entry.percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {(
                    (rootCauseData.length ? rootCauseData : []).map((_, index) => (
                      <Cell key={`cell-${index}`} fill={ROOT_CAUSE_COLORS[index % ROOT_CAUSE_COLORS.length]} />
                    ))
                  )}
                </Pie>
                <RechartsTooltip />
                <Legend verticalAlign="bottom" height={36} />
              </PieChart>
            </ResponsiveContainer>
          </div> */}

          <div className={styles.insightCard}>
            <div className={styles.insightHeader}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M2 17L12 22L22 17" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M2 12L12 17L22 12" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <h3 className={styles.insightTitle}>AI-Generated Insights</h3>
            </div>
            <div className={styles.insightContent}>
              <p className={styles.insightText}>
                <strong>Week-over-Week Improvement:</strong> Quantity mismatches have reduced by 12% compared to last week,
                indicating improved Goods Receipt (GR) posting discipline and better vendor compliance with delivery specifications.
              </p>
              <p className={styles.insightText}>
                <strong>Key Trend:</strong> Price Validation Agent is detecting 15% more exceptions this week, primarily due to
                recent vendor contract updates that haven't been reflected in the SAP master data. Recommend initiating a master
                data cleansing cycle.
              </p>
              <p className={styles.insightText}>
                <strong>Performance Highlight:</strong> Overall resolution rate has improved from 78.5% to 81.4% in the past month,
                demonstrating increasing effectiveness of autonomous agent interventions and reduced manual review requirements.
              </p>
            </div>
          </div>
        </div>

        <div className={styles.footer}>
          <p>Autonomous Agent System powered by AWS Bedrock + SAP</p>
        </div>
      </div>
      )}
    </Layout>
  );
}
