import { useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';
import styles from './Drilldown.module.css';

export default function Drilldown() {
  const navigate = useNavigate();

  return (
    <Layout>
      <div className={styles.drilldown}>
        <div className={styles.breadcrumb}>
          <span onClick={() => navigate('/')} className={styles.breadcrumbLink}>Dashboard</span>
          <span className={styles.breadcrumbSeparator}>→</span>
          <span onClick={() => navigate('/exceptions')} className={styles.breadcrumbLink}>Exceptions</span>
          <span className={styles.breadcrumbSeparator}>→</span>
          <span className={styles.breadcrumbCurrent}>EXC-2025-1047</span>
        </div>

        <div className={styles.exceptionHeader}>
          <div className={styles.headerLeft}>
            <h2 className={styles.exceptionId}>EXC-2025-1047</h2>
            <div className={styles.headerMeta}>
              <span className={styles.metaItem}>
                <span className={styles.metaLabel}>Type:</span> Price Mismatch
              </span>
              <span className={styles.metaItem}>
                <span className={styles.metaLabel}>Detected On:</span> 14 Oct 2025, 02:15 AM
              </span>
            </div>
          </div>
          <div className={styles.headerRight}>
            <span className={`${styles.statusTag} ${styles.pending}`}>Pending</span>
          </div>
        </div>

        <div className={styles.dataSection}>
          <div className={styles.dataCard}>
            <div className={styles.cardHeader}>
              <h3 className={styles.cardTitle}>Purchase Order (PO)</h3>
              <span className={styles.cardBadge}>Source</span>
            </div>
            <div className={styles.cardContent}>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>PO Number:</span>
                <span className={styles.dataValue}>PO-2025-8473</span>
              </div>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>Vendor:</span>
                <span className={styles.dataValue}>Acme Industrial Supplies Ltd.</span>
              </div>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>Order Quantity:</span>
                <span className={styles.dataValue}>500 units</span>
              </div>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>Unit Price:</span>
                <span className={styles.dataValue}>$1,250.00</span>
              </div>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>UoM:</span>
                <span className={styles.dataValue}>EA (Each)</span>
              </div>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>Total Value:</span>
                <span className={styles.dataValue}>$625,000.00</span>
              </div>
            </div>
          </div>

          <div className={styles.dataCard}>
            <div className={styles.cardHeader}>
              <h3 className={styles.cardTitle}>Goods Receipt (GR)</h3>
              <span className={styles.cardBadge}>Receipt</span>
            </div>
            <div className={styles.cardContent}>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>GR Number:</span>
                <span className={styles.dataValue}>GR-2025-6291</span>
              </div>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>PO Reference:</span>
                <span className={styles.dataValue}>PO-2025-8473</span>
              </div>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>Received Quantity:</span>
                <span className={`${styles.dataValue} ${styles.warning}`}>480 units</span>
              </div>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>Receipt Date:</span>
                <span className={styles.dataValue}>12 Oct 2025</span>
              </div>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>Variance:</span>
                <span className={`${styles.dataValue} ${styles.error}`}>-4.0% (20 units short)</span>
              </div>
            </div>
          </div>

          <div className={styles.dataCard}>
            <div className={styles.cardHeader}>
              <h3 className={styles.cardTitle}>Invoice</h3>
              <span className={`${styles.cardBadge} ${styles.badgeError}`}>Mismatch Detected</span>
            </div>
            <div className={styles.cardContent}>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>Invoice Number:</span>
                <span className={styles.dataValue}>INV-2025-4829</span>
              </div>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>PO Reference:</span>
                <span className={styles.dataValue}>PO-2025-8473</span>
              </div>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>Invoiced Quantity:</span>
                <span className={styles.dataValue}>500 units</span>
              </div>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>Unit Price:</span>
                <span className={`${styles.dataValue} ${styles.error}`}>$1,343.75</span>
              </div>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>Invoice Date:</span>
                <span className={styles.dataValue}>13 Oct 2025</span>
              </div>
              <div className={styles.dataRow}>
                <span className={styles.dataLabel}>Currency:</span>
                <span className={styles.dataValue}>INR</span>
              </div>
            </div>
          </div>
        </div>

        <div className={styles.reasoningSection}>
          <h3 className={styles.reasoningTitle}>Agent Reasoning Summary</h3>
          <div className={styles.reasoningCard}>
            <div className={styles.reasoningContent}>
              <p className={styles.reasoningText}>
                The 3-Way Match Agent has identified a significant discrepancy in this transaction requiring immediate attention:
              </p>

              <div className={styles.issueList}>
                <div className={styles.issueItem}>
                  <span className={styles.issueBullet}>●</span>
                  <div className={styles.issueContent}>
                    <strong>Price Variance:</strong> Invoice unit price ($1,343.75) exceeds PO unit price ($1,250.00) by 7.5%,
                    breaching the configured tolerance threshold of 5%. This represents an additional cost of $93.75 per unit.
                  </div>
                </div>

                <div className={styles.issueItem}>
                  <span className={styles.issueBullet}>●</span>
                  <div className={styles.issueContent}>
                    <strong>Quantity Shortage:</strong> Goods received (480 units) is 4.0% short of PO quantity (500 units),
                    yet the invoice requests payment for the full 500 units.
                  </div>
                </div>

                <div className={styles.issueItem}>
                  <span className={styles.issueBullet}>●</span>
                  <div className={styles.issueContent}>
                    <strong>Financial Impact:</strong> Combined effect results in a potential overpayment of $71,875
                    if processed without correction.
                  </div>
                </div>
              </div>

              <p className={styles.reasoningText}>
                <strong>Recommended Action:</strong> Contact vendor to issue corrected invoice reflecting actual received
                quantity (480 units) and agreed PO price ($1,250.00 per unit). Expected corrected invoice amount: $600,000.00.
              </p>
            </div>
          </div>
        </div>

        <div className={styles.actionBar}>
          <button className={styles.escalateButton}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M8 14.6667C11.6819 14.6667 14.6667 11.6819 14.6667 8C14.6667 4.3181 11.6819 1.33333 8 1.33333C4.3181 1.33333 1.33333 4.3181 1.33333 8C1.33333 11.6819 4.3181 14.6667 8 14.6667Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M8 5.33333V8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M8 10.6667H8.00667" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Escalate
          </button>
          <button className={styles.rerunButton}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M14 8C14 11.3137 11.3137 14 8 14C4.68629 14 2 11.3137 2 8C2 4.68629 4.68629 2 8 2C10.3995 2 12.4739 3.31756 13.4713 5.23077" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M14 2V5.33333H10.6667" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Re-run Check
          </button>
          <button className={styles.approveButton}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M13.3333 4L6 11.3333L2.66667 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Approve Resolution
          </button>
        </div>
      </div>
    </Layout>
  );
}
