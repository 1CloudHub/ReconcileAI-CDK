import React, { useState, useRef, useEffect } from 'react';
import TopNav from '../components/TopNav';
import SideNav from '../components/SideNav';
import ReactMarkdown from 'react-markdown';
import styles from './SAPAssistant.module.css';
import { generateMessageId, getCookie } from '../lib/utils';

interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  contextSource?: string;
}

interface Conversation {
  id: string;
  messages: Message[];
}

/**
 * Helper function to ensure proper line breaks between steps
 * Ensures double newlines after each Step announcement and before headings
 */
const normalizeStepFormatting = (text: string): string => {
  // Ensure double newlines after each Step announcement
  let normalized = text.replace(/(Step \d+ —[^\n]+?)(\n?)(?=Step \d+ —|## |$)/g, '$1\n\n');
  // Ensure double newlines before headings
  normalized = normalized.replace(/([^\n])(## )/g, '$1\n\n$2');
  return normalized;
};

/**
 * Inline error component to show timeouts
 */
const InlineErrorNotice: React.FC<{ message: string }> = ({ message }) => (
  <div
    role="alert"
    aria-live="assertive"
    className={styles.errorNotice}
  >
    {message}
  </div>
);

/**
 * Bot typing loader component with blinking cursor animation
 */
const BotTypingLoader: React.FC = () => (
  <span className={styles.typingCursor}>
    <style>{`
      @keyframes cursor-blink {
        0%, 50% { opacity: 1; }
        51%, 100% { opacity: 0; }
      }
    `}</style>
  </span>
);

/**
 * Inline streaming cursor component - appears at the end of streaming text
 */
const StreamingCursor: React.FC = () => (
  <span className={styles.typingCursor} style={{ marginLeft: '2px' }} />
);

/**
 * ERP Assistant component - Chat interface with RAG-enabled knowledge base
 * Provides SAP procurement data analysis using AI agents
 */
export default function RAGAssistant() {
  const emptyConversation: Conversation = { id: 'active-conversation', messages: [] };
  const [conversation, setConversation] = useState<Conversation>(emptyConversation);
  const [inputText, setInputText] = useState('');
  const [streamingMessage, setStreamingMessage] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [isStreaming2, setIsStreaming2] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatTranscriptRef = useRef<HTMLDivElement>(null);

  const [chatEnded, setChatEnded] = useState(false);
  const socketRef = useRef<WebSocket | null>(null);
  const sawTextDeltaRef = useRef(false);
  const currentMessageIdRef = useRef<string | null>(null);
  const messageFlushedRef = useRef(false);
  const [inputDisabled, setInputDisabled] = useState(false);
  const [timeoutNotice, setTimeoutNotice] = useState<string | null>(null);
  const lastWsMessageTimestampRef = useRef<number | null>(null);
  const lastRequestTimestampRef = useRef<number | null>(null);
  const wsGapStartRef = useRef<number | null>(null);
  const wsGapIntervalRef = useRef<number | null>(null);

  const WEBSOCKET_URL = import.meta.env.VITE_WEBSOCKET_URL;
  const SAP_CHATBOT_API_URL = import.meta.env.VITE_SAP_CHATBOT_API_URL;
  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (chatTranscriptRef.current) {
      chatTranscriptRef.current.scrollTop = chatTranscriptRef.current.scrollHeight;
    }
  }, [conversation.messages, streamingMessage]);

  /**
   * Opens a WebSocket connection and returns a promise that resolves with the connection ID
   * Connects to backend for real-time streaming of AI agent responses
   */
  const openWebsocketConnection = (): Promise<string> => {
    return new Promise((resolve, reject) => {
      // Close existing connection if any
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }

      // Connect to WebSocket endpoint for real-time streaming
      const socket = new WebSocket(WEBSOCKET_URL);
      
      let accumulatedMessage = '';
      let idleTimer: number | null = null;
      let connectionResolved = false;
      messageFlushedRef.current = false;

      const scheduleIdleFinalize = () => {
        if (idleTimer) {
          clearTimeout(idleTimer);
        }
        idleTimer = window.setTimeout(() => {
          if (sawTextDeltaRef.current) {
            setIsStreaming(false);

            if (accumulatedMessage.trim()) {
              const normalizedFinal = normalizeStepFormatting(accumulatedMessage);
              setConversation((prev) => ({
                ...prev,
                messages: [
                  ...prev.messages,
                  {
                    id: `bot-${Date.now()}`,
                    sender: 'bot',
                    text: normalizedFinal,
                    timestamp: new Date().toISOString(),
                  }
                ]
              }));
            }
            setStreamingMessage('');
            sawTextDeltaRef.current = false;
            currentMessageIdRef.current = null;
          } else {
            setIsStreaming(false);
          }
        }, 2000);
      };
      sawTextDeltaRef.current = false;
      
      socket.onopen = () => {
        socket.send(JSON.stringify({ type: "connection_init" }));
        setInputDisabled(false);
        setTimeoutNotice(null);
      };

      socket.onmessage = (e) => {
        let isControlMessage = false;
        try {
          const messageData = JSON.parse(e.data);
          
          if (
            messageData === 'api_end' ||
            messageData?.message === 'api_end' ||
            messageData?.type === 'api_end' ||
            messageData?.type === 'final_message_ff'
          ) {
            if (wsGapIntervalRef.current !== null) {
              clearInterval(wsGapIntervalRef.current);
              wsGapIntervalRef.current = null;
            }
            wsGapStartRef.current = null;
            isControlMessage = true;
            return;
          }

          if (inputDisabled || timeoutNotice) {
            setInputDisabled(false);
            setTimeoutNotice(null);
          }
          if (wsGapIntervalRef.current !== null) {
            clearInterval(wsGapIntervalRef.current);
            wsGapIntervalRef.current = null;
          }
          if (wsGapStartRef.current !== null) {
            wsGapStartRef.current = null;
          }

          const nowTs = performance.now();
          lastWsMessageTimestampRef.current = nowTs;

          if (messageData.connectionid && !connectionResolved) {
            connectionResolved = true;
            resolve(messageData.connectionid);
          }

          if (
            messageData === 'api_start' ||
            messageData?.message === 'api_start' ||
            messageData?.type === 'api_start'
          ) {
            return;
          }

          if (
            messageData === 'api_end' ||
            messageData?.message === 'api_end' ||
            messageData?.type === 'api_end'
          ) {
            return;
          }

          if (messageData.message_id && currentMessageIdRef.current && messageData.message_id !== currentMessageIdRef.current) {
            return;
          }

          if (
            messageData === 'streaming_completed' ||
            messageData?.message === 'streaming_completed' ||
            messageData?.type === 'streaming_completed'
          ) {
            if (idleTimer) {
              clearTimeout(idleTimer);
              idleTimer = null;
            }
            if (!messageFlushedRef.current) {
              if (accumulatedMessage.trim()) {
                const normalizedFinal = normalizeStepFormatting(accumulatedMessage);
                setConversation((prev) => ({
                  ...prev,
                  messages: [
                    ...prev.messages,
                    {
                      id: `bot-${Date.now()}`,
                      sender: 'bot',
                      text: normalizedFinal,
                      timestamp: new Date().toISOString(),
                    }
                  ]
                }));
              }
              messageFlushedRef.current = true;
            }
            setStreamingMessage('');
            setIsStreaming(false);
            sawTextDeltaRef.current = false;
            currentMessageIdRef.current = null;
            return;
          }

          if (typeof messageData.message === 'string') {
            const chunkText = String(messageData.message);
            if (chunkText.trim().toLowerCase() === 'connected') {
              return;
            }
            
            sawTextDeltaRef.current = true;
            if( chunkText.trim().toLowerCase() === 'message___end'){
              scheduleIdleFinalize();
              return;
            } 
            
            // Handle complete message from backend (non-streaming)
            if (chunkText.length > 100 && !messageFlushedRef.current) {
              // This appears to be a complete response, finalize it immediately
              setIsStreaming(false);
              setIsStreaming2(false);
              
              if (idleTimer) {
                clearTimeout(idleTimer);
                idleTimer = null;
              }
              
              const normalizedChunk = normalizeStepFormatting(chunkText);
              setConversation((prev) => ({
                ...prev,
                messages: [
                  ...prev.messages,
                  {
                    id: `bot-${Date.now()}`,
                    sender: 'bot',
                    text: normalizedChunk,
                    timestamp: new Date().toISOString(),
                  }
                ]
              }));
              messageFlushedRef.current = true;
              setStreamingMessage('');
              sawTextDeltaRef.current = false;
              currentMessageIdRef.current = null;
              return;
            }
            
            accumulatedMessage += chunkText;
            const normalizedMessage = normalizeStepFormatting(accumulatedMessage);
            setStreamingMessage(normalizedMessage);
            setIsStreaming(true);
            setIsStreaming2(false);
          }

          if (messageData.type === "content_block_delta" && messageData.delta?.type === "text_delta") {
            const deltaText = messageData.delta.text;
            sawTextDeltaRef.current = true;
            accumulatedMessage += deltaText;
            const normalizedMessage = normalizeStepFormatting(accumulatedMessage);
            setStreamingMessage(normalizedMessage);
            setIsStreaming(true);
            setIsStreaming2(false);
            scheduleIdleFinalize();
          }

          if (messageData.done === true || messageData.type === 'done' || messageData.type === 'complete' || messageData.type === "content_block_stop" || messageData.type === "message_stop") {
            setIsStreaming(false);
            if (idleTimer) {
              clearTimeout(idleTimer);
              idleTimer = null;
            }

            if (sawTextDeltaRef.current) {
              if (!messageFlushedRef.current) {
                if (accumulatedMessage.trim()) {
                  const normalizedFinal = normalizeStepFormatting(accumulatedMessage);
                  setConversation((prev) => ({
                    ...prev,
                    messages: [
                      ...prev.messages,
                      {
                        id: `bot-${Date.now()}`,
                        sender: 'bot',
                        text: normalizedFinal, 
                        timestamp: new Date().toISOString(),
                      }
                    ]
                  }));
                }
                messageFlushedRef.current = true;
              }
              setStreamingMessage('');
              socket.close();
              sawTextDeltaRef.current = false;
              currentMessageIdRef.current = null;
            } else {
              accumulatedMessage = '';
              setStreamingMessage('');
            }
          }
        } catch (error) {
          reject(error);
        } finally {
          if (!isControlMessage) {
            wsGapStartRef.current = performance.now();
            wsGapIntervalRef.current = window.setInterval(() => {
              if (wsGapStartRef.current !== null) {
                const elapsed = performance.now() - wsGapStartRef.current;
                if (elapsed >= 300000 && !inputDisabled) {
                  setInputDisabled(true);
                  setTimeoutNotice('Please refresh and try again after 5 minutes');
                  clearInterval(wsGapIntervalRef.current as unknown as number);
                  wsGapIntervalRef.current = null;
                }
              }
            }, 1000);
          }
        }
      };

      socket.onclose = () => {
        if (idleTimer) {
          clearTimeout(idleTimer);
          idleTimer = null;
        }
        lastWsMessageTimestampRef.current = null;
        if (wsGapIntervalRef.current !== null) {
          clearInterval(wsGapIntervalRef.current);
          wsGapIntervalRef.current = null;
        }
        wsGapStartRef.current = null;
        setIsStreaming(false);
      };

      socket.onerror = (error) => {
        if (idleTimer) {
          clearTimeout(idleTimer);
          idleTimer = null;
        }
        setIsStreaming(false);
        reject(error);
      };

      socketRef.current = socket;
      
      setTimeout(() => {
        if (!connectionResolved) {
          reject(new Error('Connection timeout'));
        }
      }, 10000);
    });
  };

  /**
   * Handles form submission for user messages
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim() === '') return;
    setIsStreaming2(true);
    
    if (inputDisabled || timeoutNotice) {
      setInputDisabled(false);
      setTimeoutNotice(null);
    }
    
    const nowReq = performance.now();
    lastRequestTimestampRef.current = nowReq;
    
    const newUserMessage: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: inputText,
      timestamp: new Date().toISOString()
    };
    
    setConversation(prev => ({
      ...prev,
      messages: [...prev.messages, newUserMessage]
    }));
    
    const currentInput = inputText;
    setInputText('');
    
    try {
      const newConnectionId = await openWebsocketConnection();
      const messageId = generateMessageId();
      currentMessageIdRef.current = messageId;

      // Get userid from cookies for API calls
      const userid = getCookie('userid');

      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      const raw = JSON.stringify({
        user_question: currentInput,
        connection_id: newConnectionId,
        message_id: messageId,
        userid: userid || null
      });

      const requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow' as const
      };

      // Fire-and-forget HTTP request to trigger backend processing
      // Note: CORS error in console is expected and harmless - the request succeeds (200 OK)
      // but browser blocks reading response headers. All actual responses come via WebSocket.
      fetch(SAP_CHATBOT_API_URL, requestOptions)
        .then(async (response) => {
          // Response may be opaque due to CORS, but request succeeded
          // We don't need the response body - WebSocket handles all communication
          try {
            await response.json().catch(() => null);
          } catch {
            // Ignore response parsing errors - expected with CORS restrictions
          }
        })
        .catch(() => {
          // Intentionally ignore HTTP errors - WebSocket handles all communication
        });

    } catch (error) {
      const errorMessage: Message = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: 'Sorry, there was a problem connecting to the ERP assistant service. Please try again.',
        timestamp: new Date().toISOString(),
      };
      
      setConversation(prev => ({
        ...prev,
        messages: [...prev.messages, errorMessage]
      }));
      
      setIsStreaming(false);
      setStreamingMessage('');
    }
  };

  const handleStartNewChat = () => {
    setChatEnded(false);
    setConversation(emptyConversation); 
    setInputText('');
    setStreamingMessage('');
    setIsStreaming(false);
    
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.close();
    }
  };

  // Clean up WebSocket on component unmount
  useEffect(() => {
    return () => {
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }
    };
  }, []);

  return (
    <div className={styles.fullScreenLayout}>
      <TopNav />
      <div className={styles.layoutContainer}>
        <SideNav />
        <main className={styles.fullScreenMain}>
          <div className={styles.chatContainer}>
            <div className={styles.chatHeader}>
              <div className={styles.chatTitleSection}>
                <div className={styles.botIcon}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/>
                    <path d="M12 6v6l4 2"/>
                  </svg>
                </div>
                <h3 className={styles.chatTitle}>ERP Assistant</h3>
              </div>
            </div>

          <div className={styles.chatBody}>
            <div
              className={styles.messagesContainer}
              ref={chatTranscriptRef}
            >
              {/* Opening message */}
              {!chatEnded && (
                <div className={styles.messageContainer}>
                  <div className={styles.botMessage}>
                    <div className={styles.botBubble}>
                      <div className={styles.messageContent}>
                        Hello! I'm your ERP assistant. I can help you analyze Purchase Orders (PO), Goods Receipt Notes (GRN), and Invoices from your SAP system. What would you like to know?
                      </div>
                      <div className={styles.messageTimestamp}>
                        <span className={styles.timestamp}>
                          {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Render conversation messages */}
              {!chatEnded && conversation.messages.map((message) => (
                <div key={message.id} className={`${styles.messageContainer} ${message.sender === 'user' ? styles.userMessage : styles.botMessage}`}>
                    <div className={message.sender === 'user' ? styles.userBubble : styles.botBubble}>
                    <div className={styles.messageContent}>
                      {message.sender === 'bot' ? (
                        <ReactMarkdown>{message.text}</ReactMarkdown>
                      ) : (
                        message.text
                      )}
                    </div>
                    <div className={styles.messageTimestamp}>
                      <span className={styles.timestamp}>
                        {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                </div>
              ))}

              {/* Streaming message */}
              {streamingMessage && isStreaming && !chatEnded && (
                <div className={styles.messageContainer}>
                  <div className={styles.botBubble}>
                    <div className={styles.messageContent}>
                      <div style={{ display: 'inline' }}>
                        <ReactMarkdown>{streamingMessage}</ReactMarkdown>
                        {!timeoutNotice && <StreamingCursor />}
                      </div>
                    </div>
                    {timeoutNotice && !chatEnded && (
                      <InlineErrorNotice message={timeoutNotice} />
                    )}
                    <div className={styles.messageTimestamp}>
                      <span className={styles.timestamp}>
                        {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {isStreaming2 && (
                <div className={styles.messageContainer}>
                  <div className={styles.botBubble}>
                    <div className={styles.messageContent}>
                      {!timeoutNotice && <BotTypingLoader />}
                    </div>
                    {timeoutNotice && !chatEnded && (
                      <InlineErrorNotice message={timeoutNotice} />
                    )}
                  </div>
                </div>
              )}

              {/* Start new chat button when chat ended */}
              {chatEnded && (
                <div className={styles.newChatContainer}>
                  <button
                    className={styles.newChatButton}
                    onClick={handleStartNewChat}
                  >
                    Start New Chat
                  </button>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className={styles.inputContainer}>
              {!chatEnded ? (
                <form onSubmit={handleSubmit} className={styles.inputForm}>
                  <div className={styles.inputWrapper}>
                    <input
                      type="text"
                      placeholder="Type your message here..."
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      disabled={isStreaming || inputDisabled}
                      className={styles.textInput}
                    />
                    <button 
                      type="submit" 
                      disabled={inputDisabled || isStreaming || !inputText.trim()}
                      className={styles.sendButton}
                    >
                      <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <line x1="22" y1="2" x2="11" y2="13"/>
                        <polygon points="22,2 15,22 11,13 2,9 22,2"/>
                      </svg>
                    </button>
                  </div>
                </form>
              ) : (
                <button 
                  className={styles.newChatButton}
                  onClick={() => window.location.reload()}
                >
                  Start a New Chat
                </button>
              )}
            </div>
          </div>
        </div>
      </main>
      </div>
    </div>
  );
}


