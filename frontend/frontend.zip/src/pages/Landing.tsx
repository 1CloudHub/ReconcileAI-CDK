import { useNavigate } from 'react-router-dom';
import { useScrollAnimation, useStaggeredAnimation } from '../hooks/useScrollAnimation';
import CountUp from 'react-countup';
import styles from './Landing.module.css';

/**
 * Landing page component showcasing ReconcileAI platform
 * Features the complete storyline and value proposition
 */
export default function Landing() {
  const navigate = useNavigate();

  // Scroll animations for different sections
  const heroAnimation = useScrollAnimation({ threshold: 0.2 });
  const problemSolutionAnimation = useScrollAnimation({ threshold: 0.1 });
  const shiftAnimation = useScrollAnimation({ threshold: 0.1 });
  const agentsAnimation = useStaggeredAnimation(3, 200, { threshold: 0.1 });
  const workflowAnimation = useScrollAnimation({ threshold: 0.1 });
  const outcomesAnimation = useStaggeredAnimation(3, 150, { threshold: 0.1 });
  const featuresAnimation = useStaggeredAnimation(6, 100, { threshold: 0.1 });
  const ctaAnimation = useScrollAnimation({ threshold: 0.1 });

  // Number counting animations (excluding 1-3% range)
  // Using react-countup library for smooth animations

  /**
   * Navigate to login page
   */
  const handleLoginClick = () => {
    navigate('/login');
  };

  return (
    <div className={styles.landingContainer}>
      {/* Hero Section */}
      
      <section className={styles.heroSection}>
        {/* Logo in Hero Section */}
        <div className={styles.heroLogo}>
          <img 
            src="/assets/new1ch.png" 
            alt="1CloudHub" 
            className={styles.heroLogoImage}
          />
        </div>
        
        <div 
          ref={heroAnimation.elementRef}
          className={`${styles.heroContent} ${styles.fadeInUp} ${heroAnimation.isVisible ? styles.visible : ''}`}
        >
          <h1 className={styles.heroTitle}>ERP Exception Management AI Platform</h1>
          <p className={styles.heroSubtitle}>
            AI-powered platform that turns ERP exceptions into instant, actionable insights.
          </p>
          <button 
            className={styles.loginButton}
            onClick={handleLoginClick}
          >
            See It in Action
          </button>
        </div>
      </section>

      {/* Market Reality Section */}
      <section className={styles.section}>
        <div className={styles.container}>
          <h2 
            ref={problemSolutionAnimation.elementRef}
            className={`${styles.sectionTitle} ${styles.fadeInUp} ${problemSolutionAnimation.isVisible ? styles.visible : ''}`}
          >
            The Market Reality – Why Now
          </h2>
          <div className={styles.marketRealityGrid}>
            <div 
              className={`${styles.marketCard} ${styles.fadeInLeft} ${problemSolutionAnimation.isVisible ? styles.visible : ''} ${styles['delay-200']}`}
            >
              <div className={styles.marketNumber}>
                <CountUp 
                  end={74} 
                  duration={2.5} 
                  suffix="%" 
                  start={problemSolutionAnimation.isVisible ? 0 : 74}
                />
              </div>
              <div className={styles.marketText}>of finance leaders say ERP exceptions are the #1 blocker to working capital optimization</div>
              </div>
            <div 
              className={`${styles.marketCard} ${styles.fadeInUp} ${problemSolutionAnimation.isVisible ? styles.visible : ''} ${styles['delay-300']}`}
            >
              <div className={styles.marketNumber}>1-3%</div>
              <div className={styles.marketText}>of annual spend lost due to invoice/PO mismatches, duplicate payments, and delayed receipts</div>
            </div>
            <div 
              className={`${styles.marketCard} ${styles.fadeInRight} ${problemSolutionAnimation.isVisible ? styles.visible : ''} ${styles['delay-400']}`}
            >
              <div className={styles.marketNumber}>
                <CountUp 
                  end={230} 
                  duration={2.5} 
                  start={problemSolutionAnimation.isVisible ? 0 : 230}
                />
              </div>
              <div className={styles.marketText}>out of every 1,000 invoices require manual review</div>
            </div>
          </div>
          <div 
            className={`${styles.marketConclusion} ${styles.fadeInUp} ${problemSolutionAnimation.isVisible ? styles.visible : ''} ${styles['delay-500']}`}
          >
            <p>Today, ERP systems only record data. They do not understand process logic or proactively intervene. ReconcileAI changes this.</p>
          </div>
        </div>
      </section>

      {/* The Shift Section */}
      <section className={styles.section}>
        <div className={styles.container}>
          <h2 
            ref={shiftAnimation.elementRef}
            className={`${styles.sectionTitle} ${styles.fadeInUp} ${shiftAnimation.isVisible ? styles.visible : ''}`}
          >
            The Shift – The Rise of Autonomous Finance
          </h2>
          <div className={styles.shiftContent}>
            <div 
              className={`${styles.shiftCard} ${styles.fadeInLeft} ${shiftAnimation.isVisible ? styles.visible : ''} ${styles['delay-200']}`}
            >
              <div className={styles.shiftNumber}>
                <CountUp 
                  end={15} 
                  duration={2.5} 
                  suffix="%" 
                  start={shiftAnimation.isVisible ? 0 : 15}
                />
              </div>
              <div className={styles.shiftText}>of all financial decisions will be made autonomously by AI agents by 2028</div>
            </div>
            <div 
              className={`${styles.shiftDescription} ${styles.fadeInRight} ${shiftAnimation.isVisible ? styles.visible : ''} ${styles['delay-400']}`}
            >
              <p>Leading CFOs are not just automating workflows — they are moving toward intelligent, self-healing finance operations.</p>
              <p>Agentic AI is the next frontier, where systems not only detect but explain and resolve exceptions.</p>
              <p><strong>ReconcileAI is built exactly for this shift — the AI layer on top of SAP that works like a digital finance analyst.</strong></p>
            </div>
          </div>
        </div>
      </section>

      {/* What is ReconcileAI Section */}
      <section className={styles.section}>
        <div className={styles.container}>
          <h2 
            ref={agentsAnimation.containerRef}
            className={`${styles.sectionTitle} ${styles.fadeInUp} ${agentsAnimation.isContainerVisible ? styles.visible : ''}`}
          >
            What is ReconcileAI?
          </h2>
          <div 
            className={`${styles.reconcileCard} ${styles.fadeInScale} ${agentsAnimation.isContainerVisible ? styles.visible : ''} ${styles['delay-200']}`}
          >
            <div className={styles.reconcileDescription}>
              <p>ReconcileAI is a modular Agentic AI platform that autonomously detects, explains, and resolves finance exceptions inside SAP — while providing real-time conversational access to SAP data in natural language.</p>
            </div>
            <div className={styles.reconcileStatement}>
              <div 
                className={`${styles.statementItem} ${styles.fadeInLeft} ${agentsAnimation.isContainerVisible ? styles.visible : ''} ${styles['delay-300']}`}
              >
                <div className={styles.starIcon}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2L15.09 8.26L22 9L17 14L18.18 21L12 17.77L5.82 21L7 14L2 9L8.91 8.26L12 2Z" fill="#3B82F6"/>
                </svg>
                </div>
                <span>Not RPA.</span>
              </div>
              <div 
                className={`${styles.statementItem} ${styles.fadeInUp} ${agentsAnimation.isContainerVisible ? styles.visible : ''} ${styles['delay-400']}`}
              >
                <div className={styles.starIcon}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2L15.09 8.26L22 9L17 14L18.18 21L12 17.77L5.82 21L7 14L2 9L8.91 8.26L12 2Z" fill="#3B82F6"/>
                  </svg>
            </div>
                <span>Not OCR.</span>
              </div>
              <div 
                className={`${styles.statementItem} ${styles.fadeInRight} ${agentsAnimation.isContainerVisible ? styles.visible : ''} ${styles['delay-500']}`}
              >
                <div className={styles.starIcon}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2L15.09 8.26L22 9L17 14L18.18 21L12 17.77L5.82 21L7 14L2 9L8.91 8.26L12 2Z" fill="#3B82F6"/>
                  </svg>
            </div>
                <span>This is autonomous financial intelligence.</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className={styles.section}>
        <div className={styles.container}>
          <h2 
            ref={workflowAnimation.elementRef}
            className={`${styles.sectionTitle} ${styles.fadeInUp} ${workflowAnimation.isVisible ? styles.visible : ''}`}
          >
            How It Works
          </h2>
          <div 
            className={`${styles.workflowCard} ${styles.fadeInScale} ${workflowAnimation.isVisible ? styles.visible : ''} ${styles['delay-200']}`}
          >
            <h3 className={styles.workflowTitle}>Smart Daily Automation Process</h3>
            <div className={styles.workflowSteps}>
              <div className={`${styles.workflowStep} ${styles.fadeInLeft} ${workflowAnimation.isVisible ? styles.visible : ''} ${styles['delay-300']}`}>
                <div className={styles.stepNumber}>1</div>
                <div className={styles.stepText}>Data ingestion: Reads ERP data automatically overnight</div>
              </div>
              <div className={`${styles.workflowStep} ${styles.fadeInRight} ${workflowAnimation.isVisible ? styles.visible : ''} ${styles['delay-400']}`}>
                <div className={styles.stepNumber}>2</div>
                <div className={styles.stepText}>Autonomous checks: Specialized agents run validations (3-Way Match, Missing Docs, Duplicates)</div>
              </div>
              <div className={`${styles.workflowStep} ${styles.fadeInLeft} ${workflowAnimation.isVisible ? styles.visible : ''} ${styles['delay-500']}`}>
                <div className={styles.stepNumber}>3</div>
                <div className={styles.stepText}>Clear explanations: Each finding includes a plain-language reason</div>
              </div>
              <div className={`${styles.workflowStep} ${styles.fadeInRight} ${workflowAnimation.isVisible ? styles.visible : ''} ${styles['delay-600']}`}>
                <div className={styles.stepNumber}>4</div>
                <div className={styles.stepText}>Dashboard update: Finance teams start their day with ready insights</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Measurable Outcomes Section */}
      <section className={styles.section}>
        <div className={styles.container}>
          <h2 
            ref={outcomesAnimation.containerRef}
            className={`${styles.sectionTitle} ${styles.fadeInUp} ${outcomesAnimation.isContainerVisible ? styles.visible : ''}`}
          >
            Measurable Outcomes
          </h2>
          <div className={styles.outcomesGrid}>
            <div 
              ref={(el) => { outcomesAnimation.elementRefs.current[0] = el; }}
              className={`${styles.outcomeCard} ${styles.fadeInScale} ${outcomesAnimation.visibleItems[0] ? styles.visible : ''}`}
            >
              <div className={styles.outcomeNumber}>
                <CountUp 
                  end={80} 
                  duration={2.5} 
                  suffix="%" 
                  start={outcomesAnimation.visibleItems[0] ? 0 : 80}
                />
              </div>
              <div className={styles.outcomeText}>Faster exception identification</div>
            </div>
            <div 
              ref={(el) => { outcomesAnimation.elementRefs.current[1] = el; }}
              className={`${styles.outcomeCard} ${styles.fadeInScale} ${outcomesAnimation.visibleItems[1] ? styles.visible : ''}`}
            >
              <div className={styles.outcomeNumber}>
                <CountUp 
                  end={70} 
                  duration={2.5} 
                  suffix="%" 
                  start={outcomesAnimation.visibleItems[1] ? 0 : 70}
                />
              </div>
              <div className={styles.outcomeText}>Reduction in manual effort</div>
            </div>
            <div 
              ref={(el) => { outcomesAnimation.elementRefs.current[2] = el; }}
              className={`${styles.outcomeCard} ${styles.fadeInScale} ${outcomesAnimation.visibleItems[2] ? styles.visible : ''}`}
            >
              <div className={styles.outcomeNumber}>✓</div>
              <div className={styles.outcomeText}>Improved accuracy, governance, and audit compliance</div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Features Section */}
      <section className={styles.section}>
        <div className={styles.container}>
          <h2 
            ref={featuresAnimation.containerRef}
            className={`${styles.sectionTitle} ${styles.fadeInUp} ${featuresAnimation.isContainerVisible ? styles.visible : ''}`}
          >
            Key Features
          </h2>
          <div className={styles.featuresGrid}>
            <div 
              ref={(el) => { featuresAnimation.elementRefs.current[0] = el; }}
              className={`${styles.featureCard} ${styles.fadeInScale} ${featuresAnimation.visibleItems[0] ? styles.visible : ''}`}
            >
              <div className={styles.featureIcon}>
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#3B82F6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M2 17L12 22L22 17" stroke="#3B82F6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M2 12L12 17L22 12" stroke="#3B82F6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <div className={styles.featureText}>Fully automated exception detection</div>
            </div>
            <div 
              ref={(el) => { featuresAnimation.elementRefs.current[1] = el; }}
              className={`${styles.featureCard} ${styles.fadeInScale} ${featuresAnimation.visibleItems[1] ? styles.visible : ''}`}
            >
              <div className={styles.featureIcon}>
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M14 2H6C4.9 2 4 2.9 4 4V20C4 21.1 4.89 22 6 22H18C19.1 22 20 21.1 20 20V8L14 2Z" stroke="#10B981" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M14 2V8H20" stroke="#10B981" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M16 13H8" stroke="#10B981" strokeWidth="2" strokeLinecap="round"/>
                  <path d="M16 17H8" stroke="#10B981" strokeWidth="2" strokeLinecap="round"/>
                </svg>
              </div>
              <div className={styles.featureText}>Simple, human-readable insights</div>
            </div>
            <div 
              ref={(el) => { featuresAnimation.elementRefs.current[2] = el; }}
              className={`${styles.featureCard} ${styles.fadeInScale} ${featuresAnimation.visibleItems[2] ? styles.visible : ''}`}
            >
              <div className={styles.featureIcon}>
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M3 3V21H21V3H3ZM19 19H5V5H19V19Z" fill="#8B5CF6"/>
                  <path d="M7 7H17V9H7V7ZM7 11H17V13H7V11ZM7 15H13V17H7V15Z" fill="#8B5CF6"/>
                </svg>
              </div>
              <div className={styles.featureText}>Centralized dashboard for all exception types</div>
            </div>
            <div 
              ref={(el) => { featuresAnimation.elementRefs.current[3] = el; }}
              className={`${styles.featureCard} ${styles.fadeInScale} ${featuresAnimation.visibleItems[3] ? styles.visible : ''}`}
            >
              <div className={styles.featureIcon}>
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9.5 2C8.1 2 7 3.1 7 4.5S8.1 7 9.5 7 12 5.9 12 4.5 10.9 2 9.5 2Z" fill="#F59E0B"/>
                  <path d="M14.5 2C13.1 2 12 3.1 12 4.5S13.1 7 14.5 7 17 5.9 17 4.5 15.9 2 14.5 2Z" fill="#F59E0B"/>
                  <path d="M9.5 8.5C8.1 8.5 7 9.6 7 11S8.1 13.5 9.5 13.5 12 12.4 12 11 10.9 8.5 9.5 8.5Z" fill="#F59E0B"/>
                  <path d="M14.5 8.5C13.1 8.5 12 9.6 12 11S13.1 13.5 14.5 13.5 17 12.4 17 11 15.9 8.5 14.5 8.5Z" fill="#F59E0B"/>
                  <path d="M12 15L14.5 17.5L12 20L9.5 17.5L12 15Z" fill="#F59E0B"/>
                </svg>
              </div>
              <div className={styles.featureText}>Continuous learning from feedback</div>
            </div>
            <div 
              ref={(el) => { featuresAnimation.elementRefs.current[4] = el; }}
              className={`${styles.featureCard} ${styles.fadeInScale} ${featuresAnimation.visibleItems[4] ? styles.visible : ''}`}
            >
              <div className={styles.featureIcon}>
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M21 16V8C21 6.9 20.1 6 19 6H5C3.9 6 3 6.9 3 8V16C3 17.1 3.9 18 5 18H19C20.1 18 21 17.1 21 16Z" stroke="#EF4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M7 10H17" stroke="#EF4444" strokeWidth="2" strokeLinecap="round"/>
                  <path d="M7 14H13" stroke="#EF4444" strokeWidth="2" strokeLinecap="round"/>
                </svg>
              </div>
              <div className={styles.featureText}>Audit-ready traceability</div>
            </div>
            <div 
              ref={(el) => { featuresAnimation.elementRefs.current[5] = el; }}
              className={`${styles.featureCard} ${styles.fadeInScale} ${featuresAnimation.visibleItems[5] ? styles.visible : ''}`}
            >
              <div className={styles.featureIcon}>
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M3 3V21H21V3H3ZM19 19H5V5H19V19Z" fill="#06B6D4"/>
                  <path d="M7 7H17V9H7V7ZM7 11H17V13H7V11ZM7 15H13V17H7V15Z" fill="#06B6D4"/>
                  <path d="M19 7L21 9L19 11" stroke="#06B6D4" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <div className={styles.featureText}>Scalable to add new finance agents</div>
            </div>
          </div>
        </div>
      </section>

      {/* Closing CTA Section */}
      <section className={styles.section}>
        <div className={styles.container}>
          <div 
            ref={ctaAnimation.elementRef}
            className={`${styles.ctaCard} ${styles.fadeInScale} ${ctaAnimation.isVisible ? styles.visible : ''}`}
          >
            <h2 className={styles.ctaTitle}>Start every day with clarity, not chaos.</h2>
            <div className={styles.ctaButtons}>
              <button 
                className={styles.ctaButton}
                onClick={handleLoginClick}
              >
                See It in Action
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer Section */}
      <footer className={styles.footer}>
        <div className={styles.footerContainer}>
          {/* Logo Section */}
          <div className={styles.footerLogo}>
            <img 
              src="/assets/new1ch.png" 
              alt="1CloudHub" 
              className={styles.footerLogoImage}
            />
          </div>
          
          {/* Tagline Section */}
          <p className={styles.footerTagline}>
            Your trusted partner for AWS migration and modernization.
          </p>
          
          {/* Icons Section */}
          <div className={styles.footerLinks}>
            <a 
              href="https://www.1cloudhub.com/" 
              target="_blank" 
              rel="noopener noreferrer"
              className={styles.footerLink}
              title="Website"
            >
              <div className={styles.footerIcon}>🌐</div>
            </a>
            <a 
              href="https://www.linkedin.com/company/1clouldhub/posts/?feedView=all" 
              target="_blank" 
              rel="noopener noreferrer"
              className={styles.footerLink}
              title="LinkedIn"
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="24" 
                height="24" 
                viewBox="0 0 256 256"
                className={styles.footerIcon}
              >
                <path 
                  fill="currentColor" 
                  d="M218.123 218.127h-37.931v-59.403c0-14.165-.253-32.4-19.728-32.4c-19.756 0-22.779 15.434-22.779 31.369v60.43h-37.93V95.967h36.413v16.694h.51a39.91 39.91 0 0 1 35.928-19.733c38.445 0 45.533 25.288 45.533 58.186zM56.955 79.27c-12.157.002-22.014-9.852-22.016-22.009s9.851-22.014 22.008-22.016c12.157-.003 22.014 9.851 22.016 22.008A22.013 22.013 0 0 1 56.955 79.27m18.966 138.858H37.95V95.967h37.97zM237.033.018H18.89C8.58-.098.125 8.161-.001 18.471v219.053c.122 10.315 8.576 18.582 18.89 18.474h218.144c10.336.128 18.823-8.139 18.966-18.474V18.454c-.147-10.33-8.635-18.588-18.966-18.453"
                />
              </svg>
            </a>
          </div>
          
          {/* Copyright Section */}
          <div className={styles.footerBottom}>
            <p className={styles.footerCopyright}>
              © 2025 1CloudHub. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
