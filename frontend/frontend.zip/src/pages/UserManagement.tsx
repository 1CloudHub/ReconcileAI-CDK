import { useState, useEffect } from 'react';
import { Table, Skeleton } from 'antd';
import Layout from '../components/Layout';
import AddUserModal from '../components/AddUserModal';
import DeleteConfirmationModal from '../components/DeleteConfirmationModal';
import { getCookie } from '../lib/utils';
import styles from './UserManagement.module.css';

interface UserData {
  userid: number;
  email: string;
  createdAt: string;
  updatedAt: string;
  isActive: boolean;
}

export default function UserManagement() {
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<UserData[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loadingTable, setLoadingTable] = useState(false);
  const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; email: string; userid: number }>({
    isOpen: false,
    email: '',
    userid: 0
  });
  const [isDeleting, setIsDeleting] = useState(false);
  const [isTogglingStatus, setIsTogglingStatus] = useState(false);
  const pageSize = 10;

  const API_URL = import.meta.env.VITE_API_URL;
  const userid = getCookie('userid');

  // Fetch users from API
  const fetchUsers = async (page: number = 1) => {
    if (!API_URL || !userid) return;

    try {
      setLoadingTable(true);
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event_type: 'list_users',
          page: page,
          page_size: pageSize,
          userid: userid
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setUsers(data.users || []);
        setTotalCount(data.pagination?.total_count || 0);
      } else {
        console.error('Failed to fetch users');
      }
    } catch (err) {
      console.error('Error fetching users:', err);
    } finally {
      setLoadingTable(false);
      setLoading(false);
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchUsers(1);
  }, [API_URL, userid]);

  // Handle page change
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    fetchUsers(page);
  };

  // Handle user status toggle
  const handleToggleStatus = async (email: string, currentStatus: boolean) => {
    if (!API_URL || !userid) return;

    try {
      setIsTogglingStatus(true);
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event_type: 'toggle_user_status',
          email: email,
          is_active: !currentStatus,
          userid: userid
        }),
      });

      if (response.ok) {
        // Update local state to preserve order instead of refetching
        setUsers(prevUsers => 
          prevUsers.map(user => 
            user.email === email 
              ? { ...user, isActive: !currentStatus }
              : user
          )
        );
      } else {
        const data = await response.json();
        alert(data.error || 'Failed to update user status');
      }
    } catch (err) {
      console.error('Error toggling user status:', err);
      alert('Network error. Please try again.');
    } finally {
      setIsTogglingStatus(false);
    }
  };

  /**
   * Open delete confirmation modal
   */
  const handleOpenDeleteModal = (email: string, userIdToDelete: number) => {
    // Prevent deletion of admin user
    if (userIdToDelete === 1) {
      alert('Cannot delete the admin user');
      return;
    }
    
    setDeleteModal({ isOpen: true, email, userid: userIdToDelete });
  };

  /**
   * Close delete confirmation modal
   */
  const handleCloseDeleteModal = () => {
    if (!isDeleting) {
      setDeleteModal({ isOpen: false, email: '', userid: 0 });
    }
  };

  /**
   * Handle user deletion after confirmation
   * Sends delete_user event to backend API
   * Only admin users (userid=1) can delete users
   */
  const handleConfirmDelete = async () => {
    if (!API_URL || !userid) return;

    const { email } = deleteModal;

    try {
      setIsDeleting(true);
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event_type: 'delete_user',
          email: email,
          userid: userid
        }),
      });

      const data = await response.json();

      if (response.ok) {
        // Remove user from local state
        setUsers(prevUsers => prevUsers.filter(user => user.email !== email));
        setTotalCount(prevCount => prevCount - 1);
        
        // Close modal and show success message
        setDeleteModal({ isOpen: false, email: '', userid: 0 });
        
        alert(
          `User deleted successfully!\n\nDeleted records:\n- Sessions: ${data.deleted_records?.sessions || 0}\n- Exceptions: ${data.deleted_records?.exceptions || 0}\n- Chat messages: ${data.deleted_records?.chat_messages || 0}`
        );
      } else {
        alert(data.error || 'Failed to delete user');
      }
    } catch (err) {
      console.error('Error deleting user:', err);
      alert('Network error. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  // Handle successful user creation
  const handleUserCreated = () => {
    // Refresh the first page to show the new user
    setCurrentPage(1);
    fetchUsers(1);
  };

  const columns = [
    {
      title: 'Date',
      dataIndex: 'createdAt',
      key: 'createdAt',
      render: (text: string) => {
        if (!text) return 'N/A';
        const date = new Date(text);
        return date.toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        });
      },
    },
    {
      title: 'Email',
      dataIndex: 'email',
      key: 'email',
      render: (text: string) => <span className={styles.email}>{text}</span>,
    },
    {
      title: 'Active Status',
      dataIndex: 'isActive',
      key: 'isActive',
      render: (isActive: boolean) => (
        <span className={`${styles.statusBadge} ${isActive ? styles.active : styles.inactive}`}>
          {isActive ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      title: 'Access',
      key: 'access',
      render: (_: any, record: UserData) => (
        <label className={styles.toggleSwitch}>
          <input
            type="checkbox"
            checked={record.isActive}
            onChange={() => handleToggleStatus(record.email, record.isActive)}
            className={styles.toggleInput}
          />
          <span className={styles.toggleSlider}></span>
        </label>
      ),
    },
    {
      title: 'Action',
      key: 'action',
      render: (_: any, record: UserData) => (
        <>
          {/* Delete button - only show for non-admin users */}
          {record.userid !== 1 && (
            <button
              className={styles.deleteButton}
              onClick={() => handleOpenDeleteModal(record.email, record.userid)}
              title="Delete user permanently"
              aria-label="Delete user"
            >
              <svg width="18" height="18" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M2 4h12M5.5 4V2.5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1V4m2 0v9.5a1 1 0 0 1-1 1h-7a1 1 0 0 1-1-1V4h9z"/>
                <path d="M6.5 7v4M9.5 7v4"/>
              </svg>
            </button>
          )}
        </>
      ),
    },
  ];

  return (
    <Layout>
      {/* Full-page loader overlay when toggling user status */}
      {isTogglingStatus && (
        <div className={styles.loaderOverlay}>
          <div className={styles.loaderContent}>
            <div className={styles.spinner}></div>
            <p className={styles.loaderText}>Updating user access...</p>
          </div>
        </div>
      )}
      {loading ? (
        <div className={styles.userManagement}>
          <div className={styles.header}>
            <Skeleton.Input active style={{ width: 250, height: 32, marginBottom: 8 }} />
            <Skeleton.Input active style={{ width: 350, height: 16 }} />
          </div>
          <div className={styles.tableContainer}>
            <Skeleton active paragraph={{ rows: 10 }} />
          </div>
        </div>
      ) : (
        <div className={styles.userManagement}>
          <div className={styles.header}>
            <div className={styles.headerInfo}>
              <h2 className={styles.title}>User Management</h2>
              <p className={styles.subtitle}>Manage user accounts and access permissions</p>
            </div>
            <button
              className={styles.addButton}
              onClick={() => setIsModalOpen(true)}
            >
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="8" y1="3" x2="8" y2="13"></line>
                <line x1="3" y1="8" x2="13" y2="8"></line>
              </svg>
              Add User
            </button>
          </div>

          <div className={styles.tableContainer}>
            <div className={styles.tablePanel}>
              <div className={styles.tableHeader}>
                <h3 className={styles.tableTitle}>User List</h3>
              </div>

              <Table
                dataSource={users}
                rowKey="userid"
                pagination={{
                  current: currentPage,
                  pageSize: pageSize,
                  total: totalCount,
                  onChange: handlePageChange,
                  showSizeChanger: false,
                  position: ['bottomRight'],
                }}
                loading={loadingTable}
                className={styles.antTable}
                columns={columns}
              />
            </div>
          </div>

          <AddUserModal
            isOpen={isModalOpen}
            onClose={() => setIsModalOpen(false)}
            onSuccess={handleUserCreated}
            apiUrl={API_URL || ''}
            userid={userid}
          />

          <DeleteConfirmationModal
            isOpen={deleteModal.isOpen}
            onClose={handleCloseDeleteModal}
            onConfirm={handleConfirmDelete}
            email={deleteModal.email}
            isDeleting={isDeleting}
          />
        </div>
      )}
    </Layout>
  );
}


