import { useState, useEffect, useRef } from 'react';
import { Tooltip, Skeleton, Table } from 'antd';
import Layout from '../components/Layout';
import SOPDetailsModal from '../components/SOPDetailsModal';
import { getCookie } from '../lib/utils';
import styles from './SOP_Control_Center.module.css';

interface AgentData {
  exceptionId: string;
  exceptionName: string;
  sopId: string;
  lastRun: string;
  records: number;
  triggerEmail?: string | string[];  // Can be string or array
}

export default function SOP_Control_Center() {
  const [sopData, setSopData] = useState<AgentData[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingTable, setLoadingTable] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedSOP, setSelectedSOP] = useState<AgentData | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [emailValues, setEmailValues] = useState<string[]>([]);  // Array of emails
  const [updatingEmail, setUpdatingEmail] = useState<string | null>(null);
  const [emailModalOpen, setEmailModalOpen] = useState(false);
  const [emailModalData, setEmailModalData] = useState<string[]>([]);
  const [emailModalEditMode, setEmailModalEditMode] = useState(false);
  const [emailModalExceptionId, setEmailModalExceptionId] = useState<string>('');
  const [emailErrors, setEmailErrors] = useState<string[]>([]);
  const pageSize = 10;

  const API_URL = import.meta.env.VITE_API_URL;
  const initialFetchRef = useRef(false);
  const pageDataFetchedRef = useRef<string | null>(null);
  const fetchInProgressRef = useRef<Record<string, boolean>>({});

  // Fetch initial data once on mount
  useEffect(() => {
    const fetchInitialData = async () => {
      if (!API_URL || initialFetchRef.current) return;
      initialFetchRef.current = true;

      // Use the same fetch guards as the paginated effect to avoid duplicate
      // requests for page 1: mark the fetch as in-progress so the other effect
      // will early-return while we are fetching.
      const fetchKey = `1`;
      if (fetchInProgressRef.current[fetchKey]) return;
      fetchInProgressRef.current[fetchKey] = true;

      try {
        // Get userid from cookies for API calls
        const userid = getCookie('userid');
        
        const response = await fetch(API_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ 
            event_type: 'sop_agents_new_schema',
            page: 1,
            page_size: pageSize,
            userid: userid || null
          }),
        });

        if (response.ok) {
          const result = await response.json();
          setSopData(result.agent_summary || []);
          setTotalCount(result.pagination?.total_count || 0);
          // Mark page 1 as fetched so the paginated effect won't refetch it.
          pageDataFetchedRef.current = fetchKey;
        }

        setLoading(false);
      } catch (err) {
        console.error('Error fetching agent data:', err);
        setLoading(false);
      } finally {
        // Clear in-progress flag so future requests can run
        fetchInProgressRef.current[fetchKey] = false;
      }
    };

    fetchInitialData();
  }, [API_URL]);

  // Fetch paginated data whenever page changes
  useEffect(() => {
    const fetchPageData = async () => {
      if (!API_URL) return;

      // Build a deterministic key for this exact fetch (page)
      const fetchKey = `${currentPage}`;

      // If we've already successfully fetched this key, skip
      if (pageDataFetchedRef.current === fetchKey) return;

      // Use an in-progress guard to prevent concurrent duplicate requests
      if (fetchInProgressRef.current[fetchKey]) return;
      fetchInProgressRef.current[fetchKey] = true;

      try {
        setLoadingTable(true);
        // Get userid from cookies for API calls
        const userid = getCookie('userid');
        
        const response = await fetch(API_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ 
            event_type: 'sop_agents_new_schema',
            page: currentPage,
            page_size: pageSize,
            userid: userid || null
          }),
        });

        if (response.ok) {
          const result = await response.json();
          setSopData(result.agent_summary || []);
          setTotalCount(result.pagination?.total_count || 0);

          // Mark this key as fetched successfully
          pageDataFetchedRef.current = fetchKey;
        }
      } catch (err) {
        console.error('Error fetching page data:', err);
      } finally {
        // clear in-progress flag so future requests can run
        fetchInProgressRef.current[fetchKey] = false;
        setLoadingTable(false);
      }
    };

    fetchPageData();
  }, [API_URL, currentPage]);

  const handleViewDetails = (sop: AgentData) => {
    setSelectedSOP(sop);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedSOP(null);
  };

  const handleEmailEdit = (exceptionId: string, currentEmails: string | string[]) => {
    // Convert to array if it's a string or empty
    const emailArray = Array.isArray(currentEmails) 
      ? currentEmails 
      : currentEmails 
        ? [currentEmails] 
        : [''];
    setEmailValues(emailArray.length > 0 ? emailArray : ['']);
    setEmailModalData(emailArray.length > 0 ? emailArray : ['']);
    setEmailModalExceptionId(exceptionId);
    setEmailModalEditMode(true);
    setEmailModalOpen(true);
    setEmailErrors((emailArray.length > 0 ? emailArray : ['']).map(() => ''));
  };

  const handleAddEmail = () => {
    setEmailValues([...emailValues, '']);
    setEmailErrors(prev => [...prev, '']);
  };

  const handleRemoveEmail = (index: number) => {
    if (emailValues.length === 1) return; // Keep at least one input
    setEmailValues(emailValues.filter((_, i) => i !== index));
    setEmailErrors(prev => prev.filter((_, i) => i !== index));
  };

  const handleEmailChange = (index: number, value: string) => {
    const newEmails = [...emailValues];
    newEmails[index] = value;
    setEmailValues(newEmails);
    // validate format and duplicates
    const trimmed = value.trim();
    const errors = [...emailErrors];
    // basic email regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (trimmed === '') {
      errors[index] = 'Email cannot be empty';
    } else if (!emailRegex.test(trimmed)) {
      errors[index] = 'Invalid email format';
    } else {
      // check duplicates (explicit loop to avoid lint issues)
      const duplicates: string[] = [];
      for (let i = 0; i < newEmails.length; i++) {
        if (i === index) continue;
        duplicates.push((newEmails[i] || '').trim().toLowerCase());
      }
      if (duplicates.includes(trimmed.toLowerCase())) {
        errors[index] = 'Duplicate email';
      } else {
        errors[index] = '';
      }
    }
    setEmailErrors(errors);
  };

  const handleEmailSave = async (exceptionId: string) => {
    if (!API_URL) return;
    
    const trimmedEmails = emailValues.map(e => e.trim());
    // run final validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const errors = trimmedEmails.map((e, idx) => {
      if (!e) return 'Email cannot be empty';
      if (!emailRegex.test(e)) return 'Invalid email format';
      // duplicate check
      const others = trimmedEmails.filter((_, i) => i !== idx).map(x => x.toLowerCase());
      if (others.includes(e.toLowerCase())) return 'Duplicate email';
      return '';
    });
    setEmailErrors(errors);

    const validEmails = trimmedEmails.filter((_, idx) => errors[idx] === '');

    if (validEmails.length === 0) {
      alert('Please add at least one valid email address');
      return;
    }
    
    setUpdatingEmail(exceptionId);
    
    try {
      // Get userid from cookies for API calls
      const userid = getCookie('userid');
      
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          event_type: 'update_sop_trigger_emails',
          exception_id: exceptionId,
          trigger_emails: validEmails,
          userid: userid || null
        }),
      });

      if (response.ok) {
        const result = await response.json();
        console.log('Emails updated:', result);
        
        // Update local state to reflect the change
        setSopData(prevData => 
          prevData.map(item => 
            item.exceptionId === exceptionId 
              ? { ...item, triggerEmail: validEmails }
              : item
          )
        );
        
        // Close modal and reset states
        setEmailModalOpen(false);
        setEmailModalEditMode(false);
        setEmailModalData([]);
        setEmailModalExceptionId('');
        setEmailValues([]);
        setEmailErrors([]);
      } else {
        console.error('Failed to update emails');
        alert('Failed to update emails. Please try again.');
      }
    } catch (err) {
      console.error('Error updating emails:', err);
      alert('Error updating emails. Please try again.');
    } finally {
      setUpdatingEmail(null);
    }
  };

  const handleEmailCancel = () => {
    setEmailModalOpen(false);
    setEmailModalEditMode(false);
    setEmailModalData([]);
    setEmailModalExceptionId('');
    setEmailValues([]);
  };

  // Map exception type names to their corresponding PDF filenames
  const exceptionTypeToPDF: Record<string, string> = {
    'Quantity Variance': 'SOP_QUANTITY_CHANGE_V1',
    'Price Mismatch': 'SOP_PRICE_CHANGE_V1',
    'Invoice Errors': 'SOP_DUPLICATE_INVOICE_V1',
    'Missing GR': 'SOP_MISSING_GRN_V1',
    'UoM Issues': 'SOP_UOM_ISSUE_V1',
    'Missing PO': 'SOP_MISSING_PO_V1'
  };

  // Get the normalized PDF name for display
  const getPDFName = (exceptionName: string): string => {
    return exceptionTypeToPDF[exceptionName] || 'SOP_UNKNOWN_V1';
  };

  return (
    <Layout>
      {loading ? (
        <div className={styles.sopControlCenter}>
          <div className={styles.header}>
            <div>
              <Skeleton.Input active style={{ width: 250, height: 32, marginBottom: 8 }} />
              <Skeleton.Input active style={{ width: 350, height: 16 }} />
            </div>
          </div>

          <div className={styles.tableContainer}>
            <div className={styles.tablePanel}>
              <div className={styles.tableHeader}>
                <Skeleton.Input active style={{ width: 150, height: 24 }} />
              </div>
              <Skeleton active paragraph={{ rows: 6 }} />
            </div>
          </div>
        </div>
      ) : (
        <div className={styles.sopControlCenter}>
          <div className={styles.header}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <h2 className={styles.title}>SOP Control Center</h2>
                <Tooltip title="Click on view details to view the SOP document" placement="bottom">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#8B9AAB" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ cursor: 'help' }}>
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="16" x2="12" y2="12"></line>
                    <line x1="12" y1="8" x2="12.01" y2="8"></line>
                  </svg>
                </Tooltip>
              </div>
              <p className={styles.subtitle}>Monitor and manage autonomous agents</p>
            </div>
          </div>

          <div className={styles.tableContainer}>
            <div className={styles.tablePanel}>
              <div className={styles.tableHeader}>
                <div className={styles.tableTitleSection}>
                  <h3 className={styles.tableTitle}>SOP Agents</h3>
                </div>
              </div>

              <Table
                dataSource={sopData}
                rowKey="exceptionId"
                pagination={{
                  current: currentPage,
                  pageSize: pageSize,
                  total: totalCount,
                  onChange: (page) => setCurrentPage(page),
                  showSizeChanger: false,
                  position: ['bottomRight'],
                }}
                loading={loadingTable}
                className={styles.antTable}
                columns={[
                  {
                    title: 'Exception Type',
                    dataIndex: 'exceptionId',
                    key: 'exceptionId',
                    render: (text: string) => (
                      <span className={styles.exceptionId}>
                        <span className={styles.exceptionIcon}>
                          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                            <circle cx="8" cy="8" r="7" fill="#00B386" />
                            <circle cx="8" cy="8" r="4" fill="white" />
                          </svg>
                        </span>
                        {text}
                      </span>
                    ),
                  },
                  {
                    title: 'Exception Name',
                    dataIndex: 'exceptionName',
                    key: 'exceptionName',
                    render: (text: string) => (
                      <div className={styles.exceptionName}>
                        {text}
                      </div>
                    ),
                  },
                  {
                    title: 'SOP Connected',
                    dataIndex: 'sopId',
                    key: 'sopId',
                    render: (_: string, record: AgentData) => (
                      <span className={styles.sopId}>{getPDFName(record.exceptionName)}</span>
                    ),
                  },
                  {
                    title: 'Last Run',
                    dataIndex: 'lastRun',
                    key: 'lastRun',
                    render: (text: string) => <span className={styles.lastRun}>{text}</span>,
                  },
                  {
                    title: 'Total Exceptions',
                    dataIndex: 'records',
                    key: 'records',
                    render: (value: number) => (
                      <div className={styles.records}>
                        <span className={styles.recordsInner}>{value.toLocaleString()}</span>
                      </div>
                    ),
                  },
                  {
                    title: 'Trigger Email',
                    dataIndex: 'triggerEmail',
                    key: 'triggerEmail',
                    render: (emails: string | string[], record: AgentData) => {
                      // Display mode - show max 2 emails with +X more
                      const emailArray = Array.isArray(emails) ? emails : emails ? [emails] : [];
                      const displayEmails = emailArray.slice(0, 2);
                      const remainingCount = emailArray.length - 2;
                      
                      return (
                        <div className={styles.emailCellWrapper}>
                          <div 
                            className={styles.emailCell}
                            onClick={(e) => {
                              e.stopPropagation();
                              if (emailArray.length > 0) {
                                // Populate modal state so Edit works reliably
                                setEmailModalData(emailArray);
                                setEmailValues(emailArray.length > 0 ? emailArray : ['']);
                                setEmailModalExceptionId(record.exceptionId);
                                setEmailModalEditMode(false);
                                setEmailModalOpen(true);
                                setEmailErrors((emailArray.length > 0 ? emailArray : ['']).map(() => ''));
                              }
                            }}
                            title="Click to view all emails"
                          >
                            <span className={styles.emailText}>
                              {emailArray.length > 0 ? (
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                                  {displayEmails.map((email, idx) => (
                                    <span key={idx} className={styles.emailBadge}>
                                      {email}
                                    </span>
                                  ))}
                                  {remainingCount > 0 && (
                                    <span className={styles.moreEmailsBadge}>
                                      +{remainingCount} more
                                    </span>
                                  )}
                                </div>
                              ) : (
                                <span style={{ color: '#999', fontStyle: 'italic' }}>Not set</span>
                              )}
                            </span>
                          </div>
                          <span 
                            className={styles.editIcon}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEmailEdit(record.exceptionId, emails || []);
                            }}
                            title="Click to edit"
                          >
                            ✎
                          </span>
                        </div>
                      );
                    },
                  },
                  {
                    title: 'Actions',
                    key: 'action',
                    render: (_: any, record: AgentData) => (
                      <button 
                        className={styles.actionButton}
                        onClick={() => handleViewDetails(record)}
                      >
                        View Details
                      </button>
                    ),
                  },
                ]}
              />
            </div>
          </div>

          {/* SOP Details Modal */}
          {selectedSOP && (
            <SOPDetailsModal
              isOpen={isModalOpen}
              onClose={handleCloseModal}
              sopData={selectedSOP}
              pdfName={getPDFName(selectedSOP.exceptionName)}
            />
          )}

          {/* Email List Modal */}
          {emailModalOpen && (
            <div className={styles.modalOverlay} onClick={handleEmailCancel}>
              <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
                <div className={styles.modalHeader}>
                  <h3>{emailModalEditMode ? 'Edit Trigger Emails' : 'Trigger Emails'}</h3>
                  <button 
                    className={styles.modalCloseButton}
                    onClick={handleEmailCancel}
                  >
                    ✕
                  </button>
                </div>
                <div className={styles.modalBody}>
                      {emailModalEditMode ? (
                    // Edit Mode
                    <div className={styles.editEmailsContainer}>
                      {emailValues.map((email, index) => (
                        <div key={index} className={styles.emailInputRow}>
                          <div className={styles.emailInputRowTop}>
                            <input
                              type="email"
                              value={email}
                              onChange={(e) => handleEmailChange(index, e.target.value)}
                              className={styles.emailInput}
                              placeholder="email@company.com"
                              autoFocus={index === 0}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  handleEmailSave(emailModalExceptionId);
                                } else if (e.key === 'Escape') {
                                  handleEmailCancel();
                                }
                              }}
                            />
                            {emailValues.length > 1 && (
                              <button
                                onClick={() => handleRemoveEmail(index)}
                                className={styles.emailRemoveButton}
                                disabled={updatingEmail === emailModalExceptionId}
                                title="Remove email"
                              >
                                ✕
                              </button>
                            )}
                          </div>
                          {emailErrors[index] && (
                            <div className={styles.emailError}>
                              {emailErrors[index]}
                            </div>
                          )}
                        </div>
                      ))}
                      <button
                        onClick={handleAddEmail}
                        className={styles.emailAddButton}
                        disabled={
                          updatingEmail === emailModalExceptionId ||
                          emailErrors.some(err => err && err.length > 0) ||
                          emailValues.some(v => !v.trim())
                        }
                      >
                        + Add Email
                      </button>
                    </div>
                  ) : (
                    // View Mode
                    <div>
                      {emailModalData.map((email, idx) => (
                        <div key={idx} className={styles.modalEmailItem}>
                          {email}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className={styles.modalFooter}>
                  {emailModalEditMode ? (
                    <>
                      <button
                        onClick={handleEmailCancel}
                        className={styles.modalCancelButton}
                        disabled={updatingEmail === emailModalExceptionId}
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => handleEmailSave(emailModalExceptionId)}
                        className={styles.modalSaveButton}
                        disabled={
                          updatingEmail === emailModalExceptionId ||
                          emailErrors.some(err => err && err.length > 0) ||
                          emailValues.some(v => !v.trim())
                        }
                      >
                        {updatingEmail === emailModalExceptionId ? 'Saving...' : 'Save'}
                      </button>
                    </>
                      ) : (
                    <button
                      onClick={() => {
                        // Ensure edit mode has the current emails populated
                        setEmailValues(emailModalData.length > 0 ? emailModalData : ['']);
                        setEmailErrors((emailModalData.length > 0 ? emailModalData : ['']).map(() => ''));
                        setEmailModalEditMode(true);
                      }}
                      className={styles.modalEditButton}
                    >
                      Edit Emails
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </Layout>
  );
}
