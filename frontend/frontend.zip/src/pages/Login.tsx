import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { setCookieMinutes } from '../lib/utils';
import styles from './Login.module.css';

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const API_URL = import.meta.env.VITE_API_URL;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const payload = {
        event_type: 'login_api',
        email: formData.email,
        password: formData.password
      };

      let res: Response;
      try {
        res = await fetch(API_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        });
      } catch (fetchError) {
        // Network error - failed to reach the server
        console.error('Network error:', fetchError);
        setError('Network error. Please check your connection and try again.');
        setIsLoading(false);
        return;
      }

      // Parse response body
      let data: any = {};
      try {
        const responseText = await res.text();
        if (responseText) {
          data = JSON.parse(responseText);
        }
      } catch (parseError) {
        // If response is not valid JSON, check status code for error type
        console.error('Error parsing response:', parseError);
        if (res.status === 401) {
          setError('Invalid email or password.');
        } else if (res.status === 403) {
          setError('UserNotConfirmed');
        } else if (res.status === 404) {
          setError('User not found.');
        } else {
          setError('An error occurred. Please try again.');
        }
        setIsLoading(false);
        return;
      }

      if (res.ok) {
        // Expected from Lambda:
        // { message, username, email, userid, tokens, user_attributes }

        // Store userid in cookie (expires in 57 minutes)
        if (data.userid) {
          setCookieMinutes('userid', String(data.userid), 57);
        }

        // Store tokens in cookies (expires in 57 minutes)
        if (data.tokens) {
          if (data.tokens.access_token) {
            setCookieMinutes('access_token', data.tokens.access_token, 57);
          }
          if (data.tokens.id_token) {
            setCookieMinutes('id_token', data.tokens.id_token, 57);
          }
          if (data.tokens.refresh_token) {
            setCookieMinutes('refresh_token', data.tokens.refresh_token, 57);
          }
        }

        const user = {
          email: data.email,
          name: data.username || '',
          attributes: data.user_attributes || {},
          loginTime: new Date().toISOString()
        };

        login(user, data.tokens);

        navigate('/dashboard');
      } else {
        // Handle error responses - extract error message from response body
        // API returns: 401 -> {error}, 403 -> {message}, 404 -> {error}
        let errorMessage = '';
        
        if (res.status === 401 || res.status === 404) {
          // 401: NotAuthorizedException -> {"error": "Invalid email or password."}
          // 404: UserNotFoundException -> {"error": "User not found."}
          errorMessage = data.error || 'Invalid credentials.';
        } else if (res.status === 403) {
          // 403: UserNotConfirmedException -> {"message": "UserNotConfirmed"}
          errorMessage = data.message || 'User not confirmed.';
        } else {
          // Other error status codes
          errorMessage = data.error || data.message || 'Login failed. Please try again.';
        }
        
        setError(errorMessage);
      }
    } catch (err) {
      // Catch any unexpected errors
      console.error('Unexpected error:', err);
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={styles.loginContainer}>
      <div className={styles.loginCard}>
        <div className={styles.header}>
          <div className={styles.logo}>
            <img 
              src="/assets/1CloudHub-Logo-horiz-hires-RGB-copy-1.jpg" 
              alt="1CloudHub" 
              className={styles.logoImage}
            />
          </div>
          <h1 className={styles.title}>Welcome Back</h1>
          <p className={styles.subtitle}>Sign in to your SAP Exception Management Platform</p>
        </div>

        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.inputGroup}>
            <label htmlFor="email" className={styles.label}>Email Address</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              className={styles.input}
              placeholder="Enter your email"
              required
            />
          </div>

          <div className={styles.inputGroup}>
            <label htmlFor="password" className={styles.label}>Password</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleInputChange}
              className={styles.input}
              placeholder="Enter your password"
              required
            />
          </div>

          {error && (
            <div className={styles.errorMessage}>{error}</div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className={styles.loginButton}
          >
            {isLoading ? <div className={styles.spinner}></div> : "Sign In"}
          </button>

        </form>

      </div>
    </div>
  );
}
